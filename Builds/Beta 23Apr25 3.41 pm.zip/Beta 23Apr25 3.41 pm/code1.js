gdjs.MainCode = {};
gdjs.MainCode.localVariables = [];
gdjs.MainCode.GDTweet1Objects1= [];
gdjs.MainCode.GDTweet1Objects2= [];
gdjs.MainCode.GDTweet1Objects3= [];
gdjs.MainCode.GDTweet1Objects4= [];
gdjs.MainCode.GDTweet1Objects5= [];
gdjs.MainCode.GDTweet1Objects6= [];
gdjs.MainCode.GDTweet1Objects7= [];
gdjs.MainCode.GDTweet1Objects8= [];
gdjs.MainCode.GDTweet1Objects9= [];
gdjs.MainCode.GDTweet1Objects10= [];
gdjs.MainCode.GDTweetTitle1Objects1= [];
gdjs.MainCode.GDTweetTitle1Objects2= [];
gdjs.MainCode.GDTweetTitle1Objects3= [];
gdjs.MainCode.GDTweetTitle1Objects4= [];
gdjs.MainCode.GDTweetTitle1Objects5= [];
gdjs.MainCode.GDTweetTitle1Objects6= [];
gdjs.MainCode.GDTweetTitle1Objects7= [];
gdjs.MainCode.GDTweetTitle1Objects8= [];
gdjs.MainCode.GDTweetTitle1Objects9= [];
gdjs.MainCode.GDTweetTitle1Objects10= [];
gdjs.MainCode.GDReactionIcons_9595HeartObjects1= [];
gdjs.MainCode.GDReactionIcons_9595HeartObjects2= [];
gdjs.MainCode.GDReactionIcons_9595HeartObjects3= [];
gdjs.MainCode.GDReactionIcons_9595HeartObjects4= [];
gdjs.MainCode.GDReactionIcons_9595HeartObjects5= [];
gdjs.MainCode.GDReactionIcons_9595HeartObjects6= [];
gdjs.MainCode.GDReactionIcons_9595HeartObjects7= [];
gdjs.MainCode.GDReactionIcons_9595HeartObjects8= [];
gdjs.MainCode.GDReactionIcons_9595HeartObjects9= [];
gdjs.MainCode.GDReactionIcons_9595HeartObjects10= [];
gdjs.MainCode.GDHeartText1Objects1= [];
gdjs.MainCode.GDHeartText1Objects2= [];
gdjs.MainCode.GDHeartText1Objects3= [];
gdjs.MainCode.GDHeartText1Objects4= [];
gdjs.MainCode.GDHeartText1Objects5= [];
gdjs.MainCode.GDHeartText1Objects6= [];
gdjs.MainCode.GDHeartText1Objects7= [];
gdjs.MainCode.GDHeartText1Objects8= [];
gdjs.MainCode.GDHeartText1Objects9= [];
gdjs.MainCode.GDHeartText1Objects10= [];
gdjs.MainCode.GDReactionIcon_9595LikeObjects1= [];
gdjs.MainCode.GDReactionIcon_9595LikeObjects2= [];
gdjs.MainCode.GDReactionIcon_9595LikeObjects3= [];
gdjs.MainCode.GDReactionIcon_9595LikeObjects4= [];
gdjs.MainCode.GDReactionIcon_9595LikeObjects5= [];
gdjs.MainCode.GDReactionIcon_9595LikeObjects6= [];
gdjs.MainCode.GDReactionIcon_9595LikeObjects7= [];
gdjs.MainCode.GDReactionIcon_9595LikeObjects8= [];
gdjs.MainCode.GDReactionIcon_9595LikeObjects9= [];
gdjs.MainCode.GDReactionIcon_9595LikeObjects10= [];
gdjs.MainCode.GDLikeText1Objects1= [];
gdjs.MainCode.GDLikeText1Objects2= [];
gdjs.MainCode.GDLikeText1Objects3= [];
gdjs.MainCode.GDLikeText1Objects4= [];
gdjs.MainCode.GDLikeText1Objects5= [];
gdjs.MainCode.GDLikeText1Objects6= [];
gdjs.MainCode.GDLikeText1Objects7= [];
gdjs.MainCode.GDLikeText1Objects8= [];
gdjs.MainCode.GDLikeText1Objects9= [];
gdjs.MainCode.GDLikeText1Objects10= [];
gdjs.MainCode.GDReactionIcon_9595FireObjects1= [];
gdjs.MainCode.GDReactionIcon_9595FireObjects2= [];
gdjs.MainCode.GDReactionIcon_9595FireObjects3= [];
gdjs.MainCode.GDReactionIcon_9595FireObjects4= [];
gdjs.MainCode.GDReactionIcon_9595FireObjects5= [];
gdjs.MainCode.GDReactionIcon_9595FireObjects6= [];
gdjs.MainCode.GDReactionIcon_9595FireObjects7= [];
gdjs.MainCode.GDReactionIcon_9595FireObjects8= [];
gdjs.MainCode.GDReactionIcon_9595FireObjects9= [];
gdjs.MainCode.GDReactionIcon_9595FireObjects10= [];
gdjs.MainCode.GDFireText1Objects1= [];
gdjs.MainCode.GDFireText1Objects2= [];
gdjs.MainCode.GDFireText1Objects3= [];
gdjs.MainCode.GDFireText1Objects4= [];
gdjs.MainCode.GDFireText1Objects5= [];
gdjs.MainCode.GDFireText1Objects6= [];
gdjs.MainCode.GDFireText1Objects7= [];
gdjs.MainCode.GDFireText1Objects8= [];
gdjs.MainCode.GDFireText1Objects9= [];
gdjs.MainCode.GDFireText1Objects10= [];
gdjs.MainCode.GDFireText2Objects1= [];
gdjs.MainCode.GDFireText2Objects2= [];
gdjs.MainCode.GDFireText2Objects3= [];
gdjs.MainCode.GDFireText2Objects4= [];
gdjs.MainCode.GDFireText2Objects5= [];
gdjs.MainCode.GDFireText2Objects6= [];
gdjs.MainCode.GDFireText2Objects7= [];
gdjs.MainCode.GDFireText2Objects8= [];
gdjs.MainCode.GDFireText2Objects9= [];
gdjs.MainCode.GDFireText2Objects10= [];
gdjs.MainCode.GDLikeText2Objects1= [];
gdjs.MainCode.GDLikeText2Objects2= [];
gdjs.MainCode.GDLikeText2Objects3= [];
gdjs.MainCode.GDLikeText2Objects4= [];
gdjs.MainCode.GDLikeText2Objects5= [];
gdjs.MainCode.GDLikeText2Objects6= [];
gdjs.MainCode.GDLikeText2Objects7= [];
gdjs.MainCode.GDLikeText2Objects8= [];
gdjs.MainCode.GDLikeText2Objects9= [];
gdjs.MainCode.GDLikeText2Objects10= [];
gdjs.MainCode.GDHeartText2Objects1= [];
gdjs.MainCode.GDHeartText2Objects2= [];
gdjs.MainCode.GDHeartText2Objects3= [];
gdjs.MainCode.GDHeartText2Objects4= [];
gdjs.MainCode.GDHeartText2Objects5= [];
gdjs.MainCode.GDHeartText2Objects6= [];
gdjs.MainCode.GDHeartText2Objects7= [];
gdjs.MainCode.GDHeartText2Objects8= [];
gdjs.MainCode.GDHeartText2Objects9= [];
gdjs.MainCode.GDHeartText2Objects10= [];
gdjs.MainCode.GDFireText3Objects1= [];
gdjs.MainCode.GDFireText3Objects2= [];
gdjs.MainCode.GDFireText3Objects3= [];
gdjs.MainCode.GDFireText3Objects4= [];
gdjs.MainCode.GDFireText3Objects5= [];
gdjs.MainCode.GDFireText3Objects6= [];
gdjs.MainCode.GDFireText3Objects7= [];
gdjs.MainCode.GDFireText3Objects8= [];
gdjs.MainCode.GDFireText3Objects9= [];
gdjs.MainCode.GDFireText3Objects10= [];
gdjs.MainCode.GDLikeText3Objects1= [];
gdjs.MainCode.GDLikeText3Objects2= [];
gdjs.MainCode.GDLikeText3Objects3= [];
gdjs.MainCode.GDLikeText3Objects4= [];
gdjs.MainCode.GDLikeText3Objects5= [];
gdjs.MainCode.GDLikeText3Objects6= [];
gdjs.MainCode.GDLikeText3Objects7= [];
gdjs.MainCode.GDLikeText3Objects8= [];
gdjs.MainCode.GDLikeText3Objects9= [];
gdjs.MainCode.GDLikeText3Objects10= [];
gdjs.MainCode.GDHeartText3Objects1= [];
gdjs.MainCode.GDHeartText3Objects2= [];
gdjs.MainCode.GDHeartText3Objects3= [];
gdjs.MainCode.GDHeartText3Objects4= [];
gdjs.MainCode.GDHeartText3Objects5= [];
gdjs.MainCode.GDHeartText3Objects6= [];
gdjs.MainCode.GDHeartText3Objects7= [];
gdjs.MainCode.GDHeartText3Objects8= [];
gdjs.MainCode.GDHeartText3Objects9= [];
gdjs.MainCode.GDHeartText3Objects10= [];
gdjs.MainCode.GDTweetFace3Objects1= [];
gdjs.MainCode.GDTweetFace3Objects2= [];
gdjs.MainCode.GDTweetFace3Objects3= [];
gdjs.MainCode.GDTweetFace3Objects4= [];
gdjs.MainCode.GDTweetFace3Objects5= [];
gdjs.MainCode.GDTweetFace3Objects6= [];
gdjs.MainCode.GDTweetFace3Objects7= [];
gdjs.MainCode.GDTweetFace3Objects8= [];
gdjs.MainCode.GDTweetFace3Objects9= [];
gdjs.MainCode.GDTweetFace3Objects10= [];
gdjs.MainCode.GDTweetTitle2Objects1= [];
gdjs.MainCode.GDTweetTitle2Objects2= [];
gdjs.MainCode.GDTweetTitle2Objects3= [];
gdjs.MainCode.GDTweetTitle2Objects4= [];
gdjs.MainCode.GDTweetTitle2Objects5= [];
gdjs.MainCode.GDTweetTitle2Objects6= [];
gdjs.MainCode.GDTweetTitle2Objects7= [];
gdjs.MainCode.GDTweetTitle2Objects8= [];
gdjs.MainCode.GDTweetTitle2Objects9= [];
gdjs.MainCode.GDTweetTitle2Objects10= [];
gdjs.MainCode.GDTweetTitle3Objects1= [];
gdjs.MainCode.GDTweetTitle3Objects2= [];
gdjs.MainCode.GDTweetTitle3Objects3= [];
gdjs.MainCode.GDTweetTitle3Objects4= [];
gdjs.MainCode.GDTweetTitle3Objects5= [];
gdjs.MainCode.GDTweetTitle3Objects6= [];
gdjs.MainCode.GDTweetTitle3Objects7= [];
gdjs.MainCode.GDTweetTitle3Objects8= [];
gdjs.MainCode.GDTweetTitle3Objects9= [];
gdjs.MainCode.GDTweetTitle3Objects10= [];
gdjs.MainCode.GDTweet2Objects1= [];
gdjs.MainCode.GDTweet2Objects2= [];
gdjs.MainCode.GDTweet2Objects3= [];
gdjs.MainCode.GDTweet2Objects4= [];
gdjs.MainCode.GDTweet2Objects5= [];
gdjs.MainCode.GDTweet2Objects6= [];
gdjs.MainCode.GDTweet2Objects7= [];
gdjs.MainCode.GDTweet2Objects8= [];
gdjs.MainCode.GDTweet2Objects9= [];
gdjs.MainCode.GDTweet2Objects10= [];
gdjs.MainCode.GDTweet3Objects1= [];
gdjs.MainCode.GDTweet3Objects2= [];
gdjs.MainCode.GDTweet3Objects3= [];
gdjs.MainCode.GDTweet3Objects4= [];
gdjs.MainCode.GDTweet3Objects5= [];
gdjs.MainCode.GDTweet3Objects6= [];
gdjs.MainCode.GDTweet3Objects7= [];
gdjs.MainCode.GDTweet3Objects8= [];
gdjs.MainCode.GDTweet3Objects9= [];
gdjs.MainCode.GDTweet3Objects10= [];
gdjs.MainCode.GDTweet_9595bkg1Objects1= [];
gdjs.MainCode.GDTweet_9595bkg1Objects2= [];
gdjs.MainCode.GDTweet_9595bkg1Objects3= [];
gdjs.MainCode.GDTweet_9595bkg1Objects4= [];
gdjs.MainCode.GDTweet_9595bkg1Objects5= [];
gdjs.MainCode.GDTweet_9595bkg1Objects6= [];
gdjs.MainCode.GDTweet_9595bkg1Objects7= [];
gdjs.MainCode.GDTweet_9595bkg1Objects8= [];
gdjs.MainCode.GDTweet_9595bkg1Objects9= [];
gdjs.MainCode.GDTweet_9595bkg1Objects10= [];
gdjs.MainCode.GDOption1Objects1= [];
gdjs.MainCode.GDOption1Objects2= [];
gdjs.MainCode.GDOption1Objects3= [];
gdjs.MainCode.GDOption1Objects4= [];
gdjs.MainCode.GDOption1Objects5= [];
gdjs.MainCode.GDOption1Objects6= [];
gdjs.MainCode.GDOption1Objects7= [];
gdjs.MainCode.GDOption1Objects8= [];
gdjs.MainCode.GDOption1Objects9= [];
gdjs.MainCode.GDOption1Objects10= [];
gdjs.MainCode.GDOption2Objects1= [];
gdjs.MainCode.GDOption2Objects2= [];
gdjs.MainCode.GDOption2Objects3= [];
gdjs.MainCode.GDOption2Objects4= [];
gdjs.MainCode.GDOption2Objects5= [];
gdjs.MainCode.GDOption2Objects6= [];
gdjs.MainCode.GDOption2Objects7= [];
gdjs.MainCode.GDOption2Objects8= [];
gdjs.MainCode.GDOption2Objects9= [];
gdjs.MainCode.GDOption2Objects10= [];
gdjs.MainCode.GDOption3Objects1= [];
gdjs.MainCode.GDOption3Objects2= [];
gdjs.MainCode.GDOption3Objects3= [];
gdjs.MainCode.GDOption3Objects4= [];
gdjs.MainCode.GDOption3Objects5= [];
gdjs.MainCode.GDOption3Objects6= [];
gdjs.MainCode.GDOption3Objects7= [];
gdjs.MainCode.GDOption3Objects8= [];
gdjs.MainCode.GDOption3Objects9= [];
gdjs.MainCode.GDOption3Objects10= [];
gdjs.MainCode.GDOptionTxt1Objects1= [];
gdjs.MainCode.GDOptionTxt1Objects2= [];
gdjs.MainCode.GDOptionTxt1Objects3= [];
gdjs.MainCode.GDOptionTxt1Objects4= [];
gdjs.MainCode.GDOptionTxt1Objects5= [];
gdjs.MainCode.GDOptionTxt1Objects6= [];
gdjs.MainCode.GDOptionTxt1Objects7= [];
gdjs.MainCode.GDOptionTxt1Objects8= [];
gdjs.MainCode.GDOptionTxt1Objects9= [];
gdjs.MainCode.GDOptionTxt1Objects10= [];
gdjs.MainCode.GDOptionTxt2Objects1= [];
gdjs.MainCode.GDOptionTxt2Objects2= [];
gdjs.MainCode.GDOptionTxt2Objects3= [];
gdjs.MainCode.GDOptionTxt2Objects4= [];
gdjs.MainCode.GDOptionTxt2Objects5= [];
gdjs.MainCode.GDOptionTxt2Objects6= [];
gdjs.MainCode.GDOptionTxt2Objects7= [];
gdjs.MainCode.GDOptionTxt2Objects8= [];
gdjs.MainCode.GDOptionTxt2Objects9= [];
gdjs.MainCode.GDOptionTxt2Objects10= [];
gdjs.MainCode.GDOptionTxt3Objects1= [];
gdjs.MainCode.GDOptionTxt3Objects2= [];
gdjs.MainCode.GDOptionTxt3Objects3= [];
gdjs.MainCode.GDOptionTxt3Objects4= [];
gdjs.MainCode.GDOptionTxt3Objects5= [];
gdjs.MainCode.GDOptionTxt3Objects6= [];
gdjs.MainCode.GDOptionTxt3Objects7= [];
gdjs.MainCode.GDOptionTxt3Objects8= [];
gdjs.MainCode.GDOptionTxt3Objects9= [];
gdjs.MainCode.GDOptionTxt3Objects10= [];
gdjs.MainCode.GDSend_9595icon1Objects1= [];
gdjs.MainCode.GDSend_9595icon1Objects2= [];
gdjs.MainCode.GDSend_9595icon1Objects3= [];
gdjs.MainCode.GDSend_9595icon1Objects4= [];
gdjs.MainCode.GDSend_9595icon1Objects5= [];
gdjs.MainCode.GDSend_9595icon1Objects6= [];
gdjs.MainCode.GDSend_9595icon1Objects7= [];
gdjs.MainCode.GDSend_9595icon1Objects8= [];
gdjs.MainCode.GDSend_9595icon1Objects9= [];
gdjs.MainCode.GDSend_9595icon1Objects10= [];
gdjs.MainCode.GDblue_9595barsObjects1= [];
gdjs.MainCode.GDblue_9595barsObjects2= [];
gdjs.MainCode.GDblue_9595barsObjects3= [];
gdjs.MainCode.GDblue_9595barsObjects4= [];
gdjs.MainCode.GDblue_9595barsObjects5= [];
gdjs.MainCode.GDblue_9595barsObjects6= [];
gdjs.MainCode.GDblue_9595barsObjects7= [];
gdjs.MainCode.GDblue_9595barsObjects8= [];
gdjs.MainCode.GDblue_9595barsObjects9= [];
gdjs.MainCode.GDblue_9595barsObjects10= [];
gdjs.MainCode.GDGreen_9595barsObjects1= [];
gdjs.MainCode.GDGreen_9595barsObjects2= [];
gdjs.MainCode.GDGreen_9595barsObjects3= [];
gdjs.MainCode.GDGreen_9595barsObjects4= [];
gdjs.MainCode.GDGreen_9595barsObjects5= [];
gdjs.MainCode.GDGreen_9595barsObjects6= [];
gdjs.MainCode.GDGreen_9595barsObjects7= [];
gdjs.MainCode.GDGreen_9595barsObjects8= [];
gdjs.MainCode.GDGreen_9595barsObjects9= [];
gdjs.MainCode.GDGreen_9595barsObjects10= [];
gdjs.MainCode.GDOrange_9595barsObjects1= [];
gdjs.MainCode.GDOrange_9595barsObjects2= [];
gdjs.MainCode.GDOrange_9595barsObjects3= [];
gdjs.MainCode.GDOrange_9595barsObjects4= [];
gdjs.MainCode.GDOrange_9595barsObjects5= [];
gdjs.MainCode.GDOrange_9595barsObjects6= [];
gdjs.MainCode.GDOrange_9595barsObjects7= [];
gdjs.MainCode.GDOrange_9595barsObjects8= [];
gdjs.MainCode.GDOrange_9595barsObjects9= [];
gdjs.MainCode.GDOrange_9595barsObjects10= [];
gdjs.MainCode.GDPink_9595barsObjects1= [];
gdjs.MainCode.GDPink_9595barsObjects2= [];
gdjs.MainCode.GDPink_9595barsObjects3= [];
gdjs.MainCode.GDPink_9595barsObjects4= [];
gdjs.MainCode.GDPink_9595barsObjects5= [];
gdjs.MainCode.GDPink_9595barsObjects6= [];
gdjs.MainCode.GDPink_9595barsObjects7= [];
gdjs.MainCode.GDPink_9595barsObjects8= [];
gdjs.MainCode.GDPink_9595barsObjects9= [];
gdjs.MainCode.GDPink_9595barsObjects10= [];
gdjs.MainCode.GDEconomyTxtObjects1= [];
gdjs.MainCode.GDEconomyTxtObjects2= [];
gdjs.MainCode.GDEconomyTxtObjects3= [];
gdjs.MainCode.GDEconomyTxtObjects4= [];
gdjs.MainCode.GDEconomyTxtObjects5= [];
gdjs.MainCode.GDEconomyTxtObjects6= [];
gdjs.MainCode.GDEconomyTxtObjects7= [];
gdjs.MainCode.GDEconomyTxtObjects8= [];
gdjs.MainCode.GDEconomyTxtObjects9= [];
gdjs.MainCode.GDEconomyTxtObjects10= [];
gdjs.MainCode.GDPersonalGainsTxtObjects1= [];
gdjs.MainCode.GDPersonalGainsTxtObjects2= [];
gdjs.MainCode.GDPersonalGainsTxtObjects3= [];
gdjs.MainCode.GDPersonalGainsTxtObjects4= [];
gdjs.MainCode.GDPersonalGainsTxtObjects5= [];
gdjs.MainCode.GDPersonalGainsTxtObjects6= [];
gdjs.MainCode.GDPersonalGainsTxtObjects7= [];
gdjs.MainCode.GDPersonalGainsTxtObjects8= [];
gdjs.MainCode.GDPersonalGainsTxtObjects9= [];
gdjs.MainCode.GDPersonalGainsTxtObjects10= [];
gdjs.MainCode.GDScandalRiskTxtObjects1= [];
gdjs.MainCode.GDScandalRiskTxtObjects2= [];
gdjs.MainCode.GDScandalRiskTxtObjects3= [];
gdjs.MainCode.GDScandalRiskTxtObjects4= [];
gdjs.MainCode.GDScandalRiskTxtObjects5= [];
gdjs.MainCode.GDScandalRiskTxtObjects6= [];
gdjs.MainCode.GDScandalRiskTxtObjects7= [];
gdjs.MainCode.GDScandalRiskTxtObjects8= [];
gdjs.MainCode.GDScandalRiskTxtObjects9= [];
gdjs.MainCode.GDScandalRiskTxtObjects10= [];
gdjs.MainCode.GDPublicApprovalTxtObjects1= [];
gdjs.MainCode.GDPublicApprovalTxtObjects2= [];
gdjs.MainCode.GDPublicApprovalTxtObjects3= [];
gdjs.MainCode.GDPublicApprovalTxtObjects4= [];
gdjs.MainCode.GDPublicApprovalTxtObjects5= [];
gdjs.MainCode.GDPublicApprovalTxtObjects6= [];
gdjs.MainCode.GDPublicApprovalTxtObjects7= [];
gdjs.MainCode.GDPublicApprovalTxtObjects8= [];
gdjs.MainCode.GDPublicApprovalTxtObjects9= [];
gdjs.MainCode.GDPublicApprovalTxtObjects10= [];
gdjs.MainCode.GDCapObjects1= [];
gdjs.MainCode.GDCapObjects2= [];
gdjs.MainCode.GDCapObjects3= [];
gdjs.MainCode.GDCapObjects4= [];
gdjs.MainCode.GDCapObjects5= [];
gdjs.MainCode.GDCapObjects6= [];
gdjs.MainCode.GDCapObjects7= [];
gdjs.MainCode.GDCapObjects8= [];
gdjs.MainCode.GDCapObjects9= [];
gdjs.MainCode.GDCapObjects10= [];
gdjs.MainCode.GDCap_9595commentsObjects1= [];
gdjs.MainCode.GDCap_9595commentsObjects2= [];
gdjs.MainCode.GDCap_9595commentsObjects3= [];
gdjs.MainCode.GDCap_9595commentsObjects4= [];
gdjs.MainCode.GDCap_9595commentsObjects5= [];
gdjs.MainCode.GDCap_9595commentsObjects6= [];
gdjs.MainCode.GDCap_9595commentsObjects7= [];
gdjs.MainCode.GDCap_9595commentsObjects8= [];
gdjs.MainCode.GDCap_9595commentsObjects9= [];
gdjs.MainCode.GDCap_9595commentsObjects10= [];
gdjs.MainCode.GDDayTxtObjects1= [];
gdjs.MainCode.GDDayTxtObjects2= [];
gdjs.MainCode.GDDayTxtObjects3= [];
gdjs.MainCode.GDDayTxtObjects4= [];
gdjs.MainCode.GDDayTxtObjects5= [];
gdjs.MainCode.GDDayTxtObjects6= [];
gdjs.MainCode.GDDayTxtObjects7= [];
gdjs.MainCode.GDDayTxtObjects8= [];
gdjs.MainCode.GDDayTxtObjects9= [];
gdjs.MainCode.GDDayTxtObjects10= [];
gdjs.MainCode.GDChirpObjects1= [];
gdjs.MainCode.GDChirpObjects2= [];
gdjs.MainCode.GDChirpObjects3= [];
gdjs.MainCode.GDChirpObjects4= [];
gdjs.MainCode.GDChirpObjects5= [];
gdjs.MainCode.GDChirpObjects6= [];
gdjs.MainCode.GDChirpObjects7= [];
gdjs.MainCode.GDChirpObjects8= [];
gdjs.MainCode.GDChirpObjects9= [];
gdjs.MainCode.GDChirpObjects10= [];
gdjs.MainCode.GDMy_9595optionsObjects1= [];
gdjs.MainCode.GDMy_9595optionsObjects2= [];
gdjs.MainCode.GDMy_9595optionsObjects3= [];
gdjs.MainCode.GDMy_9595optionsObjects4= [];
gdjs.MainCode.GDMy_9595optionsObjects5= [];
gdjs.MainCode.GDMy_9595optionsObjects6= [];
gdjs.MainCode.GDMy_9595optionsObjects7= [];
gdjs.MainCode.GDMy_9595optionsObjects8= [];
gdjs.MainCode.GDMy_9595optionsObjects9= [];
gdjs.MainCode.GDMy_9595optionsObjects10= [];
gdjs.MainCode.GDCap_9595facesObjects1= [];
gdjs.MainCode.GDCap_9595facesObjects2= [];
gdjs.MainCode.GDCap_9595facesObjects3= [];
gdjs.MainCode.GDCap_9595facesObjects4= [];
gdjs.MainCode.GDCap_9595facesObjects5= [];
gdjs.MainCode.GDCap_9595facesObjects6= [];
gdjs.MainCode.GDCap_9595facesObjects7= [];
gdjs.MainCode.GDCap_9595facesObjects8= [];
gdjs.MainCode.GDCap_9595facesObjects9= [];
gdjs.MainCode.GDCap_9595facesObjects10= [];
gdjs.MainCode.GDSend_9595icon2Objects1= [];
gdjs.MainCode.GDSend_9595icon2Objects2= [];
gdjs.MainCode.GDSend_9595icon2Objects3= [];
gdjs.MainCode.GDSend_9595icon2Objects4= [];
gdjs.MainCode.GDSend_9595icon2Objects5= [];
gdjs.MainCode.GDSend_9595icon2Objects6= [];
gdjs.MainCode.GDSend_9595icon2Objects7= [];
gdjs.MainCode.GDSend_9595icon2Objects8= [];
gdjs.MainCode.GDSend_9595icon2Objects9= [];
gdjs.MainCode.GDSend_9595icon2Objects10= [];
gdjs.MainCode.GDSend_9595icon3Objects1= [];
gdjs.MainCode.GDSend_9595icon3Objects2= [];
gdjs.MainCode.GDSend_9595icon3Objects3= [];
gdjs.MainCode.GDSend_9595icon3Objects4= [];
gdjs.MainCode.GDSend_9595icon3Objects5= [];
gdjs.MainCode.GDSend_9595icon3Objects6= [];
gdjs.MainCode.GDSend_9595icon3Objects7= [];
gdjs.MainCode.GDSend_9595icon3Objects8= [];
gdjs.MainCode.GDSend_9595icon3Objects9= [];
gdjs.MainCode.GDSend_9595icon3Objects10= [];
gdjs.MainCode.GDTweetFace2Objects1= [];
gdjs.MainCode.GDTweetFace2Objects2= [];
gdjs.MainCode.GDTweetFace2Objects3= [];
gdjs.MainCode.GDTweetFace2Objects4= [];
gdjs.MainCode.GDTweetFace2Objects5= [];
gdjs.MainCode.GDTweetFace2Objects6= [];
gdjs.MainCode.GDTweetFace2Objects7= [];
gdjs.MainCode.GDTweetFace2Objects8= [];
gdjs.MainCode.GDTweetFace2Objects9= [];
gdjs.MainCode.GDTweetFace2Objects10= [];
gdjs.MainCode.GDTweetFace1Objects1= [];
gdjs.MainCode.GDTweetFace1Objects2= [];
gdjs.MainCode.GDTweetFace1Objects3= [];
gdjs.MainCode.GDTweetFace1Objects4= [];
gdjs.MainCode.GDTweetFace1Objects5= [];
gdjs.MainCode.GDTweetFace1Objects6= [];
gdjs.MainCode.GDTweetFace1Objects7= [];
gdjs.MainCode.GDTweetFace1Objects8= [];
gdjs.MainCode.GDTweetFace1Objects9= [];
gdjs.MainCode.GDTweetFace1Objects10= [];
gdjs.MainCode.GDLayoutObjects1= [];
gdjs.MainCode.GDLayoutObjects2= [];
gdjs.MainCode.GDLayoutObjects3= [];
gdjs.MainCode.GDLayoutObjects4= [];
gdjs.MainCode.GDLayoutObjects5= [];
gdjs.MainCode.GDLayoutObjects6= [];
gdjs.MainCode.GDLayoutObjects7= [];
gdjs.MainCode.GDLayoutObjects8= [];
gdjs.MainCode.GDLayoutObjects9= [];
gdjs.MainCode.GDLayoutObjects10= [];
gdjs.MainCode.GDTweetMarker1Objects1= [];
gdjs.MainCode.GDTweetMarker1Objects2= [];
gdjs.MainCode.GDTweetMarker1Objects3= [];
gdjs.MainCode.GDTweetMarker1Objects4= [];
gdjs.MainCode.GDTweetMarker1Objects5= [];
gdjs.MainCode.GDTweetMarker1Objects6= [];
gdjs.MainCode.GDTweetMarker1Objects7= [];
gdjs.MainCode.GDTweetMarker1Objects8= [];
gdjs.MainCode.GDTweetMarker1Objects9= [];
gdjs.MainCode.GDTweetMarker1Objects10= [];
gdjs.MainCode.GDTweetMarker2Objects1= [];
gdjs.MainCode.GDTweetMarker2Objects2= [];
gdjs.MainCode.GDTweetMarker2Objects3= [];
gdjs.MainCode.GDTweetMarker2Objects4= [];
gdjs.MainCode.GDTweetMarker2Objects5= [];
gdjs.MainCode.GDTweetMarker2Objects6= [];
gdjs.MainCode.GDTweetMarker2Objects7= [];
gdjs.MainCode.GDTweetMarker2Objects8= [];
gdjs.MainCode.GDTweetMarker2Objects9= [];
gdjs.MainCode.GDTweetMarker2Objects10= [];
gdjs.MainCode.GDTweetMarker3Objects1= [];
gdjs.MainCode.GDTweetMarker3Objects2= [];
gdjs.MainCode.GDTweetMarker3Objects3= [];
gdjs.MainCode.GDTweetMarker3Objects4= [];
gdjs.MainCode.GDTweetMarker3Objects5= [];
gdjs.MainCode.GDTweetMarker3Objects6= [];
gdjs.MainCode.GDTweetMarker3Objects7= [];
gdjs.MainCode.GDTweetMarker3Objects8= [];
gdjs.MainCode.GDTweetMarker3Objects9= [];
gdjs.MainCode.GDTweetMarker3Objects10= [];
gdjs.MainCode.GDTweetMarker4Objects1= [];
gdjs.MainCode.GDTweetMarker4Objects2= [];
gdjs.MainCode.GDTweetMarker4Objects3= [];
gdjs.MainCode.GDTweetMarker4Objects4= [];
gdjs.MainCode.GDTweetMarker4Objects5= [];
gdjs.MainCode.GDTweetMarker4Objects6= [];
gdjs.MainCode.GDTweetMarker4Objects7= [];
gdjs.MainCode.GDTweetMarker4Objects8= [];
gdjs.MainCode.GDTweetMarker4Objects9= [];
gdjs.MainCode.GDTweetMarker4Objects10= [];
gdjs.MainCode.GDTweetMarker5Objects1= [];
gdjs.MainCode.GDTweetMarker5Objects2= [];
gdjs.MainCode.GDTweetMarker5Objects3= [];
gdjs.MainCode.GDTweetMarker5Objects4= [];
gdjs.MainCode.GDTweetMarker5Objects5= [];
gdjs.MainCode.GDTweetMarker5Objects6= [];
gdjs.MainCode.GDTweetMarker5Objects7= [];
gdjs.MainCode.GDTweetMarker5Objects8= [];
gdjs.MainCode.GDTweetMarker5Objects9= [];
gdjs.MainCode.GDTweetMarker5Objects10= [];
gdjs.MainCode.GDTweetMarker6Objects1= [];
gdjs.MainCode.GDTweetMarker6Objects2= [];
gdjs.MainCode.GDTweetMarker6Objects3= [];
gdjs.MainCode.GDTweetMarker6Objects4= [];
gdjs.MainCode.GDTweetMarker6Objects5= [];
gdjs.MainCode.GDTweetMarker6Objects6= [];
gdjs.MainCode.GDTweetMarker6Objects7= [];
gdjs.MainCode.GDTweetMarker6Objects8= [];
gdjs.MainCode.GDTweetMarker6Objects9= [];
gdjs.MainCode.GDTweetMarker6Objects10= [];
gdjs.MainCode.GDTweetMarker7Objects1= [];
gdjs.MainCode.GDTweetMarker7Objects2= [];
gdjs.MainCode.GDTweetMarker7Objects3= [];
gdjs.MainCode.GDTweetMarker7Objects4= [];
gdjs.MainCode.GDTweetMarker7Objects5= [];
gdjs.MainCode.GDTweetMarker7Objects6= [];
gdjs.MainCode.GDTweetMarker7Objects7= [];
gdjs.MainCode.GDTweetMarker7Objects8= [];
gdjs.MainCode.GDTweetMarker7Objects9= [];
gdjs.MainCode.GDTweetMarker7Objects10= [];
gdjs.MainCode.GDTweet_9595bkg2Objects1= [];
gdjs.MainCode.GDTweet_9595bkg2Objects2= [];
gdjs.MainCode.GDTweet_9595bkg2Objects3= [];
gdjs.MainCode.GDTweet_9595bkg2Objects4= [];
gdjs.MainCode.GDTweet_9595bkg2Objects5= [];
gdjs.MainCode.GDTweet_9595bkg2Objects6= [];
gdjs.MainCode.GDTweet_9595bkg2Objects7= [];
gdjs.MainCode.GDTweet_9595bkg2Objects8= [];
gdjs.MainCode.GDTweet_9595bkg2Objects9= [];
gdjs.MainCode.GDTweet_9595bkg2Objects10= [];
gdjs.MainCode.GDTweet_9595bkg3Objects1= [];
gdjs.MainCode.GDTweet_9595bkg3Objects2= [];
gdjs.MainCode.GDTweet_9595bkg3Objects3= [];
gdjs.MainCode.GDTweet_9595bkg3Objects4= [];
gdjs.MainCode.GDTweet_9595bkg3Objects5= [];
gdjs.MainCode.GDTweet_9595bkg3Objects6= [];
gdjs.MainCode.GDTweet_9595bkg3Objects7= [];
gdjs.MainCode.GDTweet_9595bkg3Objects8= [];
gdjs.MainCode.GDTweet_9595bkg3Objects9= [];
gdjs.MainCode.GDTweet_9595bkg3Objects10= [];
gdjs.MainCode.GDTweet_9595bkg4Objects1= [];
gdjs.MainCode.GDTweet_9595bkg4Objects2= [];
gdjs.MainCode.GDTweet_9595bkg4Objects3= [];
gdjs.MainCode.GDTweet_9595bkg4Objects4= [];
gdjs.MainCode.GDTweet_9595bkg4Objects5= [];
gdjs.MainCode.GDTweet_9595bkg4Objects6= [];
gdjs.MainCode.GDTweet_9595bkg4Objects7= [];
gdjs.MainCode.GDTweet_9595bkg4Objects8= [];
gdjs.MainCode.GDTweet_9595bkg4Objects9= [];
gdjs.MainCode.GDTweet_9595bkg4Objects10= [];
gdjs.MainCode.GDTweet_9595bkg5Objects1= [];
gdjs.MainCode.GDTweet_9595bkg5Objects2= [];
gdjs.MainCode.GDTweet_9595bkg5Objects3= [];
gdjs.MainCode.GDTweet_9595bkg5Objects4= [];
gdjs.MainCode.GDTweet_9595bkg5Objects5= [];
gdjs.MainCode.GDTweet_9595bkg5Objects6= [];
gdjs.MainCode.GDTweet_9595bkg5Objects7= [];
gdjs.MainCode.GDTweet_9595bkg5Objects8= [];
gdjs.MainCode.GDTweet_9595bkg5Objects9= [];
gdjs.MainCode.GDTweet_9595bkg5Objects10= [];
gdjs.MainCode.GDTweet_9595bkg6Objects1= [];
gdjs.MainCode.GDTweet_9595bkg6Objects2= [];
gdjs.MainCode.GDTweet_9595bkg6Objects3= [];
gdjs.MainCode.GDTweet_9595bkg6Objects4= [];
gdjs.MainCode.GDTweet_9595bkg6Objects5= [];
gdjs.MainCode.GDTweet_9595bkg6Objects6= [];
gdjs.MainCode.GDTweet_9595bkg6Objects7= [];
gdjs.MainCode.GDTweet_9595bkg6Objects8= [];
gdjs.MainCode.GDTweet_9595bkg6Objects9= [];
gdjs.MainCode.GDTweet_9595bkg6Objects10= [];
gdjs.MainCode.GDTweetMarker8Objects1= [];
gdjs.MainCode.GDTweetMarker8Objects2= [];
gdjs.MainCode.GDTweetMarker8Objects3= [];
gdjs.MainCode.GDTweetMarker8Objects4= [];
gdjs.MainCode.GDTweetMarker8Objects5= [];
gdjs.MainCode.GDTweetMarker8Objects6= [];
gdjs.MainCode.GDTweetMarker8Objects7= [];
gdjs.MainCode.GDTweetMarker8Objects8= [];
gdjs.MainCode.GDTweetMarker8Objects9= [];
gdjs.MainCode.GDTweetMarker8Objects10= [];
gdjs.MainCode.GDFireText4Objects1= [];
gdjs.MainCode.GDFireText4Objects2= [];
gdjs.MainCode.GDFireText4Objects3= [];
gdjs.MainCode.GDFireText4Objects4= [];
gdjs.MainCode.GDFireText4Objects5= [];
gdjs.MainCode.GDFireText4Objects6= [];
gdjs.MainCode.GDFireText4Objects7= [];
gdjs.MainCode.GDFireText4Objects8= [];
gdjs.MainCode.GDFireText4Objects9= [];
gdjs.MainCode.GDFireText4Objects10= [];
gdjs.MainCode.GDFireText5Objects1= [];
gdjs.MainCode.GDFireText5Objects2= [];
gdjs.MainCode.GDFireText5Objects3= [];
gdjs.MainCode.GDFireText5Objects4= [];
gdjs.MainCode.GDFireText5Objects5= [];
gdjs.MainCode.GDFireText5Objects6= [];
gdjs.MainCode.GDFireText5Objects7= [];
gdjs.MainCode.GDFireText5Objects8= [];
gdjs.MainCode.GDFireText5Objects9= [];
gdjs.MainCode.GDFireText5Objects10= [];
gdjs.MainCode.GDFireText6Objects1= [];
gdjs.MainCode.GDFireText6Objects2= [];
gdjs.MainCode.GDFireText6Objects3= [];
gdjs.MainCode.GDFireText6Objects4= [];
gdjs.MainCode.GDFireText6Objects5= [];
gdjs.MainCode.GDFireText6Objects6= [];
gdjs.MainCode.GDFireText6Objects7= [];
gdjs.MainCode.GDFireText6Objects8= [];
gdjs.MainCode.GDFireText6Objects9= [];
gdjs.MainCode.GDFireText6Objects10= [];
gdjs.MainCode.GDLikeText4Objects1= [];
gdjs.MainCode.GDLikeText4Objects2= [];
gdjs.MainCode.GDLikeText4Objects3= [];
gdjs.MainCode.GDLikeText4Objects4= [];
gdjs.MainCode.GDLikeText4Objects5= [];
gdjs.MainCode.GDLikeText4Objects6= [];
gdjs.MainCode.GDLikeText4Objects7= [];
gdjs.MainCode.GDLikeText4Objects8= [];
gdjs.MainCode.GDLikeText4Objects9= [];
gdjs.MainCode.GDLikeText4Objects10= [];
gdjs.MainCode.GDLikeText5Objects1= [];
gdjs.MainCode.GDLikeText5Objects2= [];
gdjs.MainCode.GDLikeText5Objects3= [];
gdjs.MainCode.GDLikeText5Objects4= [];
gdjs.MainCode.GDLikeText5Objects5= [];
gdjs.MainCode.GDLikeText5Objects6= [];
gdjs.MainCode.GDLikeText5Objects7= [];
gdjs.MainCode.GDLikeText5Objects8= [];
gdjs.MainCode.GDLikeText5Objects9= [];
gdjs.MainCode.GDLikeText5Objects10= [];
gdjs.MainCode.GDLikeText6Objects1= [];
gdjs.MainCode.GDLikeText6Objects2= [];
gdjs.MainCode.GDLikeText6Objects3= [];
gdjs.MainCode.GDLikeText6Objects4= [];
gdjs.MainCode.GDLikeText6Objects5= [];
gdjs.MainCode.GDLikeText6Objects6= [];
gdjs.MainCode.GDLikeText6Objects7= [];
gdjs.MainCode.GDLikeText6Objects8= [];
gdjs.MainCode.GDLikeText6Objects9= [];
gdjs.MainCode.GDLikeText6Objects10= [];
gdjs.MainCode.GDHeartText4Objects1= [];
gdjs.MainCode.GDHeartText4Objects2= [];
gdjs.MainCode.GDHeartText4Objects3= [];
gdjs.MainCode.GDHeartText4Objects4= [];
gdjs.MainCode.GDHeartText4Objects5= [];
gdjs.MainCode.GDHeartText4Objects6= [];
gdjs.MainCode.GDHeartText4Objects7= [];
gdjs.MainCode.GDHeartText4Objects8= [];
gdjs.MainCode.GDHeartText4Objects9= [];
gdjs.MainCode.GDHeartText4Objects10= [];
gdjs.MainCode.GDHeartText5Objects1= [];
gdjs.MainCode.GDHeartText5Objects2= [];
gdjs.MainCode.GDHeartText5Objects3= [];
gdjs.MainCode.GDHeartText5Objects4= [];
gdjs.MainCode.GDHeartText5Objects5= [];
gdjs.MainCode.GDHeartText5Objects6= [];
gdjs.MainCode.GDHeartText5Objects7= [];
gdjs.MainCode.GDHeartText5Objects8= [];
gdjs.MainCode.GDHeartText5Objects9= [];
gdjs.MainCode.GDHeartText5Objects10= [];
gdjs.MainCode.GDHeartText6Objects1= [];
gdjs.MainCode.GDHeartText6Objects2= [];
gdjs.MainCode.GDHeartText6Objects3= [];
gdjs.MainCode.GDHeartText6Objects4= [];
gdjs.MainCode.GDHeartText6Objects5= [];
gdjs.MainCode.GDHeartText6Objects6= [];
gdjs.MainCode.GDHeartText6Objects7= [];
gdjs.MainCode.GDHeartText6Objects8= [];
gdjs.MainCode.GDHeartText6Objects9= [];
gdjs.MainCode.GDHeartText6Objects10= [];
gdjs.MainCode.GDTweetFace4Objects1= [];
gdjs.MainCode.GDTweetFace4Objects2= [];
gdjs.MainCode.GDTweetFace4Objects3= [];
gdjs.MainCode.GDTweetFace4Objects4= [];
gdjs.MainCode.GDTweetFace4Objects5= [];
gdjs.MainCode.GDTweetFace4Objects6= [];
gdjs.MainCode.GDTweetFace4Objects7= [];
gdjs.MainCode.GDTweetFace4Objects8= [];
gdjs.MainCode.GDTweetFace4Objects9= [];
gdjs.MainCode.GDTweetFace4Objects10= [];
gdjs.MainCode.GDTweetFace5Objects1= [];
gdjs.MainCode.GDTweetFace5Objects2= [];
gdjs.MainCode.GDTweetFace5Objects3= [];
gdjs.MainCode.GDTweetFace5Objects4= [];
gdjs.MainCode.GDTweetFace5Objects5= [];
gdjs.MainCode.GDTweetFace5Objects6= [];
gdjs.MainCode.GDTweetFace5Objects7= [];
gdjs.MainCode.GDTweetFace5Objects8= [];
gdjs.MainCode.GDTweetFace5Objects9= [];
gdjs.MainCode.GDTweetFace5Objects10= [];
gdjs.MainCode.GDTweetFace6Objects1= [];
gdjs.MainCode.GDTweetFace6Objects2= [];
gdjs.MainCode.GDTweetFace6Objects3= [];
gdjs.MainCode.GDTweetFace6Objects4= [];
gdjs.MainCode.GDTweetFace6Objects5= [];
gdjs.MainCode.GDTweetFace6Objects6= [];
gdjs.MainCode.GDTweetFace6Objects7= [];
gdjs.MainCode.GDTweetFace6Objects8= [];
gdjs.MainCode.GDTweetFace6Objects9= [];
gdjs.MainCode.GDTweetFace6Objects10= [];
gdjs.MainCode.GDTweetTitle4Objects1= [];
gdjs.MainCode.GDTweetTitle4Objects2= [];
gdjs.MainCode.GDTweetTitle4Objects3= [];
gdjs.MainCode.GDTweetTitle4Objects4= [];
gdjs.MainCode.GDTweetTitle4Objects5= [];
gdjs.MainCode.GDTweetTitle4Objects6= [];
gdjs.MainCode.GDTweetTitle4Objects7= [];
gdjs.MainCode.GDTweetTitle4Objects8= [];
gdjs.MainCode.GDTweetTitle4Objects9= [];
gdjs.MainCode.GDTweetTitle4Objects10= [];
gdjs.MainCode.GDTweetTitle5Objects1= [];
gdjs.MainCode.GDTweetTitle5Objects2= [];
gdjs.MainCode.GDTweetTitle5Objects3= [];
gdjs.MainCode.GDTweetTitle5Objects4= [];
gdjs.MainCode.GDTweetTitle5Objects5= [];
gdjs.MainCode.GDTweetTitle5Objects6= [];
gdjs.MainCode.GDTweetTitle5Objects7= [];
gdjs.MainCode.GDTweetTitle5Objects8= [];
gdjs.MainCode.GDTweetTitle5Objects9= [];
gdjs.MainCode.GDTweetTitle5Objects10= [];
gdjs.MainCode.GDTweetTitle6Objects1= [];
gdjs.MainCode.GDTweetTitle6Objects2= [];
gdjs.MainCode.GDTweetTitle6Objects3= [];
gdjs.MainCode.GDTweetTitle6Objects4= [];
gdjs.MainCode.GDTweetTitle6Objects5= [];
gdjs.MainCode.GDTweetTitle6Objects6= [];
gdjs.MainCode.GDTweetTitle6Objects7= [];
gdjs.MainCode.GDTweetTitle6Objects8= [];
gdjs.MainCode.GDTweetTitle6Objects9= [];
gdjs.MainCode.GDTweetTitle6Objects10= [];
gdjs.MainCode.GDTweet4Objects1= [];
gdjs.MainCode.GDTweet4Objects2= [];
gdjs.MainCode.GDTweet4Objects3= [];
gdjs.MainCode.GDTweet4Objects4= [];
gdjs.MainCode.GDTweet4Objects5= [];
gdjs.MainCode.GDTweet4Objects6= [];
gdjs.MainCode.GDTweet4Objects7= [];
gdjs.MainCode.GDTweet4Objects8= [];
gdjs.MainCode.GDTweet4Objects9= [];
gdjs.MainCode.GDTweet4Objects10= [];
gdjs.MainCode.GDTweet5Objects1= [];
gdjs.MainCode.GDTweet5Objects2= [];
gdjs.MainCode.GDTweet5Objects3= [];
gdjs.MainCode.GDTweet5Objects4= [];
gdjs.MainCode.GDTweet5Objects5= [];
gdjs.MainCode.GDTweet5Objects6= [];
gdjs.MainCode.GDTweet5Objects7= [];
gdjs.MainCode.GDTweet5Objects8= [];
gdjs.MainCode.GDTweet5Objects9= [];
gdjs.MainCode.GDTweet5Objects10= [];
gdjs.MainCode.GDTweet6Objects1= [];
gdjs.MainCode.GDTweet6Objects2= [];
gdjs.MainCode.GDTweet6Objects3= [];
gdjs.MainCode.GDTweet6Objects4= [];
gdjs.MainCode.GDTweet6Objects5= [];
gdjs.MainCode.GDTweet6Objects6= [];
gdjs.MainCode.GDTweet6Objects7= [];
gdjs.MainCode.GDTweet6Objects8= [];
gdjs.MainCode.GDTweet6Objects9= [];
gdjs.MainCode.GDTweet6Objects10= [];
gdjs.MainCode.GDBars_9595cover_9595blueObjects1= [];
gdjs.MainCode.GDBars_9595cover_9595blueObjects2= [];
gdjs.MainCode.GDBars_9595cover_9595blueObjects3= [];
gdjs.MainCode.GDBars_9595cover_9595blueObjects4= [];
gdjs.MainCode.GDBars_9595cover_9595blueObjects5= [];
gdjs.MainCode.GDBars_9595cover_9595blueObjects6= [];
gdjs.MainCode.GDBars_9595cover_9595blueObjects7= [];
gdjs.MainCode.GDBars_9595cover_9595blueObjects8= [];
gdjs.MainCode.GDBars_9595cover_9595blueObjects9= [];
gdjs.MainCode.GDBars_9595cover_9595blueObjects10= [];
gdjs.MainCode.GDBars_9595cover_9595greenObjects1= [];
gdjs.MainCode.GDBars_9595cover_9595greenObjects2= [];
gdjs.MainCode.GDBars_9595cover_9595greenObjects3= [];
gdjs.MainCode.GDBars_9595cover_9595greenObjects4= [];
gdjs.MainCode.GDBars_9595cover_9595greenObjects5= [];
gdjs.MainCode.GDBars_9595cover_9595greenObjects6= [];
gdjs.MainCode.GDBars_9595cover_9595greenObjects7= [];
gdjs.MainCode.GDBars_9595cover_9595greenObjects8= [];
gdjs.MainCode.GDBars_9595cover_9595greenObjects9= [];
gdjs.MainCode.GDBars_9595cover_9595greenObjects10= [];
gdjs.MainCode.GDBars_9595cover_9595orangeObjects1= [];
gdjs.MainCode.GDBars_9595cover_9595orangeObjects2= [];
gdjs.MainCode.GDBars_9595cover_9595orangeObjects3= [];
gdjs.MainCode.GDBars_9595cover_9595orangeObjects4= [];
gdjs.MainCode.GDBars_9595cover_9595orangeObjects5= [];
gdjs.MainCode.GDBars_9595cover_9595orangeObjects6= [];
gdjs.MainCode.GDBars_9595cover_9595orangeObjects7= [];
gdjs.MainCode.GDBars_9595cover_9595orangeObjects8= [];
gdjs.MainCode.GDBars_9595cover_9595orangeObjects9= [];
gdjs.MainCode.GDBars_9595cover_9595orangeObjects10= [];
gdjs.MainCode.GDBars_9595cover_9595pinkObjects1= [];
gdjs.MainCode.GDBars_9595cover_9595pinkObjects2= [];
gdjs.MainCode.GDBars_9595cover_9595pinkObjects3= [];
gdjs.MainCode.GDBars_9595cover_9595pinkObjects4= [];
gdjs.MainCode.GDBars_9595cover_9595pinkObjects5= [];
gdjs.MainCode.GDBars_9595cover_9595pinkObjects6= [];
gdjs.MainCode.GDBars_9595cover_9595pinkObjects7= [];
gdjs.MainCode.GDBars_9595cover_9595pinkObjects8= [];
gdjs.MainCode.GDBars_9595cover_9595pinkObjects9= [];
gdjs.MainCode.GDBars_9595cover_9595pinkObjects10= [];
gdjs.MainCode.GDTestTextObjects1= [];
gdjs.MainCode.GDTestTextObjects2= [];
gdjs.MainCode.GDTestTextObjects3= [];
gdjs.MainCode.GDTestTextObjects4= [];
gdjs.MainCode.GDTestTextObjects5= [];
gdjs.MainCode.GDTestTextObjects6= [];
gdjs.MainCode.GDTestTextObjects7= [];
gdjs.MainCode.GDTestTextObjects8= [];
gdjs.MainCode.GDTestTextObjects9= [];
gdjs.MainCode.GDTestTextObjects10= [];
gdjs.MainCode.GDTestText2Objects1= [];
gdjs.MainCode.GDTestText2Objects2= [];
gdjs.MainCode.GDTestText2Objects3= [];
gdjs.MainCode.GDTestText2Objects4= [];
gdjs.MainCode.GDTestText2Objects5= [];
gdjs.MainCode.GDTestText2Objects6= [];
gdjs.MainCode.GDTestText2Objects7= [];
gdjs.MainCode.GDTestText2Objects8= [];
gdjs.MainCode.GDTestText2Objects9= [];
gdjs.MainCode.GDTestText2Objects10= [];
gdjs.MainCode.GDBlackScreenObjects1= [];
gdjs.MainCode.GDBlackScreenObjects2= [];
gdjs.MainCode.GDBlackScreenObjects3= [];
gdjs.MainCode.GDBlackScreenObjects4= [];
gdjs.MainCode.GDBlackScreenObjects5= [];
gdjs.MainCode.GDBlackScreenObjects6= [];
gdjs.MainCode.GDBlackScreenObjects7= [];
gdjs.MainCode.GDBlackScreenObjects8= [];
gdjs.MainCode.GDBlackScreenObjects9= [];
gdjs.MainCode.GDBlackScreenObjects10= [];
gdjs.MainCode.GDBlackScreenTextObjects1= [];
gdjs.MainCode.GDBlackScreenTextObjects2= [];
gdjs.MainCode.GDBlackScreenTextObjects3= [];
gdjs.MainCode.GDBlackScreenTextObjects4= [];
gdjs.MainCode.GDBlackScreenTextObjects5= [];
gdjs.MainCode.GDBlackScreenTextObjects6= [];
gdjs.MainCode.GDBlackScreenTextObjects7= [];
gdjs.MainCode.GDBlackScreenTextObjects8= [];
gdjs.MainCode.GDBlackScreenTextObjects9= [];
gdjs.MainCode.GDBlackScreenTextObjects10= [];
gdjs.MainCode.GDLayout_9595maskObjects1= [];
gdjs.MainCode.GDLayout_9595maskObjects2= [];
gdjs.MainCode.GDLayout_9595maskObjects3= [];
gdjs.MainCode.GDLayout_9595maskObjects4= [];
gdjs.MainCode.GDLayout_9595maskObjects5= [];
gdjs.MainCode.GDLayout_9595maskObjects6= [];
gdjs.MainCode.GDLayout_9595maskObjects7= [];
gdjs.MainCode.GDLayout_9595maskObjects8= [];
gdjs.MainCode.GDLayout_9595maskObjects9= [];
gdjs.MainCode.GDLayout_9595maskObjects10= [];
gdjs.MainCode.GDEconomyResultObjects1= [];
gdjs.MainCode.GDEconomyResultObjects2= [];
gdjs.MainCode.GDEconomyResultObjects3= [];
gdjs.MainCode.GDEconomyResultObjects4= [];
gdjs.MainCode.GDEconomyResultObjects5= [];
gdjs.MainCode.GDEconomyResultObjects6= [];
gdjs.MainCode.GDEconomyResultObjects7= [];
gdjs.MainCode.GDEconomyResultObjects8= [];
gdjs.MainCode.GDEconomyResultObjects9= [];
gdjs.MainCode.GDEconomyResultObjects10= [];
gdjs.MainCode.GDPAResultObjects1= [];
gdjs.MainCode.GDPAResultObjects2= [];
gdjs.MainCode.GDPAResultObjects3= [];
gdjs.MainCode.GDPAResultObjects4= [];
gdjs.MainCode.GDPAResultObjects5= [];
gdjs.MainCode.GDPAResultObjects6= [];
gdjs.MainCode.GDPAResultObjects7= [];
gdjs.MainCode.GDPAResultObjects8= [];
gdjs.MainCode.GDPAResultObjects9= [];
gdjs.MainCode.GDPAResultObjects10= [];
gdjs.MainCode.GDRiskResultObjects1= [];
gdjs.MainCode.GDRiskResultObjects2= [];
gdjs.MainCode.GDRiskResultObjects3= [];
gdjs.MainCode.GDRiskResultObjects4= [];
gdjs.MainCode.GDRiskResultObjects5= [];
gdjs.MainCode.GDRiskResultObjects6= [];
gdjs.MainCode.GDRiskResultObjects7= [];
gdjs.MainCode.GDRiskResultObjects8= [];
gdjs.MainCode.GDRiskResultObjects9= [];
gdjs.MainCode.GDRiskResultObjects10= [];
gdjs.MainCode.GDPersonalWealthResultObjects1= [];
gdjs.MainCode.GDPersonalWealthResultObjects2= [];
gdjs.MainCode.GDPersonalWealthResultObjects3= [];
gdjs.MainCode.GDPersonalWealthResultObjects4= [];
gdjs.MainCode.GDPersonalWealthResultObjects5= [];
gdjs.MainCode.GDPersonalWealthResultObjects6= [];
gdjs.MainCode.GDPersonalWealthResultObjects7= [];
gdjs.MainCode.GDPersonalWealthResultObjects8= [];
gdjs.MainCode.GDPersonalWealthResultObjects9= [];
gdjs.MainCode.GDPersonalWealthResultObjects10= [];
gdjs.MainCode.GDNext_9595buttonObjects1= [];
gdjs.MainCode.GDNext_9595buttonObjects2= [];
gdjs.MainCode.GDNext_9595buttonObjects3= [];
gdjs.MainCode.GDNext_9595buttonObjects4= [];
gdjs.MainCode.GDNext_9595buttonObjects5= [];
gdjs.MainCode.GDNext_9595buttonObjects6= [];
gdjs.MainCode.GDNext_9595buttonObjects7= [];
gdjs.MainCode.GDNext_9595buttonObjects8= [];
gdjs.MainCode.GDNext_9595buttonObjects9= [];
gdjs.MainCode.GDNext_9595buttonObjects10= [];
gdjs.MainCode.GDNextTextObjects1= [];
gdjs.MainCode.GDNextTextObjects2= [];
gdjs.MainCode.GDNextTextObjects3= [];
gdjs.MainCode.GDNextTextObjects4= [];
gdjs.MainCode.GDNextTextObjects5= [];
gdjs.MainCode.GDNextTextObjects6= [];
gdjs.MainCode.GDNextTextObjects7= [];
gdjs.MainCode.GDNextTextObjects8= [];
gdjs.MainCode.GDNextTextObjects9= [];
gdjs.MainCode.GDNextTextObjects10= [];
gdjs.MainCode.GDSoundToggleObjects1= [];
gdjs.MainCode.GDSoundToggleObjects2= [];
gdjs.MainCode.GDSoundToggleObjects3= [];
gdjs.MainCode.GDSoundToggleObjects4= [];
gdjs.MainCode.GDSoundToggleObjects5= [];
gdjs.MainCode.GDSoundToggleObjects6= [];
gdjs.MainCode.GDSoundToggleObjects7= [];
gdjs.MainCode.GDSoundToggleObjects8= [];
gdjs.MainCode.GDSoundToggleObjects9= [];
gdjs.MainCode.GDSoundToggleObjects10= [];
gdjs.MainCode.GDSkipTutorialObjects1= [];
gdjs.MainCode.GDSkipTutorialObjects2= [];
gdjs.MainCode.GDSkipTutorialObjects3= [];
gdjs.MainCode.GDSkipTutorialObjects4= [];
gdjs.MainCode.GDSkipTutorialObjects5= [];
gdjs.MainCode.GDSkipTutorialObjects6= [];
gdjs.MainCode.GDSkipTutorialObjects7= [];
gdjs.MainCode.GDSkipTutorialObjects8= [];
gdjs.MainCode.GDSkipTutorialObjects9= [];
gdjs.MainCode.GDSkipTutorialObjects10= [];
gdjs.MainCode.GDCapConditionObjects1= [];
gdjs.MainCode.GDCapConditionObjects2= [];
gdjs.MainCode.GDCapConditionObjects3= [];
gdjs.MainCode.GDCapConditionObjects4= [];
gdjs.MainCode.GDCapConditionObjects5= [];
gdjs.MainCode.GDCapConditionObjects6= [];
gdjs.MainCode.GDCapConditionObjects7= [];
gdjs.MainCode.GDCapConditionObjects8= [];
gdjs.MainCode.GDCapConditionObjects9= [];
gdjs.MainCode.GDCapConditionObjects10= [];
gdjs.MainCode.GDRestart_9595buttonObjects1= [];
gdjs.MainCode.GDRestart_9595buttonObjects2= [];
gdjs.MainCode.GDRestart_9595buttonObjects3= [];
gdjs.MainCode.GDRestart_9595buttonObjects4= [];
gdjs.MainCode.GDRestart_9595buttonObjects5= [];
gdjs.MainCode.GDRestart_9595buttonObjects6= [];
gdjs.MainCode.GDRestart_9595buttonObjects7= [];
gdjs.MainCode.GDRestart_9595buttonObjects8= [];
gdjs.MainCode.GDRestart_9595buttonObjects9= [];
gdjs.MainCode.GDRestart_9595buttonObjects10= [];
gdjs.MainCode.GDMenu_9595bkgObjects1= [];
gdjs.MainCode.GDMenu_9595bkgObjects2= [];
gdjs.MainCode.GDMenu_9595bkgObjects3= [];
gdjs.MainCode.GDMenu_9595bkgObjects4= [];
gdjs.MainCode.GDMenu_9595bkgObjects5= [];
gdjs.MainCode.GDMenu_9595bkgObjects6= [];
gdjs.MainCode.GDMenu_9595bkgObjects7= [];
gdjs.MainCode.GDMenu_9595bkgObjects8= [];
gdjs.MainCode.GDMenu_9595bkgObjects9= [];
gdjs.MainCode.GDMenu_9595bkgObjects10= [];
gdjs.MainCode.GDPlay_9595buttonObjects1= [];
gdjs.MainCode.GDPlay_9595buttonObjects2= [];
gdjs.MainCode.GDPlay_9595buttonObjects3= [];
gdjs.MainCode.GDPlay_9595buttonObjects4= [];
gdjs.MainCode.GDPlay_9595buttonObjects5= [];
gdjs.MainCode.GDPlay_9595buttonObjects6= [];
gdjs.MainCode.GDPlay_9595buttonObjects7= [];
gdjs.MainCode.GDPlay_9595buttonObjects8= [];
gdjs.MainCode.GDPlay_9595buttonObjects9= [];
gdjs.MainCode.GDPlay_9595buttonObjects10= [];


gdjs.MainCode.eventsList0 = function(runtimeScene) {

{



}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("TestText"), gdjs.MainCode.GDTestTextObjects2);
{for(var i = 0, len = gdjs.MainCode.GDTestTextObjects2.length ;i < len;++i) {
    gdjs.MainCode.GDTestTextObjects2[i].getBehavior("Text").setText(gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableChildCount(runtimeScene.getScene().getVariables().getFromIndex(9))) + " strTemp = " + runtimeScene.getScene().getVariables().getFromIndex(1).getAsString() + " Sounds= " + runtimeScene.getScene().getVariables().getFromIndex(27).getAsString());
}
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("TestText2"), gdjs.MainCode.GDTestText2Objects2);
{for(var i = 0, len = gdjs.MainCode.GDTestText2Objects2.length ;i < len;++i) {
    gdjs.MainCode.GDTestText2Objects2[i].getBehavior("Text").setText("State = " + runtimeScene.getScene().getVariables().getFromIndex(7).getAsString());
}
}}

}


{



}


{



}


{



}


{



}


{



}


{



}


{



}


};gdjs.MainCode.eventsList1 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
{gdjs.evtTools.sound.preloadSound(runtimeScene, "assets\\Sounds\\Day change.mp3");
}{gdjs.evtTools.sound.preloadSound(runtimeScene, "assets\\Sounds\\Reaction appears.mp3");
}{gdjs.evtTools.sound.preloadSound(runtimeScene, "assets\\Sounds\\Send appears.mp3");
}{gdjs.evtTools.sound.preloadSound(runtimeScene, "assets\\Sounds\\Send-good-6081.mp3");
}{gdjs.evtTools.sound.preloadSound(runtimeScene, "assets\\Sounds\\Shocked.mp3");
}{gdjs.evtTools.sound.preloadSound(runtimeScene, "assets\\Sounds\\Yay.mp3");
}{gdjs.evtTools.sound.preloadSound(runtimeScene, "assets\\Sounds\\CapClick");
}{gdjs.evtTools.sound.preloadSound(runtimeScene, "assets\\Sounds\\rooster-call-cock-a-doodle-doo-46096.mp3");
}}

}


};gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDTweet_95959595bkg1Objects4Objects = Hashtable.newFrom({"Tweet_bkg1": gdjs.MainCode.GDTweet_9595bkg1Objects4});
gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDTweet_95959595bkg1Objects4Objects = Hashtable.newFrom({"Tweet_bkg1": gdjs.MainCode.GDTweet_9595bkg1Objects4});
gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDTweet_95959595bkg1Objects4Objects = Hashtable.newFrom({"Tweet_bkg1": gdjs.MainCode.GDTweet_9595bkg1Objects4});
gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDTweet_95959595bkg1Objects4Objects = Hashtable.newFrom({"Tweet_bkg1": gdjs.MainCode.GDTweet_9595bkg1Objects4});
gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDTweet_95959595bkg1Objects4Objects = Hashtable.newFrom({"Tweet_bkg1": gdjs.MainCode.GDTweet_9595bkg1Objects4});
gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDTweet_95959595bkg1Objects4Objects = Hashtable.newFrom({"Tweet_bkg1": gdjs.MainCode.GDTweet_9595bkg1Objects4});
gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDTweet_95959595bkg2Objects4Objects = Hashtable.newFrom({"Tweet_bkg2": gdjs.MainCode.GDTweet_9595bkg2Objects4});
gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDTweet_95959595bkg2Objects4Objects = Hashtable.newFrom({"Tweet_bkg2": gdjs.MainCode.GDTweet_9595bkg2Objects4});
gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDTweet_95959595bkg2Objects4Objects = Hashtable.newFrom({"Tweet_bkg2": gdjs.MainCode.GDTweet_9595bkg2Objects4});
gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDTweet_95959595bkg2Objects4Objects = Hashtable.newFrom({"Tweet_bkg2": gdjs.MainCode.GDTweet_9595bkg2Objects4});
gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDTweet_95959595bkg2Objects4Objects = Hashtable.newFrom({"Tweet_bkg2": gdjs.MainCode.GDTweet_9595bkg2Objects4});
gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDTweet_95959595bkg2Objects4Objects = Hashtable.newFrom({"Tweet_bkg2": gdjs.MainCode.GDTweet_9595bkg2Objects4});
gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDTweet_95959595bkg3Objects4Objects = Hashtable.newFrom({"Tweet_bkg3": gdjs.MainCode.GDTweet_9595bkg3Objects4});
gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDTweet_95959595bkg3Objects4Objects = Hashtable.newFrom({"Tweet_bkg3": gdjs.MainCode.GDTweet_9595bkg3Objects4});
gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDTweet_95959595bkg3Objects4Objects = Hashtable.newFrom({"Tweet_bkg3": gdjs.MainCode.GDTweet_9595bkg3Objects4});
gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDTweet_95959595bkg3Objects4Objects = Hashtable.newFrom({"Tweet_bkg3": gdjs.MainCode.GDTweet_9595bkg3Objects4});
gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDTweet_95959595bkg3Objects4Objects = Hashtable.newFrom({"Tweet_bkg3": gdjs.MainCode.GDTweet_9595bkg3Objects4});
gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDTweet_95959595bkg3Objects4Objects = Hashtable.newFrom({"Tweet_bkg3": gdjs.MainCode.GDTweet_9595bkg3Objects4});
gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDTweet_95959595bkg4Objects4Objects = Hashtable.newFrom({"Tweet_bkg4": gdjs.MainCode.GDTweet_9595bkg4Objects4});
gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDTweet_95959595bkg4Objects4Objects = Hashtable.newFrom({"Tweet_bkg4": gdjs.MainCode.GDTweet_9595bkg4Objects4});
gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDTweet_95959595bkg4Objects4Objects = Hashtable.newFrom({"Tweet_bkg4": gdjs.MainCode.GDTweet_9595bkg4Objects4});
gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDTweet_95959595bkg4Objects4Objects = Hashtable.newFrom({"Tweet_bkg4": gdjs.MainCode.GDTweet_9595bkg4Objects4});
gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDTweet_95959595bkg4Objects4Objects = Hashtable.newFrom({"Tweet_bkg4": gdjs.MainCode.GDTweet_9595bkg4Objects4});
gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDTweet_95959595bkg4Objects4Objects = Hashtable.newFrom({"Tweet_bkg4": gdjs.MainCode.GDTweet_9595bkg4Objects4});
gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDTweet_95959595bkg5Objects4Objects = Hashtable.newFrom({"Tweet_bkg5": gdjs.MainCode.GDTweet_9595bkg5Objects4});
gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDTweet_95959595bkg5Objects4Objects = Hashtable.newFrom({"Tweet_bkg5": gdjs.MainCode.GDTweet_9595bkg5Objects4});
gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDTweet_95959595bkg5Objects4Objects = Hashtable.newFrom({"Tweet_bkg5": gdjs.MainCode.GDTweet_9595bkg5Objects4});
gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDTweet_95959595bkg5Objects4Objects = Hashtable.newFrom({"Tweet_bkg5": gdjs.MainCode.GDTweet_9595bkg5Objects4});
gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDTweet_95959595bkg5Objects4Objects = Hashtable.newFrom({"Tweet_bkg5": gdjs.MainCode.GDTweet_9595bkg5Objects4});
gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDTweet_95959595bkg5Objects4Objects = Hashtable.newFrom({"Tweet_bkg5": gdjs.MainCode.GDTweet_9595bkg5Objects4});
gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDTweet_95959595bkg6Objects3Objects = Hashtable.newFrom({"Tweet_bkg6": gdjs.MainCode.GDTweet_9595bkg6Objects3});
gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDTweet_95959595bkg6Objects3Objects = Hashtable.newFrom({"Tweet_bkg6": gdjs.MainCode.GDTweet_9595bkg6Objects3});
gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDTweet_95959595bkg6Objects3Objects = Hashtable.newFrom({"Tweet_bkg6": gdjs.MainCode.GDTweet_9595bkg6Objects3});
gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDTweet_95959595bkg6Objects3Objects = Hashtable.newFrom({"Tweet_bkg6": gdjs.MainCode.GDTweet_9595bkg6Objects3});
gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDTweet_95959595bkg6Objects3Objects = Hashtable.newFrom({"Tweet_bkg6": gdjs.MainCode.GDTweet_9595bkg6Objects3});
gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDTweet_95959595bkg6Objects3Objects = Hashtable.newFrom({"Tweet_bkg6": gdjs.MainCode.GDTweet_9595bkg6Objects3});
gdjs.MainCode.eventsList2 = function(runtimeScene) {

{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("FireText1"), gdjs.MainCode.GDFireText1Objects4);
gdjs.copyArray(runtimeScene.getObjects("HeartText1"), gdjs.MainCode.GDHeartText1Objects4);
gdjs.copyArray(runtimeScene.getObjects("LikeText1"), gdjs.MainCode.GDLikeText1Objects4);
gdjs.copyArray(runtimeScene.getObjects("Tweet1"), gdjs.MainCode.GDTweet1Objects4);
gdjs.copyArray(runtimeScene.getObjects("TweetFace1"), gdjs.MainCode.GDTweetFace1Objects4);
gdjs.copyArray(runtimeScene.getObjects("TweetTitle1"), gdjs.MainCode.GDTweetTitle1Objects4);
gdjs.copyArray(runtimeScene.getObjects("Tweet_bkg1"), gdjs.MainCode.GDTweet_9595bkg1Objects4);
{for(var i = 0, len = gdjs.MainCode.GDTweet1Objects4.length ;i < len;++i) {
    gdjs.MainCode.GDTweet1Objects4[i].getBehavior("Sticker").Stick(gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDTweet_95959595bkg1Objects4Objects, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.MainCode.GDTweetTitle1Objects4.length ;i < len;++i) {
    gdjs.MainCode.GDTweetTitle1Objects4[i].getBehavior("Sticker").Stick(gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDTweet_95959595bkg1Objects4Objects, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.MainCode.GDLikeText1Objects4.length ;i < len;++i) {
    gdjs.MainCode.GDLikeText1Objects4[i].getBehavior("Sticker").Stick(gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDTweet_95959595bkg1Objects4Objects, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.MainCode.GDHeartText1Objects4.length ;i < len;++i) {
    gdjs.MainCode.GDHeartText1Objects4[i].getBehavior("Sticker").Stick(gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDTweet_95959595bkg1Objects4Objects, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.MainCode.GDFireText1Objects4.length ;i < len;++i) {
    gdjs.MainCode.GDFireText1Objects4[i].getBehavior("Sticker").Stick(gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDTweet_95959595bkg1Objects4Objects, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.MainCode.GDTweetFace1Objects4.length ;i < len;++i) {
    gdjs.MainCode.GDTweetFace1Objects4[i].getBehavior("Sticker").Stick(gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDTweet_95959595bkg1Objects4Objects, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("FireText2"), gdjs.MainCode.GDFireText2Objects4);
gdjs.copyArray(runtimeScene.getObjects("HeartText2"), gdjs.MainCode.GDHeartText2Objects4);
gdjs.copyArray(runtimeScene.getObjects("LikeText2"), gdjs.MainCode.GDLikeText2Objects4);
gdjs.copyArray(runtimeScene.getObjects("Tweet2"), gdjs.MainCode.GDTweet2Objects4);
gdjs.copyArray(runtimeScene.getObjects("TweetFace2"), gdjs.MainCode.GDTweetFace2Objects4);
gdjs.copyArray(runtimeScene.getObjects("TweetTitle2"), gdjs.MainCode.GDTweetTitle2Objects4);
gdjs.copyArray(runtimeScene.getObjects("Tweet_bkg2"), gdjs.MainCode.GDTweet_9595bkg2Objects4);
{for(var i = 0, len = gdjs.MainCode.GDTweet2Objects4.length ;i < len;++i) {
    gdjs.MainCode.GDTweet2Objects4[i].getBehavior("Sticker").Stick(gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDTweet_95959595bkg2Objects4Objects, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.MainCode.GDTweetTitle2Objects4.length ;i < len;++i) {
    gdjs.MainCode.GDTweetTitle2Objects4[i].getBehavior("Sticker").Stick(gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDTweet_95959595bkg2Objects4Objects, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.MainCode.GDLikeText2Objects4.length ;i < len;++i) {
    gdjs.MainCode.GDLikeText2Objects4[i].getBehavior("Sticker").Stick(gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDTweet_95959595bkg2Objects4Objects, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.MainCode.GDHeartText2Objects4.length ;i < len;++i) {
    gdjs.MainCode.GDHeartText2Objects4[i].getBehavior("Sticker").Stick(gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDTweet_95959595bkg2Objects4Objects, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.MainCode.GDFireText2Objects4.length ;i < len;++i) {
    gdjs.MainCode.GDFireText2Objects4[i].getBehavior("Sticker").Stick(gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDTweet_95959595bkg2Objects4Objects, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.MainCode.GDTweetFace2Objects4.length ;i < len;++i) {
    gdjs.MainCode.GDTweetFace2Objects4[i].getBehavior("Sticker").Stick(gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDTweet_95959595bkg2Objects4Objects, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("FireText3"), gdjs.MainCode.GDFireText3Objects4);
gdjs.copyArray(runtimeScene.getObjects("HeartText3"), gdjs.MainCode.GDHeartText3Objects4);
gdjs.copyArray(runtimeScene.getObjects("LikeText3"), gdjs.MainCode.GDLikeText3Objects4);
gdjs.copyArray(runtimeScene.getObjects("Tweet3"), gdjs.MainCode.GDTweet3Objects4);
gdjs.copyArray(runtimeScene.getObjects("TweetFace3"), gdjs.MainCode.GDTweetFace3Objects4);
gdjs.copyArray(runtimeScene.getObjects("TweetTitle3"), gdjs.MainCode.GDTweetTitle3Objects4);
gdjs.copyArray(runtimeScene.getObjects("Tweet_bkg3"), gdjs.MainCode.GDTweet_9595bkg3Objects4);
{for(var i = 0, len = gdjs.MainCode.GDTweet3Objects4.length ;i < len;++i) {
    gdjs.MainCode.GDTweet3Objects4[i].getBehavior("Sticker").Stick(gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDTweet_95959595bkg3Objects4Objects, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.MainCode.GDTweetTitle3Objects4.length ;i < len;++i) {
    gdjs.MainCode.GDTweetTitle3Objects4[i].getBehavior("Sticker").Stick(gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDTweet_95959595bkg3Objects4Objects, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.MainCode.GDLikeText3Objects4.length ;i < len;++i) {
    gdjs.MainCode.GDLikeText3Objects4[i].getBehavior("Sticker").Stick(gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDTweet_95959595bkg3Objects4Objects, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.MainCode.GDHeartText3Objects4.length ;i < len;++i) {
    gdjs.MainCode.GDHeartText3Objects4[i].getBehavior("Sticker").Stick(gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDTweet_95959595bkg3Objects4Objects, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.MainCode.GDFireText3Objects4.length ;i < len;++i) {
    gdjs.MainCode.GDFireText3Objects4[i].getBehavior("Sticker").Stick(gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDTweet_95959595bkg3Objects4Objects, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.MainCode.GDTweetFace3Objects4.length ;i < len;++i) {
    gdjs.MainCode.GDTweetFace3Objects4[i].getBehavior("Sticker").Stick(gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDTweet_95959595bkg3Objects4Objects, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("FireText4"), gdjs.MainCode.GDFireText4Objects4);
gdjs.copyArray(runtimeScene.getObjects("HeartText4"), gdjs.MainCode.GDHeartText4Objects4);
gdjs.copyArray(runtimeScene.getObjects("LikeText4"), gdjs.MainCode.GDLikeText4Objects4);
gdjs.copyArray(runtimeScene.getObjects("Tweet4"), gdjs.MainCode.GDTweet4Objects4);
gdjs.copyArray(runtimeScene.getObjects("TweetFace4"), gdjs.MainCode.GDTweetFace4Objects4);
gdjs.copyArray(runtimeScene.getObjects("TweetTitle4"), gdjs.MainCode.GDTweetTitle4Objects4);
gdjs.copyArray(runtimeScene.getObjects("Tweet_bkg4"), gdjs.MainCode.GDTweet_9595bkg4Objects4);
{for(var i = 0, len = gdjs.MainCode.GDTweet4Objects4.length ;i < len;++i) {
    gdjs.MainCode.GDTweet4Objects4[i].getBehavior("Sticker").Stick(gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDTweet_95959595bkg4Objects4Objects, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.MainCode.GDTweetTitle4Objects4.length ;i < len;++i) {
    gdjs.MainCode.GDTweetTitle4Objects4[i].getBehavior("Sticker").Stick(gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDTweet_95959595bkg4Objects4Objects, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.MainCode.GDLikeText4Objects4.length ;i < len;++i) {
    gdjs.MainCode.GDLikeText4Objects4[i].getBehavior("Sticker").Stick(gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDTweet_95959595bkg4Objects4Objects, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.MainCode.GDHeartText4Objects4.length ;i < len;++i) {
    gdjs.MainCode.GDHeartText4Objects4[i].getBehavior("Sticker").Stick(gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDTweet_95959595bkg4Objects4Objects, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.MainCode.GDFireText4Objects4.length ;i < len;++i) {
    gdjs.MainCode.GDFireText4Objects4[i].getBehavior("Sticker").Stick(gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDTweet_95959595bkg4Objects4Objects, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.MainCode.GDTweetFace4Objects4.length ;i < len;++i) {
    gdjs.MainCode.GDTweetFace4Objects4[i].getBehavior("Sticker").Stick(gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDTweet_95959595bkg4Objects4Objects, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("FireText5"), gdjs.MainCode.GDFireText5Objects4);
gdjs.copyArray(runtimeScene.getObjects("HeartText5"), gdjs.MainCode.GDHeartText5Objects4);
gdjs.copyArray(runtimeScene.getObjects("LikeText5"), gdjs.MainCode.GDLikeText5Objects4);
gdjs.copyArray(runtimeScene.getObjects("Tweet5"), gdjs.MainCode.GDTweet5Objects4);
gdjs.copyArray(runtimeScene.getObjects("TweetFace5"), gdjs.MainCode.GDTweetFace5Objects4);
gdjs.copyArray(runtimeScene.getObjects("TweetTitle5"), gdjs.MainCode.GDTweetTitle5Objects4);
gdjs.copyArray(runtimeScene.getObjects("Tweet_bkg5"), gdjs.MainCode.GDTweet_9595bkg5Objects4);
{for(var i = 0, len = gdjs.MainCode.GDTweet5Objects4.length ;i < len;++i) {
    gdjs.MainCode.GDTweet5Objects4[i].getBehavior("Sticker").Stick(gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDTweet_95959595bkg5Objects4Objects, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.MainCode.GDTweetTitle5Objects4.length ;i < len;++i) {
    gdjs.MainCode.GDTweetTitle5Objects4[i].getBehavior("Sticker").Stick(gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDTweet_95959595bkg5Objects4Objects, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.MainCode.GDLikeText5Objects4.length ;i < len;++i) {
    gdjs.MainCode.GDLikeText5Objects4[i].getBehavior("Sticker").Stick(gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDTweet_95959595bkg5Objects4Objects, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.MainCode.GDHeartText5Objects4.length ;i < len;++i) {
    gdjs.MainCode.GDHeartText5Objects4[i].getBehavior("Sticker").Stick(gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDTweet_95959595bkg5Objects4Objects, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.MainCode.GDFireText5Objects4.length ;i < len;++i) {
    gdjs.MainCode.GDFireText5Objects4[i].getBehavior("Sticker").Stick(gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDTweet_95959595bkg5Objects4Objects, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.MainCode.GDTweetFace5Objects4.length ;i < len;++i) {
    gdjs.MainCode.GDTweetFace5Objects4[i].getBehavior("Sticker").Stick(gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDTweet_95959595bkg5Objects4Objects, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("FireText6"), gdjs.MainCode.GDFireText6Objects3);
gdjs.copyArray(runtimeScene.getObjects("HeartText6"), gdjs.MainCode.GDHeartText6Objects3);
gdjs.copyArray(runtimeScene.getObjects("LikeText6"), gdjs.MainCode.GDLikeText6Objects3);
gdjs.copyArray(runtimeScene.getObjects("Tweet6"), gdjs.MainCode.GDTweet6Objects3);
gdjs.copyArray(runtimeScene.getObjects("TweetFace6"), gdjs.MainCode.GDTweetFace6Objects3);
gdjs.copyArray(runtimeScene.getObjects("TweetTitle6"), gdjs.MainCode.GDTweetTitle6Objects3);
gdjs.copyArray(runtimeScene.getObjects("Tweet_bkg6"), gdjs.MainCode.GDTweet_9595bkg6Objects3);
{for(var i = 0, len = gdjs.MainCode.GDTweet6Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDTweet6Objects3[i].getBehavior("Sticker").Stick(gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDTweet_95959595bkg6Objects3Objects, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.MainCode.GDTweetTitle6Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDTweetTitle6Objects3[i].getBehavior("Sticker").Stick(gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDTweet_95959595bkg6Objects3Objects, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.MainCode.GDLikeText6Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDLikeText6Objects3[i].getBehavior("Sticker").Stick(gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDTweet_95959595bkg6Objects3Objects, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.MainCode.GDHeartText6Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDHeartText6Objects3[i].getBehavior("Sticker").Stick(gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDTweet_95959595bkg6Objects3Objects, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.MainCode.GDFireText6Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDFireText6Objects3[i].getBehavior("Sticker").Stick(gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDTweet_95959595bkg6Objects3Objects, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.MainCode.GDTweetFace6Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDTweetFace6Objects3[i].getBehavior("Sticker").Stick(gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDTweet_95959595bkg6Objects3Objects, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


};gdjs.MainCode.eventsList3 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Send_icon1"), gdjs.MainCode.GDSend_9595icon1Objects3);
gdjs.copyArray(runtimeScene.getObjects("Send_icon2"), gdjs.MainCode.GDSend_9595icon2Objects3);
gdjs.copyArray(runtimeScene.getObjects("Send_icon3"), gdjs.MainCode.GDSend_9595icon3Objects3);
{for(var i = 0, len = gdjs.MainCode.GDSend_9595icon1Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDSend_9595icon1Objects3[i].hide();
}
}{for(var i = 0, len = gdjs.MainCode.GDSend_9595icon2Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDSend_9595icon2Objects3[i].hide();
}
}{for(var i = 0, len = gdjs.MainCode.GDSend_9595icon3Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDSend_9595icon3Objects3[i].hide();
}
}}

}


};gdjs.MainCode.eventsList4 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Chirp"), gdjs.MainCode.GDChirpObjects3);
gdjs.copyArray(runtimeScene.getObjects("DayTxt"), gdjs.MainCode.GDDayTxtObjects3);
gdjs.copyArray(runtimeScene.getObjects("EconomyTxt"), gdjs.MainCode.GDEconomyTxtObjects3);
gdjs.copyArray(runtimeScene.getObjects("FireText1"), gdjs.MainCode.GDFireText1Objects3);
gdjs.copyArray(runtimeScene.getObjects("FireText2"), gdjs.MainCode.GDFireText2Objects3);
gdjs.copyArray(runtimeScene.getObjects("FireText3"), gdjs.MainCode.GDFireText3Objects3);
gdjs.copyArray(runtimeScene.getObjects("FireText4"), gdjs.MainCode.GDFireText4Objects3);
gdjs.copyArray(runtimeScene.getObjects("FireText5"), gdjs.MainCode.GDFireText5Objects3);
gdjs.copyArray(runtimeScene.getObjects("FireText6"), gdjs.MainCode.GDFireText6Objects3);
gdjs.copyArray(runtimeScene.getObjects("Green_bars"), gdjs.MainCode.GDGreen_9595barsObjects3);
gdjs.copyArray(runtimeScene.getObjects("HeartText1"), gdjs.MainCode.GDHeartText1Objects3);
gdjs.copyArray(runtimeScene.getObjects("HeartText2"), gdjs.MainCode.GDHeartText2Objects3);
gdjs.copyArray(runtimeScene.getObjects("HeartText3"), gdjs.MainCode.GDHeartText3Objects3);
gdjs.copyArray(runtimeScene.getObjects("HeartText4"), gdjs.MainCode.GDHeartText4Objects3);
gdjs.copyArray(runtimeScene.getObjects("HeartText5"), gdjs.MainCode.GDHeartText5Objects3);
gdjs.copyArray(runtimeScene.getObjects("HeartText6"), gdjs.MainCode.GDHeartText6Objects3);
gdjs.copyArray(runtimeScene.getObjects("LikeText1"), gdjs.MainCode.GDLikeText1Objects3);
gdjs.copyArray(runtimeScene.getObjects("LikeText2"), gdjs.MainCode.GDLikeText2Objects3);
gdjs.copyArray(runtimeScene.getObjects("LikeText3"), gdjs.MainCode.GDLikeText3Objects3);
gdjs.copyArray(runtimeScene.getObjects("LikeText4"), gdjs.MainCode.GDLikeText4Objects3);
gdjs.copyArray(runtimeScene.getObjects("LikeText5"), gdjs.MainCode.GDLikeText5Objects3);
gdjs.copyArray(runtimeScene.getObjects("LikeText6"), gdjs.MainCode.GDLikeText6Objects3);
gdjs.copyArray(runtimeScene.getObjects("My_options"), gdjs.MainCode.GDMy_9595optionsObjects3);
gdjs.copyArray(runtimeScene.getObjects("Option1"), gdjs.MainCode.GDOption1Objects3);
gdjs.copyArray(runtimeScene.getObjects("Option2"), gdjs.MainCode.GDOption2Objects3);
gdjs.copyArray(runtimeScene.getObjects("Option3"), gdjs.MainCode.GDOption3Objects3);
gdjs.copyArray(runtimeScene.getObjects("OptionTxt1"), gdjs.MainCode.GDOptionTxt1Objects3);
gdjs.copyArray(runtimeScene.getObjects("OptionTxt2"), gdjs.MainCode.GDOptionTxt2Objects3);
gdjs.copyArray(runtimeScene.getObjects("OptionTxt3"), gdjs.MainCode.GDOptionTxt3Objects3);
gdjs.copyArray(runtimeScene.getObjects("Orange_bars"), gdjs.MainCode.GDOrange_9595barsObjects3);
gdjs.copyArray(runtimeScene.getObjects("PersonalGainsTxt"), gdjs.MainCode.GDPersonalGainsTxtObjects3);
gdjs.copyArray(runtimeScene.getObjects("Pink_bars"), gdjs.MainCode.GDPink_9595barsObjects3);
gdjs.copyArray(runtimeScene.getObjects("PublicApprovalTxt"), gdjs.MainCode.GDPublicApprovalTxtObjects3);
gdjs.copyArray(runtimeScene.getObjects("ReactionIcon_Fire"), gdjs.MainCode.GDReactionIcon_9595FireObjects3);
gdjs.copyArray(runtimeScene.getObjects("ReactionIcon_Like"), gdjs.MainCode.GDReactionIcon_9595LikeObjects3);
gdjs.copyArray(runtimeScene.getObjects("ReactionIcons_Heart"), gdjs.MainCode.GDReactionIcons_9595HeartObjects3);
gdjs.copyArray(runtimeScene.getObjects("ScandalRiskTxt"), gdjs.MainCode.GDScandalRiskTxtObjects3);
gdjs.copyArray(runtimeScene.getObjects("Send_icon1"), gdjs.MainCode.GDSend_9595icon1Objects3);
gdjs.copyArray(runtimeScene.getObjects("Send_icon2"), gdjs.MainCode.GDSend_9595icon2Objects3);
gdjs.copyArray(runtimeScene.getObjects("Send_icon3"), gdjs.MainCode.GDSend_9595icon3Objects3);
gdjs.copyArray(runtimeScene.getObjects("Tweet1"), gdjs.MainCode.GDTweet1Objects3);
gdjs.copyArray(runtimeScene.getObjects("Tweet2"), gdjs.MainCode.GDTweet2Objects3);
gdjs.copyArray(runtimeScene.getObjects("Tweet3"), gdjs.MainCode.GDTweet3Objects3);
gdjs.copyArray(runtimeScene.getObjects("Tweet4"), gdjs.MainCode.GDTweet4Objects3);
gdjs.copyArray(runtimeScene.getObjects("Tweet5"), gdjs.MainCode.GDTweet5Objects3);
gdjs.copyArray(runtimeScene.getObjects("Tweet6"), gdjs.MainCode.GDTweet6Objects3);
gdjs.copyArray(runtimeScene.getObjects("TweetFace1"), gdjs.MainCode.GDTweetFace1Objects3);
gdjs.copyArray(runtimeScene.getObjects("TweetFace2"), gdjs.MainCode.GDTweetFace2Objects3);
gdjs.copyArray(runtimeScene.getObjects("TweetFace3"), gdjs.MainCode.GDTweetFace3Objects3);
gdjs.copyArray(runtimeScene.getObjects("TweetFace4"), gdjs.MainCode.GDTweetFace4Objects3);
gdjs.copyArray(runtimeScene.getObjects("TweetFace5"), gdjs.MainCode.GDTweetFace5Objects3);
gdjs.copyArray(runtimeScene.getObjects("TweetFace6"), gdjs.MainCode.GDTweetFace6Objects3);
gdjs.copyArray(runtimeScene.getObjects("TweetTitle1"), gdjs.MainCode.GDTweetTitle1Objects3);
gdjs.copyArray(runtimeScene.getObjects("TweetTitle2"), gdjs.MainCode.GDTweetTitle2Objects3);
gdjs.copyArray(runtimeScene.getObjects("TweetTitle3"), gdjs.MainCode.GDTweetTitle3Objects3);
gdjs.copyArray(runtimeScene.getObjects("TweetTitle4"), gdjs.MainCode.GDTweetTitle4Objects3);
gdjs.copyArray(runtimeScene.getObjects("TweetTitle5"), gdjs.MainCode.GDTweetTitle5Objects3);
gdjs.copyArray(runtimeScene.getObjects("TweetTitle6"), gdjs.MainCode.GDTweetTitle6Objects3);
gdjs.copyArray(runtimeScene.getObjects("Tweet_bkg1"), gdjs.MainCode.GDTweet_9595bkg1Objects3);
gdjs.copyArray(runtimeScene.getObjects("Tweet_bkg2"), gdjs.MainCode.GDTweet_9595bkg2Objects3);
gdjs.copyArray(runtimeScene.getObjects("Tweet_bkg3"), gdjs.MainCode.GDTweet_9595bkg3Objects3);
gdjs.copyArray(runtimeScene.getObjects("Tweet_bkg4"), gdjs.MainCode.GDTweet_9595bkg4Objects3);
gdjs.copyArray(runtimeScene.getObjects("Tweet_bkg5"), gdjs.MainCode.GDTweet_9595bkg5Objects3);
gdjs.copyArray(runtimeScene.getObjects("Tweet_bkg6"), gdjs.MainCode.GDTweet_9595bkg6Objects3);
gdjs.copyArray(runtimeScene.getObjects("blue_bars"), gdjs.MainCode.GDblue_9595barsObjects3);
{for(var i = 0, len = gdjs.MainCode.GDTweet1Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDTweet1Objects3[i].hide();
}
for(var i = 0, len = gdjs.MainCode.GDTweetTitle1Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDTweetTitle1Objects3[i].hide();
}
for(var i = 0, len = gdjs.MainCode.GDHeartText1Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDHeartText1Objects3[i].hide();
}
for(var i = 0, len = gdjs.MainCode.GDReactionIcons_9595HeartObjects3.length ;i < len;++i) {
    gdjs.MainCode.GDReactionIcons_9595HeartObjects3[i].hide();
}
for(var i = 0, len = gdjs.MainCode.GDReactionIcon_9595LikeObjects3.length ;i < len;++i) {
    gdjs.MainCode.GDReactionIcon_9595LikeObjects3[i].hide();
}
for(var i = 0, len = gdjs.MainCode.GDLikeText1Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDLikeText1Objects3[i].hide();
}
for(var i = 0, len = gdjs.MainCode.GDReactionIcon_9595FireObjects3.length ;i < len;++i) {
    gdjs.MainCode.GDReactionIcon_9595FireObjects3[i].hide();
}
for(var i = 0, len = gdjs.MainCode.GDFireText1Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDFireText1Objects3[i].hide();
}
for(var i = 0, len = gdjs.MainCode.GDLikeText2Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDLikeText2Objects3[i].hide();
}
for(var i = 0, len = gdjs.MainCode.GDFireText2Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDFireText2Objects3[i].hide();
}
for(var i = 0, len = gdjs.MainCode.GDHeartText2Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDHeartText2Objects3[i].hide();
}
for(var i = 0, len = gdjs.MainCode.GDFireText3Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDFireText3Objects3[i].hide();
}
for(var i = 0, len = gdjs.MainCode.GDOption1Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDOption1Objects3[i].hide();
}
for(var i = 0, len = gdjs.MainCode.GDOption2Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDOption2Objects3[i].hide();
}
for(var i = 0, len = gdjs.MainCode.GDOption3Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDOption3Objects3[i].hide();
}
for(var i = 0, len = gdjs.MainCode.GDOptionTxt1Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDOptionTxt1Objects3[i].hide();
}
for(var i = 0, len = gdjs.MainCode.GDOptionTxt2Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDOptionTxt2Objects3[i].hide();
}
for(var i = 0, len = gdjs.MainCode.GDOptionTxt3Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDOptionTxt3Objects3[i].hide();
}
for(var i = 0, len = gdjs.MainCode.GDSend_9595icon1Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDSend_9595icon1Objects3[i].hide();
}
for(var i = 0, len = gdjs.MainCode.GDblue_9595barsObjects3.length ;i < len;++i) {
    gdjs.MainCode.GDblue_9595barsObjects3[i].hide();
}
for(var i = 0, len = gdjs.MainCode.GDGreen_9595barsObjects3.length ;i < len;++i) {
    gdjs.MainCode.GDGreen_9595barsObjects3[i].hide();
}
for(var i = 0, len = gdjs.MainCode.GDOrange_9595barsObjects3.length ;i < len;++i) {
    gdjs.MainCode.GDOrange_9595barsObjects3[i].hide();
}
for(var i = 0, len = gdjs.MainCode.GDPink_9595barsObjects3.length ;i < len;++i) {
    gdjs.MainCode.GDPink_9595barsObjects3[i].hide();
}
for(var i = 0, len = gdjs.MainCode.GDEconomyTxtObjects3.length ;i < len;++i) {
    gdjs.MainCode.GDEconomyTxtObjects3[i].hide();
}
for(var i = 0, len = gdjs.MainCode.GDPersonalGainsTxtObjects3.length ;i < len;++i) {
    gdjs.MainCode.GDPersonalGainsTxtObjects3[i].hide();
}
for(var i = 0, len = gdjs.MainCode.GDScandalRiskTxtObjects3.length ;i < len;++i) {
    gdjs.MainCode.GDScandalRiskTxtObjects3[i].hide();
}
for(var i = 0, len = gdjs.MainCode.GDPublicApprovalTxtObjects3.length ;i < len;++i) {
    gdjs.MainCode.GDPublicApprovalTxtObjects3[i].hide();
}
for(var i = 0, len = gdjs.MainCode.GDLikeText3Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDLikeText3Objects3[i].hide();
}
for(var i = 0, len = gdjs.MainCode.GDHeartText3Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDHeartText3Objects3[i].hide();
}
for(var i = 0, len = gdjs.MainCode.GDTweetFace3Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDTweetFace3Objects3[i].hide();
}
for(var i = 0, len = gdjs.MainCode.GDTweetTitle2Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDTweetTitle2Objects3[i].hide();
}
for(var i = 0, len = gdjs.MainCode.GDTweetTitle3Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDTweetTitle3Objects3[i].hide();
}
for(var i = 0, len = gdjs.MainCode.GDTweet2Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDTweet2Objects3[i].hide();
}
for(var i = 0, len = gdjs.MainCode.GDTweet3Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDTweet3Objects3[i].hide();
}
for(var i = 0, len = gdjs.MainCode.GDTweet_9595bkg1Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDTweet_9595bkg1Objects3[i].hide();
}
for(var i = 0, len = gdjs.MainCode.GDTweetFace2Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDTweetFace2Objects3[i].hide();
}
for(var i = 0, len = gdjs.MainCode.GDTweetFace1Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDTweetFace1Objects3[i].hide();
}
for(var i = 0, len = gdjs.MainCode.GDSend_9595icon3Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDSend_9595icon3Objects3[i].hide();
}
for(var i = 0, len = gdjs.MainCode.GDSend_9595icon2Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDSend_9595icon2Objects3[i].hide();
}
for(var i = 0, len = gdjs.MainCode.GDMy_9595optionsObjects3.length ;i < len;++i) {
    gdjs.MainCode.GDMy_9595optionsObjects3[i].hide();
}
for(var i = 0, len = gdjs.MainCode.GDTweetTitle6Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDTweetTitle6Objects3[i].hide();
}
for(var i = 0, len = gdjs.MainCode.GDTweet6Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDTweet6Objects3[i].hide();
}
for(var i = 0, len = gdjs.MainCode.GDChirpObjects3.length ;i < len;++i) {
    gdjs.MainCode.GDChirpObjects3[i].hide();
}
for(var i = 0, len = gdjs.MainCode.GDDayTxtObjects3.length ;i < len;++i) {
    gdjs.MainCode.GDDayTxtObjects3[i].hide();
}
for(var i = 0, len = gdjs.MainCode.GDTweet_9595bkg2Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDTweet_9595bkg2Objects3[i].hide();
}
for(var i = 0, len = gdjs.MainCode.GDTweet5Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDTweet5Objects3[i].hide();
}
for(var i = 0, len = gdjs.MainCode.GDTweet4Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDTweet4Objects3[i].hide();
}
for(var i = 0, len = gdjs.MainCode.GDTweetTitle5Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDTweetTitle5Objects3[i].hide();
}
for(var i = 0, len = gdjs.MainCode.GDTweetTitle4Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDTweetTitle4Objects3[i].hide();
}
for(var i = 0, len = gdjs.MainCode.GDTweet_9595bkg3Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDTweet_9595bkg3Objects3[i].hide();
}
for(var i = 0, len = gdjs.MainCode.GDTweet_9595bkg4Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDTweet_9595bkg4Objects3[i].hide();
}
for(var i = 0, len = gdjs.MainCode.GDFireText4Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDFireText4Objects3[i].hide();
}
for(var i = 0, len = gdjs.MainCode.GDTweet_9595bkg5Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDTweet_9595bkg5Objects3[i].hide();
}
for(var i = 0, len = gdjs.MainCode.GDTweet_9595bkg6Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDTweet_9595bkg6Objects3[i].hide();
}
for(var i = 0, len = gdjs.MainCode.GDFireText5Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDFireText5Objects3[i].hide();
}
for(var i = 0, len = gdjs.MainCode.GDFireText6Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDFireText6Objects3[i].hide();
}
for(var i = 0, len = gdjs.MainCode.GDLikeText4Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDLikeText4Objects3[i].hide();
}
for(var i = 0, len = gdjs.MainCode.GDLikeText5Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDLikeText5Objects3[i].hide();
}
for(var i = 0, len = gdjs.MainCode.GDLikeText6Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDLikeText6Objects3[i].hide();
}
for(var i = 0, len = gdjs.MainCode.GDHeartText4Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDHeartText4Objects3[i].hide();
}
for(var i = 0, len = gdjs.MainCode.GDHeartText5Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDHeartText5Objects3[i].hide();
}
for(var i = 0, len = gdjs.MainCode.GDHeartText6Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDHeartText6Objects3[i].hide();
}
for(var i = 0, len = gdjs.MainCode.GDTweetFace4Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDTweetFace4Objects3[i].hide();
}
for(var i = 0, len = gdjs.MainCode.GDTweetFace5Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDTweetFace5Objects3[i].hide();
}
for(var i = 0, len = gdjs.MainCode.GDTweetFace6Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDTweetFace6Objects3[i].hide();
}
}}

}


};gdjs.MainCode.eventsList5 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
{gdjs.evtTools.variable.valuePush(runtimeScene.getScene().getVariables().getFromIndex(11), "We’re doing TREMENDOUS things.");
}{gdjs.evtTools.variable.valuePush(runtimeScene.getScene().getVariables().getFromIndex(11), "That chirp was beautiful. Beautiful!");
}{gdjs.evtTools.variable.valuePush(runtimeScene.getScene().getVariables().getFromIndex(11), "Last sleepy president couldn’t have done this.");
}{gdjs.evtTools.variable.valuePush(runtimeScene.getScene().getVariables().getFromIndex(11), "I don’t read the news. I am the news.");
}{gdjs.evtTools.variable.valuePush(runtimeScene.getScene().getVariables().getFromIndex(11), "They said no. I did it backwards, blindfolded, on a scooter.");
}{gdjs.evtTools.variable.valuePush(runtimeScene.getScene().getVariables().getFromIndex(11), "The economy just asked for my autograph.");
}{gdjs.evtTools.variable.valuePush(runtimeScene.getScene().getVariables().getFromIndex(11), "I only chirp facts. Some just haven’t happened yet.");
}{gdjs.evtTools.variable.valuePush(runtimeScene.getScene().getVariables().getFromIndex(11), "Plans are for quitters. I’ve got pure instincts.");
}{gdjs.evtTools.variable.valuePush(runtimeScene.getScene().getVariables().getFromIndex(11), "Money isn’t everything. It’s just all mine.");
}{gdjs.evtTools.variable.valuePush(runtimeScene.getScene().getVariables().getFromIndex(11), "Approval ratings? I built the whole theme park.");
}{gdjs.evtTools.variable.valuePush(runtimeScene.getScene().getVariables().getFromIndex(11), "Hard questions? I dodge them in style.");
}{gdjs.evtTools.variable.valuePush(runtimeScene.getScene().getVariables().getFromIndex(11), "Every chirp I send makes an economist cry.");
}{gdjs.evtTools.variable.valuePush(runtimeScene.getScene().getVariables().getFromIndex(11), "Am I winning? Always. Even when I’m not.");
}}

}


};gdjs.MainCode.eventsList6 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
}

}


};gdjs.MainCode.eventsList7 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
{gdjs.evtTools.variable.valuePush(runtimeScene.getScene().getVariables().getFromIndex(28), "The people are smiling, and so is your bank account!");
}{gdjs.evtTools.variable.valuePush(runtimeScene.getScene().getVariables().getFromIndex(28), "Economy’s thriving! Did you just invent money again?");
}{gdjs.evtTools.variable.valuePush(runtimeScene.getScene().getVariables().getFromIndex(28), "Public's loving it. You’re basically a meme hero now.");
}{gdjs.evtTools.variable.valuePush(runtimeScene.getScene().getVariables().getFromIndex(28), "Scandal’s low. You might just survive the next headline!");
}{gdjs.evtTools.variable.valuePush(runtimeScene.getScene().getVariables().getFromIndex(28), "You’re popular, rich, and not in jail. A true hat-trick!");
}{gdjs.evtTools.variable.valuePush(runtimeScene.getScene().getVariables().getFromIndex(28), "Country's booming. And so is your offshore account!");
}{gdjs.evtTools.variable.valuePush(runtimeScene.getScene().getVariables().getFromIndex(28), "You're on fire—but like, in a good, slightly corrupt way.");
}{gdjs.evtTools.variable.valuePush(runtimeScene.getScene().getVariables().getFromIndex(28), "The nation cheers. Mostly for the fries, but still.");
}{gdjs.evtTools.variable.valuePush(runtimeScene.getScene().getVariables().getFromIndex(28), "Approval’s rising like gas prices. Wait, that’s good?");
}{gdjs.evtTools.variable.valuePush(runtimeScene.getScene().getVariables().getFromIndex(28), "Keep this up, and history books might actually be nice!");
}}

}


};gdjs.MainCode.eventsList8 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
{gdjs.evtTools.variable.valuePush(runtimeScene.getScene().getVariables().getFromIndex(29), "Yikes. People are sharpening pitchforks and chirps.");
}{gdjs.evtTools.variable.valuePush(runtimeScene.getScene().getVariables().getFromIndex(29), "The vibes are off. Like... historically off.");
}{gdjs.evtTools.variable.valuePush(runtimeScene.getScene().getVariables().getFromIndex(29), "Uh-oh. Feels like a ‘resign gracefully’ kind of moment.");
}{gdjs.evtTools.variable.valuePush(runtimeScene.getScene().getVariables().getFromIndex(29), "This might be your villain origin story.");
}{gdjs.evtTools.variable.valuePush(runtimeScene.getScene().getVariables().getFromIndex(29), "Not saying it’s bad… but it’s definitely not good.");
}{gdjs.evtTools.variable.valuePush(runtimeScene.getScene().getVariables().getFromIndex(29), "Sir, the nation just sent a nervous emoji.");
}{gdjs.evtTools.variable.valuePush(runtimeScene.getScene().getVariables().getFromIndex(29), "You might want to start packing… emotionally.");
}{gdjs.evtTools.variable.valuePush(runtimeScene.getScene().getVariables().getFromIndex(29), "Let’s just say history won’t be kind to this chapter.");
}{gdjs.evtTools.variable.valuePush(runtimeScene.getScene().getVariables().getFromIndex(29), "This isn’t looking great. Or good. Or… survivable.");
}{gdjs.evtTools.variable.valuePush(runtimeScene.getScene().getVariables().getFromIndex(29), "Even your lucky socks can’t fix this mess.");
}{gdjs.evtTools.variable.valuePush(runtimeScene.getScene().getVariables().getFromIndex(29), "Red alert! And not just because of the cap.");
}}

}


};gdjs.MainCode.eventsList9 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
{gdjs.evtTools.variable.valuePush(runtimeScene.getScene().getVariables().getFromIndex(12), "BOOM! The economy just did a backflip. Investors can't stop clapping.");
}{gdjs.evtTools.variable.valuePush(runtimeScene.getScene().getVariables().getFromIndex(12), "Economy up! Experts credit... vibes? Either way, party at the stock exchange!");
}{gdjs.evtTools.variable.valuePush(runtimeScene.getScene().getVariables().getFromIndex(12), "GDP grows 420%. Coincidence or sheer genius? You decide. We already did.");
}{gdjs.evtTools.variable.valuePush(runtimeScene.getScene().getVariables().getFromIndex(12), "Economy hits all-time high! Local man tries to invest in bread & gets rich.");
}{gdjs.evtTools.variable.valuePush(runtimeScene.getScene().getVariables().getFromIndex(12), "Economy up. Billionaires cheer. Middle class confused. Poor still poor.");
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
{gdjs.evtTools.variable.valuePush(runtimeScene.getScene().getVariables().getFromIndex(13), "BREAKING: Economy tanks harder than a submarine made of duct tape.");
}{gdjs.evtTools.variable.valuePush(runtimeScene.getScene().getVariables().getFromIndex(13), "Panic! Markets fall. Stocks cry. Crypto disappears into the woods.");
}{gdjs.evtTools.variable.valuePush(runtimeScene.getScene().getVariables().getFromIndex(13), "Economy doing the worm underground. Is this... strategy? Or sabotage?");
}{gdjs.evtTools.variable.valuePush(runtimeScene.getScene().getVariables().getFromIndex(13), "Nation’s wallet empty. Experts say, ‘Oops.’ More at 11.");
}{gdjs.evtTools.variable.valuePush(runtimeScene.getScene().getVariables().getFromIndex(13), "Recession hits. Politicians blame each other. A goose is also under suspicion.");
}}

}


};gdjs.MainCode.eventsList10 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
{gdjs.evtTools.variable.valuePush(runtimeScene.getScene().getVariables().getFromIndex(24), "The people are cheering! One guy even named his dog after the President.");
}{gdjs.evtTools.variable.valuePush(runtimeScene.getScene().getVariables().getFromIndex(24), "Strong leadership or just strong vibes? Either way, things are looking up.");
}{gdjs.evtTools.variable.valuePush(runtimeScene.getScene().getVariables().getFromIndex(24), "Nation agrees: that chirp slapped. Morale is up, memes are thriving.");
}{gdjs.evtTools.variable.valuePush(runtimeScene.getScene().getVariables().getFromIndex(24), "Crowds chant, hashtags trend. Approval so high it has its own zip code.");
}{gdjs.evtTools.variable.valuePush(runtimeScene.getScene().getVariables().getFromIndex(24), "Strong leadership or just strong vibes? Either way, things are looking up.");
}{gdjs.evtTools.variable.valuePush(runtimeScene.getScene().getVariables().getFromIndex(24), "The nation claps back with applause. Approval ratings surge!");
}{gdjs.evtTools.variable.valuePush(runtimeScene.getScene().getVariables().getFromIndex(24), "Even grandma liked the chirp. That’s a historic first.");
}{gdjs.evtTools.variable.valuePush(runtimeScene.getScene().getVariables().getFromIndex(24), "Bold move pays off. Even the opposition hit like on this one.");
}{gdjs.evtTools.variable.valuePush(runtimeScene.getScene().getVariables().getFromIndex(24), "Economists confused. Citizens happy. We call that a win.");
}{gdjs.evtTools.variable.valuePush(runtimeScene.getScene().getVariables().getFromIndex(24), "This chirp might go down in history—or at least on a T-shirt.");
}{gdjs.evtTools.variable.valuePush(runtimeScene.getScene().getVariables().getFromIndex(24), "Approval numbers rising faster than your uncle’s conspiracy posts.");
}{gdjs.evtTools.variable.valuePush(runtimeScene.getScene().getVariables().getFromIndex(24), "This move united the internet. Even the comment section is civil.");
}{gdjs.evtTools.variable.valuePush(runtimeScene.getScene().getVariables().getFromIndex(24), "Sources confirm: public officially vibing with this decision.");
}{gdjs.evtTools.variable.valuePush(runtimeScene.getScene().getVariables().getFromIndex(24), "Smart. Sharp. Slightly chaotic. Just how the people like it.");
}{gdjs.evtTools.variable.valuePush(runtimeScene.getScene().getVariables().getFromIndex(24), "Major win for the country. Minor boost to cap sales. Everyone wins.");
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
{gdjs.evtTools.variable.valuePush(runtimeScene.getScene().getVariables().getFromIndex(25), "Approval rating dives faster than a cat off a kitchen counter.");
}{gdjs.evtTools.variable.valuePush(runtimeScene.getScene().getVariables().getFromIndex(25), "Protests sparked by... a typo? Public approval hits snooze.");
}{gdjs.evtTools.variable.valuePush(runtimeScene.getScene().getVariables().getFromIndex(25), "Nation confused, concerned, and mildly offended by that chirp.");
}{gdjs.evtTools.variable.valuePush(runtimeScene.getScene().getVariables().getFromIndex(25), "If this were a popularity contest, you just got voted off the island.");
}{gdjs.evtTools.variable.valuePush(runtimeScene.getScene().getVariables().getFromIndex(25), "Nation collectively cringes. Approval rating enters free fall.");
}{gdjs.evtTools.variable.valuePush(runtimeScene.getScene().getVariables().getFromIndex(25), "Experts baffled. Public annoyed. Interns crying.");
}{gdjs.evtTools.variable.valuePush(runtimeScene.getScene().getVariables().getFromIndex(25), "Bold choice. Wrong timeline.");
}{gdjs.evtTools.variable.valuePush(runtimeScene.getScene().getVariables().getFromIndex(25), "This move made grandma cancel her internet subscription. Again");
}{gdjs.evtTools.variable.valuePush(runtimeScene.getScene().getVariables().getFromIndex(25), "Chirp heard around the world… and instantly regretted.");
}{gdjs.evtTools.variable.valuePush(runtimeScene.getScene().getVariables().getFromIndex(25), "If bad PR had a ringtone, it just played loudly.");
}{gdjs.evtTools.variable.valuePush(runtimeScene.getScene().getVariables().getFromIndex(25), "The nation is confused, but mostly disappointed.");
}{gdjs.evtTools.variable.valuePush(runtimeScene.getScene().getVariables().getFromIndex(25), "Press conferences can’t fix this. Not even memes can.");
}{gdjs.evtTools.variable.valuePush(runtimeScene.getScene().getVariables().getFromIndex(25), "Critics call it ‘innovatively bad.’ Supporters just vanished.");
}}

}


};gdjs.MainCode.eventsList11 = function(runtimeScene) {

{


gdjs.MainCode.eventsList1(runtimeScene);
}


{


gdjs.MainCode.eventsList2(runtimeScene);
}


{


gdjs.MainCode.eventsList3(runtimeScene);
}


{


gdjs.MainCode.eventsList4(runtimeScene);
}


{


gdjs.MainCode.eventsList5(runtimeScene);
}


{


gdjs.MainCode.eventsList6(runtimeScene);
}


{


gdjs.MainCode.eventsList7(runtimeScene);
}


{


gdjs.MainCode.eventsList8(runtimeScene);
}


{


gdjs.MainCode.eventsList9(runtimeScene);
}


{


gdjs.MainCode.eventsList10(runtimeScene);
}


};gdjs.MainCode.eventsList12 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("BlackScreen"), gdjs.MainCode.GDBlackScreenObjects2);
gdjs.copyArray(runtimeScene.getObjects("Restart_button"), gdjs.MainCode.GDRestart_9595buttonObjects2);
{gdjs.evtTools.camera.hideLayer(runtimeScene, "BlackScreen");
}{for(var i = 0, len = gdjs.MainCode.GDBlackScreenObjects2.length ;i < len;++i) {
    gdjs.MainCode.GDBlackScreenObjects2[i].getBehavior("Opacity").setOpacity(0);
}
}{for(var i = 0, len = gdjs.MainCode.GDRestart_9595buttonObjects2.length ;i < len;++i) {
    gdjs.MainCode.GDRestart_9595buttonObjects2[i].hide();
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Cap_comments"), gdjs.MainCode.GDCap_9595commentsObjects2);
{runtimeScene.getScene().getVariables().getFromIndex(0).setNumber(1);
}{runtimeScene.getScene().getVariables().getFromIndex(7).setString("TUTORIAL");
}{for(var i = 0, len = gdjs.MainCode.GDCap_9595commentsObjects2.length ;i < len;++i) {
    gdjs.MainCode.GDCap_9595commentsObjects2[i].getBehavior("Text").setText("[ CLICK ON ME! ]");
}
}{runtimeScene.getScene().getVariables().getFromIndex(3).setNumber(6);
}{runtimeScene.getScene().getVariables().getFromIndex(4).setNumber(6);
}{runtimeScene.getScene().getVariables().getFromIndex(6).setNumber(1);
}{runtimeScene.getScene().getVariables().getFromIndex(5).setNumber(2);
}{runtimeScene.getScene().getVariables().getFromIndex(8).setNumber(gdjs.randomInRange(0, 2));
}{runtimeScene.getScene().getVariables().getFromIndex(1).setString("Aliens");
}
{ //Subevents
gdjs.MainCode.eventsList11(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(21).setBoolean(false);
}{runtimeScene.getScene().getVariables().getFromIndex(22).setBoolean(false);
}{runtimeScene.getScene().getVariables().getFromIndex(23).setBoolean(false);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(18).setNumber(gdjs.randomInRange(50, 99));
}{runtimeScene.getScene().getVariables().getFromIndex(19).setNumber(gdjs.randomInRange(50, 99));
}{runtimeScene.getScene().getVariables().getFromIndex(20).setNumber(gdjs.randomInRange(50, 99));
}}

}


};gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDNext_95959595buttonObjects2Objects = Hashtable.newFrom({"Next_button": gdjs.MainCode.GDNext_9595buttonObjects2});
gdjs.MainCode.eventsList13 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(11474196);
}
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(0).add(1);
}}

}


};gdjs.MainCode.eventsList14 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableChildCount(runtimeScene.getScene().getVariables().getFromIndex(9)) > 0;
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "assets\\Sounds\\rooster-call-cock-a-doodle-doo-46096.mp3", 2, false, 100, 1);
}{runtimeScene.getScene().getVariables().getFromIndex(7).setString("CLOSING");
}
{ //Subevents
gdjs.MainCode.eventsList13(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableChildCount(runtimeScene.getScene().getVariables().getFromIndex(9)) == 0;
}
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(7).setString("WIN_LOSE");
}}

}


};gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDNext_95959595buttonObjects1Objects = Hashtable.newFrom({"Next_button": gdjs.MainCode.GDNext_9595buttonObjects1});
gdjs.MainCode.eventsList15 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("NextText"), gdjs.MainCode.GDNextTextObjects2);
gdjs.copyArray(runtimeScene.getObjects("Next_button"), gdjs.MainCode.GDNext_9595buttonObjects2);
{for(var i = 0, len = gdjs.MainCode.GDNext_9595buttonObjects2.length ;i < len;++i) {
    gdjs.MainCode.GDNext_9595buttonObjects2[i].hide();
}
for(var i = 0, len = gdjs.MainCode.GDNextTextObjects2.length ;i < len;++i) {
    gdjs.MainCode.GDNextTextObjects2[i].hide();
}
}{runtimeScene.getScene().getVariables().getFromIndex(26).setBoolean(false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Next_button"), gdjs.MainCode.GDNext_9595buttonObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDNext_95959595buttonObjects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
/* Reuse gdjs.MainCode.GDNext_9595buttonObjects2 */
{for(var i = 0, len = gdjs.MainCode.GDNext_9595buttonObjects2.length ;i < len;++i) {
    gdjs.MainCode.GDNext_9595buttonObjects2[i].getBehavior("ShakeObject_PositionAngleScale").StopShaking((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}
{ //Subevents
gdjs.MainCode.eventsList14(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Next_button"), gdjs.MainCode.GDNext_9595buttonObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDNext_95959595buttonObjects1Objects, runtimeScene, true, true);
if (isConditionTrue_0) {
/* Reuse gdjs.MainCode.GDNext_9595buttonObjects1 */
{for(var i = 0, len = gdjs.MainCode.GDNext_9595buttonObjects1.length ;i < len;++i) {
    gdjs.MainCode.GDNext_9595buttonObjects1[i].getBehavior("ShakeObject_PositionAngleScale").ShakeObject_PositionAngleScale(1, 0, 0, 0, 20, 0.2, true, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


};gdjs.MainCode.eventsList16 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
{gdjs.evtTools.variable.valuePush(runtimeScene.getScene().getVariables().getFromIndex(9), "Aliens");
}{gdjs.evtTools.variable.valuePush(runtimeScene.getScene().getVariables().getFromIndex(9), "KetchupShortage");
}{gdjs.evtTools.variable.valuePush(runtimeScene.getScene().getVariables().getFromIndex(9), "HamsterEscapes");
}{gdjs.evtTools.variable.valuePush(runtimeScene.getScene().getVariables().getFromIndex(9), "SunglassesDay");
}{gdjs.evtTools.variable.valuePush(runtimeScene.getScene().getVariables().getFromIndex(9), "HotdogDeclaredaVegetable");
}{gdjs.evtTools.variable.valuePush(runtimeScene.getScene().getVariables().getFromIndex(9), "InternetBlackoutRumor");
}{gdjs.evtTools.variable.valuePush(runtimeScene.getScene().getVariables().getFromIndex(9), "AGooseWinsLocalElection");
}{gdjs.evtTools.variable.valuePush(runtimeScene.getScene().getVariables().getFromIndex(9), "FliopFlopDanceCausesMildEarthquake");
}{gdjs.evtTools.variable.valuePush(runtimeScene.getScene().getVariables().getFromIndex(9), "AIWritesNationalAnthemRemix");
}{gdjs.evtTools.variable.valuePush(runtimeScene.getScene().getVariables().getFromIndex(9), "DogsLearntoUseTablets");
}}

}


};gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDRestart_95959595buttonObjects2Objects = Hashtable.newFrom({"Restart_button": gdjs.MainCode.GDRestart_9595buttonObjects2});
gdjs.MainCode.eventsList17 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Main", false);
}}

}


};gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDRestart_95959595buttonObjects2Objects = Hashtable.newFrom({"Restart_button": gdjs.MainCode.GDRestart_9595buttonObjects2});
gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDSoundToggleObjects3Objects = Hashtable.newFrom({"SoundToggle": gdjs.MainCode.GDSoundToggleObjects3});
gdjs.MainCode.eventsList18 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getScene().getVariables().getFromIndex(27).getAsBoolean();
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "assets\\Sounds\\Cat caffe.mp3", 1, true, 80, 1);
}{gdjs.evtTools.sound.continueSoundOnChannel(runtimeScene, 2);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = !runtimeScene.getScene().getVariables().getFromIndex(27).getAsBoolean();
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.pauseSoundOnChannel(runtimeScene, 1);
}{gdjs.evtTools.sound.stopSoundOnChannel(runtimeScene, 2);
}}

}


};gdjs.MainCode.eventsList19 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("SoundToggle"), gdjs.MainCode.GDSoundToggleObjects3);
{for(var i = 0, len = gdjs.MainCode.GDSoundToggleObjects3.length ;i < len;++i) {
    gdjs.MainCode.GDSoundToggleObjects3[i].SetChecked(true, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.MainCode.GDSoundToggleObjects3.length ;i < len;++i) {
    gdjs.MainCode.GDSoundToggleObjects3[i].getBehavior("Opacity").setOpacity(128);
}
}{runtimeScene.getScene().getVariables().getFromIndex(27).setBoolean(true);
}{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "assets\\Sounds\\Cat caffe.mp3", 1, true, 80, 1);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("SoundToggle"), gdjs.MainCode.GDSoundToggleObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDSoundToggleObjects3Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15049556);
}
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.variable.toggleVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(27));
}
{ //Subevents
gdjs.MainCode.eventsList18(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("SoundToggle"), gdjs.MainCode.GDSoundToggleObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.MainCode.GDSoundToggleObjects3.length;i<l;++i) {
    if ( gdjs.MainCode.GDSoundToggleObjects3[i].IsHovered((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.MainCode.GDSoundToggleObjects3[k] = gdjs.MainCode.GDSoundToggleObjects3[i];
        ++k;
    }
}
gdjs.MainCode.GDSoundToggleObjects3.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.MainCode.GDSoundToggleObjects3 */
{for(var i = 0, len = gdjs.MainCode.GDSoundToggleObjects3.length ;i < len;++i) {
    gdjs.MainCode.GDSoundToggleObjects3[i].getBehavior("Opacity").setOpacity(255);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("SoundToggle"), gdjs.MainCode.GDSoundToggleObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.MainCode.GDSoundToggleObjects3.length;i<l;++i) {
    if ( !(gdjs.MainCode.GDSoundToggleObjects3[i].IsHovered((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))) ) {
        isConditionTrue_0 = true;
        gdjs.MainCode.GDSoundToggleObjects3[k] = gdjs.MainCode.GDSoundToggleObjects3[i];
        ++k;
    }
}
gdjs.MainCode.GDSoundToggleObjects3.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.MainCode.GDSoundToggleObjects3 */
{for(var i = 0, len = gdjs.MainCode.GDSoundToggleObjects3.length ;i < len;++i) {
    gdjs.MainCode.GDSoundToggleObjects3[i].getBehavior("Opacity").setOpacity(128);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = !runtimeScene.getScene().getVariables().getFromIndex(27).getAsBoolean();
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(11370556);
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.pauseSoundOnChannel(runtimeScene, 1);
}{gdjs.evtTools.sound.stopSoundOnChannel(runtimeScene, 2);
}}

}


};gdjs.MainCode.eventsList20 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Bars_cover_blue"), gdjs.MainCode.GDBars_9595cover_9595blueObjects2);
gdjs.copyArray(runtimeScene.getObjects("Bars_cover_green"), gdjs.MainCode.GDBars_9595cover_9595greenObjects2);
gdjs.copyArray(runtimeScene.getObjects("Bars_cover_orange"), gdjs.MainCode.GDBars_9595cover_9595orangeObjects2);
gdjs.copyArray(runtimeScene.getObjects("Bars_cover_pink"), gdjs.MainCode.GDBars_9595cover_9595pinkObjects2);
gdjs.copyArray(runtimeScene.getObjects("EconomyTxt"), gdjs.MainCode.GDEconomyTxtObjects2);
gdjs.copyArray(runtimeScene.getObjects("PersonalGainsTxt"), gdjs.MainCode.GDPersonalGainsTxtObjects2);
gdjs.copyArray(runtimeScene.getObjects("PublicApprovalTxt"), gdjs.MainCode.GDPublicApprovalTxtObjects2);
gdjs.copyArray(runtimeScene.getObjects("ScandalRiskTxt"), gdjs.MainCode.GDScandalRiskTxtObjects2);
{for(var i = 0, len = gdjs.MainCode.GDBars_9595cover_9595greenObjects2.length ;i < len;++i) {
    gdjs.MainCode.GDBars_9595cover_9595greenObjects2[i].getBehavior("Scale").setScaleX(1 - 0.1 * runtimeScene.getScene().getVariables().getFromIndex(3).getAsNumber());
}
}{for(var i = 0, len = gdjs.MainCode.GDBars_9595cover_9595blueObjects2.length ;i < len;++i) {
    gdjs.MainCode.GDBars_9595cover_9595blueObjects2[i].getBehavior("Scale").setScaleX(1 - 0.1 * runtimeScene.getScene().getVariables().getFromIndex(4).getAsNumber());
}
}{for(var i = 0, len = gdjs.MainCode.GDBars_9595cover_9595orangeObjects2.length ;i < len;++i) {
    gdjs.MainCode.GDBars_9595cover_9595orangeObjects2[i].getBehavior("Scale").setScaleX(1 - 0.1 * runtimeScene.getScene().getVariables().getFromIndex(5).getAsNumber());
}
}{for(var i = 0, len = gdjs.MainCode.GDBars_9595cover_9595pinkObjects2.length ;i < len;++i) {
    gdjs.MainCode.GDBars_9595cover_9595pinkObjects2[i].getBehavior("Scale").setScaleX(1 - 0.1 * runtimeScene.getScene().getVariables().getFromIndex(6).getAsNumber());
}
}{for(var i = 0, len = gdjs.MainCode.GDEconomyTxtObjects2.length ;i < len;++i) {
    gdjs.MainCode.GDEconomyTxtObjects2[i].getBehavior("Text").setText("Economy = " + gdjs.evtTools.common.toString(runtimeScene.getScene().getVariables().getFromIndex(3).getAsNumber()));
}
}{for(var i = 0, len = gdjs.MainCode.GDPublicApprovalTxtObjects2.length ;i < len;++i) {
    gdjs.MainCode.GDPublicApprovalTxtObjects2[i].getBehavior("Text").setText("Public Approval = " + gdjs.evtTools.common.toString(runtimeScene.getScene().getVariables().getFromIndex(4).getAsNumber()));
}
}{for(var i = 0, len = gdjs.MainCode.GDScandalRiskTxtObjects2.length ;i < len;++i) {
    gdjs.MainCode.GDScandalRiskTxtObjects2[i].getBehavior("Text").setText("Risk of Scandal = " + gdjs.evtTools.common.toString(runtimeScene.getScene().getVariables().getFromIndex(5).getAsNumber()));
}
}{for(var i = 0, len = gdjs.MainCode.GDPersonalGainsTxtObjects2.length ;i < len;++i) {
    gdjs.MainCode.GDPersonalGainsTxtObjects2[i].getBehavior("Text").setText("Personal Wealth = " + gdjs.evtTools.common.toString(runtimeScene.getScene().getVariables().getFromIndex(6).getAsNumber()));
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(3).getAsNumber() < 0);
}
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(3).setNumber(0);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(3).getAsNumber() > 10);
}
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(3).setNumber(10);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(6).getAsNumber() < 0);
}
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(6).setNumber(0);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(6).getAsNumber() > 10);
}
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(6).setNumber(10);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(4).getAsNumber() < 0);
}
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(4).setNumber(0);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(4).getAsNumber() > 10);
}
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(4).setNumber(10);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(5).getAsNumber() < 0);
}
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(5).setNumber(0);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(5).getAsNumber() > 10);
}
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(5).setNumber(10);
}}

}


};gdjs.MainCode.eventsList21 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Restart_button"), gdjs.MainCode.GDRestart_9595buttonObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDRestart_95959595buttonObjects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
/* Reuse gdjs.MainCode.GDRestart_9595buttonObjects2 */
{for(var i = 0, len = gdjs.MainCode.GDRestart_9595buttonObjects2.length ;i < len;++i) {
    gdjs.MainCode.GDRestart_9595buttonObjects2[i].getBehavior("Opacity").setOpacity(255);
}
}
{ //Subevents
gdjs.MainCode.eventsList17(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Restart_button"), gdjs.MainCode.GDRestart_9595buttonObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDRestart_95959595buttonObjects2Objects, runtimeScene, true, true);
if (isConditionTrue_0) {
/* Reuse gdjs.MainCode.GDRestart_9595buttonObjects2 */
{for(var i = 0, len = gdjs.MainCode.GDRestart_9595buttonObjects2.length ;i < len;++i) {
    gdjs.MainCode.GDRestart_9595buttonObjects2[i].getBehavior("Opacity").setOpacity(150);
}
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("DayTxt"), gdjs.MainCode.GDDayTxtObjects2);
{for(var i = 0, len = gdjs.MainCode.GDDayTxtObjects2.length ;i < len;++i) {
    gdjs.MainCode.GDDayTxtObjects2[i].getBehavior("Text").setText("Day " + gdjs.evtTools.common.toString(runtimeScene.getScene().getVariables().getFromIndex(0).getAsNumber()) + "/11");
}
}}

}


{


gdjs.MainCode.eventsList19(runtimeScene);
}


{


gdjs.MainCode.eventsList20(runtimeScene);
}


};gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDCapObjects2Objects = Hashtable.newFrom({"Cap": gdjs.MainCode.GDCapObjects2});
gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDCapObjects1Objects = Hashtable.newFrom({"Cap": gdjs.MainCode.GDCapObjects1});
gdjs.MainCode.eventsList22 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Cap"), gdjs.MainCode.GDCapObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDCapObjects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
/* Reuse gdjs.MainCode.GDCapObjects2 */
{for(var i = 0, len = gdjs.MainCode.GDCapObjects2.length ;i < len;++i) {
    gdjs.MainCode.GDCapObjects2[i].getBehavior("Animation").setAnimationName("Hover");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Cap"), gdjs.MainCode.GDCapObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDCapObjects1Objects, runtimeScene, true, true);
if (isConditionTrue_0) {
/* Reuse gdjs.MainCode.GDCapObjects1 */
{for(var i = 0, len = gdjs.MainCode.GDCapObjects1.length ;i < len;++i) {
    gdjs.MainCode.GDCapObjects1[i].getBehavior("Animation").setAnimationName("Default");
}
}}

}


};gdjs.MainCode.eventsList23 = function(runtimeScene) {

{


gdjs.MainCode.eventsList22(runtimeScene);
}


};gdjs.MainCode.eventsList24 = function(runtimeScene) {

{



}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("FireText1"), gdjs.MainCode.GDFireText1Objects2);
gdjs.copyArray(runtimeScene.getObjects("FireText2"), gdjs.MainCode.GDFireText2Objects2);
gdjs.copyArray(runtimeScene.getObjects("FireText3"), gdjs.MainCode.GDFireText3Objects2);
gdjs.copyArray(runtimeScene.getObjects("FireText5"), gdjs.MainCode.GDFireText5Objects2);
gdjs.copyArray(runtimeScene.getObjects("FireText6"), gdjs.MainCode.GDFireText6Objects2);
gdjs.copyArray(runtimeScene.getObjects("HeartText1"), gdjs.MainCode.GDHeartText1Objects2);
gdjs.copyArray(runtimeScene.getObjects("HeartText2"), gdjs.MainCode.GDHeartText2Objects2);
gdjs.copyArray(runtimeScene.getObjects("HeartText3"), gdjs.MainCode.GDHeartText3Objects2);
gdjs.copyArray(runtimeScene.getObjects("HeartText5"), gdjs.MainCode.GDHeartText5Objects2);
gdjs.copyArray(runtimeScene.getObjects("HeartText6"), gdjs.MainCode.GDHeartText6Objects2);
gdjs.copyArray(runtimeScene.getObjects("LikeText1"), gdjs.MainCode.GDLikeText1Objects2);
gdjs.copyArray(runtimeScene.getObjects("LikeText2"), gdjs.MainCode.GDLikeText2Objects2);
gdjs.copyArray(runtimeScene.getObjects("LikeText3"), gdjs.MainCode.GDLikeText3Objects2);
gdjs.copyArray(runtimeScene.getObjects("LikeText5"), gdjs.MainCode.GDLikeText5Objects2);
gdjs.copyArray(runtimeScene.getObjects("LikeText6"), gdjs.MainCode.GDLikeText6Objects2);
gdjs.copyArray(runtimeScene.getObjects("TweetFace1"), gdjs.MainCode.GDTweetFace1Objects2);
gdjs.copyArray(runtimeScene.getObjects("TweetFace2"), gdjs.MainCode.GDTweetFace2Objects2);
gdjs.copyArray(runtimeScene.getObjects("TweetFace3"), gdjs.MainCode.GDTweetFace3Objects2);
gdjs.copyArray(runtimeScene.getObjects("TweetFace5"), gdjs.MainCode.GDTweetFace5Objects2);
gdjs.copyArray(runtimeScene.getObjects("TweetFace6"), gdjs.MainCode.GDTweetFace6Objects2);
gdjs.copyArray(runtimeScene.getObjects("TweetTitle1"), gdjs.MainCode.GDTweetTitle1Objects2);
gdjs.copyArray(runtimeScene.getObjects("TweetTitle2"), gdjs.MainCode.GDTweetTitle2Objects2);
gdjs.copyArray(runtimeScene.getObjects("TweetTitle3"), gdjs.MainCode.GDTweetTitle3Objects2);
gdjs.copyArray(runtimeScene.getObjects("TweetTitle5"), gdjs.MainCode.GDTweetTitle5Objects2);
gdjs.copyArray(runtimeScene.getObjects("TweetTitle6"), gdjs.MainCode.GDTweetTitle6Objects2);
{for(var i = 0, len = gdjs.MainCode.GDTweetTitle1Objects2.length ;i < len;++i) {
    gdjs.MainCode.GDTweetTitle1Objects2[i].getBehavior("Text").setText(runtimeScene.getScene().getVariables().getFromIndex(10).getChild(gdjs.randomInRange(0, 14)).getAsString());
}
}{for(var i = 0, len = gdjs.MainCode.GDTweetTitle2Objects2.length ;i < len;++i) {
    gdjs.MainCode.GDTweetTitle2Objects2[i].getBehavior("Text").setText(runtimeScene.getScene().getVariables().getFromIndex(10).getChild(gdjs.randomInRange(0, 14)).getAsString());
}
}{for(var i = 0, len = gdjs.MainCode.GDTweetTitle3Objects2.length ;i < len;++i) {
    gdjs.MainCode.GDTweetTitle3Objects2[i].getBehavior("Text").setText(runtimeScene.getScene().getVariables().getFromIndex(10).getChild(gdjs.randomInRange(0, 14)).getAsString());
}
}{for(var i = 0, len = gdjs.MainCode.GDTweetTitle5Objects2.length ;i < len;++i) {
    gdjs.MainCode.GDTweetTitle5Objects2[i].getBehavior("Text").setText(runtimeScene.getScene().getVariables().getFromIndex(10).getChild(gdjs.randomInRange(0, 14)).getAsString());
}
}{for(var i = 0, len = gdjs.MainCode.GDTweetTitle6Objects2.length ;i < len;++i) {
    gdjs.MainCode.GDTweetTitle6Objects2[i].getBehavior("Text").setText(runtimeScene.getScene().getVariables().getFromIndex(10).getChild(gdjs.randomInRange(0, 14)).getAsString());
}
}{for(var i = 0, len = gdjs.MainCode.GDTweetFace1Objects2.length ;i < len;++i) {
    gdjs.MainCode.GDTweetFace1Objects2[i].getBehavior("Animation").setAnimationIndex(gdjs.randomInRange(0, 5));
}
}{for(var i = 0, len = gdjs.MainCode.GDTweetFace2Objects2.length ;i < len;++i) {
    gdjs.MainCode.GDTweetFace2Objects2[i].getBehavior("Animation").setAnimationIndex(gdjs.randomInRange(0, 5));
}
}{for(var i = 0, len = gdjs.MainCode.GDTweetFace3Objects2.length ;i < len;++i) {
    gdjs.MainCode.GDTweetFace3Objects2[i].getBehavior("Animation").setAnimationIndex(gdjs.randomInRange(0, 5));
}
}{for(var i = 0, len = gdjs.MainCode.GDTweetFace5Objects2.length ;i < len;++i) {
    gdjs.MainCode.GDTweetFace5Objects2[i].getBehavior("Animation").setAnimationIndex(gdjs.randomInRange(0, 5));
}
}{for(var i = 0, len = gdjs.MainCode.GDTweetFace6Objects2.length ;i < len;++i) {
    gdjs.MainCode.GDTweetFace6Objects2[i].getBehavior("Animation").setAnimationIndex(gdjs.randomInRange(0, 5));
}
}{for(var i = 0, len = gdjs.MainCode.GDFireText1Objects2.length ;i < len;++i) {
    gdjs.MainCode.GDFireText1Objects2[i].getBehavior("Text").setText(gdjs.evtTools.common.toString(gdjs.randomInRange(10, 99)));
}
}{for(var i = 0, len = gdjs.MainCode.GDFireText2Objects2.length ;i < len;++i) {
    gdjs.MainCode.GDFireText2Objects2[i].getBehavior("Text").setText(gdjs.evtTools.common.toString(gdjs.randomInRange(10, 99)));
}
}{for(var i = 0, len = gdjs.MainCode.GDFireText3Objects2.length ;i < len;++i) {
    gdjs.MainCode.GDFireText3Objects2[i].getBehavior("Text").setText(gdjs.evtTools.common.toString(gdjs.randomInRange(10, 99)));
}
}{for(var i = 0, len = gdjs.MainCode.GDFireText5Objects2.length ;i < len;++i) {
    gdjs.MainCode.GDFireText5Objects2[i].getBehavior("Text").setText(gdjs.evtTools.common.toString(gdjs.randomInRange(10, 99)));
}
}{for(var i = 0, len = gdjs.MainCode.GDFireText6Objects2.length ;i < len;++i) {
    gdjs.MainCode.GDFireText6Objects2[i].getBehavior("Text").setText(gdjs.evtTools.common.toString(gdjs.randomInRange(10, 99)));
}
}{for(var i = 0, len = gdjs.MainCode.GDHeartText1Objects2.length ;i < len;++i) {
    gdjs.MainCode.GDHeartText1Objects2[i].getBehavior("Text").setText(gdjs.evtTools.common.toString(gdjs.randomInRange(10, 99)));
}
}{for(var i = 0, len = gdjs.MainCode.GDHeartText2Objects2.length ;i < len;++i) {
    gdjs.MainCode.GDHeartText2Objects2[i].getBehavior("Text").setText(gdjs.evtTools.common.toString(gdjs.randomInRange(10, 99)));
}
}{for(var i = 0, len = gdjs.MainCode.GDHeartText3Objects2.length ;i < len;++i) {
    gdjs.MainCode.GDHeartText3Objects2[i].getBehavior("Text").setText(gdjs.evtTools.common.toString(gdjs.randomInRange(10, 99)));
}
}{for(var i = 0, len = gdjs.MainCode.GDHeartText5Objects2.length ;i < len;++i) {
    gdjs.MainCode.GDHeartText5Objects2[i].getBehavior("Text").setText(gdjs.evtTools.common.toString(gdjs.randomInRange(10, 99)));
}
}{for(var i = 0, len = gdjs.MainCode.GDHeartText6Objects2.length ;i < len;++i) {
    gdjs.MainCode.GDHeartText6Objects2[i].getBehavior("Text").setText(gdjs.evtTools.common.toString(gdjs.randomInRange(10, 99)));
}
}{for(var i = 0, len = gdjs.MainCode.GDLikeText1Objects2.length ;i < len;++i) {
    gdjs.MainCode.GDLikeText1Objects2[i].getBehavior("Text").setText(gdjs.evtTools.common.toString(gdjs.randomInRange(10, 99)));
}
}{for(var i = 0, len = gdjs.MainCode.GDLikeText2Objects2.length ;i < len;++i) {
    gdjs.MainCode.GDLikeText2Objects2[i].getBehavior("Text").setText(gdjs.evtTools.common.toString(gdjs.randomInRange(10, 99)));
}
}{for(var i = 0, len = gdjs.MainCode.GDLikeText3Objects2.length ;i < len;++i) {
    gdjs.MainCode.GDLikeText3Objects2[i].getBehavior("Text").setText(gdjs.evtTools.common.toString(gdjs.randomInRange(10, 99)));
}
}{for(var i = 0, len = gdjs.MainCode.GDLikeText5Objects2.length ;i < len;++i) {
    gdjs.MainCode.GDLikeText5Objects2[i].getBehavior("Text").setText(gdjs.evtTools.common.toString(gdjs.randomInRange(10, 99)));
}
}{for(var i = 0, len = gdjs.MainCode.GDLikeText6Objects2.length ;i < len;++i) {
    gdjs.MainCode.GDLikeText6Objects2[i].getBehavior("Text").setText(gdjs.evtTools.common.toString(gdjs.randomInRange(10, 99)));
}
}}

}


};gdjs.MainCode.eventsList25 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15070660);
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.MainCode.eventsList24(runtimeScene);} //End of subevents
}

}


};gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDCapObjects2Objects = Hashtable.newFrom({"Cap": gdjs.MainCode.GDCapObjects2});
gdjs.MainCode.asyncCallback15071484 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.MainCode.localVariables);
gdjs.copyArray(asyncObjectsList.getObjects("Cap_comments"), gdjs.MainCode.GDCap_9595commentsObjects3);

gdjs.copyArray(runtimeScene.getObjects("Cap_faces"), gdjs.MainCode.GDCap_9595facesObjects3);
{for(var i = 0, len = gdjs.MainCode.GDCap_9595commentsObjects3.length ;i < len;++i) {
    gdjs.MainCode.GDCap_9595commentsObjects3[i].getBehavior("Text").setText("Welcome, President! Let’s make riches great again. I'll advice you");
}
}{for(var i = 0, len = gdjs.MainCode.GDCap_9595facesObjects3.length ;i < len;++i) {
    gdjs.MainCode.GDCap_9595facesObjects3[i].getBehavior("Animation").setAnimationName("Happy1");
}
}gdjs.MainCode.localVariables.length = 0;
}
gdjs.MainCode.eventsList26 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.MainCode.localVariables);
for (const obj of gdjs.MainCode.GDCap_9595commentsObjects2) asyncObjectsList.addObject("Cap_comments", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.5), (runtimeScene) => (gdjs.MainCode.asyncCallback15071484(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDCapObjects2Objects = Hashtable.newFrom({"Cap": gdjs.MainCode.GDCapObjects2});
gdjs.MainCode.asyncCallback15073452 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.MainCode.localVariables);
gdjs.copyArray(asyncObjectsList.getObjects("Cap_comments"), gdjs.MainCode.GDCap_9595commentsObjects3);

gdjs.copyArray(runtimeScene.getObjects("Cap_faces"), gdjs.MainCode.GDCap_9595facesObjects3);
gdjs.copyArray(runtimeScene.getObjects("EconomyTxt"), gdjs.MainCode.GDEconomyTxtObjects3);
gdjs.copyArray(runtimeScene.getObjects("Green_bars"), gdjs.MainCode.GDGreen_9595barsObjects3);
gdjs.copyArray(runtimeScene.getObjects("PublicApprovalTxt"), gdjs.MainCode.GDPublicApprovalTxtObjects3);
gdjs.copyArray(runtimeScene.getObjects("blue_bars"), gdjs.MainCode.GDblue_9595barsObjects3);
{for(var i = 0, len = gdjs.MainCode.GDCap_9595commentsObjects3.length ;i < len;++i) {
    gdjs.MainCode.GDCap_9595commentsObjects3[i].getBehavior("Text").setText("Keep Approval & Economy above 5. Or face the heat.");
}
}{for(var i = 0, len = gdjs.MainCode.GDCap_9595facesObjects3.length ;i < len;++i) {
    gdjs.MainCode.GDCap_9595facesObjects3[i].getBehavior("Animation").setAnimationName("Happy2");
}
}{for(var i = 0, len = gdjs.MainCode.GDEconomyTxtObjects3.length ;i < len;++i) {
    gdjs.MainCode.GDEconomyTxtObjects3[i].hide(false);
}
}{for(var i = 0, len = gdjs.MainCode.GDPublicApprovalTxtObjects3.length ;i < len;++i) {
    gdjs.MainCode.GDPublicApprovalTxtObjects3[i].hide(false);
}
}{for(var i = 0, len = gdjs.MainCode.GDGreen_9595barsObjects3.length ;i < len;++i) {
    gdjs.MainCode.GDGreen_9595barsObjects3[i].hide(false);
}
}{for(var i = 0, len = gdjs.MainCode.GDblue_9595barsObjects3.length ;i < len;++i) {
    gdjs.MainCode.GDblue_9595barsObjects3[i].hide(false);
}
}gdjs.MainCode.localVariables.length = 0;
}
gdjs.MainCode.eventsList27 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.MainCode.localVariables);
for (const obj of gdjs.MainCode.GDCap_9595commentsObjects2) asyncObjectsList.addObject("Cap_comments", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.5), (runtimeScene) => (gdjs.MainCode.asyncCallback15073452(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDCapObjects2Objects = Hashtable.newFrom({"Cap": gdjs.MainCode.GDCapObjects2});
gdjs.MainCode.asyncCallback15075700 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.MainCode.localVariables);
gdjs.copyArray(asyncObjectsList.getObjects("Cap_comments"), gdjs.MainCode.GDCap_9595commentsObjects3);

gdjs.copyArray(runtimeScene.getObjects("Cap_faces"), gdjs.MainCode.GDCap_9595facesObjects3);
gdjs.copyArray(runtimeScene.getObjects("PersonalGainsTxt"), gdjs.MainCode.GDPersonalGainsTxtObjects3);
gdjs.copyArray(runtimeScene.getObjects("Pink_bars"), gdjs.MainCode.GDPink_9595barsObjects3);
{for(var i = 0, len = gdjs.MainCode.GDCap_9595commentsObjects3.length ;i < len;++i) {
    gdjs.MainCode.GDCap_9595commentsObjects3[i].getBehavior("Text").setText("Max your wealth but don’t burn the nation doing it!");
}
}{for(var i = 0, len = gdjs.MainCode.GDCap_9595facesObjects3.length ;i < len;++i) {
    gdjs.MainCode.GDCap_9595facesObjects3[i].getBehavior("Animation").setAnimationName("Smiling");
}
}{for(var i = 0, len = gdjs.MainCode.GDPink_9595barsObjects3.length ;i < len;++i) {
    gdjs.MainCode.GDPink_9595barsObjects3[i].hide(false);
}
}{for(var i = 0, len = gdjs.MainCode.GDPersonalGainsTxtObjects3.length ;i < len;++i) {
    gdjs.MainCode.GDPersonalGainsTxtObjects3[i].hide(false);
}
}gdjs.MainCode.localVariables.length = 0;
}
gdjs.MainCode.eventsList28 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.MainCode.localVariables);
for (const obj of gdjs.MainCode.GDCap_9595commentsObjects2) asyncObjectsList.addObject("Cap_comments", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.5), (runtimeScene) => (gdjs.MainCode.asyncCallback15075700(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDCapObjects2Objects = Hashtable.newFrom({"Cap": gdjs.MainCode.GDCapObjects2});
gdjs.MainCode.asyncCallback15077828 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.MainCode.localVariables);
gdjs.copyArray(asyncObjectsList.getObjects("Cap_comments"), gdjs.MainCode.GDCap_9595commentsObjects3);

gdjs.copyArray(runtimeScene.getObjects("Cap_faces"), gdjs.MainCode.GDCap_9595facesObjects3);
gdjs.copyArray(runtimeScene.getObjects("Orange_bars"), gdjs.MainCode.GDOrange_9595barsObjects3);
gdjs.copyArray(runtimeScene.getObjects("ScandalRiskTxt"), gdjs.MainCode.GDScandalRiskTxtObjects3);
{for(var i = 0, len = gdjs.MainCode.GDCap_9595commentsObjects3.length ;i < len;++i) {
    gdjs.MainCode.GDCap_9595commentsObjects3[i].getBehavior("Text").setText("Scandal hits 5? Say bye to the big desk.");
}
}{for(var i = 0, len = gdjs.MainCode.GDCap_9595facesObjects3.length ;i < len;++i) {
    gdjs.MainCode.GDCap_9595facesObjects3[i].getBehavior("Animation").setAnimationName("Scared");
}
}{for(var i = 0, len = gdjs.MainCode.GDOrange_9595barsObjects3.length ;i < len;++i) {
    gdjs.MainCode.GDOrange_9595barsObjects3[i].hide(false);
}
}{for(var i = 0, len = gdjs.MainCode.GDScandalRiskTxtObjects3.length ;i < len;++i) {
    gdjs.MainCode.GDScandalRiskTxtObjects3[i].hide(false);
}
}gdjs.MainCode.localVariables.length = 0;
}
gdjs.MainCode.eventsList29 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.MainCode.localVariables);
for (const obj of gdjs.MainCode.GDCap_9595commentsObjects2) asyncObjectsList.addObject("Cap_comments", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.5), (runtimeScene) => (gdjs.MainCode.asyncCallback15077828(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDCapObjects1Objects = Hashtable.newFrom({"Cap": gdjs.MainCode.GDCapObjects1});
gdjs.MainCode.asyncCallback15080524 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.MainCode.localVariables);
gdjs.copyArray(runtimeScene.getObjects("Chirp"), gdjs.MainCode.GDChirpObjects3);
gdjs.copyArray(runtimeScene.getObjects("DayTxt"), gdjs.MainCode.GDDayTxtObjects3);
gdjs.copyArray(runtimeScene.getObjects("EconomyTxt"), gdjs.MainCode.GDEconomyTxtObjects3);
gdjs.copyArray(runtimeScene.getObjects("FireText1"), gdjs.MainCode.GDFireText1Objects3);
gdjs.copyArray(runtimeScene.getObjects("FireText2"), gdjs.MainCode.GDFireText2Objects3);
gdjs.copyArray(runtimeScene.getObjects("FireText3"), gdjs.MainCode.GDFireText3Objects3);
gdjs.copyArray(runtimeScene.getObjects("FireText4"), gdjs.MainCode.GDFireText4Objects3);
gdjs.copyArray(runtimeScene.getObjects("FireText5"), gdjs.MainCode.GDFireText5Objects3);
gdjs.copyArray(runtimeScene.getObjects("FireText6"), gdjs.MainCode.GDFireText6Objects3);
gdjs.copyArray(runtimeScene.getObjects("Green_bars"), gdjs.MainCode.GDGreen_9595barsObjects3);
gdjs.copyArray(runtimeScene.getObjects("HeartText1"), gdjs.MainCode.GDHeartText1Objects3);
gdjs.copyArray(runtimeScene.getObjects("HeartText2"), gdjs.MainCode.GDHeartText2Objects3);
gdjs.copyArray(runtimeScene.getObjects("HeartText3"), gdjs.MainCode.GDHeartText3Objects3);
gdjs.copyArray(runtimeScene.getObjects("HeartText4"), gdjs.MainCode.GDHeartText4Objects3);
gdjs.copyArray(runtimeScene.getObjects("HeartText5"), gdjs.MainCode.GDHeartText5Objects3);
gdjs.copyArray(runtimeScene.getObjects("HeartText6"), gdjs.MainCode.GDHeartText6Objects3);
gdjs.copyArray(runtimeScene.getObjects("LikeText1"), gdjs.MainCode.GDLikeText1Objects3);
gdjs.copyArray(runtimeScene.getObjects("LikeText2"), gdjs.MainCode.GDLikeText2Objects3);
gdjs.copyArray(runtimeScene.getObjects("LikeText3"), gdjs.MainCode.GDLikeText3Objects3);
gdjs.copyArray(runtimeScene.getObjects("LikeText4"), gdjs.MainCode.GDLikeText4Objects3);
gdjs.copyArray(runtimeScene.getObjects("LikeText5"), gdjs.MainCode.GDLikeText5Objects3);
gdjs.copyArray(runtimeScene.getObjects("LikeText6"), gdjs.MainCode.GDLikeText6Objects3);
gdjs.copyArray(runtimeScene.getObjects("My_options"), gdjs.MainCode.GDMy_9595optionsObjects3);
gdjs.copyArray(runtimeScene.getObjects("Option1"), gdjs.MainCode.GDOption1Objects3);
gdjs.copyArray(runtimeScene.getObjects("Option2"), gdjs.MainCode.GDOption2Objects3);
gdjs.copyArray(runtimeScene.getObjects("Option3"), gdjs.MainCode.GDOption3Objects3);
gdjs.copyArray(runtimeScene.getObjects("OptionTxt1"), gdjs.MainCode.GDOptionTxt1Objects3);
gdjs.copyArray(runtimeScene.getObjects("OptionTxt2"), gdjs.MainCode.GDOptionTxt2Objects3);
gdjs.copyArray(runtimeScene.getObjects("OptionTxt3"), gdjs.MainCode.GDOptionTxt3Objects3);
gdjs.copyArray(runtimeScene.getObjects("Orange_bars"), gdjs.MainCode.GDOrange_9595barsObjects3);
gdjs.copyArray(runtimeScene.getObjects("PersonalGainsTxt"), gdjs.MainCode.GDPersonalGainsTxtObjects3);
gdjs.copyArray(runtimeScene.getObjects("Pink_bars"), gdjs.MainCode.GDPink_9595barsObjects3);
gdjs.copyArray(runtimeScene.getObjects("PublicApprovalTxt"), gdjs.MainCode.GDPublicApprovalTxtObjects3);
gdjs.copyArray(runtimeScene.getObjects("ReactionIcon_Fire"), gdjs.MainCode.GDReactionIcon_9595FireObjects3);
gdjs.copyArray(runtimeScene.getObjects("ReactionIcon_Like"), gdjs.MainCode.GDReactionIcon_9595LikeObjects3);
gdjs.copyArray(runtimeScene.getObjects("ReactionIcons_Heart"), gdjs.MainCode.GDReactionIcons_9595HeartObjects3);
gdjs.copyArray(runtimeScene.getObjects("ScandalRiskTxt"), gdjs.MainCode.GDScandalRiskTxtObjects3);
gdjs.copyArray(runtimeScene.getObjects("Send_icon1"), gdjs.MainCode.GDSend_9595icon1Objects3);
gdjs.copyArray(runtimeScene.getObjects("Send_icon2"), gdjs.MainCode.GDSend_9595icon2Objects3);
gdjs.copyArray(runtimeScene.getObjects("Send_icon3"), gdjs.MainCode.GDSend_9595icon3Objects3);
gdjs.copyArray(runtimeScene.getObjects("SkipTutorial"), gdjs.MainCode.GDSkipTutorialObjects3);
gdjs.copyArray(runtimeScene.getObjects("Tweet1"), gdjs.MainCode.GDTweet1Objects3);
gdjs.copyArray(runtimeScene.getObjects("Tweet2"), gdjs.MainCode.GDTweet2Objects3);
gdjs.copyArray(runtimeScene.getObjects("Tweet3"), gdjs.MainCode.GDTweet3Objects3);
gdjs.copyArray(runtimeScene.getObjects("Tweet4"), gdjs.MainCode.GDTweet4Objects3);
gdjs.copyArray(runtimeScene.getObjects("Tweet5"), gdjs.MainCode.GDTweet5Objects3);
gdjs.copyArray(runtimeScene.getObjects("Tweet6"), gdjs.MainCode.GDTweet6Objects3);
gdjs.copyArray(runtimeScene.getObjects("TweetFace1"), gdjs.MainCode.GDTweetFace1Objects3);
gdjs.copyArray(runtimeScene.getObjects("TweetFace2"), gdjs.MainCode.GDTweetFace2Objects3);
gdjs.copyArray(runtimeScene.getObjects("TweetFace3"), gdjs.MainCode.GDTweetFace3Objects3);
gdjs.copyArray(runtimeScene.getObjects("TweetFace4"), gdjs.MainCode.GDTweetFace4Objects3);
gdjs.copyArray(runtimeScene.getObjects("TweetFace5"), gdjs.MainCode.GDTweetFace5Objects3);
gdjs.copyArray(runtimeScene.getObjects("TweetFace6"), gdjs.MainCode.GDTweetFace6Objects3);
gdjs.copyArray(runtimeScene.getObjects("TweetTitle1"), gdjs.MainCode.GDTweetTitle1Objects3);
gdjs.copyArray(runtimeScene.getObjects("TweetTitle2"), gdjs.MainCode.GDTweetTitle2Objects3);
gdjs.copyArray(runtimeScene.getObjects("TweetTitle3"), gdjs.MainCode.GDTweetTitle3Objects3);
gdjs.copyArray(runtimeScene.getObjects("TweetTitle4"), gdjs.MainCode.GDTweetTitle4Objects3);
gdjs.copyArray(runtimeScene.getObjects("TweetTitle5"), gdjs.MainCode.GDTweetTitle5Objects3);
gdjs.copyArray(runtimeScene.getObjects("TweetTitle6"), gdjs.MainCode.GDTweetTitle6Objects3);
gdjs.copyArray(runtimeScene.getObjects("Tweet_bkg1"), gdjs.MainCode.GDTweet_9595bkg1Objects3);
gdjs.copyArray(runtimeScene.getObjects("Tweet_bkg2"), gdjs.MainCode.GDTweet_9595bkg2Objects3);
gdjs.copyArray(runtimeScene.getObjects("Tweet_bkg3"), gdjs.MainCode.GDTweet_9595bkg3Objects3);
gdjs.copyArray(runtimeScene.getObjects("Tweet_bkg4"), gdjs.MainCode.GDTweet_9595bkg4Objects3);
gdjs.copyArray(runtimeScene.getObjects("Tweet_bkg5"), gdjs.MainCode.GDTweet_9595bkg5Objects3);
gdjs.copyArray(runtimeScene.getObjects("Tweet_bkg6"), gdjs.MainCode.GDTweet_9595bkg6Objects3);
gdjs.copyArray(runtimeScene.getObjects("blue_bars"), gdjs.MainCode.GDblue_9595barsObjects3);
{for(var i = 0, len = gdjs.MainCode.GDSkipTutorialObjects3.length ;i < len;++i) {
    gdjs.MainCode.GDSkipTutorialObjects3[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.MainCode.GDTweet1Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDTweet1Objects3[i].hide(false);
}
for(var i = 0, len = gdjs.MainCode.GDTweetTitle1Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDTweetTitle1Objects3[i].hide(false);
}
for(var i = 0, len = gdjs.MainCode.GDHeartText1Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDHeartText1Objects3[i].hide(false);
}
for(var i = 0, len = gdjs.MainCode.GDReactionIcons_9595HeartObjects3.length ;i < len;++i) {
    gdjs.MainCode.GDReactionIcons_9595HeartObjects3[i].hide(false);
}
for(var i = 0, len = gdjs.MainCode.GDReactionIcon_9595LikeObjects3.length ;i < len;++i) {
    gdjs.MainCode.GDReactionIcon_9595LikeObjects3[i].hide(false);
}
for(var i = 0, len = gdjs.MainCode.GDLikeText1Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDLikeText1Objects3[i].hide(false);
}
for(var i = 0, len = gdjs.MainCode.GDReactionIcon_9595FireObjects3.length ;i < len;++i) {
    gdjs.MainCode.GDReactionIcon_9595FireObjects3[i].hide(false);
}
for(var i = 0, len = gdjs.MainCode.GDFireText1Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDFireText1Objects3[i].hide(false);
}
for(var i = 0, len = gdjs.MainCode.GDLikeText2Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDLikeText2Objects3[i].hide(false);
}
for(var i = 0, len = gdjs.MainCode.GDFireText2Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDFireText2Objects3[i].hide(false);
}
for(var i = 0, len = gdjs.MainCode.GDHeartText2Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDHeartText2Objects3[i].hide(false);
}
for(var i = 0, len = gdjs.MainCode.GDFireText3Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDFireText3Objects3[i].hide(false);
}
for(var i = 0, len = gdjs.MainCode.GDOption1Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDOption1Objects3[i].hide(false);
}
for(var i = 0, len = gdjs.MainCode.GDOption2Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDOption2Objects3[i].hide(false);
}
for(var i = 0, len = gdjs.MainCode.GDOption3Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDOption3Objects3[i].hide(false);
}
for(var i = 0, len = gdjs.MainCode.GDOptionTxt1Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDOptionTxt1Objects3[i].hide(false);
}
for(var i = 0, len = gdjs.MainCode.GDOptionTxt2Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDOptionTxt2Objects3[i].hide(false);
}
for(var i = 0, len = gdjs.MainCode.GDOptionTxt3Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDOptionTxt3Objects3[i].hide(false);
}
for(var i = 0, len = gdjs.MainCode.GDSend_9595icon1Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDSend_9595icon1Objects3[i].hide(false);
}
for(var i = 0, len = gdjs.MainCode.GDblue_9595barsObjects3.length ;i < len;++i) {
    gdjs.MainCode.GDblue_9595barsObjects3[i].hide(false);
}
for(var i = 0, len = gdjs.MainCode.GDGreen_9595barsObjects3.length ;i < len;++i) {
    gdjs.MainCode.GDGreen_9595barsObjects3[i].hide(false);
}
for(var i = 0, len = gdjs.MainCode.GDOrange_9595barsObjects3.length ;i < len;++i) {
    gdjs.MainCode.GDOrange_9595barsObjects3[i].hide(false);
}
for(var i = 0, len = gdjs.MainCode.GDPink_9595barsObjects3.length ;i < len;++i) {
    gdjs.MainCode.GDPink_9595barsObjects3[i].hide(false);
}
for(var i = 0, len = gdjs.MainCode.GDEconomyTxtObjects3.length ;i < len;++i) {
    gdjs.MainCode.GDEconomyTxtObjects3[i].hide(false);
}
for(var i = 0, len = gdjs.MainCode.GDPersonalGainsTxtObjects3.length ;i < len;++i) {
    gdjs.MainCode.GDPersonalGainsTxtObjects3[i].hide(false);
}
for(var i = 0, len = gdjs.MainCode.GDScandalRiskTxtObjects3.length ;i < len;++i) {
    gdjs.MainCode.GDScandalRiskTxtObjects3[i].hide(false);
}
for(var i = 0, len = gdjs.MainCode.GDPublicApprovalTxtObjects3.length ;i < len;++i) {
    gdjs.MainCode.GDPublicApprovalTxtObjects3[i].hide(false);
}
for(var i = 0, len = gdjs.MainCode.GDLikeText3Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDLikeText3Objects3[i].hide(false);
}
for(var i = 0, len = gdjs.MainCode.GDHeartText3Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDHeartText3Objects3[i].hide(false);
}
for(var i = 0, len = gdjs.MainCode.GDTweetFace3Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDTweetFace3Objects3[i].hide(false);
}
for(var i = 0, len = gdjs.MainCode.GDTweetTitle2Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDTweetTitle2Objects3[i].hide(false);
}
for(var i = 0, len = gdjs.MainCode.GDTweetTitle3Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDTweetTitle3Objects3[i].hide(false);
}
for(var i = 0, len = gdjs.MainCode.GDTweet2Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDTweet2Objects3[i].hide(false);
}
for(var i = 0, len = gdjs.MainCode.GDTweet3Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDTweet3Objects3[i].hide(false);
}
for(var i = 0, len = gdjs.MainCode.GDTweet_9595bkg1Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDTweet_9595bkg1Objects3[i].hide(false);
}
for(var i = 0, len = gdjs.MainCode.GDTweetFace2Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDTweetFace2Objects3[i].hide(false);
}
for(var i = 0, len = gdjs.MainCode.GDTweetFace1Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDTweetFace1Objects3[i].hide(false);
}
for(var i = 0, len = gdjs.MainCode.GDSend_9595icon3Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDSend_9595icon3Objects3[i].hide(false);
}
for(var i = 0, len = gdjs.MainCode.GDSend_9595icon2Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDSend_9595icon2Objects3[i].hide(false);
}
for(var i = 0, len = gdjs.MainCode.GDMy_9595optionsObjects3.length ;i < len;++i) {
    gdjs.MainCode.GDMy_9595optionsObjects3[i].hide(false);
}
for(var i = 0, len = gdjs.MainCode.GDTweetTitle6Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDTweetTitle6Objects3[i].hide(false);
}
for(var i = 0, len = gdjs.MainCode.GDTweet6Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDTweet6Objects3[i].hide(false);
}
for(var i = 0, len = gdjs.MainCode.GDChirpObjects3.length ;i < len;++i) {
    gdjs.MainCode.GDChirpObjects3[i].hide(false);
}
for(var i = 0, len = gdjs.MainCode.GDDayTxtObjects3.length ;i < len;++i) {
    gdjs.MainCode.GDDayTxtObjects3[i].hide(false);
}
for(var i = 0, len = gdjs.MainCode.GDTweet_9595bkg2Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDTweet_9595bkg2Objects3[i].hide(false);
}
for(var i = 0, len = gdjs.MainCode.GDTweet5Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDTweet5Objects3[i].hide(false);
}
for(var i = 0, len = gdjs.MainCode.GDTweet4Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDTweet4Objects3[i].hide(false);
}
for(var i = 0, len = gdjs.MainCode.GDTweetTitle5Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDTweetTitle5Objects3[i].hide(false);
}
for(var i = 0, len = gdjs.MainCode.GDTweetTitle4Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDTweetTitle4Objects3[i].hide(false);
}
for(var i = 0, len = gdjs.MainCode.GDTweet_9595bkg3Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDTweet_9595bkg3Objects3[i].hide(false);
}
for(var i = 0, len = gdjs.MainCode.GDTweet_9595bkg4Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDTweet_9595bkg4Objects3[i].hide(false);
}
for(var i = 0, len = gdjs.MainCode.GDFireText4Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDFireText4Objects3[i].hide(false);
}
for(var i = 0, len = gdjs.MainCode.GDTweet_9595bkg5Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDTweet_9595bkg5Objects3[i].hide(false);
}
for(var i = 0, len = gdjs.MainCode.GDTweet_9595bkg6Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDTweet_9595bkg6Objects3[i].hide(false);
}
for(var i = 0, len = gdjs.MainCode.GDFireText5Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDFireText5Objects3[i].hide(false);
}
for(var i = 0, len = gdjs.MainCode.GDFireText6Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDFireText6Objects3[i].hide(false);
}
for(var i = 0, len = gdjs.MainCode.GDLikeText4Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDLikeText4Objects3[i].hide(false);
}
for(var i = 0, len = gdjs.MainCode.GDLikeText5Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDLikeText5Objects3[i].hide(false);
}
for(var i = 0, len = gdjs.MainCode.GDLikeText6Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDLikeText6Objects3[i].hide(false);
}
for(var i = 0, len = gdjs.MainCode.GDHeartText4Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDHeartText4Objects3[i].hide(false);
}
for(var i = 0, len = gdjs.MainCode.GDHeartText5Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDHeartText5Objects3[i].hide(false);
}
for(var i = 0, len = gdjs.MainCode.GDHeartText6Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDHeartText6Objects3[i].hide(false);
}
for(var i = 0, len = gdjs.MainCode.GDTweetFace4Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDTweetFace4Objects3[i].hide(false);
}
for(var i = 0, len = gdjs.MainCode.GDTweetFace5Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDTweetFace5Objects3[i].hide(false);
}
for(var i = 0, len = gdjs.MainCode.GDTweetFace6Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDTweetFace6Objects3[i].hide(false);
}
}{runtimeScene.getScene().getVariables().getFromIndex(7).setString("DECISION");
}gdjs.MainCode.localVariables.length = 0;
}
gdjs.MainCode.eventsList30 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
asyncObjectsList.backupLocalVariablesContainers(gdjs.MainCode.localVariables);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(3), (runtimeScene) => (gdjs.MainCode.asyncCallback15080524(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.MainCode.asyncCallback15079868 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.MainCode.localVariables);
gdjs.copyArray(asyncObjectsList.getObjects("Cap_comments"), gdjs.MainCode.GDCap_9595commentsObjects2);

gdjs.copyArray(runtimeScene.getObjects("Cap_faces"), gdjs.MainCode.GDCap_9595facesObjects2);
{for(var i = 0, len = gdjs.MainCode.GDCap_9595facesObjects2.length ;i < len;++i) {
    gdjs.MainCode.GDCap_9595facesObjects2[i].getBehavior("Animation").setAnimationName("Laughing1");
}
}{for(var i = 0, len = gdjs.MainCode.GDCap_9595commentsObjects2.length ;i < len;++i) {
    gdjs.MainCode.GDCap_9595commentsObjects2[i].getBehavior("Text").setText("One chirp a day, Commander. Make it count! Balance for 11 days");
}
}
{ //Subevents
gdjs.MainCode.eventsList30(runtimeScene, asyncObjectsList);} //End of subevents
gdjs.MainCode.localVariables.length = 0;
}
gdjs.MainCode.eventsList31 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.MainCode.localVariables);
for (const obj of gdjs.MainCode.GDCap_9595commentsObjects1) asyncObjectsList.addObject("Cap_comments", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.5), (runtimeScene) => (gdjs.MainCode.asyncCallback15079868(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.MainCode.eventsList32 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.wasKeyReleased(runtimeScene, "s");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Chirp"), gdjs.MainCode.GDChirpObjects2);
gdjs.copyArray(runtimeScene.getObjects("DayTxt"), gdjs.MainCode.GDDayTxtObjects2);
gdjs.copyArray(runtimeScene.getObjects("EconomyTxt"), gdjs.MainCode.GDEconomyTxtObjects2);
gdjs.copyArray(runtimeScene.getObjects("FireText1"), gdjs.MainCode.GDFireText1Objects2);
gdjs.copyArray(runtimeScene.getObjects("FireText2"), gdjs.MainCode.GDFireText2Objects2);
gdjs.copyArray(runtimeScene.getObjects("FireText3"), gdjs.MainCode.GDFireText3Objects2);
gdjs.copyArray(runtimeScene.getObjects("FireText4"), gdjs.MainCode.GDFireText4Objects2);
gdjs.copyArray(runtimeScene.getObjects("FireText5"), gdjs.MainCode.GDFireText5Objects2);
gdjs.copyArray(runtimeScene.getObjects("FireText6"), gdjs.MainCode.GDFireText6Objects2);
gdjs.copyArray(runtimeScene.getObjects("Green_bars"), gdjs.MainCode.GDGreen_9595barsObjects2);
gdjs.copyArray(runtimeScene.getObjects("HeartText1"), gdjs.MainCode.GDHeartText1Objects2);
gdjs.copyArray(runtimeScene.getObjects("HeartText2"), gdjs.MainCode.GDHeartText2Objects2);
gdjs.copyArray(runtimeScene.getObjects("HeartText3"), gdjs.MainCode.GDHeartText3Objects2);
gdjs.copyArray(runtimeScene.getObjects("HeartText4"), gdjs.MainCode.GDHeartText4Objects2);
gdjs.copyArray(runtimeScene.getObjects("HeartText5"), gdjs.MainCode.GDHeartText5Objects2);
gdjs.copyArray(runtimeScene.getObjects("HeartText6"), gdjs.MainCode.GDHeartText6Objects2);
gdjs.copyArray(runtimeScene.getObjects("LikeText1"), gdjs.MainCode.GDLikeText1Objects2);
gdjs.copyArray(runtimeScene.getObjects("LikeText2"), gdjs.MainCode.GDLikeText2Objects2);
gdjs.copyArray(runtimeScene.getObjects("LikeText3"), gdjs.MainCode.GDLikeText3Objects2);
gdjs.copyArray(runtimeScene.getObjects("LikeText4"), gdjs.MainCode.GDLikeText4Objects2);
gdjs.copyArray(runtimeScene.getObjects("LikeText5"), gdjs.MainCode.GDLikeText5Objects2);
gdjs.copyArray(runtimeScene.getObjects("LikeText6"), gdjs.MainCode.GDLikeText6Objects2);
gdjs.copyArray(runtimeScene.getObjects("My_options"), gdjs.MainCode.GDMy_9595optionsObjects2);
gdjs.copyArray(runtimeScene.getObjects("Option1"), gdjs.MainCode.GDOption1Objects2);
gdjs.copyArray(runtimeScene.getObjects("Option2"), gdjs.MainCode.GDOption2Objects2);
gdjs.copyArray(runtimeScene.getObjects("Option3"), gdjs.MainCode.GDOption3Objects2);
gdjs.copyArray(runtimeScene.getObjects("OptionTxt1"), gdjs.MainCode.GDOptionTxt1Objects2);
gdjs.copyArray(runtimeScene.getObjects("OptionTxt2"), gdjs.MainCode.GDOptionTxt2Objects2);
gdjs.copyArray(runtimeScene.getObjects("OptionTxt3"), gdjs.MainCode.GDOptionTxt3Objects2);
gdjs.copyArray(runtimeScene.getObjects("Orange_bars"), gdjs.MainCode.GDOrange_9595barsObjects2);
gdjs.copyArray(runtimeScene.getObjects("PersonalGainsTxt"), gdjs.MainCode.GDPersonalGainsTxtObjects2);
gdjs.copyArray(runtimeScene.getObjects("Pink_bars"), gdjs.MainCode.GDPink_9595barsObjects2);
gdjs.copyArray(runtimeScene.getObjects("PublicApprovalTxt"), gdjs.MainCode.GDPublicApprovalTxtObjects2);
gdjs.copyArray(runtimeScene.getObjects("ReactionIcon_Fire"), gdjs.MainCode.GDReactionIcon_9595FireObjects2);
gdjs.copyArray(runtimeScene.getObjects("ReactionIcon_Like"), gdjs.MainCode.GDReactionIcon_9595LikeObjects2);
gdjs.copyArray(runtimeScene.getObjects("ReactionIcons_Heart"), gdjs.MainCode.GDReactionIcons_9595HeartObjects2);
gdjs.copyArray(runtimeScene.getObjects("ScandalRiskTxt"), gdjs.MainCode.GDScandalRiskTxtObjects2);
gdjs.copyArray(runtimeScene.getObjects("Send_icon1"), gdjs.MainCode.GDSend_9595icon1Objects2);
gdjs.copyArray(runtimeScene.getObjects("Send_icon2"), gdjs.MainCode.GDSend_9595icon2Objects2);
gdjs.copyArray(runtimeScene.getObjects("Send_icon3"), gdjs.MainCode.GDSend_9595icon3Objects2);
gdjs.copyArray(runtimeScene.getObjects("SkipTutorial"), gdjs.MainCode.GDSkipTutorialObjects2);
gdjs.copyArray(runtimeScene.getObjects("Tweet1"), gdjs.MainCode.GDTweet1Objects2);
gdjs.copyArray(runtimeScene.getObjects("Tweet2"), gdjs.MainCode.GDTweet2Objects2);
gdjs.copyArray(runtimeScene.getObjects("Tweet3"), gdjs.MainCode.GDTweet3Objects2);
gdjs.copyArray(runtimeScene.getObjects("Tweet4"), gdjs.MainCode.GDTweet4Objects2);
gdjs.copyArray(runtimeScene.getObjects("Tweet5"), gdjs.MainCode.GDTweet5Objects2);
gdjs.copyArray(runtimeScene.getObjects("Tweet6"), gdjs.MainCode.GDTweet6Objects2);
gdjs.copyArray(runtimeScene.getObjects("TweetFace1"), gdjs.MainCode.GDTweetFace1Objects2);
gdjs.copyArray(runtimeScene.getObjects("TweetFace2"), gdjs.MainCode.GDTweetFace2Objects2);
gdjs.copyArray(runtimeScene.getObjects("TweetFace3"), gdjs.MainCode.GDTweetFace3Objects2);
gdjs.copyArray(runtimeScene.getObjects("TweetFace4"), gdjs.MainCode.GDTweetFace4Objects2);
gdjs.copyArray(runtimeScene.getObjects("TweetFace5"), gdjs.MainCode.GDTweetFace5Objects2);
gdjs.copyArray(runtimeScene.getObjects("TweetFace6"), gdjs.MainCode.GDTweetFace6Objects2);
gdjs.copyArray(runtimeScene.getObjects("TweetTitle1"), gdjs.MainCode.GDTweetTitle1Objects2);
gdjs.copyArray(runtimeScene.getObjects("TweetTitle2"), gdjs.MainCode.GDTweetTitle2Objects2);
gdjs.copyArray(runtimeScene.getObjects("TweetTitle3"), gdjs.MainCode.GDTweetTitle3Objects2);
gdjs.copyArray(runtimeScene.getObjects("TweetTitle4"), gdjs.MainCode.GDTweetTitle4Objects2);
gdjs.copyArray(runtimeScene.getObjects("TweetTitle5"), gdjs.MainCode.GDTweetTitle5Objects2);
gdjs.copyArray(runtimeScene.getObjects("TweetTitle6"), gdjs.MainCode.GDTweetTitle6Objects2);
gdjs.copyArray(runtimeScene.getObjects("Tweet_bkg1"), gdjs.MainCode.GDTweet_9595bkg1Objects2);
gdjs.copyArray(runtimeScene.getObjects("Tweet_bkg2"), gdjs.MainCode.GDTweet_9595bkg2Objects2);
gdjs.copyArray(runtimeScene.getObjects("Tweet_bkg3"), gdjs.MainCode.GDTweet_9595bkg3Objects2);
gdjs.copyArray(runtimeScene.getObjects("Tweet_bkg4"), gdjs.MainCode.GDTweet_9595bkg4Objects2);
gdjs.copyArray(runtimeScene.getObjects("Tweet_bkg5"), gdjs.MainCode.GDTweet_9595bkg5Objects2);
gdjs.copyArray(runtimeScene.getObjects("Tweet_bkg6"), gdjs.MainCode.GDTweet_9595bkg6Objects2);
gdjs.copyArray(runtimeScene.getObjects("blue_bars"), gdjs.MainCode.GDblue_9595barsObjects2);
{for(var i = 0, len = gdjs.MainCode.GDPersonalGainsTxtObjects2.length ;i < len;++i) {
    gdjs.MainCode.GDPersonalGainsTxtObjects2[i].hide(false);
}
}{for(var i = 0, len = gdjs.MainCode.GDPink_9595barsObjects2.length ;i < len;++i) {
    gdjs.MainCode.GDPink_9595barsObjects2[i].hide(false);
}
}{for(var i = 0, len = gdjs.MainCode.GDEconomyTxtObjects2.length ;i < len;++i) {
    gdjs.MainCode.GDEconomyTxtObjects2[i].hide(false);
}
}{for(var i = 0, len = gdjs.MainCode.GDPublicApprovalTxtObjects2.length ;i < len;++i) {
    gdjs.MainCode.GDPublicApprovalTxtObjects2[i].hide(false);
}
}{for(var i = 0, len = gdjs.MainCode.GDGreen_9595barsObjects2.length ;i < len;++i) {
    gdjs.MainCode.GDGreen_9595barsObjects2[i].hide(false);
}
}{for(var i = 0, len = gdjs.MainCode.GDblue_9595barsObjects2.length ;i < len;++i) {
    gdjs.MainCode.GDblue_9595barsObjects2[i].hide(false);
}
}{for(var i = 0, len = gdjs.MainCode.GDOrange_9595barsObjects2.length ;i < len;++i) {
    gdjs.MainCode.GDOrange_9595barsObjects2[i].hide(false);
}
}{for(var i = 0, len = gdjs.MainCode.GDScandalRiskTxtObjects2.length ;i < len;++i) {
    gdjs.MainCode.GDScandalRiskTxtObjects2[i].hide(false);
}
}{for(var i = 0, len = gdjs.MainCode.GDTweet1Objects2.length ;i < len;++i) {
    gdjs.MainCode.GDTweet1Objects2[i].hide(false);
}
for(var i = 0, len = gdjs.MainCode.GDTweetTitle1Objects2.length ;i < len;++i) {
    gdjs.MainCode.GDTweetTitle1Objects2[i].hide(false);
}
for(var i = 0, len = gdjs.MainCode.GDHeartText1Objects2.length ;i < len;++i) {
    gdjs.MainCode.GDHeartText1Objects2[i].hide(false);
}
for(var i = 0, len = gdjs.MainCode.GDReactionIcons_9595HeartObjects2.length ;i < len;++i) {
    gdjs.MainCode.GDReactionIcons_9595HeartObjects2[i].hide(false);
}
for(var i = 0, len = gdjs.MainCode.GDReactionIcon_9595LikeObjects2.length ;i < len;++i) {
    gdjs.MainCode.GDReactionIcon_9595LikeObjects2[i].hide(false);
}
for(var i = 0, len = gdjs.MainCode.GDLikeText1Objects2.length ;i < len;++i) {
    gdjs.MainCode.GDLikeText1Objects2[i].hide(false);
}
for(var i = 0, len = gdjs.MainCode.GDReactionIcon_9595FireObjects2.length ;i < len;++i) {
    gdjs.MainCode.GDReactionIcon_9595FireObjects2[i].hide(false);
}
for(var i = 0, len = gdjs.MainCode.GDFireText1Objects2.length ;i < len;++i) {
    gdjs.MainCode.GDFireText1Objects2[i].hide(false);
}
for(var i = 0, len = gdjs.MainCode.GDLikeText2Objects2.length ;i < len;++i) {
    gdjs.MainCode.GDLikeText2Objects2[i].hide(false);
}
for(var i = 0, len = gdjs.MainCode.GDFireText2Objects2.length ;i < len;++i) {
    gdjs.MainCode.GDFireText2Objects2[i].hide(false);
}
for(var i = 0, len = gdjs.MainCode.GDHeartText2Objects2.length ;i < len;++i) {
    gdjs.MainCode.GDHeartText2Objects2[i].hide(false);
}
for(var i = 0, len = gdjs.MainCode.GDFireText3Objects2.length ;i < len;++i) {
    gdjs.MainCode.GDFireText3Objects2[i].hide(false);
}
for(var i = 0, len = gdjs.MainCode.GDOption1Objects2.length ;i < len;++i) {
    gdjs.MainCode.GDOption1Objects2[i].hide(false);
}
for(var i = 0, len = gdjs.MainCode.GDOption2Objects2.length ;i < len;++i) {
    gdjs.MainCode.GDOption2Objects2[i].hide(false);
}
for(var i = 0, len = gdjs.MainCode.GDOption3Objects2.length ;i < len;++i) {
    gdjs.MainCode.GDOption3Objects2[i].hide(false);
}
for(var i = 0, len = gdjs.MainCode.GDOptionTxt1Objects2.length ;i < len;++i) {
    gdjs.MainCode.GDOptionTxt1Objects2[i].hide(false);
}
for(var i = 0, len = gdjs.MainCode.GDOptionTxt2Objects2.length ;i < len;++i) {
    gdjs.MainCode.GDOptionTxt2Objects2[i].hide(false);
}
for(var i = 0, len = gdjs.MainCode.GDOptionTxt3Objects2.length ;i < len;++i) {
    gdjs.MainCode.GDOptionTxt3Objects2[i].hide(false);
}
for(var i = 0, len = gdjs.MainCode.GDSend_9595icon1Objects2.length ;i < len;++i) {
    gdjs.MainCode.GDSend_9595icon1Objects2[i].hide(false);
}
for(var i = 0, len = gdjs.MainCode.GDblue_9595barsObjects2.length ;i < len;++i) {
    gdjs.MainCode.GDblue_9595barsObjects2[i].hide(false);
}
for(var i = 0, len = gdjs.MainCode.GDGreen_9595barsObjects2.length ;i < len;++i) {
    gdjs.MainCode.GDGreen_9595barsObjects2[i].hide(false);
}
for(var i = 0, len = gdjs.MainCode.GDOrange_9595barsObjects2.length ;i < len;++i) {
    gdjs.MainCode.GDOrange_9595barsObjects2[i].hide(false);
}
for(var i = 0, len = gdjs.MainCode.GDPink_9595barsObjects2.length ;i < len;++i) {
    gdjs.MainCode.GDPink_9595barsObjects2[i].hide(false);
}
for(var i = 0, len = gdjs.MainCode.GDEconomyTxtObjects2.length ;i < len;++i) {
    gdjs.MainCode.GDEconomyTxtObjects2[i].hide(false);
}
for(var i = 0, len = gdjs.MainCode.GDPersonalGainsTxtObjects2.length ;i < len;++i) {
    gdjs.MainCode.GDPersonalGainsTxtObjects2[i].hide(false);
}
for(var i = 0, len = gdjs.MainCode.GDScandalRiskTxtObjects2.length ;i < len;++i) {
    gdjs.MainCode.GDScandalRiskTxtObjects2[i].hide(false);
}
for(var i = 0, len = gdjs.MainCode.GDPublicApprovalTxtObjects2.length ;i < len;++i) {
    gdjs.MainCode.GDPublicApprovalTxtObjects2[i].hide(false);
}
for(var i = 0, len = gdjs.MainCode.GDLikeText3Objects2.length ;i < len;++i) {
    gdjs.MainCode.GDLikeText3Objects2[i].hide(false);
}
for(var i = 0, len = gdjs.MainCode.GDHeartText3Objects2.length ;i < len;++i) {
    gdjs.MainCode.GDHeartText3Objects2[i].hide(false);
}
for(var i = 0, len = gdjs.MainCode.GDTweetFace3Objects2.length ;i < len;++i) {
    gdjs.MainCode.GDTweetFace3Objects2[i].hide(false);
}
for(var i = 0, len = gdjs.MainCode.GDTweetTitle2Objects2.length ;i < len;++i) {
    gdjs.MainCode.GDTweetTitle2Objects2[i].hide(false);
}
for(var i = 0, len = gdjs.MainCode.GDTweetTitle3Objects2.length ;i < len;++i) {
    gdjs.MainCode.GDTweetTitle3Objects2[i].hide(false);
}
for(var i = 0, len = gdjs.MainCode.GDTweet2Objects2.length ;i < len;++i) {
    gdjs.MainCode.GDTweet2Objects2[i].hide(false);
}
for(var i = 0, len = gdjs.MainCode.GDTweet3Objects2.length ;i < len;++i) {
    gdjs.MainCode.GDTweet3Objects2[i].hide(false);
}
for(var i = 0, len = gdjs.MainCode.GDTweet_9595bkg1Objects2.length ;i < len;++i) {
    gdjs.MainCode.GDTweet_9595bkg1Objects2[i].hide(false);
}
for(var i = 0, len = gdjs.MainCode.GDTweetFace2Objects2.length ;i < len;++i) {
    gdjs.MainCode.GDTweetFace2Objects2[i].hide(false);
}
for(var i = 0, len = gdjs.MainCode.GDTweetFace1Objects2.length ;i < len;++i) {
    gdjs.MainCode.GDTweetFace1Objects2[i].hide(false);
}
for(var i = 0, len = gdjs.MainCode.GDSend_9595icon3Objects2.length ;i < len;++i) {
    gdjs.MainCode.GDSend_9595icon3Objects2[i].hide(false);
}
for(var i = 0, len = gdjs.MainCode.GDSend_9595icon2Objects2.length ;i < len;++i) {
    gdjs.MainCode.GDSend_9595icon2Objects2[i].hide(false);
}
for(var i = 0, len = gdjs.MainCode.GDMy_9595optionsObjects2.length ;i < len;++i) {
    gdjs.MainCode.GDMy_9595optionsObjects2[i].hide(false);
}
for(var i = 0, len = gdjs.MainCode.GDTweetTitle6Objects2.length ;i < len;++i) {
    gdjs.MainCode.GDTweetTitle6Objects2[i].hide(false);
}
for(var i = 0, len = gdjs.MainCode.GDTweet6Objects2.length ;i < len;++i) {
    gdjs.MainCode.GDTweet6Objects2[i].hide(false);
}
for(var i = 0, len = gdjs.MainCode.GDChirpObjects2.length ;i < len;++i) {
    gdjs.MainCode.GDChirpObjects2[i].hide(false);
}
for(var i = 0, len = gdjs.MainCode.GDDayTxtObjects2.length ;i < len;++i) {
    gdjs.MainCode.GDDayTxtObjects2[i].hide(false);
}
for(var i = 0, len = gdjs.MainCode.GDTweet_9595bkg2Objects2.length ;i < len;++i) {
    gdjs.MainCode.GDTweet_9595bkg2Objects2[i].hide(false);
}
for(var i = 0, len = gdjs.MainCode.GDTweet5Objects2.length ;i < len;++i) {
    gdjs.MainCode.GDTweet5Objects2[i].hide(false);
}
for(var i = 0, len = gdjs.MainCode.GDTweet4Objects2.length ;i < len;++i) {
    gdjs.MainCode.GDTweet4Objects2[i].hide(false);
}
for(var i = 0, len = gdjs.MainCode.GDTweetTitle5Objects2.length ;i < len;++i) {
    gdjs.MainCode.GDTweetTitle5Objects2[i].hide(false);
}
for(var i = 0, len = gdjs.MainCode.GDTweetTitle4Objects2.length ;i < len;++i) {
    gdjs.MainCode.GDTweetTitle4Objects2[i].hide(false);
}
for(var i = 0, len = gdjs.MainCode.GDTweet_9595bkg3Objects2.length ;i < len;++i) {
    gdjs.MainCode.GDTweet_9595bkg3Objects2[i].hide(false);
}
for(var i = 0, len = gdjs.MainCode.GDTweet_9595bkg4Objects2.length ;i < len;++i) {
    gdjs.MainCode.GDTweet_9595bkg4Objects2[i].hide(false);
}
for(var i = 0, len = gdjs.MainCode.GDFireText4Objects2.length ;i < len;++i) {
    gdjs.MainCode.GDFireText4Objects2[i].hide(false);
}
for(var i = 0, len = gdjs.MainCode.GDTweet_9595bkg5Objects2.length ;i < len;++i) {
    gdjs.MainCode.GDTweet_9595bkg5Objects2[i].hide(false);
}
for(var i = 0, len = gdjs.MainCode.GDTweet_9595bkg6Objects2.length ;i < len;++i) {
    gdjs.MainCode.GDTweet_9595bkg6Objects2[i].hide(false);
}
for(var i = 0, len = gdjs.MainCode.GDFireText5Objects2.length ;i < len;++i) {
    gdjs.MainCode.GDFireText5Objects2[i].hide(false);
}
for(var i = 0, len = gdjs.MainCode.GDFireText6Objects2.length ;i < len;++i) {
    gdjs.MainCode.GDFireText6Objects2[i].hide(false);
}
for(var i = 0, len = gdjs.MainCode.GDLikeText4Objects2.length ;i < len;++i) {
    gdjs.MainCode.GDLikeText4Objects2[i].hide(false);
}
for(var i = 0, len = gdjs.MainCode.GDLikeText5Objects2.length ;i < len;++i) {
    gdjs.MainCode.GDLikeText5Objects2[i].hide(false);
}
for(var i = 0, len = gdjs.MainCode.GDLikeText6Objects2.length ;i < len;++i) {
    gdjs.MainCode.GDLikeText6Objects2[i].hide(false);
}
for(var i = 0, len = gdjs.MainCode.GDHeartText4Objects2.length ;i < len;++i) {
    gdjs.MainCode.GDHeartText4Objects2[i].hide(false);
}
for(var i = 0, len = gdjs.MainCode.GDHeartText5Objects2.length ;i < len;++i) {
    gdjs.MainCode.GDHeartText5Objects2[i].hide(false);
}
for(var i = 0, len = gdjs.MainCode.GDHeartText6Objects2.length ;i < len;++i) {
    gdjs.MainCode.GDHeartText6Objects2[i].hide(false);
}
for(var i = 0, len = gdjs.MainCode.GDTweetFace4Objects2.length ;i < len;++i) {
    gdjs.MainCode.GDTweetFace4Objects2[i].hide(false);
}
for(var i = 0, len = gdjs.MainCode.GDTweetFace5Objects2.length ;i < len;++i) {
    gdjs.MainCode.GDTweetFace5Objects2[i].hide(false);
}
for(var i = 0, len = gdjs.MainCode.GDTweetFace6Objects2.length ;i < len;++i) {
    gdjs.MainCode.GDTweetFace6Objects2[i].hide(false);
}
}{runtimeScene.getScene().getVariables().getFromIndex(7).setString("DECISION");
}{for(var i = 0, len = gdjs.MainCode.GDSkipTutorialObjects2.length ;i < len;++i) {
    gdjs.MainCode.GDSkipTutorialObjects2[i].deleteFromScene(runtimeScene);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(1).getAsString() == "Aliens");
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15067660);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("OptionTxt1"), gdjs.MainCode.GDOptionTxt1Objects2);
gdjs.copyArray(runtimeScene.getObjects("OptionTxt2"), gdjs.MainCode.GDOptionTxt2Objects2);
gdjs.copyArray(runtimeScene.getObjects("OptionTxt3"), gdjs.MainCode.GDOptionTxt3Objects2);
gdjs.copyArray(runtimeScene.getObjects("Tweet1"), gdjs.MainCode.GDTweet1Objects2);
gdjs.copyArray(runtimeScene.getObjects("Tweet2"), gdjs.MainCode.GDTweet2Objects2);
gdjs.copyArray(runtimeScene.getObjects("Tweet3"), gdjs.MainCode.GDTweet3Objects2);
{for(var i = 0, len = gdjs.MainCode.GDTweet1Objects2.length ;i < len;++i) {
    gdjs.MainCode.GDTweet1Objects2[i].getBehavior("Text").setText("Alien Signal Detected. Scientists urge calm, but conspiracy forums are lighting up.");
}
}{for(var i = 0, len = gdjs.MainCode.GDTweet2Objects2.length ;i < len;++i) {
    gdjs.MainCode.GDTweet2Objects2[i].getBehavior("Text").setText("NASA confirms strange radio signal from deep space. Could it be alien memes?");
}
}{for(var i = 0, len = gdjs.MainCode.GDTweet3Objects2.length ;i < len;++i) {
    gdjs.MainCode.GDTweet3Objects2[i].getBehavior("Text").setText("Government budget requested for ‘Space Listening Department’ (SLD).");
}
}{for(var i = 0, len = gdjs.MainCode.GDOptionTxt1Objects2.length ;i < len;++i) {
    gdjs.MainCode.GDOptionTxt1Objects2[i].getBehavior("Text").setText("Aliens? I’ve been saying it for YEARS. The people know I’m right. #ToldYouSo");
}
}{for(var i = 0, len = gdjs.MainCode.GDOptionTxt2Objects2.length ;i < len;++i) {
    gdjs.MainCode.GDOptionTxt2Objects2[i].getBehavior("Text").setText("Let’s create jobs by building eagle shaped like satellites! #EconBoom");
}
}{for(var i = 0, len = gdjs.MainCode.GDOptionTxt3Objects2.length ;i < len;++i) {
    gdjs.MainCode.GDOptionTxt3Objects2[i].getBehavior("Text").setText("Launching new NFT: ‘First Contact Collection.’ 10,000 pics. Limited edition.");
}
}{gdjs.evtTools.variable.variableRemoveChild(runtimeScene.getScene().getVariables().getFromIndex(9), "Aliens");
}{gdjs.evtsExt__ArrayTools__Shuffle.func(runtimeScene, runtimeScene.getScene().getVariables().getFromIndex(9), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
{ //Subevents
gdjs.MainCode.eventsList25(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Cap"), gdjs.MainCode.GDCapObjects2);
gdjs.copyArray(runtimeScene.getObjects("Cap_comments"), gdjs.MainCode.GDCap_9595commentsObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDCapObjects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.MainCode.GDCap_9595commentsObjects2.length;i<l;++i) {
    if ( gdjs.MainCode.GDCap_9595commentsObjects2[i].getBehavior("Text").getText() == "[ CLICK ON ME! ]" ) {
        isConditionTrue_0 = true;
        gdjs.MainCode.GDCap_9595commentsObjects2[k] = gdjs.MainCode.GDCap_9595commentsObjects2[i];
        ++k;
    }
}
gdjs.MainCode.GDCap_9595commentsObjects2.length = k;
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "assets\\Sounds\\assets_Sounds_CapClick.wav", 2, false, 50, 1);
}
{ //Subevents
gdjs.MainCode.eventsList26(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Cap"), gdjs.MainCode.GDCapObjects2);
gdjs.copyArray(runtimeScene.getObjects("Cap_comments"), gdjs.MainCode.GDCap_9595commentsObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDCapObjects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.MainCode.GDCap_9595commentsObjects2.length;i<l;++i) {
    if ( gdjs.MainCode.GDCap_9595commentsObjects2[i].getBehavior("Text").getText() == "Welcome, President! Let’s make riches great again. I'll advice you" ) {
        isConditionTrue_0 = true;
        gdjs.MainCode.GDCap_9595commentsObjects2[k] = gdjs.MainCode.GDCap_9595commentsObjects2[i];
        ++k;
    }
}
gdjs.MainCode.GDCap_9595commentsObjects2.length = k;
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "assets\\Sounds\\assets_Sounds_CapClick.wav", 2, false, 50, 1);
}
{ //Subevents
gdjs.MainCode.eventsList27(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Cap"), gdjs.MainCode.GDCapObjects2);
gdjs.copyArray(runtimeScene.getObjects("Cap_comments"), gdjs.MainCode.GDCap_9595commentsObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDCapObjects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.MainCode.GDCap_9595commentsObjects2.length;i<l;++i) {
    if ( gdjs.MainCode.GDCap_9595commentsObjects2[i].getBehavior("Text").getText() == "Keep Approval & Economy above 5. Or face the heat." ) {
        isConditionTrue_0 = true;
        gdjs.MainCode.GDCap_9595commentsObjects2[k] = gdjs.MainCode.GDCap_9595commentsObjects2[i];
        ++k;
    }
}
gdjs.MainCode.GDCap_9595commentsObjects2.length = k;
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "assets\\Sounds\\assets_Sounds_CapClick.wav", 2, false, 50, 1);
}
{ //Subevents
gdjs.MainCode.eventsList28(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Cap"), gdjs.MainCode.GDCapObjects2);
gdjs.copyArray(runtimeScene.getObjects("Cap_comments"), gdjs.MainCode.GDCap_9595commentsObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDCapObjects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.MainCode.GDCap_9595commentsObjects2.length;i<l;++i) {
    if ( gdjs.MainCode.GDCap_9595commentsObjects2[i].getBehavior("Text").getText() == "Max your wealth but don’t burn the nation doing it!" ) {
        isConditionTrue_0 = true;
        gdjs.MainCode.GDCap_9595commentsObjects2[k] = gdjs.MainCode.GDCap_9595commentsObjects2[i];
        ++k;
    }
}
gdjs.MainCode.GDCap_9595commentsObjects2.length = k;
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSound(runtimeScene, "assets\\Sounds\\assets_Sounds_CapClick.wav", false, 50, 1);
}
{ //Subevents
gdjs.MainCode.eventsList29(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Cap"), gdjs.MainCode.GDCapObjects1);
gdjs.copyArray(runtimeScene.getObjects("Cap_comments"), gdjs.MainCode.GDCap_9595commentsObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDCapObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.MainCode.GDCap_9595commentsObjects1.length;i<l;++i) {
    if ( gdjs.MainCode.GDCap_9595commentsObjects1[i].getBehavior("Text").getText() == "Scandal hits 5? Say bye to the big desk." ) {
        isConditionTrue_0 = true;
        gdjs.MainCode.GDCap_9595commentsObjects1[k] = gdjs.MainCode.GDCap_9595commentsObjects1[i];
        ++k;
    }
}
gdjs.MainCode.GDCap_9595commentsObjects1.length = k;
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "assets\\Sounds\\assets_Sounds_CapClick.wav", 2, false, 50, 1);
}
{ //Subevents
gdjs.MainCode.eventsList31(runtimeScene);} //End of subevents
}

}


};gdjs.MainCode.eventsList33 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(7).getAsString() == "TUTORIAL");
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.MainCode.eventsList32(runtimeScene);} //End of subevents
}

}


};gdjs.MainCode.eventsList34 = function(runtimeScene, asyncObjectsList) {

{



}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("FireText1"), gdjs.MainCode.GDFireText1Objects3);
gdjs.copyArray(runtimeScene.getObjects("FireText2"), gdjs.MainCode.GDFireText2Objects3);
gdjs.copyArray(runtimeScene.getObjects("FireText3"), gdjs.MainCode.GDFireText3Objects3);
gdjs.copyArray(runtimeScene.getObjects("FireText5"), gdjs.MainCode.GDFireText5Objects3);
gdjs.copyArray(runtimeScene.getObjects("FireText6"), gdjs.MainCode.GDFireText6Objects3);
gdjs.copyArray(runtimeScene.getObjects("HeartText1"), gdjs.MainCode.GDHeartText1Objects3);
gdjs.copyArray(runtimeScene.getObjects("HeartText2"), gdjs.MainCode.GDHeartText2Objects3);
gdjs.copyArray(runtimeScene.getObjects("HeartText3"), gdjs.MainCode.GDHeartText3Objects3);
gdjs.copyArray(runtimeScene.getObjects("HeartText5"), gdjs.MainCode.GDHeartText5Objects3);
gdjs.copyArray(runtimeScene.getObjects("HeartText6"), gdjs.MainCode.GDHeartText6Objects3);
gdjs.copyArray(runtimeScene.getObjects("LikeText1"), gdjs.MainCode.GDLikeText1Objects3);
gdjs.copyArray(runtimeScene.getObjects("LikeText2"), gdjs.MainCode.GDLikeText2Objects3);
gdjs.copyArray(runtimeScene.getObjects("LikeText3"), gdjs.MainCode.GDLikeText3Objects3);
gdjs.copyArray(runtimeScene.getObjects("LikeText5"), gdjs.MainCode.GDLikeText5Objects3);
gdjs.copyArray(runtimeScene.getObjects("LikeText6"), gdjs.MainCode.GDLikeText6Objects3);
gdjs.copyArray(runtimeScene.getObjects("TweetFace1"), gdjs.MainCode.GDTweetFace1Objects3);
gdjs.copyArray(runtimeScene.getObjects("TweetFace2"), gdjs.MainCode.GDTweetFace2Objects3);
gdjs.copyArray(runtimeScene.getObjects("TweetFace3"), gdjs.MainCode.GDTweetFace3Objects3);
gdjs.copyArray(runtimeScene.getObjects("TweetFace5"), gdjs.MainCode.GDTweetFace5Objects3);
gdjs.copyArray(runtimeScene.getObjects("TweetFace6"), gdjs.MainCode.GDTweetFace6Objects3);
gdjs.copyArray(runtimeScene.getObjects("TweetTitle1"), gdjs.MainCode.GDTweetTitle1Objects3);
gdjs.copyArray(runtimeScene.getObjects("TweetTitle2"), gdjs.MainCode.GDTweetTitle2Objects3);
gdjs.copyArray(runtimeScene.getObjects("TweetTitle3"), gdjs.MainCode.GDTweetTitle3Objects3);
gdjs.copyArray(runtimeScene.getObjects("TweetTitle5"), gdjs.MainCode.GDTweetTitle5Objects3);
gdjs.copyArray(runtimeScene.getObjects("TweetTitle6"), gdjs.MainCode.GDTweetTitle6Objects3);
{for(var i = 0, len = gdjs.MainCode.GDTweetTitle1Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDTweetTitle1Objects3[i].getBehavior("Text").setText(runtimeScene.getScene().getVariables().getFromIndex(10).getChild(gdjs.randomInRange(0, 14)).getAsString());
}
}{for(var i = 0, len = gdjs.MainCode.GDTweetTitle2Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDTweetTitle2Objects3[i].getBehavior("Text").setText(runtimeScene.getScene().getVariables().getFromIndex(10).getChild(gdjs.randomInRange(0, 14)).getAsString());
}
}{for(var i = 0, len = gdjs.MainCode.GDTweetTitle3Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDTweetTitle3Objects3[i].getBehavior("Text").setText(runtimeScene.getScene().getVariables().getFromIndex(10).getChild(gdjs.randomInRange(0, 14)).getAsString());
}
}{for(var i = 0, len = gdjs.MainCode.GDTweetTitle5Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDTweetTitle5Objects3[i].getBehavior("Text").setText(runtimeScene.getScene().getVariables().getFromIndex(10).getChild(gdjs.randomInRange(0, 14)).getAsString());
}
}{for(var i = 0, len = gdjs.MainCode.GDTweetTitle6Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDTweetTitle6Objects3[i].getBehavior("Text").setText(runtimeScene.getScene().getVariables().getFromIndex(10).getChild(gdjs.randomInRange(0, 14)).getAsString());
}
}{for(var i = 0, len = gdjs.MainCode.GDTweetFace1Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDTweetFace1Objects3[i].getBehavior("Animation").setAnimationIndex(gdjs.randomInRange(0, 5));
}
}{for(var i = 0, len = gdjs.MainCode.GDTweetFace2Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDTweetFace2Objects3[i].getBehavior("Animation").setAnimationIndex(gdjs.randomInRange(0, 5));
}
}{for(var i = 0, len = gdjs.MainCode.GDTweetFace3Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDTweetFace3Objects3[i].getBehavior("Animation").setAnimationIndex(gdjs.randomInRange(0, 5));
}
}{for(var i = 0, len = gdjs.MainCode.GDTweetFace5Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDTweetFace5Objects3[i].getBehavior("Animation").setAnimationIndex(gdjs.randomInRange(0, 5));
}
}{for(var i = 0, len = gdjs.MainCode.GDTweetFace6Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDTweetFace6Objects3[i].getBehavior("Animation").setAnimationIndex(gdjs.randomInRange(0, 5));
}
}{for(var i = 0, len = gdjs.MainCode.GDFireText1Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDFireText1Objects3[i].getBehavior("Text").setText(gdjs.evtTools.common.toString(gdjs.randomInRange(10, 99)));
}
}{for(var i = 0, len = gdjs.MainCode.GDFireText2Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDFireText2Objects3[i].getBehavior("Text").setText(gdjs.evtTools.common.toString(gdjs.randomInRange(10, 99)));
}
}{for(var i = 0, len = gdjs.MainCode.GDFireText3Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDFireText3Objects3[i].getBehavior("Text").setText(gdjs.evtTools.common.toString(gdjs.randomInRange(10, 99)));
}
}{for(var i = 0, len = gdjs.MainCode.GDFireText5Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDFireText5Objects3[i].getBehavior("Text").setText(gdjs.evtTools.common.toString(gdjs.randomInRange(10, 99)));
}
}{for(var i = 0, len = gdjs.MainCode.GDFireText6Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDFireText6Objects3[i].getBehavior("Text").setText(gdjs.evtTools.common.toString(gdjs.randomInRange(10, 99)));
}
}{for(var i = 0, len = gdjs.MainCode.GDHeartText1Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDHeartText1Objects3[i].getBehavior("Text").setText(gdjs.evtTools.common.toString(gdjs.randomInRange(10, 99)));
}
}{for(var i = 0, len = gdjs.MainCode.GDHeartText2Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDHeartText2Objects3[i].getBehavior("Text").setText(gdjs.evtTools.common.toString(gdjs.randomInRange(10, 99)));
}
}{for(var i = 0, len = gdjs.MainCode.GDHeartText3Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDHeartText3Objects3[i].getBehavior("Text").setText(gdjs.evtTools.common.toString(gdjs.randomInRange(10, 99)));
}
}{for(var i = 0, len = gdjs.MainCode.GDHeartText5Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDHeartText5Objects3[i].getBehavior("Text").setText(gdjs.evtTools.common.toString(gdjs.randomInRange(10, 99)));
}
}{for(var i = 0, len = gdjs.MainCode.GDHeartText6Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDHeartText6Objects3[i].getBehavior("Text").setText(gdjs.evtTools.common.toString(gdjs.randomInRange(10, 99)));
}
}{for(var i = 0, len = gdjs.MainCode.GDLikeText1Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDLikeText1Objects3[i].getBehavior("Text").setText(gdjs.evtTools.common.toString(gdjs.randomInRange(10, 99)));
}
}{for(var i = 0, len = gdjs.MainCode.GDLikeText2Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDLikeText2Objects3[i].getBehavior("Text").setText(gdjs.evtTools.common.toString(gdjs.randomInRange(10, 99)));
}
}{for(var i = 0, len = gdjs.MainCode.GDLikeText3Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDLikeText3Objects3[i].getBehavior("Text").setText(gdjs.evtTools.common.toString(gdjs.randomInRange(10, 99)));
}
}{for(var i = 0, len = gdjs.MainCode.GDLikeText5Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDLikeText5Objects3[i].getBehavior("Text").setText(gdjs.evtTools.common.toString(gdjs.randomInRange(10, 99)));
}
}{for(var i = 0, len = gdjs.MainCode.GDLikeText6Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDLikeText6Objects3[i].getBehavior("Text").setText(gdjs.evtTools.common.toString(gdjs.randomInRange(10, 99)));
}
}}

}


};gdjs.MainCode.eventsList35 = function(runtimeScene, asyncObjectsList) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15097020);
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.MainCode.eventsList34(runtimeScene, asyncObjectsList);} //End of subevents
}

}


};gdjs.MainCode.eventsList36 = function(runtimeScene, asyncObjectsList) {

{



}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("FireText1"), gdjs.MainCode.GDFireText1Objects3);
gdjs.copyArray(runtimeScene.getObjects("FireText2"), gdjs.MainCode.GDFireText2Objects3);
gdjs.copyArray(runtimeScene.getObjects("FireText3"), gdjs.MainCode.GDFireText3Objects3);
gdjs.copyArray(runtimeScene.getObjects("FireText5"), gdjs.MainCode.GDFireText5Objects3);
gdjs.copyArray(runtimeScene.getObjects("FireText6"), gdjs.MainCode.GDFireText6Objects3);
gdjs.copyArray(runtimeScene.getObjects("HeartText1"), gdjs.MainCode.GDHeartText1Objects3);
gdjs.copyArray(runtimeScene.getObjects("HeartText2"), gdjs.MainCode.GDHeartText2Objects3);
gdjs.copyArray(runtimeScene.getObjects("HeartText3"), gdjs.MainCode.GDHeartText3Objects3);
gdjs.copyArray(runtimeScene.getObjects("HeartText5"), gdjs.MainCode.GDHeartText5Objects3);
gdjs.copyArray(runtimeScene.getObjects("HeartText6"), gdjs.MainCode.GDHeartText6Objects3);
gdjs.copyArray(runtimeScene.getObjects("LikeText1"), gdjs.MainCode.GDLikeText1Objects3);
gdjs.copyArray(runtimeScene.getObjects("LikeText2"), gdjs.MainCode.GDLikeText2Objects3);
gdjs.copyArray(runtimeScene.getObjects("LikeText3"), gdjs.MainCode.GDLikeText3Objects3);
gdjs.copyArray(runtimeScene.getObjects("LikeText5"), gdjs.MainCode.GDLikeText5Objects3);
gdjs.copyArray(runtimeScene.getObjects("LikeText6"), gdjs.MainCode.GDLikeText6Objects3);
gdjs.copyArray(runtimeScene.getObjects("TweetFace1"), gdjs.MainCode.GDTweetFace1Objects3);
gdjs.copyArray(runtimeScene.getObjects("TweetFace2"), gdjs.MainCode.GDTweetFace2Objects3);
gdjs.copyArray(runtimeScene.getObjects("TweetFace3"), gdjs.MainCode.GDTweetFace3Objects3);
gdjs.copyArray(runtimeScene.getObjects("TweetFace5"), gdjs.MainCode.GDTweetFace5Objects3);
gdjs.copyArray(runtimeScene.getObjects("TweetFace6"), gdjs.MainCode.GDTweetFace6Objects3);
gdjs.copyArray(runtimeScene.getObjects("TweetTitle1"), gdjs.MainCode.GDTweetTitle1Objects3);
gdjs.copyArray(runtimeScene.getObjects("TweetTitle2"), gdjs.MainCode.GDTweetTitle2Objects3);
gdjs.copyArray(runtimeScene.getObjects("TweetTitle3"), gdjs.MainCode.GDTweetTitle3Objects3);
gdjs.copyArray(runtimeScene.getObjects("TweetTitle5"), gdjs.MainCode.GDTweetTitle5Objects3);
gdjs.copyArray(runtimeScene.getObjects("TweetTitle6"), gdjs.MainCode.GDTweetTitle6Objects3);
{for(var i = 0, len = gdjs.MainCode.GDTweetTitle1Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDTweetTitle1Objects3[i].getBehavior("Text").setText(runtimeScene.getScene().getVariables().getFromIndex(10).getChild(gdjs.randomInRange(0, 14)).getAsString());
}
}{for(var i = 0, len = gdjs.MainCode.GDTweetTitle2Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDTweetTitle2Objects3[i].getBehavior("Text").setText(runtimeScene.getScene().getVariables().getFromIndex(10).getChild(gdjs.randomInRange(0, 14)).getAsString());
}
}{for(var i = 0, len = gdjs.MainCode.GDTweetTitle3Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDTweetTitle3Objects3[i].getBehavior("Text").setText(runtimeScene.getScene().getVariables().getFromIndex(10).getChild(gdjs.randomInRange(0, 14)).getAsString());
}
}{for(var i = 0, len = gdjs.MainCode.GDTweetTitle5Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDTweetTitle5Objects3[i].getBehavior("Text").setText(runtimeScene.getScene().getVariables().getFromIndex(10).getChild(gdjs.randomInRange(0, 14)).getAsString());
}
}{for(var i = 0, len = gdjs.MainCode.GDTweetTitle6Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDTweetTitle6Objects3[i].getBehavior("Text").setText(runtimeScene.getScene().getVariables().getFromIndex(10).getChild(gdjs.randomInRange(0, 14)).getAsString());
}
}{for(var i = 0, len = gdjs.MainCode.GDTweetFace1Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDTweetFace1Objects3[i].getBehavior("Animation").setAnimationIndex(gdjs.randomInRange(0, 5));
}
}{for(var i = 0, len = gdjs.MainCode.GDTweetFace2Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDTweetFace2Objects3[i].getBehavior("Animation").setAnimationIndex(gdjs.randomInRange(0, 5));
}
}{for(var i = 0, len = gdjs.MainCode.GDTweetFace3Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDTweetFace3Objects3[i].getBehavior("Animation").setAnimationIndex(gdjs.randomInRange(0, 5));
}
}{for(var i = 0, len = gdjs.MainCode.GDTweetFace5Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDTweetFace5Objects3[i].getBehavior("Animation").setAnimationIndex(gdjs.randomInRange(0, 5));
}
}{for(var i = 0, len = gdjs.MainCode.GDTweetFace6Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDTweetFace6Objects3[i].getBehavior("Animation").setAnimationIndex(gdjs.randomInRange(0, 5));
}
}{for(var i = 0, len = gdjs.MainCode.GDFireText1Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDFireText1Objects3[i].getBehavior("Text").setText(gdjs.evtTools.common.toString(gdjs.randomInRange(10, 99)));
}
}{for(var i = 0, len = gdjs.MainCode.GDFireText2Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDFireText2Objects3[i].getBehavior("Text").setText(gdjs.evtTools.common.toString(gdjs.randomInRange(10, 99)));
}
}{for(var i = 0, len = gdjs.MainCode.GDFireText3Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDFireText3Objects3[i].getBehavior("Text").setText(gdjs.evtTools.common.toString(gdjs.randomInRange(10, 99)));
}
}{for(var i = 0, len = gdjs.MainCode.GDFireText5Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDFireText5Objects3[i].getBehavior("Text").setText(gdjs.evtTools.common.toString(gdjs.randomInRange(10, 99)));
}
}{for(var i = 0, len = gdjs.MainCode.GDFireText6Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDFireText6Objects3[i].getBehavior("Text").setText(gdjs.evtTools.common.toString(gdjs.randomInRange(10, 99)));
}
}{for(var i = 0, len = gdjs.MainCode.GDHeartText1Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDHeartText1Objects3[i].getBehavior("Text").setText(gdjs.evtTools.common.toString(gdjs.randomInRange(10, 99)));
}
}{for(var i = 0, len = gdjs.MainCode.GDHeartText2Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDHeartText2Objects3[i].getBehavior("Text").setText(gdjs.evtTools.common.toString(gdjs.randomInRange(10, 99)));
}
}{for(var i = 0, len = gdjs.MainCode.GDHeartText3Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDHeartText3Objects3[i].getBehavior("Text").setText(gdjs.evtTools.common.toString(gdjs.randomInRange(10, 99)));
}
}{for(var i = 0, len = gdjs.MainCode.GDHeartText5Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDHeartText5Objects3[i].getBehavior("Text").setText(gdjs.evtTools.common.toString(gdjs.randomInRange(10, 99)));
}
}{for(var i = 0, len = gdjs.MainCode.GDHeartText6Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDHeartText6Objects3[i].getBehavior("Text").setText(gdjs.evtTools.common.toString(gdjs.randomInRange(10, 99)));
}
}{for(var i = 0, len = gdjs.MainCode.GDLikeText1Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDLikeText1Objects3[i].getBehavior("Text").setText(gdjs.evtTools.common.toString(gdjs.randomInRange(10, 99)));
}
}{for(var i = 0, len = gdjs.MainCode.GDLikeText2Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDLikeText2Objects3[i].getBehavior("Text").setText(gdjs.evtTools.common.toString(gdjs.randomInRange(10, 99)));
}
}{for(var i = 0, len = gdjs.MainCode.GDLikeText3Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDLikeText3Objects3[i].getBehavior("Text").setText(gdjs.evtTools.common.toString(gdjs.randomInRange(10, 99)));
}
}{for(var i = 0, len = gdjs.MainCode.GDLikeText5Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDLikeText5Objects3[i].getBehavior("Text").setText(gdjs.evtTools.common.toString(gdjs.randomInRange(10, 99)));
}
}{for(var i = 0, len = gdjs.MainCode.GDLikeText6Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDLikeText6Objects3[i].getBehavior("Text").setText(gdjs.evtTools.common.toString(gdjs.randomInRange(10, 99)));
}
}}

}


};gdjs.MainCode.eventsList37 = function(runtimeScene, asyncObjectsList) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15100452);
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.MainCode.eventsList36(runtimeScene, asyncObjectsList);} //End of subevents
}

}


};gdjs.MainCode.eventsList38 = function(runtimeScene, asyncObjectsList) {

{



}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("FireText1"), gdjs.MainCode.GDFireText1Objects3);
gdjs.copyArray(runtimeScene.getObjects("FireText2"), gdjs.MainCode.GDFireText2Objects3);
gdjs.copyArray(runtimeScene.getObjects("FireText3"), gdjs.MainCode.GDFireText3Objects3);
gdjs.copyArray(runtimeScene.getObjects("FireText5"), gdjs.MainCode.GDFireText5Objects3);
gdjs.copyArray(runtimeScene.getObjects("FireText6"), gdjs.MainCode.GDFireText6Objects3);
gdjs.copyArray(runtimeScene.getObjects("HeartText1"), gdjs.MainCode.GDHeartText1Objects3);
gdjs.copyArray(runtimeScene.getObjects("HeartText2"), gdjs.MainCode.GDHeartText2Objects3);
gdjs.copyArray(runtimeScene.getObjects("HeartText3"), gdjs.MainCode.GDHeartText3Objects3);
gdjs.copyArray(runtimeScene.getObjects("HeartText5"), gdjs.MainCode.GDHeartText5Objects3);
gdjs.copyArray(runtimeScene.getObjects("HeartText6"), gdjs.MainCode.GDHeartText6Objects3);
gdjs.copyArray(runtimeScene.getObjects("LikeText1"), gdjs.MainCode.GDLikeText1Objects3);
gdjs.copyArray(runtimeScene.getObjects("LikeText2"), gdjs.MainCode.GDLikeText2Objects3);
gdjs.copyArray(runtimeScene.getObjects("LikeText3"), gdjs.MainCode.GDLikeText3Objects3);
gdjs.copyArray(runtimeScene.getObjects("LikeText5"), gdjs.MainCode.GDLikeText5Objects3);
gdjs.copyArray(runtimeScene.getObjects("LikeText6"), gdjs.MainCode.GDLikeText6Objects3);
gdjs.copyArray(runtimeScene.getObjects("TweetFace1"), gdjs.MainCode.GDTweetFace1Objects3);
gdjs.copyArray(runtimeScene.getObjects("TweetFace2"), gdjs.MainCode.GDTweetFace2Objects3);
gdjs.copyArray(runtimeScene.getObjects("TweetFace3"), gdjs.MainCode.GDTweetFace3Objects3);
gdjs.copyArray(runtimeScene.getObjects("TweetFace5"), gdjs.MainCode.GDTweetFace5Objects3);
gdjs.copyArray(runtimeScene.getObjects("TweetFace6"), gdjs.MainCode.GDTweetFace6Objects3);
gdjs.copyArray(runtimeScene.getObjects("TweetTitle1"), gdjs.MainCode.GDTweetTitle1Objects3);
gdjs.copyArray(runtimeScene.getObjects("TweetTitle2"), gdjs.MainCode.GDTweetTitle2Objects3);
gdjs.copyArray(runtimeScene.getObjects("TweetTitle3"), gdjs.MainCode.GDTweetTitle3Objects3);
gdjs.copyArray(runtimeScene.getObjects("TweetTitle5"), gdjs.MainCode.GDTweetTitle5Objects3);
gdjs.copyArray(runtimeScene.getObjects("TweetTitle6"), gdjs.MainCode.GDTweetTitle6Objects3);
{for(var i = 0, len = gdjs.MainCode.GDTweetTitle1Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDTweetTitle1Objects3[i].getBehavior("Text").setText(runtimeScene.getScene().getVariables().getFromIndex(10).getChild(gdjs.randomInRange(0, 14)).getAsString());
}
}{for(var i = 0, len = gdjs.MainCode.GDTweetTitle2Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDTweetTitle2Objects3[i].getBehavior("Text").setText(runtimeScene.getScene().getVariables().getFromIndex(10).getChild(gdjs.randomInRange(0, 14)).getAsString());
}
}{for(var i = 0, len = gdjs.MainCode.GDTweetTitle3Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDTweetTitle3Objects3[i].getBehavior("Text").setText(runtimeScene.getScene().getVariables().getFromIndex(10).getChild(gdjs.randomInRange(0, 14)).getAsString());
}
}{for(var i = 0, len = gdjs.MainCode.GDTweetTitle5Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDTweetTitle5Objects3[i].getBehavior("Text").setText(runtimeScene.getScene().getVariables().getFromIndex(10).getChild(gdjs.randomInRange(0, 14)).getAsString());
}
}{for(var i = 0, len = gdjs.MainCode.GDTweetTitle6Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDTweetTitle6Objects3[i].getBehavior("Text").setText(runtimeScene.getScene().getVariables().getFromIndex(10).getChild(gdjs.randomInRange(0, 14)).getAsString());
}
}{for(var i = 0, len = gdjs.MainCode.GDTweetFace1Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDTweetFace1Objects3[i].getBehavior("Animation").setAnimationIndex(gdjs.randomInRange(0, 5));
}
}{for(var i = 0, len = gdjs.MainCode.GDTweetFace2Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDTweetFace2Objects3[i].getBehavior("Animation").setAnimationIndex(gdjs.randomInRange(0, 5));
}
}{for(var i = 0, len = gdjs.MainCode.GDTweetFace3Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDTweetFace3Objects3[i].getBehavior("Animation").setAnimationIndex(gdjs.randomInRange(0, 5));
}
}{for(var i = 0, len = gdjs.MainCode.GDTweetFace5Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDTweetFace5Objects3[i].getBehavior("Animation").setAnimationIndex(gdjs.randomInRange(0, 5));
}
}{for(var i = 0, len = gdjs.MainCode.GDTweetFace6Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDTweetFace6Objects3[i].getBehavior("Animation").setAnimationIndex(gdjs.randomInRange(0, 5));
}
}{for(var i = 0, len = gdjs.MainCode.GDFireText1Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDFireText1Objects3[i].getBehavior("Text").setText(gdjs.evtTools.common.toString(gdjs.randomInRange(10, 99)));
}
}{for(var i = 0, len = gdjs.MainCode.GDFireText2Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDFireText2Objects3[i].getBehavior("Text").setText(gdjs.evtTools.common.toString(gdjs.randomInRange(10, 99)));
}
}{for(var i = 0, len = gdjs.MainCode.GDFireText3Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDFireText3Objects3[i].getBehavior("Text").setText(gdjs.evtTools.common.toString(gdjs.randomInRange(10, 99)));
}
}{for(var i = 0, len = gdjs.MainCode.GDFireText5Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDFireText5Objects3[i].getBehavior("Text").setText(gdjs.evtTools.common.toString(gdjs.randomInRange(10, 99)));
}
}{for(var i = 0, len = gdjs.MainCode.GDFireText6Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDFireText6Objects3[i].getBehavior("Text").setText(gdjs.evtTools.common.toString(gdjs.randomInRange(10, 99)));
}
}{for(var i = 0, len = gdjs.MainCode.GDHeartText1Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDHeartText1Objects3[i].getBehavior("Text").setText(gdjs.evtTools.common.toString(gdjs.randomInRange(10, 99)));
}
}{for(var i = 0, len = gdjs.MainCode.GDHeartText2Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDHeartText2Objects3[i].getBehavior("Text").setText(gdjs.evtTools.common.toString(gdjs.randomInRange(10, 99)));
}
}{for(var i = 0, len = gdjs.MainCode.GDHeartText3Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDHeartText3Objects3[i].getBehavior("Text").setText(gdjs.evtTools.common.toString(gdjs.randomInRange(10, 99)));
}
}{for(var i = 0, len = gdjs.MainCode.GDHeartText5Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDHeartText5Objects3[i].getBehavior("Text").setText(gdjs.evtTools.common.toString(gdjs.randomInRange(10, 99)));
}
}{for(var i = 0, len = gdjs.MainCode.GDHeartText6Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDHeartText6Objects3[i].getBehavior("Text").setText(gdjs.evtTools.common.toString(gdjs.randomInRange(10, 99)));
}
}{for(var i = 0, len = gdjs.MainCode.GDLikeText1Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDLikeText1Objects3[i].getBehavior("Text").setText(gdjs.evtTools.common.toString(gdjs.randomInRange(10, 99)));
}
}{for(var i = 0, len = gdjs.MainCode.GDLikeText2Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDLikeText2Objects3[i].getBehavior("Text").setText(gdjs.evtTools.common.toString(gdjs.randomInRange(10, 99)));
}
}{for(var i = 0, len = gdjs.MainCode.GDLikeText3Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDLikeText3Objects3[i].getBehavior("Text").setText(gdjs.evtTools.common.toString(gdjs.randomInRange(10, 99)));
}
}{for(var i = 0, len = gdjs.MainCode.GDLikeText5Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDLikeText5Objects3[i].getBehavior("Text").setText(gdjs.evtTools.common.toString(gdjs.randomInRange(10, 99)));
}
}{for(var i = 0, len = gdjs.MainCode.GDLikeText6Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDLikeText6Objects3[i].getBehavior("Text").setText(gdjs.evtTools.common.toString(gdjs.randomInRange(10, 99)));
}
}}

}


};gdjs.MainCode.eventsList39 = function(runtimeScene, asyncObjectsList) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15103924);
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.MainCode.eventsList38(runtimeScene, asyncObjectsList);} //End of subevents
}

}


};gdjs.MainCode.eventsList40 = function(runtimeScene, asyncObjectsList) {

{



}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("FireText1"), gdjs.MainCode.GDFireText1Objects3);
gdjs.copyArray(runtimeScene.getObjects("FireText2"), gdjs.MainCode.GDFireText2Objects3);
gdjs.copyArray(runtimeScene.getObjects("FireText3"), gdjs.MainCode.GDFireText3Objects3);
gdjs.copyArray(runtimeScene.getObjects("FireText5"), gdjs.MainCode.GDFireText5Objects3);
gdjs.copyArray(runtimeScene.getObjects("FireText6"), gdjs.MainCode.GDFireText6Objects3);
gdjs.copyArray(runtimeScene.getObjects("HeartText1"), gdjs.MainCode.GDHeartText1Objects3);
gdjs.copyArray(runtimeScene.getObjects("HeartText2"), gdjs.MainCode.GDHeartText2Objects3);
gdjs.copyArray(runtimeScene.getObjects("HeartText3"), gdjs.MainCode.GDHeartText3Objects3);
gdjs.copyArray(runtimeScene.getObjects("HeartText5"), gdjs.MainCode.GDHeartText5Objects3);
gdjs.copyArray(runtimeScene.getObjects("HeartText6"), gdjs.MainCode.GDHeartText6Objects3);
gdjs.copyArray(runtimeScene.getObjects("LikeText1"), gdjs.MainCode.GDLikeText1Objects3);
gdjs.copyArray(runtimeScene.getObjects("LikeText2"), gdjs.MainCode.GDLikeText2Objects3);
gdjs.copyArray(runtimeScene.getObjects("LikeText3"), gdjs.MainCode.GDLikeText3Objects3);
gdjs.copyArray(runtimeScene.getObjects("LikeText5"), gdjs.MainCode.GDLikeText5Objects3);
gdjs.copyArray(runtimeScene.getObjects("LikeText6"), gdjs.MainCode.GDLikeText6Objects3);
gdjs.copyArray(runtimeScene.getObjects("TweetFace1"), gdjs.MainCode.GDTweetFace1Objects3);
gdjs.copyArray(runtimeScene.getObjects("TweetFace2"), gdjs.MainCode.GDTweetFace2Objects3);
gdjs.copyArray(runtimeScene.getObjects("TweetFace3"), gdjs.MainCode.GDTweetFace3Objects3);
gdjs.copyArray(runtimeScene.getObjects("TweetFace5"), gdjs.MainCode.GDTweetFace5Objects3);
gdjs.copyArray(runtimeScene.getObjects("TweetFace6"), gdjs.MainCode.GDTweetFace6Objects3);
gdjs.copyArray(runtimeScene.getObjects("TweetTitle1"), gdjs.MainCode.GDTweetTitle1Objects3);
gdjs.copyArray(runtimeScene.getObjects("TweetTitle2"), gdjs.MainCode.GDTweetTitle2Objects3);
gdjs.copyArray(runtimeScene.getObjects("TweetTitle3"), gdjs.MainCode.GDTweetTitle3Objects3);
gdjs.copyArray(runtimeScene.getObjects("TweetTitle5"), gdjs.MainCode.GDTweetTitle5Objects3);
gdjs.copyArray(runtimeScene.getObjects("TweetTitle6"), gdjs.MainCode.GDTweetTitle6Objects3);
{for(var i = 0, len = gdjs.MainCode.GDTweetTitle1Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDTweetTitle1Objects3[i].getBehavior("Text").setText(runtimeScene.getScene().getVariables().getFromIndex(10).getChild(gdjs.randomInRange(0, 14)).getAsString());
}
}{for(var i = 0, len = gdjs.MainCode.GDTweetTitle2Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDTweetTitle2Objects3[i].getBehavior("Text").setText(runtimeScene.getScene().getVariables().getFromIndex(10).getChild(gdjs.randomInRange(0, 14)).getAsString());
}
}{for(var i = 0, len = gdjs.MainCode.GDTweetTitle3Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDTweetTitle3Objects3[i].getBehavior("Text").setText(runtimeScene.getScene().getVariables().getFromIndex(10).getChild(gdjs.randomInRange(0, 14)).getAsString());
}
}{for(var i = 0, len = gdjs.MainCode.GDTweetTitle5Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDTweetTitle5Objects3[i].getBehavior("Text").setText(runtimeScene.getScene().getVariables().getFromIndex(10).getChild(gdjs.randomInRange(0, 14)).getAsString());
}
}{for(var i = 0, len = gdjs.MainCode.GDTweetTitle6Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDTweetTitle6Objects3[i].getBehavior("Text").setText(runtimeScene.getScene().getVariables().getFromIndex(10).getChild(gdjs.randomInRange(0, 14)).getAsString());
}
}{for(var i = 0, len = gdjs.MainCode.GDTweetFace1Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDTweetFace1Objects3[i].getBehavior("Animation").setAnimationIndex(gdjs.randomInRange(0, 5));
}
}{for(var i = 0, len = gdjs.MainCode.GDTweetFace2Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDTweetFace2Objects3[i].getBehavior("Animation").setAnimationIndex(gdjs.randomInRange(0, 5));
}
}{for(var i = 0, len = gdjs.MainCode.GDTweetFace3Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDTweetFace3Objects3[i].getBehavior("Animation").setAnimationIndex(gdjs.randomInRange(0, 5));
}
}{for(var i = 0, len = gdjs.MainCode.GDTweetFace5Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDTweetFace5Objects3[i].getBehavior("Animation").setAnimationIndex(gdjs.randomInRange(0, 5));
}
}{for(var i = 0, len = gdjs.MainCode.GDTweetFace6Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDTweetFace6Objects3[i].getBehavior("Animation").setAnimationIndex(gdjs.randomInRange(0, 5));
}
}{for(var i = 0, len = gdjs.MainCode.GDFireText1Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDFireText1Objects3[i].getBehavior("Text").setText(gdjs.evtTools.common.toString(gdjs.randomInRange(10, 99)));
}
}{for(var i = 0, len = gdjs.MainCode.GDFireText2Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDFireText2Objects3[i].getBehavior("Text").setText(gdjs.evtTools.common.toString(gdjs.randomInRange(10, 99)));
}
}{for(var i = 0, len = gdjs.MainCode.GDFireText3Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDFireText3Objects3[i].getBehavior("Text").setText(gdjs.evtTools.common.toString(gdjs.randomInRange(10, 99)));
}
}{for(var i = 0, len = gdjs.MainCode.GDFireText5Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDFireText5Objects3[i].getBehavior("Text").setText(gdjs.evtTools.common.toString(gdjs.randomInRange(10, 99)));
}
}{for(var i = 0, len = gdjs.MainCode.GDFireText6Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDFireText6Objects3[i].getBehavior("Text").setText(gdjs.evtTools.common.toString(gdjs.randomInRange(10, 99)));
}
}{for(var i = 0, len = gdjs.MainCode.GDHeartText1Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDHeartText1Objects3[i].getBehavior("Text").setText(gdjs.evtTools.common.toString(gdjs.randomInRange(10, 99)));
}
}{for(var i = 0, len = gdjs.MainCode.GDHeartText2Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDHeartText2Objects3[i].getBehavior("Text").setText(gdjs.evtTools.common.toString(gdjs.randomInRange(10, 99)));
}
}{for(var i = 0, len = gdjs.MainCode.GDHeartText3Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDHeartText3Objects3[i].getBehavior("Text").setText(gdjs.evtTools.common.toString(gdjs.randomInRange(10, 99)));
}
}{for(var i = 0, len = gdjs.MainCode.GDHeartText5Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDHeartText5Objects3[i].getBehavior("Text").setText(gdjs.evtTools.common.toString(gdjs.randomInRange(10, 99)));
}
}{for(var i = 0, len = gdjs.MainCode.GDHeartText6Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDHeartText6Objects3[i].getBehavior("Text").setText(gdjs.evtTools.common.toString(gdjs.randomInRange(10, 99)));
}
}{for(var i = 0, len = gdjs.MainCode.GDLikeText1Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDLikeText1Objects3[i].getBehavior("Text").setText(gdjs.evtTools.common.toString(gdjs.randomInRange(10, 99)));
}
}{for(var i = 0, len = gdjs.MainCode.GDLikeText2Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDLikeText2Objects3[i].getBehavior("Text").setText(gdjs.evtTools.common.toString(gdjs.randomInRange(10, 99)));
}
}{for(var i = 0, len = gdjs.MainCode.GDLikeText3Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDLikeText3Objects3[i].getBehavior("Text").setText(gdjs.evtTools.common.toString(gdjs.randomInRange(10, 99)));
}
}{for(var i = 0, len = gdjs.MainCode.GDLikeText5Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDLikeText5Objects3[i].getBehavior("Text").setText(gdjs.evtTools.common.toString(gdjs.randomInRange(10, 99)));
}
}{for(var i = 0, len = gdjs.MainCode.GDLikeText6Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDLikeText6Objects3[i].getBehavior("Text").setText(gdjs.evtTools.common.toString(gdjs.randomInRange(10, 99)));
}
}}

}


};gdjs.MainCode.eventsList41 = function(runtimeScene, asyncObjectsList) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15107364);
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.MainCode.eventsList40(runtimeScene, asyncObjectsList);} //End of subevents
}

}


};gdjs.MainCode.eventsList42 = function(runtimeScene, asyncObjectsList) {

{



}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("FireText1"), gdjs.MainCode.GDFireText1Objects3);
gdjs.copyArray(runtimeScene.getObjects("FireText2"), gdjs.MainCode.GDFireText2Objects3);
gdjs.copyArray(runtimeScene.getObjects("FireText3"), gdjs.MainCode.GDFireText3Objects3);
gdjs.copyArray(runtimeScene.getObjects("FireText5"), gdjs.MainCode.GDFireText5Objects3);
gdjs.copyArray(runtimeScene.getObjects("FireText6"), gdjs.MainCode.GDFireText6Objects3);
gdjs.copyArray(runtimeScene.getObjects("HeartText1"), gdjs.MainCode.GDHeartText1Objects3);
gdjs.copyArray(runtimeScene.getObjects("HeartText2"), gdjs.MainCode.GDHeartText2Objects3);
gdjs.copyArray(runtimeScene.getObjects("HeartText3"), gdjs.MainCode.GDHeartText3Objects3);
gdjs.copyArray(runtimeScene.getObjects("HeartText5"), gdjs.MainCode.GDHeartText5Objects3);
gdjs.copyArray(runtimeScene.getObjects("HeartText6"), gdjs.MainCode.GDHeartText6Objects3);
gdjs.copyArray(runtimeScene.getObjects("LikeText1"), gdjs.MainCode.GDLikeText1Objects3);
gdjs.copyArray(runtimeScene.getObjects("LikeText2"), gdjs.MainCode.GDLikeText2Objects3);
gdjs.copyArray(runtimeScene.getObjects("LikeText3"), gdjs.MainCode.GDLikeText3Objects3);
gdjs.copyArray(runtimeScene.getObjects("LikeText5"), gdjs.MainCode.GDLikeText5Objects3);
gdjs.copyArray(runtimeScene.getObjects("LikeText6"), gdjs.MainCode.GDLikeText6Objects3);
gdjs.copyArray(runtimeScene.getObjects("TweetFace1"), gdjs.MainCode.GDTweetFace1Objects3);
gdjs.copyArray(runtimeScene.getObjects("TweetFace2"), gdjs.MainCode.GDTweetFace2Objects3);
gdjs.copyArray(runtimeScene.getObjects("TweetFace3"), gdjs.MainCode.GDTweetFace3Objects3);
gdjs.copyArray(runtimeScene.getObjects("TweetFace5"), gdjs.MainCode.GDTweetFace5Objects3);
gdjs.copyArray(runtimeScene.getObjects("TweetFace6"), gdjs.MainCode.GDTweetFace6Objects3);
gdjs.copyArray(runtimeScene.getObjects("TweetTitle1"), gdjs.MainCode.GDTweetTitle1Objects3);
gdjs.copyArray(runtimeScene.getObjects("TweetTitle2"), gdjs.MainCode.GDTweetTitle2Objects3);
gdjs.copyArray(runtimeScene.getObjects("TweetTitle3"), gdjs.MainCode.GDTweetTitle3Objects3);
gdjs.copyArray(runtimeScene.getObjects("TweetTitle5"), gdjs.MainCode.GDTweetTitle5Objects3);
gdjs.copyArray(runtimeScene.getObjects("TweetTitle6"), gdjs.MainCode.GDTweetTitle6Objects3);
{for(var i = 0, len = gdjs.MainCode.GDTweetTitle1Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDTweetTitle1Objects3[i].getBehavior("Text").setText(runtimeScene.getScene().getVariables().getFromIndex(10).getChild(gdjs.randomInRange(0, 14)).getAsString());
}
}{for(var i = 0, len = gdjs.MainCode.GDTweetTitle2Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDTweetTitle2Objects3[i].getBehavior("Text").setText(runtimeScene.getScene().getVariables().getFromIndex(10).getChild(gdjs.randomInRange(0, 14)).getAsString());
}
}{for(var i = 0, len = gdjs.MainCode.GDTweetTitle3Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDTweetTitle3Objects3[i].getBehavior("Text").setText(runtimeScene.getScene().getVariables().getFromIndex(10).getChild(gdjs.randomInRange(0, 14)).getAsString());
}
}{for(var i = 0, len = gdjs.MainCode.GDTweetTitle5Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDTweetTitle5Objects3[i].getBehavior("Text").setText(runtimeScene.getScene().getVariables().getFromIndex(10).getChild(gdjs.randomInRange(0, 14)).getAsString());
}
}{for(var i = 0, len = gdjs.MainCode.GDTweetTitle6Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDTweetTitle6Objects3[i].getBehavior("Text").setText(runtimeScene.getScene().getVariables().getFromIndex(10).getChild(gdjs.randomInRange(0, 14)).getAsString());
}
}{for(var i = 0, len = gdjs.MainCode.GDTweetFace1Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDTweetFace1Objects3[i].getBehavior("Animation").setAnimationIndex(gdjs.randomInRange(0, 5));
}
}{for(var i = 0, len = gdjs.MainCode.GDTweetFace2Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDTweetFace2Objects3[i].getBehavior("Animation").setAnimationIndex(gdjs.randomInRange(0, 5));
}
}{for(var i = 0, len = gdjs.MainCode.GDTweetFace3Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDTweetFace3Objects3[i].getBehavior("Animation").setAnimationIndex(gdjs.randomInRange(0, 5));
}
}{for(var i = 0, len = gdjs.MainCode.GDTweetFace5Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDTweetFace5Objects3[i].getBehavior("Animation").setAnimationIndex(gdjs.randomInRange(0, 5));
}
}{for(var i = 0, len = gdjs.MainCode.GDTweetFace6Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDTweetFace6Objects3[i].getBehavior("Animation").setAnimationIndex(gdjs.randomInRange(0, 5));
}
}{for(var i = 0, len = gdjs.MainCode.GDFireText1Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDFireText1Objects3[i].getBehavior("Text").setText(gdjs.evtTools.common.toString(gdjs.randomInRange(10, 99)));
}
}{for(var i = 0, len = gdjs.MainCode.GDFireText2Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDFireText2Objects3[i].getBehavior("Text").setText(gdjs.evtTools.common.toString(gdjs.randomInRange(10, 99)));
}
}{for(var i = 0, len = gdjs.MainCode.GDFireText3Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDFireText3Objects3[i].getBehavior("Text").setText(gdjs.evtTools.common.toString(gdjs.randomInRange(10, 99)));
}
}{for(var i = 0, len = gdjs.MainCode.GDFireText5Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDFireText5Objects3[i].getBehavior("Text").setText(gdjs.evtTools.common.toString(gdjs.randomInRange(10, 99)));
}
}{for(var i = 0, len = gdjs.MainCode.GDFireText6Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDFireText6Objects3[i].getBehavior("Text").setText(gdjs.evtTools.common.toString(gdjs.randomInRange(10, 99)));
}
}{for(var i = 0, len = gdjs.MainCode.GDHeartText1Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDHeartText1Objects3[i].getBehavior("Text").setText(gdjs.evtTools.common.toString(gdjs.randomInRange(10, 99)));
}
}{for(var i = 0, len = gdjs.MainCode.GDHeartText2Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDHeartText2Objects3[i].getBehavior("Text").setText(gdjs.evtTools.common.toString(gdjs.randomInRange(10, 99)));
}
}{for(var i = 0, len = gdjs.MainCode.GDHeartText3Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDHeartText3Objects3[i].getBehavior("Text").setText(gdjs.evtTools.common.toString(gdjs.randomInRange(10, 99)));
}
}{for(var i = 0, len = gdjs.MainCode.GDHeartText5Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDHeartText5Objects3[i].getBehavior("Text").setText(gdjs.evtTools.common.toString(gdjs.randomInRange(10, 99)));
}
}{for(var i = 0, len = gdjs.MainCode.GDHeartText6Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDHeartText6Objects3[i].getBehavior("Text").setText(gdjs.evtTools.common.toString(gdjs.randomInRange(10, 99)));
}
}{for(var i = 0, len = gdjs.MainCode.GDLikeText1Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDLikeText1Objects3[i].getBehavior("Text").setText(gdjs.evtTools.common.toString(gdjs.randomInRange(10, 99)));
}
}{for(var i = 0, len = gdjs.MainCode.GDLikeText2Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDLikeText2Objects3[i].getBehavior("Text").setText(gdjs.evtTools.common.toString(gdjs.randomInRange(10, 99)));
}
}{for(var i = 0, len = gdjs.MainCode.GDLikeText3Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDLikeText3Objects3[i].getBehavior("Text").setText(gdjs.evtTools.common.toString(gdjs.randomInRange(10, 99)));
}
}{for(var i = 0, len = gdjs.MainCode.GDLikeText5Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDLikeText5Objects3[i].getBehavior("Text").setText(gdjs.evtTools.common.toString(gdjs.randomInRange(10, 99)));
}
}{for(var i = 0, len = gdjs.MainCode.GDLikeText6Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDLikeText6Objects3[i].getBehavior("Text").setText(gdjs.evtTools.common.toString(gdjs.randomInRange(10, 99)));
}
}}

}


};gdjs.MainCode.eventsList43 = function(runtimeScene, asyncObjectsList) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15110668);
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.MainCode.eventsList42(runtimeScene, asyncObjectsList);} //End of subevents
}

}


};gdjs.MainCode.eventsList44 = function(runtimeScene, asyncObjectsList) {

{



}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("FireText1"), gdjs.MainCode.GDFireText1Objects3);
gdjs.copyArray(runtimeScene.getObjects("FireText2"), gdjs.MainCode.GDFireText2Objects3);
gdjs.copyArray(runtimeScene.getObjects("FireText3"), gdjs.MainCode.GDFireText3Objects3);
gdjs.copyArray(runtimeScene.getObjects("FireText5"), gdjs.MainCode.GDFireText5Objects3);
gdjs.copyArray(runtimeScene.getObjects("FireText6"), gdjs.MainCode.GDFireText6Objects3);
gdjs.copyArray(runtimeScene.getObjects("HeartText1"), gdjs.MainCode.GDHeartText1Objects3);
gdjs.copyArray(runtimeScene.getObjects("HeartText2"), gdjs.MainCode.GDHeartText2Objects3);
gdjs.copyArray(runtimeScene.getObjects("HeartText3"), gdjs.MainCode.GDHeartText3Objects3);
gdjs.copyArray(runtimeScene.getObjects("HeartText5"), gdjs.MainCode.GDHeartText5Objects3);
gdjs.copyArray(runtimeScene.getObjects("HeartText6"), gdjs.MainCode.GDHeartText6Objects3);
gdjs.copyArray(runtimeScene.getObjects("LikeText1"), gdjs.MainCode.GDLikeText1Objects3);
gdjs.copyArray(runtimeScene.getObjects("LikeText2"), gdjs.MainCode.GDLikeText2Objects3);
gdjs.copyArray(runtimeScene.getObjects("LikeText3"), gdjs.MainCode.GDLikeText3Objects3);
gdjs.copyArray(runtimeScene.getObjects("LikeText5"), gdjs.MainCode.GDLikeText5Objects3);
gdjs.copyArray(runtimeScene.getObjects("LikeText6"), gdjs.MainCode.GDLikeText6Objects3);
gdjs.copyArray(runtimeScene.getObjects("TweetFace1"), gdjs.MainCode.GDTweetFace1Objects3);
gdjs.copyArray(runtimeScene.getObjects("TweetFace2"), gdjs.MainCode.GDTweetFace2Objects3);
gdjs.copyArray(runtimeScene.getObjects("TweetFace3"), gdjs.MainCode.GDTweetFace3Objects3);
gdjs.copyArray(runtimeScene.getObjects("TweetFace5"), gdjs.MainCode.GDTweetFace5Objects3);
gdjs.copyArray(runtimeScene.getObjects("TweetFace6"), gdjs.MainCode.GDTweetFace6Objects3);
gdjs.copyArray(runtimeScene.getObjects("TweetTitle1"), gdjs.MainCode.GDTweetTitle1Objects3);
gdjs.copyArray(runtimeScene.getObjects("TweetTitle2"), gdjs.MainCode.GDTweetTitle2Objects3);
gdjs.copyArray(runtimeScene.getObjects("TweetTitle3"), gdjs.MainCode.GDTweetTitle3Objects3);
gdjs.copyArray(runtimeScene.getObjects("TweetTitle5"), gdjs.MainCode.GDTweetTitle5Objects3);
gdjs.copyArray(runtimeScene.getObjects("TweetTitle6"), gdjs.MainCode.GDTweetTitle6Objects3);
{for(var i = 0, len = gdjs.MainCode.GDTweetTitle1Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDTweetTitle1Objects3[i].getBehavior("Text").setText(runtimeScene.getScene().getVariables().getFromIndex(10).getChild(gdjs.randomInRange(0, 14)).getAsString());
}
}{for(var i = 0, len = gdjs.MainCode.GDTweetTitle2Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDTweetTitle2Objects3[i].getBehavior("Text").setText(runtimeScene.getScene().getVariables().getFromIndex(10).getChild(gdjs.randomInRange(0, 14)).getAsString());
}
}{for(var i = 0, len = gdjs.MainCode.GDTweetTitle3Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDTweetTitle3Objects3[i].getBehavior("Text").setText(runtimeScene.getScene().getVariables().getFromIndex(10).getChild(gdjs.randomInRange(0, 14)).getAsString());
}
}{for(var i = 0, len = gdjs.MainCode.GDTweetTitle5Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDTweetTitle5Objects3[i].getBehavior("Text").setText(runtimeScene.getScene().getVariables().getFromIndex(10).getChild(gdjs.randomInRange(0, 14)).getAsString());
}
}{for(var i = 0, len = gdjs.MainCode.GDTweetTitle6Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDTweetTitle6Objects3[i].getBehavior("Text").setText(runtimeScene.getScene().getVariables().getFromIndex(10).getChild(gdjs.randomInRange(0, 14)).getAsString());
}
}{for(var i = 0, len = gdjs.MainCode.GDTweetFace1Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDTweetFace1Objects3[i].getBehavior("Animation").setAnimationIndex(gdjs.randomInRange(0, 5));
}
}{for(var i = 0, len = gdjs.MainCode.GDTweetFace2Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDTweetFace2Objects3[i].getBehavior("Animation").setAnimationIndex(gdjs.randomInRange(0, 5));
}
}{for(var i = 0, len = gdjs.MainCode.GDTweetFace3Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDTweetFace3Objects3[i].getBehavior("Animation").setAnimationIndex(gdjs.randomInRange(0, 5));
}
}{for(var i = 0, len = gdjs.MainCode.GDTweetFace5Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDTweetFace5Objects3[i].getBehavior("Animation").setAnimationIndex(gdjs.randomInRange(0, 5));
}
}{for(var i = 0, len = gdjs.MainCode.GDTweetFace6Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDTweetFace6Objects3[i].getBehavior("Animation").setAnimationIndex(gdjs.randomInRange(0, 5));
}
}{for(var i = 0, len = gdjs.MainCode.GDFireText1Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDFireText1Objects3[i].getBehavior("Text").setText(gdjs.evtTools.common.toString(gdjs.randomInRange(10, 99)));
}
}{for(var i = 0, len = gdjs.MainCode.GDFireText2Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDFireText2Objects3[i].getBehavior("Text").setText(gdjs.evtTools.common.toString(gdjs.randomInRange(10, 99)));
}
}{for(var i = 0, len = gdjs.MainCode.GDFireText3Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDFireText3Objects3[i].getBehavior("Text").setText(gdjs.evtTools.common.toString(gdjs.randomInRange(10, 99)));
}
}{for(var i = 0, len = gdjs.MainCode.GDFireText5Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDFireText5Objects3[i].getBehavior("Text").setText(gdjs.evtTools.common.toString(gdjs.randomInRange(10, 99)));
}
}{for(var i = 0, len = gdjs.MainCode.GDFireText6Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDFireText6Objects3[i].getBehavior("Text").setText(gdjs.evtTools.common.toString(gdjs.randomInRange(10, 99)));
}
}{for(var i = 0, len = gdjs.MainCode.GDHeartText1Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDHeartText1Objects3[i].getBehavior("Text").setText(gdjs.evtTools.common.toString(gdjs.randomInRange(10, 99)));
}
}{for(var i = 0, len = gdjs.MainCode.GDHeartText2Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDHeartText2Objects3[i].getBehavior("Text").setText(gdjs.evtTools.common.toString(gdjs.randomInRange(10, 99)));
}
}{for(var i = 0, len = gdjs.MainCode.GDHeartText3Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDHeartText3Objects3[i].getBehavior("Text").setText(gdjs.evtTools.common.toString(gdjs.randomInRange(10, 99)));
}
}{for(var i = 0, len = gdjs.MainCode.GDHeartText5Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDHeartText5Objects3[i].getBehavior("Text").setText(gdjs.evtTools.common.toString(gdjs.randomInRange(10, 99)));
}
}{for(var i = 0, len = gdjs.MainCode.GDHeartText6Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDHeartText6Objects3[i].getBehavior("Text").setText(gdjs.evtTools.common.toString(gdjs.randomInRange(10, 99)));
}
}{for(var i = 0, len = gdjs.MainCode.GDLikeText1Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDLikeText1Objects3[i].getBehavior("Text").setText(gdjs.evtTools.common.toString(gdjs.randomInRange(10, 99)));
}
}{for(var i = 0, len = gdjs.MainCode.GDLikeText2Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDLikeText2Objects3[i].getBehavior("Text").setText(gdjs.evtTools.common.toString(gdjs.randomInRange(10, 99)));
}
}{for(var i = 0, len = gdjs.MainCode.GDLikeText3Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDLikeText3Objects3[i].getBehavior("Text").setText(gdjs.evtTools.common.toString(gdjs.randomInRange(10, 99)));
}
}{for(var i = 0, len = gdjs.MainCode.GDLikeText5Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDLikeText5Objects3[i].getBehavior("Text").setText(gdjs.evtTools.common.toString(gdjs.randomInRange(10, 99)));
}
}{for(var i = 0, len = gdjs.MainCode.GDLikeText6Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDLikeText6Objects3[i].getBehavior("Text").setText(gdjs.evtTools.common.toString(gdjs.randomInRange(10, 99)));
}
}}

}


};gdjs.MainCode.eventsList45 = function(runtimeScene, asyncObjectsList) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15114220);
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.MainCode.eventsList44(runtimeScene, asyncObjectsList);} //End of subevents
}

}


};gdjs.MainCode.eventsList46 = function(runtimeScene, asyncObjectsList) {

{



}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("FireText1"), gdjs.MainCode.GDFireText1Objects3);
gdjs.copyArray(runtimeScene.getObjects("FireText2"), gdjs.MainCode.GDFireText2Objects3);
gdjs.copyArray(runtimeScene.getObjects("FireText3"), gdjs.MainCode.GDFireText3Objects3);
gdjs.copyArray(runtimeScene.getObjects("FireText5"), gdjs.MainCode.GDFireText5Objects3);
gdjs.copyArray(runtimeScene.getObjects("FireText6"), gdjs.MainCode.GDFireText6Objects3);
gdjs.copyArray(runtimeScene.getObjects("HeartText1"), gdjs.MainCode.GDHeartText1Objects3);
gdjs.copyArray(runtimeScene.getObjects("HeartText2"), gdjs.MainCode.GDHeartText2Objects3);
gdjs.copyArray(runtimeScene.getObjects("HeartText3"), gdjs.MainCode.GDHeartText3Objects3);
gdjs.copyArray(runtimeScene.getObjects("HeartText5"), gdjs.MainCode.GDHeartText5Objects3);
gdjs.copyArray(runtimeScene.getObjects("HeartText6"), gdjs.MainCode.GDHeartText6Objects3);
gdjs.copyArray(runtimeScene.getObjects("LikeText1"), gdjs.MainCode.GDLikeText1Objects3);
gdjs.copyArray(runtimeScene.getObjects("LikeText2"), gdjs.MainCode.GDLikeText2Objects3);
gdjs.copyArray(runtimeScene.getObjects("LikeText3"), gdjs.MainCode.GDLikeText3Objects3);
gdjs.copyArray(runtimeScene.getObjects("LikeText5"), gdjs.MainCode.GDLikeText5Objects3);
gdjs.copyArray(runtimeScene.getObjects("LikeText6"), gdjs.MainCode.GDLikeText6Objects3);
gdjs.copyArray(runtimeScene.getObjects("TweetFace1"), gdjs.MainCode.GDTweetFace1Objects3);
gdjs.copyArray(runtimeScene.getObjects("TweetFace2"), gdjs.MainCode.GDTweetFace2Objects3);
gdjs.copyArray(runtimeScene.getObjects("TweetFace3"), gdjs.MainCode.GDTweetFace3Objects3);
gdjs.copyArray(runtimeScene.getObjects("TweetFace5"), gdjs.MainCode.GDTweetFace5Objects3);
gdjs.copyArray(runtimeScene.getObjects("TweetFace6"), gdjs.MainCode.GDTweetFace6Objects3);
gdjs.copyArray(runtimeScene.getObjects("TweetTitle1"), gdjs.MainCode.GDTweetTitle1Objects3);
gdjs.copyArray(runtimeScene.getObjects("TweetTitle2"), gdjs.MainCode.GDTweetTitle2Objects3);
gdjs.copyArray(runtimeScene.getObjects("TweetTitle3"), gdjs.MainCode.GDTweetTitle3Objects3);
gdjs.copyArray(runtimeScene.getObjects("TweetTitle5"), gdjs.MainCode.GDTweetTitle5Objects3);
gdjs.copyArray(runtimeScene.getObjects("TweetTitle6"), gdjs.MainCode.GDTweetTitle6Objects3);
{for(var i = 0, len = gdjs.MainCode.GDTweetTitle1Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDTweetTitle1Objects3[i].getBehavior("Text").setText(runtimeScene.getScene().getVariables().getFromIndex(10).getChild(gdjs.randomInRange(0, 14)).getAsString());
}
}{for(var i = 0, len = gdjs.MainCode.GDTweetTitle2Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDTweetTitle2Objects3[i].getBehavior("Text").setText(runtimeScene.getScene().getVariables().getFromIndex(10).getChild(gdjs.randomInRange(0, 14)).getAsString());
}
}{for(var i = 0, len = gdjs.MainCode.GDTweetTitle3Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDTweetTitle3Objects3[i].getBehavior("Text").setText(runtimeScene.getScene().getVariables().getFromIndex(10).getChild(gdjs.randomInRange(0, 14)).getAsString());
}
}{for(var i = 0, len = gdjs.MainCode.GDTweetTitle5Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDTweetTitle5Objects3[i].getBehavior("Text").setText(runtimeScene.getScene().getVariables().getFromIndex(10).getChild(gdjs.randomInRange(0, 14)).getAsString());
}
}{for(var i = 0, len = gdjs.MainCode.GDTweetTitle6Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDTweetTitle6Objects3[i].getBehavior("Text").setText(runtimeScene.getScene().getVariables().getFromIndex(10).getChild(gdjs.randomInRange(0, 14)).getAsString());
}
}{for(var i = 0, len = gdjs.MainCode.GDTweetFace1Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDTweetFace1Objects3[i].getBehavior("Animation").setAnimationIndex(gdjs.randomInRange(0, 5));
}
}{for(var i = 0, len = gdjs.MainCode.GDTweetFace2Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDTweetFace2Objects3[i].getBehavior("Animation").setAnimationIndex(gdjs.randomInRange(0, 5));
}
}{for(var i = 0, len = gdjs.MainCode.GDTweetFace3Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDTweetFace3Objects3[i].getBehavior("Animation").setAnimationIndex(gdjs.randomInRange(0, 5));
}
}{for(var i = 0, len = gdjs.MainCode.GDTweetFace5Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDTweetFace5Objects3[i].getBehavior("Animation").setAnimationIndex(gdjs.randomInRange(0, 5));
}
}{for(var i = 0, len = gdjs.MainCode.GDTweetFace6Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDTweetFace6Objects3[i].getBehavior("Animation").setAnimationIndex(gdjs.randomInRange(0, 5));
}
}{for(var i = 0, len = gdjs.MainCode.GDFireText1Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDFireText1Objects3[i].getBehavior("Text").setText(gdjs.evtTools.common.toString(gdjs.randomInRange(10, 99)));
}
}{for(var i = 0, len = gdjs.MainCode.GDFireText2Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDFireText2Objects3[i].getBehavior("Text").setText(gdjs.evtTools.common.toString(gdjs.randomInRange(10, 99)));
}
}{for(var i = 0, len = gdjs.MainCode.GDFireText3Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDFireText3Objects3[i].getBehavior("Text").setText(gdjs.evtTools.common.toString(gdjs.randomInRange(10, 99)));
}
}{for(var i = 0, len = gdjs.MainCode.GDFireText5Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDFireText5Objects3[i].getBehavior("Text").setText(gdjs.evtTools.common.toString(gdjs.randomInRange(10, 99)));
}
}{for(var i = 0, len = gdjs.MainCode.GDFireText6Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDFireText6Objects3[i].getBehavior("Text").setText(gdjs.evtTools.common.toString(gdjs.randomInRange(10, 99)));
}
}{for(var i = 0, len = gdjs.MainCode.GDHeartText1Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDHeartText1Objects3[i].getBehavior("Text").setText(gdjs.evtTools.common.toString(gdjs.randomInRange(10, 99)));
}
}{for(var i = 0, len = gdjs.MainCode.GDHeartText2Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDHeartText2Objects3[i].getBehavior("Text").setText(gdjs.evtTools.common.toString(gdjs.randomInRange(10, 99)));
}
}{for(var i = 0, len = gdjs.MainCode.GDHeartText3Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDHeartText3Objects3[i].getBehavior("Text").setText(gdjs.evtTools.common.toString(gdjs.randomInRange(10, 99)));
}
}{for(var i = 0, len = gdjs.MainCode.GDHeartText5Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDHeartText5Objects3[i].getBehavior("Text").setText(gdjs.evtTools.common.toString(gdjs.randomInRange(10, 99)));
}
}{for(var i = 0, len = gdjs.MainCode.GDHeartText6Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDHeartText6Objects3[i].getBehavior("Text").setText(gdjs.evtTools.common.toString(gdjs.randomInRange(10, 99)));
}
}{for(var i = 0, len = gdjs.MainCode.GDLikeText1Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDLikeText1Objects3[i].getBehavior("Text").setText(gdjs.evtTools.common.toString(gdjs.randomInRange(10, 99)));
}
}{for(var i = 0, len = gdjs.MainCode.GDLikeText2Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDLikeText2Objects3[i].getBehavior("Text").setText(gdjs.evtTools.common.toString(gdjs.randomInRange(10, 99)));
}
}{for(var i = 0, len = gdjs.MainCode.GDLikeText3Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDLikeText3Objects3[i].getBehavior("Text").setText(gdjs.evtTools.common.toString(gdjs.randomInRange(10, 99)));
}
}{for(var i = 0, len = gdjs.MainCode.GDLikeText5Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDLikeText5Objects3[i].getBehavior("Text").setText(gdjs.evtTools.common.toString(gdjs.randomInRange(10, 99)));
}
}{for(var i = 0, len = gdjs.MainCode.GDLikeText6Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDLikeText6Objects3[i].getBehavior("Text").setText(gdjs.evtTools.common.toString(gdjs.randomInRange(10, 99)));
}
}}

}


};gdjs.MainCode.eventsList47 = function(runtimeScene, asyncObjectsList) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15117612);
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.MainCode.eventsList46(runtimeScene, asyncObjectsList);} //End of subevents
}

}


};gdjs.MainCode.eventsList48 = function(runtimeScene, asyncObjectsList) {

{



}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("FireText1"), gdjs.MainCode.GDFireText1Objects3);
gdjs.copyArray(runtimeScene.getObjects("FireText2"), gdjs.MainCode.GDFireText2Objects3);
gdjs.copyArray(runtimeScene.getObjects("FireText3"), gdjs.MainCode.GDFireText3Objects3);
gdjs.copyArray(runtimeScene.getObjects("FireText5"), gdjs.MainCode.GDFireText5Objects3);
gdjs.copyArray(runtimeScene.getObjects("FireText6"), gdjs.MainCode.GDFireText6Objects3);
gdjs.copyArray(runtimeScene.getObjects("HeartText1"), gdjs.MainCode.GDHeartText1Objects3);
gdjs.copyArray(runtimeScene.getObjects("HeartText2"), gdjs.MainCode.GDHeartText2Objects3);
gdjs.copyArray(runtimeScene.getObjects("HeartText3"), gdjs.MainCode.GDHeartText3Objects3);
gdjs.copyArray(runtimeScene.getObjects("HeartText5"), gdjs.MainCode.GDHeartText5Objects3);
gdjs.copyArray(runtimeScene.getObjects("HeartText6"), gdjs.MainCode.GDHeartText6Objects3);
gdjs.copyArray(runtimeScene.getObjects("LikeText1"), gdjs.MainCode.GDLikeText1Objects3);
gdjs.copyArray(runtimeScene.getObjects("LikeText2"), gdjs.MainCode.GDLikeText2Objects3);
gdjs.copyArray(runtimeScene.getObjects("LikeText3"), gdjs.MainCode.GDLikeText3Objects3);
gdjs.copyArray(runtimeScene.getObjects("LikeText5"), gdjs.MainCode.GDLikeText5Objects3);
gdjs.copyArray(runtimeScene.getObjects("LikeText6"), gdjs.MainCode.GDLikeText6Objects3);
gdjs.copyArray(runtimeScene.getObjects("TweetFace1"), gdjs.MainCode.GDTweetFace1Objects3);
gdjs.copyArray(runtimeScene.getObjects("TweetFace2"), gdjs.MainCode.GDTweetFace2Objects3);
gdjs.copyArray(runtimeScene.getObjects("TweetFace3"), gdjs.MainCode.GDTweetFace3Objects3);
gdjs.copyArray(runtimeScene.getObjects("TweetFace5"), gdjs.MainCode.GDTweetFace5Objects3);
gdjs.copyArray(runtimeScene.getObjects("TweetFace6"), gdjs.MainCode.GDTweetFace6Objects3);
gdjs.copyArray(runtimeScene.getObjects("TweetTitle1"), gdjs.MainCode.GDTweetTitle1Objects3);
gdjs.copyArray(runtimeScene.getObjects("TweetTitle2"), gdjs.MainCode.GDTweetTitle2Objects3);
gdjs.copyArray(runtimeScene.getObjects("TweetTitle3"), gdjs.MainCode.GDTweetTitle3Objects3);
gdjs.copyArray(runtimeScene.getObjects("TweetTitle5"), gdjs.MainCode.GDTweetTitle5Objects3);
gdjs.copyArray(runtimeScene.getObjects("TweetTitle6"), gdjs.MainCode.GDTweetTitle6Objects3);
{for(var i = 0, len = gdjs.MainCode.GDTweetTitle1Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDTweetTitle1Objects3[i].getBehavior("Text").setText(runtimeScene.getScene().getVariables().getFromIndex(10).getChild(gdjs.randomInRange(0, 14)).getAsString());
}
}{for(var i = 0, len = gdjs.MainCode.GDTweetTitle2Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDTweetTitle2Objects3[i].getBehavior("Text").setText(runtimeScene.getScene().getVariables().getFromIndex(10).getChild(gdjs.randomInRange(0, 14)).getAsString());
}
}{for(var i = 0, len = gdjs.MainCode.GDTweetTitle3Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDTweetTitle3Objects3[i].getBehavior("Text").setText(runtimeScene.getScene().getVariables().getFromIndex(10).getChild(gdjs.randomInRange(0, 14)).getAsString());
}
}{for(var i = 0, len = gdjs.MainCode.GDTweetTitle5Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDTweetTitle5Objects3[i].getBehavior("Text").setText(runtimeScene.getScene().getVariables().getFromIndex(10).getChild(gdjs.randomInRange(0, 14)).getAsString());
}
}{for(var i = 0, len = gdjs.MainCode.GDTweetTitle6Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDTweetTitle6Objects3[i].getBehavior("Text").setText(runtimeScene.getScene().getVariables().getFromIndex(10).getChild(gdjs.randomInRange(0, 14)).getAsString());
}
}{for(var i = 0, len = gdjs.MainCode.GDTweetFace1Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDTweetFace1Objects3[i].getBehavior("Animation").setAnimationIndex(gdjs.randomInRange(0, 5));
}
}{for(var i = 0, len = gdjs.MainCode.GDTweetFace2Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDTweetFace2Objects3[i].getBehavior("Animation").setAnimationIndex(gdjs.randomInRange(0, 5));
}
}{for(var i = 0, len = gdjs.MainCode.GDTweetFace3Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDTweetFace3Objects3[i].getBehavior("Animation").setAnimationIndex(gdjs.randomInRange(0, 5));
}
}{for(var i = 0, len = gdjs.MainCode.GDTweetFace5Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDTweetFace5Objects3[i].getBehavior("Animation").setAnimationIndex(gdjs.randomInRange(0, 5));
}
}{for(var i = 0, len = gdjs.MainCode.GDTweetFace6Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDTweetFace6Objects3[i].getBehavior("Animation").setAnimationIndex(gdjs.randomInRange(0, 5));
}
}{for(var i = 0, len = gdjs.MainCode.GDFireText1Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDFireText1Objects3[i].getBehavior("Text").setText(gdjs.evtTools.common.toString(gdjs.randomInRange(10, 99)));
}
}{for(var i = 0, len = gdjs.MainCode.GDFireText2Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDFireText2Objects3[i].getBehavior("Text").setText(gdjs.evtTools.common.toString(gdjs.randomInRange(10, 99)));
}
}{for(var i = 0, len = gdjs.MainCode.GDFireText3Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDFireText3Objects3[i].getBehavior("Text").setText(gdjs.evtTools.common.toString(gdjs.randomInRange(10, 99)));
}
}{for(var i = 0, len = gdjs.MainCode.GDFireText5Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDFireText5Objects3[i].getBehavior("Text").setText(gdjs.evtTools.common.toString(gdjs.randomInRange(10, 99)));
}
}{for(var i = 0, len = gdjs.MainCode.GDFireText6Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDFireText6Objects3[i].getBehavior("Text").setText(gdjs.evtTools.common.toString(gdjs.randomInRange(10, 99)));
}
}{for(var i = 0, len = gdjs.MainCode.GDHeartText1Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDHeartText1Objects3[i].getBehavior("Text").setText(gdjs.evtTools.common.toString(gdjs.randomInRange(10, 99)));
}
}{for(var i = 0, len = gdjs.MainCode.GDHeartText2Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDHeartText2Objects3[i].getBehavior("Text").setText(gdjs.evtTools.common.toString(gdjs.randomInRange(10, 99)));
}
}{for(var i = 0, len = gdjs.MainCode.GDHeartText3Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDHeartText3Objects3[i].getBehavior("Text").setText(gdjs.evtTools.common.toString(gdjs.randomInRange(10, 99)));
}
}{for(var i = 0, len = gdjs.MainCode.GDHeartText5Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDHeartText5Objects3[i].getBehavior("Text").setText(gdjs.evtTools.common.toString(gdjs.randomInRange(10, 99)));
}
}{for(var i = 0, len = gdjs.MainCode.GDHeartText6Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDHeartText6Objects3[i].getBehavior("Text").setText(gdjs.evtTools.common.toString(gdjs.randomInRange(10, 99)));
}
}{for(var i = 0, len = gdjs.MainCode.GDLikeText1Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDLikeText1Objects3[i].getBehavior("Text").setText(gdjs.evtTools.common.toString(gdjs.randomInRange(10, 99)));
}
}{for(var i = 0, len = gdjs.MainCode.GDLikeText2Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDLikeText2Objects3[i].getBehavior("Text").setText(gdjs.evtTools.common.toString(gdjs.randomInRange(10, 99)));
}
}{for(var i = 0, len = gdjs.MainCode.GDLikeText3Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDLikeText3Objects3[i].getBehavior("Text").setText(gdjs.evtTools.common.toString(gdjs.randomInRange(10, 99)));
}
}{for(var i = 0, len = gdjs.MainCode.GDLikeText5Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDLikeText5Objects3[i].getBehavior("Text").setText(gdjs.evtTools.common.toString(gdjs.randomInRange(10, 99)));
}
}{for(var i = 0, len = gdjs.MainCode.GDLikeText6Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDLikeText6Objects3[i].getBehavior("Text").setText(gdjs.evtTools.common.toString(gdjs.randomInRange(10, 99)));
}
}}

}


};gdjs.MainCode.eventsList49 = function(runtimeScene, asyncObjectsList) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15121004);
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.MainCode.eventsList48(runtimeScene, asyncObjectsList);} //End of subevents
}

}


};gdjs.MainCode.eventsList50 = function(runtimeScene, asyncObjectsList) {

{



}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("FireText1"), gdjs.MainCode.GDFireText1Objects2);
gdjs.copyArray(runtimeScene.getObjects("FireText2"), gdjs.MainCode.GDFireText2Objects2);
gdjs.copyArray(runtimeScene.getObjects("FireText3"), gdjs.MainCode.GDFireText3Objects2);
gdjs.copyArray(runtimeScene.getObjects("FireText5"), gdjs.MainCode.GDFireText5Objects2);
gdjs.copyArray(runtimeScene.getObjects("FireText6"), gdjs.MainCode.GDFireText6Objects2);
gdjs.copyArray(runtimeScene.getObjects("HeartText1"), gdjs.MainCode.GDHeartText1Objects2);
gdjs.copyArray(runtimeScene.getObjects("HeartText2"), gdjs.MainCode.GDHeartText2Objects2);
gdjs.copyArray(runtimeScene.getObjects("HeartText3"), gdjs.MainCode.GDHeartText3Objects2);
gdjs.copyArray(runtimeScene.getObjects("HeartText5"), gdjs.MainCode.GDHeartText5Objects2);
gdjs.copyArray(runtimeScene.getObjects("HeartText6"), gdjs.MainCode.GDHeartText6Objects2);
gdjs.copyArray(runtimeScene.getObjects("LikeText1"), gdjs.MainCode.GDLikeText1Objects2);
gdjs.copyArray(runtimeScene.getObjects("LikeText2"), gdjs.MainCode.GDLikeText2Objects2);
gdjs.copyArray(runtimeScene.getObjects("LikeText3"), gdjs.MainCode.GDLikeText3Objects2);
gdjs.copyArray(runtimeScene.getObjects("LikeText5"), gdjs.MainCode.GDLikeText5Objects2);
gdjs.copyArray(runtimeScene.getObjects("LikeText6"), gdjs.MainCode.GDLikeText6Objects2);
gdjs.copyArray(runtimeScene.getObjects("TweetFace1"), gdjs.MainCode.GDTweetFace1Objects2);
gdjs.copyArray(runtimeScene.getObjects("TweetFace2"), gdjs.MainCode.GDTweetFace2Objects2);
gdjs.copyArray(runtimeScene.getObjects("TweetFace3"), gdjs.MainCode.GDTweetFace3Objects2);
gdjs.copyArray(runtimeScene.getObjects("TweetFace5"), gdjs.MainCode.GDTweetFace5Objects2);
gdjs.copyArray(runtimeScene.getObjects("TweetFace6"), gdjs.MainCode.GDTweetFace6Objects2);
gdjs.copyArray(runtimeScene.getObjects("TweetTitle1"), gdjs.MainCode.GDTweetTitle1Objects2);
gdjs.copyArray(runtimeScene.getObjects("TweetTitle2"), gdjs.MainCode.GDTweetTitle2Objects2);
gdjs.copyArray(runtimeScene.getObjects("TweetTitle3"), gdjs.MainCode.GDTweetTitle3Objects2);
gdjs.copyArray(runtimeScene.getObjects("TweetTitle5"), gdjs.MainCode.GDTweetTitle5Objects2);
gdjs.copyArray(runtimeScene.getObjects("TweetTitle6"), gdjs.MainCode.GDTweetTitle6Objects2);
{for(var i = 0, len = gdjs.MainCode.GDTweetTitle1Objects2.length ;i < len;++i) {
    gdjs.MainCode.GDTweetTitle1Objects2[i].getBehavior("Text").setText(runtimeScene.getScene().getVariables().getFromIndex(10).getChild(gdjs.randomInRange(0, 14)).getAsString());
}
}{for(var i = 0, len = gdjs.MainCode.GDTweetTitle2Objects2.length ;i < len;++i) {
    gdjs.MainCode.GDTweetTitle2Objects2[i].getBehavior("Text").setText(runtimeScene.getScene().getVariables().getFromIndex(10).getChild(gdjs.randomInRange(0, 14)).getAsString());
}
}{for(var i = 0, len = gdjs.MainCode.GDTweetTitle3Objects2.length ;i < len;++i) {
    gdjs.MainCode.GDTweetTitle3Objects2[i].getBehavior("Text").setText(runtimeScene.getScene().getVariables().getFromIndex(10).getChild(gdjs.randomInRange(0, 14)).getAsString());
}
}{for(var i = 0, len = gdjs.MainCode.GDTweetTitle5Objects2.length ;i < len;++i) {
    gdjs.MainCode.GDTweetTitle5Objects2[i].getBehavior("Text").setText(runtimeScene.getScene().getVariables().getFromIndex(10).getChild(gdjs.randomInRange(0, 14)).getAsString());
}
}{for(var i = 0, len = gdjs.MainCode.GDTweetTitle6Objects2.length ;i < len;++i) {
    gdjs.MainCode.GDTweetTitle6Objects2[i].getBehavior("Text").setText(runtimeScene.getScene().getVariables().getFromIndex(10).getChild(gdjs.randomInRange(0, 14)).getAsString());
}
}{for(var i = 0, len = gdjs.MainCode.GDTweetFace1Objects2.length ;i < len;++i) {
    gdjs.MainCode.GDTweetFace1Objects2[i].getBehavior("Animation").setAnimationIndex(gdjs.randomInRange(0, 5));
}
}{for(var i = 0, len = gdjs.MainCode.GDTweetFace2Objects2.length ;i < len;++i) {
    gdjs.MainCode.GDTweetFace2Objects2[i].getBehavior("Animation").setAnimationIndex(gdjs.randomInRange(0, 5));
}
}{for(var i = 0, len = gdjs.MainCode.GDTweetFace3Objects2.length ;i < len;++i) {
    gdjs.MainCode.GDTweetFace3Objects2[i].getBehavior("Animation").setAnimationIndex(gdjs.randomInRange(0, 5));
}
}{for(var i = 0, len = gdjs.MainCode.GDTweetFace5Objects2.length ;i < len;++i) {
    gdjs.MainCode.GDTweetFace5Objects2[i].getBehavior("Animation").setAnimationIndex(gdjs.randomInRange(0, 5));
}
}{for(var i = 0, len = gdjs.MainCode.GDTweetFace6Objects2.length ;i < len;++i) {
    gdjs.MainCode.GDTweetFace6Objects2[i].getBehavior("Animation").setAnimationIndex(gdjs.randomInRange(0, 5));
}
}{for(var i = 0, len = gdjs.MainCode.GDFireText1Objects2.length ;i < len;++i) {
    gdjs.MainCode.GDFireText1Objects2[i].getBehavior("Text").setText(gdjs.evtTools.common.toString(gdjs.randomInRange(10, 99)));
}
}{for(var i = 0, len = gdjs.MainCode.GDFireText2Objects2.length ;i < len;++i) {
    gdjs.MainCode.GDFireText2Objects2[i].getBehavior("Text").setText(gdjs.evtTools.common.toString(gdjs.randomInRange(10, 99)));
}
}{for(var i = 0, len = gdjs.MainCode.GDFireText3Objects2.length ;i < len;++i) {
    gdjs.MainCode.GDFireText3Objects2[i].getBehavior("Text").setText(gdjs.evtTools.common.toString(gdjs.randomInRange(10, 99)));
}
}{for(var i = 0, len = gdjs.MainCode.GDFireText5Objects2.length ;i < len;++i) {
    gdjs.MainCode.GDFireText5Objects2[i].getBehavior("Text").setText(gdjs.evtTools.common.toString(gdjs.randomInRange(10, 99)));
}
}{for(var i = 0, len = gdjs.MainCode.GDFireText6Objects2.length ;i < len;++i) {
    gdjs.MainCode.GDFireText6Objects2[i].getBehavior("Text").setText(gdjs.evtTools.common.toString(gdjs.randomInRange(10, 99)));
}
}{for(var i = 0, len = gdjs.MainCode.GDHeartText1Objects2.length ;i < len;++i) {
    gdjs.MainCode.GDHeartText1Objects2[i].getBehavior("Text").setText(gdjs.evtTools.common.toString(gdjs.randomInRange(10, 99)));
}
}{for(var i = 0, len = gdjs.MainCode.GDHeartText2Objects2.length ;i < len;++i) {
    gdjs.MainCode.GDHeartText2Objects2[i].getBehavior("Text").setText(gdjs.evtTools.common.toString(gdjs.randomInRange(10, 99)));
}
}{for(var i = 0, len = gdjs.MainCode.GDHeartText3Objects2.length ;i < len;++i) {
    gdjs.MainCode.GDHeartText3Objects2[i].getBehavior("Text").setText(gdjs.evtTools.common.toString(gdjs.randomInRange(10, 99)));
}
}{for(var i = 0, len = gdjs.MainCode.GDHeartText5Objects2.length ;i < len;++i) {
    gdjs.MainCode.GDHeartText5Objects2[i].getBehavior("Text").setText(gdjs.evtTools.common.toString(gdjs.randomInRange(10, 99)));
}
}{for(var i = 0, len = gdjs.MainCode.GDHeartText6Objects2.length ;i < len;++i) {
    gdjs.MainCode.GDHeartText6Objects2[i].getBehavior("Text").setText(gdjs.evtTools.common.toString(gdjs.randomInRange(10, 99)));
}
}{for(var i = 0, len = gdjs.MainCode.GDLikeText1Objects2.length ;i < len;++i) {
    gdjs.MainCode.GDLikeText1Objects2[i].getBehavior("Text").setText(gdjs.evtTools.common.toString(gdjs.randomInRange(10, 99)));
}
}{for(var i = 0, len = gdjs.MainCode.GDLikeText2Objects2.length ;i < len;++i) {
    gdjs.MainCode.GDLikeText2Objects2[i].getBehavior("Text").setText(gdjs.evtTools.common.toString(gdjs.randomInRange(10, 99)));
}
}{for(var i = 0, len = gdjs.MainCode.GDLikeText3Objects2.length ;i < len;++i) {
    gdjs.MainCode.GDLikeText3Objects2[i].getBehavior("Text").setText(gdjs.evtTools.common.toString(gdjs.randomInRange(10, 99)));
}
}{for(var i = 0, len = gdjs.MainCode.GDLikeText5Objects2.length ;i < len;++i) {
    gdjs.MainCode.GDLikeText5Objects2[i].getBehavior("Text").setText(gdjs.evtTools.common.toString(gdjs.randomInRange(10, 99)));
}
}{for(var i = 0, len = gdjs.MainCode.GDLikeText6Objects2.length ;i < len;++i) {
    gdjs.MainCode.GDLikeText6Objects2[i].getBehavior("Text").setText(gdjs.evtTools.common.toString(gdjs.randomInRange(10, 99)));
}
}}

}


};gdjs.MainCode.eventsList51 = function(runtimeScene, asyncObjectsList) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15124516);
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.MainCode.eventsList50(runtimeScene, asyncObjectsList);} //End of subevents
}

}


};gdjs.MainCode.eventsList52 = function(runtimeScene, asyncObjectsList) {

{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(1).getAsString() == "KetchupShortage");
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15093980);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("OptionTxt1"), gdjs.MainCode.GDOptionTxt1Objects3);
gdjs.copyArray(runtimeScene.getObjects("OptionTxt2"), gdjs.MainCode.GDOptionTxt2Objects3);
gdjs.copyArray(runtimeScene.getObjects("OptionTxt3"), gdjs.MainCode.GDOptionTxt3Objects3);
gdjs.copyArray(runtimeScene.getObjects("Tweet1"), gdjs.MainCode.GDTweet1Objects3);
gdjs.copyArray(runtimeScene.getObjects("Tweet2"), gdjs.MainCode.GDTweet2Objects3);
gdjs.copyArray(runtimeScene.getObjects("Tweet3"), gdjs.MainCode.GDTweet3Objects3);
{for(var i = 0, len = gdjs.MainCode.GDTweet1Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDTweet1Objects3[i].getBehavior("Text").setText("Burger joints across the country run dry on ketchup packets.");
}
}{for(var i = 0, len = gdjs.MainCode.GDTweet2Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDTweet2Objects3[i].getBehavior("Text").setText("Black market condiments surge online: $5 per sachet.");
}
}{for(var i = 0, len = gdjs.MainCode.GDTweet3Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDTweet3Objects3[i].getBehavior("Text").setText("Citizens demand answers: 'Where’s the sauce?!'");
}
}{for(var i = 0, len = gdjs.MainCode.GDOptionTxt1Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDOptionTxt1Objects3[i].getBehavior("Text").setText("This country was BUILT on ketchup. We’ll fix this with pride and extra fries.");
}
}{for(var i = 0, len = gdjs.MainCode.GDOptionTxt2Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDOptionTxt2Objects3[i].getBehavior("Text").setText("Time to fund local tomato farms. Red jobs for red sauce. #Agrinomics");
}
}{for(var i = 0, len = gdjs.MainCode.GDOptionTxt3Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDOptionTxt3Objects3[i].getBehavior("Text").setText("Introducing: PRESIMATO. Luxury ketchup. Gold bottle, same old taste.");
}
}{gdjs.evtsExt__ArrayTools__Shuffle.func(runtimeScene, runtimeScene.getScene().getVariables().getFromIndex(9), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
{ //Subevents
gdjs.MainCode.eventsList35(runtimeScene, asyncObjectsList);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(1).getAsString() == "HamsterEscapes");
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15097652);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("OptionTxt1"), gdjs.MainCode.GDOptionTxt1Objects3);
gdjs.copyArray(runtimeScene.getObjects("OptionTxt2"), gdjs.MainCode.GDOptionTxt2Objects3);
gdjs.copyArray(runtimeScene.getObjects("OptionTxt3"), gdjs.MainCode.GDOptionTxt3Objects3);
gdjs.copyArray(runtimeScene.getObjects("Tweet1"), gdjs.MainCode.GDTweet1Objects3);
gdjs.copyArray(runtimeScene.getObjects("Tweet2"), gdjs.MainCode.GDTweet2Objects3);
gdjs.copyArray(runtimeScene.getObjects("Tweet3"), gdjs.MainCode.GDTweet3Objects3);
{for(var i = 0, len = gdjs.MainCode.GDTweet1Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDTweet1Objects3[i].getBehavior("Text").setText("Experimental biotech hamster the size of a golf cart spotted downtown.");
}
}{for(var i = 0, len = gdjs.MainCode.GDTweet2Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDTweet2Objects3[i].getBehavior("Text").setText("Kids love it. Scientists horrified.");
}
}{for(var i = 0, len = gdjs.MainCode.GDTweet3Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDTweet3Objects3[i].getBehavior("Text").setText("Hasn't bitten anyone... yet.");
}
}{for(var i = 0, len = gdjs.MainCode.GDOptionTxt1Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDOptionTxt1Objects3[i].getBehavior("Text").setText("Kids love the hamster? Great. Let’s mascot it. Giant Hammy for President!");
}
}{for(var i = 0, len = gdjs.MainCode.GDOptionTxt2Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDOptionTxt2Objects3[i].getBehavior("Text").setText("Sell plushies. Open a theme park. Call it Rodentland. Huge potential.");
}
}{for(var i = 0, len = gdjs.MainCode.GDOptionTxt3Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDOptionTxt3Objects3[i].getBehavior("Text").setText("I’m licensing the giant hamster’s image for a new crypto: ChewCoin.");
}
}{gdjs.evtsExt__ArrayTools__Shuffle.func(runtimeScene, runtimeScene.getScene().getVariables().getFromIndex(9), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
{ //Subevents
gdjs.MainCode.eventsList37(runtimeScene, asyncObjectsList);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(1).getAsString() == "SunglassesDay");
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15101084);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("OptionTxt1"), gdjs.MainCode.GDOptionTxt1Objects3);
gdjs.copyArray(runtimeScene.getObjects("OptionTxt2"), gdjs.MainCode.GDOptionTxt2Objects3);
gdjs.copyArray(runtimeScene.getObjects("OptionTxt3"), gdjs.MainCode.GDOptionTxt3Objects3);
gdjs.copyArray(runtimeScene.getObjects("Tweet1"), gdjs.MainCode.GDTweet1Objects3);
gdjs.copyArray(runtimeScene.getObjects("Tweet2"), gdjs.MainCode.GDTweet2Objects3);
gdjs.copyArray(runtimeScene.getObjects("Tweet3"), gdjs.MainCode.GDTweet3Objects3);
{for(var i = 0, len = gdjs.MainCode.GDTweet1Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDTweet1Objects3[i].getBehavior("Text").setText("National Health Assc. 'Citizens encouraged to wear shades all day.'");
}
}{for(var i = 0, len = gdjs.MainCode.GDTweet2Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDTweet2Objects3[i].getBehavior("Text").setText("Sales skyrocket for designer eyewear.");
}
}{for(var i = 0, len = gdjs.MainCode.GDTweet3Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDTweet3Objects3[i].getBehavior("Text").setText("Minor chaos as people can’t see indoors.");
}
}{for(var i = 0, len = gdjs.MainCode.GDOptionTxt1Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDOptionTxt1Objects3[i].getBehavior("Text").setText("Sunglasses? I never take mine off. Coolness is mandatory. #ShadeNation");
}
}{for(var i = 0, len = gdjs.MainCode.GDOptionTxt2Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDOptionTxt2Objects3[i].getBehavior("Text").setText("National production push! Boost jobs, block sun. #SolarStimulus");
}
}{for(var i = 0, len = gdjs.MainCode.GDOptionTxt3Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDOptionTxt3Objects3[i].getBehavior("Text").setText("Launching limited edition red cap-shaped sunglasses. Smartest ever. #Visionary");
}
}{gdjs.evtsExt__ArrayTools__Shuffle.func(runtimeScene, runtimeScene.getScene().getVariables().getFromIndex(9), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
{ //Subevents
gdjs.MainCode.eventsList39(runtimeScene, asyncObjectsList);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(1).getAsString() == "HotdogDeclaredaVegetable");
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15104556);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("OptionTxt1"), gdjs.MainCode.GDOptionTxt1Objects3);
gdjs.copyArray(runtimeScene.getObjects("OptionTxt2"), gdjs.MainCode.GDOptionTxt2Objects3);
gdjs.copyArray(runtimeScene.getObjects("OptionTxt3"), gdjs.MainCode.GDOptionTxt3Objects3);
gdjs.copyArray(runtimeScene.getObjects("Tweet1"), gdjs.MainCode.GDTweet1Objects3);
gdjs.copyArray(runtimeScene.getObjects("Tweet2"), gdjs.MainCode.GDTweet2Objects3);
gdjs.copyArray(runtimeScene.getObjects("Tweet3"), gdjs.MainCode.GDTweet3Objects3);
{for(var i = 0, len = gdjs.MainCode.GDTweet1Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDTweet1Objects3[i].getBehavior("Text").setText("Hotdog Declared a Vegetable: reclassification shocks nutritionists.");
}
}{for(var i = 0, len = gdjs.MainCode.GDTweet2Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDTweet2Objects3[i].getBehavior("Text").setText("Meat lobby celebrates. Vegans confused.");
}
}{for(var i = 0, len = gdjs.MainCode.GDTweet3Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDTweet3Objects3[i].getBehavior("Text").setText("Nation unsure whether to celebrate or panic.");
}
}{for(var i = 0, len = gdjs.MainCode.GDOptionTxt1Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDOptionTxt1Objects3[i].getBehavior("Text").setText("Of course hotdogs are veggies. I’ve been eating healthy this whole time!");
}
}{for(var i = 0, len = gdjs.MainCode.GDOptionTxt2Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDOptionTxt2Objects3[i].getBehavior("Text").setText("Time to rebrand school lunches. Hotdogs for everyone. tax write-off.");
}
}{for(var i = 0, len = gdjs.MainCode.GDOptionTxt3Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDOptionTxt3Objects3[i].getBehavior("Text").setText("Visit my shop: VeganDog™. 99% mystery, 1% marketing. #EarnToEat");
}
}{gdjs.evtsExt__ArrayTools__Shuffle.func(runtimeScene, runtimeScene.getScene().getVariables().getFromIndex(9), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
{ //Subevents
gdjs.MainCode.eventsList41(runtimeScene, asyncObjectsList);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(1).getAsString() == "InternetBlackoutRumor");
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15108028);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("OptionTxt1"), gdjs.MainCode.GDOptionTxt1Objects3);
gdjs.copyArray(runtimeScene.getObjects("OptionTxt2"), gdjs.MainCode.GDOptionTxt2Objects3);
gdjs.copyArray(runtimeScene.getObjects("OptionTxt3"), gdjs.MainCode.GDOptionTxt3Objects3);
gdjs.copyArray(runtimeScene.getObjects("Tweet1"), gdjs.MainCode.GDTweet1Objects3);
gdjs.copyArray(runtimeScene.getObjects("Tweet2"), gdjs.MainCode.GDTweet2Objects3);
gdjs.copyArray(runtimeScene.getObjects("Tweet3"), gdjs.MainCode.GDTweet3Objects3);
{for(var i = 0, len = gdjs.MainCode.GDTweet1Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDTweet1Objects3[i].getBehavior("Text").setText("Anonymous source claims internet will go dark next week.");
}
}{for(var i = 0, len = gdjs.MainCode.GDTweet2Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDTweet2Objects3[i].getBehavior("Text").setText("Panic buying of USB sticks and printers.");
}
}{for(var i = 0, len = gdjs.MainCode.GDTweet3Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDTweet3Objects3[i].getBehavior("Text").setText("Tech stocks dip, meme stocks rise.");
}
}{for(var i = 0, len = gdjs.MainCode.GDOptionTxt1Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDOptionTxt1Objects3[i].getBehavior("Text").setText("Relax, folks. I’ve got a hotline to the Internet. We’re all good. #NoOfflineZone");
}
}{for(var i = 0, len = gdjs.MainCode.GDOptionTxt2Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDOptionTxt2Objects3[i].getBehavior("Text").setText("Time to build local servers. Keep the net local, keep the jobs booming.");
}
}{for(var i = 0, len = gdjs.MainCode.GDOptionTxt3Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDOptionTxt3Objects3[i].getBehavior("Text").setText("Use PresiDrive™. Holds memes, emails, AND my autobiography. Only $99.99");
}
}{gdjs.evtsExt__ArrayTools__Shuffle.func(runtimeScene, runtimeScene.getScene().getVariables().getFromIndex(9), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
{ //Subevents
gdjs.MainCode.eventsList43(runtimeScene, asyncObjectsList);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(1).getAsString() == "AGooseWinsLocalElection");
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15111428);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("OptionTxt1"), gdjs.MainCode.GDOptionTxt1Objects3);
gdjs.copyArray(runtimeScene.getObjects("OptionTxt2"), gdjs.MainCode.GDOptionTxt2Objects3);
gdjs.copyArray(runtimeScene.getObjects("OptionTxt3"), gdjs.MainCode.GDOptionTxt3Objects3);
gdjs.copyArray(runtimeScene.getObjects("Tweet1"), gdjs.MainCode.GDTweet1Objects3);
gdjs.copyArray(runtimeScene.getObjects("Tweet2"), gdjs.MainCode.GDTweet2Objects3);
gdjs.copyArray(runtimeScene.getObjects("Tweet3"), gdjs.MainCode.GDTweet3Objects3);
{for(var i = 0, len = gdjs.MainCode.GDTweet1Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDTweet1Objects3[i].getBehavior("Text").setText("A Goose Wins Local Election: as mayor after protest vote.");
}
}{for(var i = 0, len = gdjs.MainCode.GDTweet2Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDTweet2Objects3[i].getBehavior("Text").setText("Goose honks during press conference. Chaos ensues.");
}
}{for(var i = 0, len = gdjs.MainCode.GDTweet3Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDTweet3Objects3[i].getBehavior("Text").setText("Approval rating at 93%. Citizens love it.");
}
}{for(var i = 0, len = gdjs.MainCode.GDOptionTxt1Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDOptionTxt1Objects3[i].getBehavior("Text").setText("That goose gets it. Maybe I’ll appoint it to my advisory board.");
}
}{for(var i = 0, len = gdjs.MainCode.GDOptionTxt2Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDOptionTxt2Objects3[i].getBehavior("Text").setText("Let’s build the Goose Capitol right next to the Parliament. #GooseGDP");
}
}{for(var i = 0, len = gdjs.MainCode.GDOptionTxt3Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDOptionTxt3Objects3[i].getBehavior("Text").setText("Exclusive goose-branded merchandise coming. Hats, hoodies, honks.");
}
}{gdjs.evtsExt__ArrayTools__Shuffle.func(runtimeScene, runtimeScene.getScene().getVariables().getFromIndex(9), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
{ //Subevents
gdjs.MainCode.eventsList45(runtimeScene, asyncObjectsList);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(1).getAsString() == "FliopFlopDanceCausesMildEarthquake");
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15114468);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("OptionTxt1"), gdjs.MainCode.GDOptionTxt1Objects3);
gdjs.copyArray(runtimeScene.getObjects("OptionTxt2"), gdjs.MainCode.GDOptionTxt2Objects3);
gdjs.copyArray(runtimeScene.getObjects("OptionTxt3"), gdjs.MainCode.GDOptionTxt3Objects3);
gdjs.copyArray(runtimeScene.getObjects("Tweet1"), gdjs.MainCode.GDTweet1Objects3);
gdjs.copyArray(runtimeScene.getObjects("Tweet2"), gdjs.MainCode.GDTweet2Objects3);
gdjs.copyArray(runtimeScene.getObjects("Tweet3"), gdjs.MainCode.GDTweet3Objects3);
{for(var i = 0, len = gdjs.MainCode.GDTweet1Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDTweet1Objects3[i].getBehavior("Text").setText("FlipFlop Dance Causes Mild Earthquake as Millions jump in sync doing viral dance trend.");
}
}{for(var i = 0, len = gdjs.MainCode.GDTweet2Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDTweet2Objects3[i].getBehavior("Text").setText("Seismic activity recorded in four states.");
}
}{for(var i = 0, len = gdjs.MainCode.GDTweet3Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDTweet3Objects3[i].getBehavior("Text").setText("Scientists baffled. Dancers unfazed.");
}
}{for(var i = 0, len = gdjs.MainCode.GDOptionTxt1Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDOptionTxt1Objects3[i].getBehavior("Text").setText("Just did the dance. My hips broke a window. #PowerMovesOnly");
}
}{for(var i = 0, len = gdjs.MainCode.GDOptionTxt2Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDOptionTxt2Objects3[i].getBehavior("Text").setText("Fund our own national dance app: ChatterChirp. Jobs, fun, control. #AppConomy");
}
}{for(var i = 0, len = gdjs.MainCode.GDOptionTxt3Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDOptionTxt3Objects3[i].getBehavior("Text").setText("Watch me dance: The PresiSlide™. Unlockable with red cap token. #ShakeItRich");
}
}{gdjs.evtsExt__ArrayTools__Shuffle.func(runtimeScene, runtimeScene.getScene().getVariables().getFromIndex(9), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
{ //Subevents
gdjs.MainCode.eventsList47(runtimeScene, asyncObjectsList);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(1).getAsString() == "AIWritesNationalAnthemRemix");
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15118308);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("OptionTxt1"), gdjs.MainCode.GDOptionTxt1Objects3);
gdjs.copyArray(runtimeScene.getObjects("OptionTxt2"), gdjs.MainCode.GDOptionTxt2Objects3);
gdjs.copyArray(runtimeScene.getObjects("OptionTxt3"), gdjs.MainCode.GDOptionTxt3Objects3);
gdjs.copyArray(runtimeScene.getObjects("Tweet1"), gdjs.MainCode.GDTweet1Objects3);
gdjs.copyArray(runtimeScene.getObjects("Tweet2"), gdjs.MainCode.GDTweet2Objects3);
gdjs.copyArray(runtimeScene.getObjects("Tweet3"), gdjs.MainCode.GDTweet3Objects3);
{for(var i = 0, len = gdjs.MainCode.GDTweet1Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDTweet1Objects3[i].getBehavior("Text").setText("AI Writes National Anthem Remix: Goes viral");
}
}{for(var i = 0, len = gdjs.MainCode.GDTweet2Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDTweet2Objects3[i].getBehavior("Text").setText("Featuring:  trap beat and robot vocals.");
}
}{for(var i = 0, len = gdjs.MainCode.GDTweet3Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDTweet3Objects3[i].getBehavior("Text").setText("Some call it inspiring. Others call it noise.");
}
}{for(var i = 0, len = gdjs.MainCode.GDOptionTxt1Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDOptionTxt1Objects3[i].getBehavior("Text").setText("I love it. The anthem SLAPS now. #RobotRhythm");
}
}{for(var i = 0, len = gdjs.MainCode.GDOptionTxt2Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDOptionTxt2Objects3[i].getBehavior("Text").setText("National AI for National anthems. Invest in future jams. #CodeToCash");
}
}{for(var i = 0, len = gdjs.MainCode.GDOptionTxt3Objects3.length ;i < len;++i) {
    gdjs.MainCode.GDOptionTxt3Objects3[i].getBehavior("Text").setText("Buy my album: PresiBeats Vol.1 - only $49.99. #StreamingEmpire");
}
}{gdjs.evtsExt__ArrayTools__Shuffle.func(runtimeScene, runtimeScene.getScene().getVariables().getFromIndex(9), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
{ //Subevents
gdjs.MainCode.eventsList49(runtimeScene, asyncObjectsList);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(1).getAsString() == "DogsLearntoUseTablets");
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15107516);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("OptionTxt1"), gdjs.MainCode.GDOptionTxt1Objects2);
gdjs.copyArray(runtimeScene.getObjects("OptionTxt2"), gdjs.MainCode.GDOptionTxt2Objects2);
gdjs.copyArray(runtimeScene.getObjects("OptionTxt3"), gdjs.MainCode.GDOptionTxt3Objects2);
gdjs.copyArray(runtimeScene.getObjects("Tweet1"), gdjs.MainCode.GDTweet1Objects2);
gdjs.copyArray(runtimeScene.getObjects("Tweet2"), gdjs.MainCode.GDTweet2Objects2);
gdjs.copyArray(runtimeScene.getObjects("Tweet3"), gdjs.MainCode.GDTweet3Objects2);
{for(var i = 0, len = gdjs.MainCode.GDTweet1Objects2.length ;i < len;++i) {
    gdjs.MainCode.GDTweet1Objects2[i].getBehavior("Text").setText("Dogs Learn to Use Tablets - Breakthrough in canine-tech interface!");
}
}{for(var i = 0, len = gdjs.MainCode.GDTweet2Objects2.length ;i < len;++i) {
    gdjs.MainCode.GDTweet2Objects2[i].getBehavior("Text").setText("Pets now shopping online, booking hotels.");
}
}{for(var i = 0, len = gdjs.MainCode.GDTweet3Objects2.length ;i < len;++i) {
    gdjs.MainCode.GDTweet3Objects2[i].getBehavior("Text").setText("Cats reportedly furious.");
}
}{for(var i = 0, len = gdjs.MainCode.GDOptionTxt1Objects2.length ;i < len;++i) {
    gdjs.MainCode.GDOptionTxt1Objects2[i].getBehavior("Text").setText("Every dog gets a tablet. It’s time. We believe in pet progress. #SmartDogsRule");
}
}{for(var i = 0, len = gdjs.MainCode.GDOptionTxt2Objects2.length ;i < len;++i) {
    gdjs.MainCode.GDOptionTxt2Objects2[i].getBehavior("Text").setText("Launch CanineTech initiative. Training labs, jobs, dog dollars. #Pawductivity");
}
}{for(var i = 0, len = gdjs.MainCode.GDOptionTxt3Objects2.length ;i < len;++i) {
    gdjs.MainCode.GDOptionTxt3Objects2[i].getBehavior("Text").setText("Exclusive BarkCoin pre-sale begins now. Invest in your dog’s future. #FurRich");
}
}{gdjs.evtsExt__ArrayTools__Shuffle.func(runtimeScene, runtimeScene.getScene().getVariables().getFromIndex(9), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
{ //Subevents
gdjs.MainCode.eventsList51(runtimeScene, asyncObjectsList);} //End of subevents
}

}


};gdjs.MainCode.eventsList53 = function(runtimeScene, asyncObjectsList) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableChildCount(runtimeScene.getScene().getVariables().getFromIndex(9)) >= 0;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("TestText"), gdjs.MainCode.GDTestTextObjects2);
{for(var i = 0, len = gdjs.MainCode.GDTestTextObjects2.length ;i < len;++i) {
    gdjs.MainCode.GDTestTextObjects2[i].getBehavior("Text").setText("Yes");
}
}
{ //Subevents
gdjs.MainCode.eventsList52(runtimeScene, asyncObjectsList);} //End of subevents
}

}


};gdjs.MainCode.eventsList54 = function(runtimeScene, asyncObjectsList) {

{


gdjs.MainCode.eventsList53(runtimeScene, asyncObjectsList);
}


};gdjs.MainCode.asyncCallback15088636 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.MainCode.localVariables);
{runtimeScene.getScene().getVariables().getFromIndex(7).setString("DECISION");
}
{ //Subevents
gdjs.MainCode.eventsList54(runtimeScene, asyncObjectsList);} //End of subevents
gdjs.MainCode.localVariables.length = 0;
}
gdjs.MainCode.eventsList55 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.MainCode.localVariables);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.5), (runtimeScene) => (gdjs.MainCode.asyncCallback15088636(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.MainCode.eventsList56 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15082364);
}
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(21).setBoolean(false);
}{runtimeScene.getScene().getVariables().getFromIndex(22).setBoolean(false);
}{runtimeScene.getScene().getVariables().getFromIndex(23).setBoolean(false);
}{runtimeScene.getScene().getVariables().getFromIndex(26).setBoolean(false);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15083772);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("NextText"), gdjs.MainCode.GDNextTextObjects2);
gdjs.copyArray(runtimeScene.getObjects("Next_button"), gdjs.MainCode.GDNext_9595buttonObjects2);
{for(var i = 0, len = gdjs.MainCode.GDNext_9595buttonObjects2.length ;i < len;++i) {
    gdjs.MainCode.GDNext_9595buttonObjects2[i].hide();
}
for(var i = 0, len = gdjs.MainCode.GDNextTextObjects2.length ;i < len;++i) {
    gdjs.MainCode.GDNextTextObjects2[i].hide();
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15084204);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("TweetMarker3"), gdjs.MainCode.GDTweetMarker3Objects2);
gdjs.copyArray(runtimeScene.getObjects("TweetMarker4"), gdjs.MainCode.GDTweetMarker4Objects2);
gdjs.copyArray(runtimeScene.getObjects("TweetMarker5"), gdjs.MainCode.GDTweetMarker5Objects2);
gdjs.copyArray(runtimeScene.getObjects("TweetMarker6"), gdjs.MainCode.GDTweetMarker6Objects2);
gdjs.copyArray(runtimeScene.getObjects("TweetMarker7"), gdjs.MainCode.GDTweetMarker7Objects2);
gdjs.copyArray(runtimeScene.getObjects("TweetMarker8"), gdjs.MainCode.GDTweetMarker8Objects2);
gdjs.copyArray(runtimeScene.getObjects("Tweet_bkg1"), gdjs.MainCode.GDTweet_9595bkg1Objects2);
gdjs.copyArray(runtimeScene.getObjects("Tweet_bkg2"), gdjs.MainCode.GDTweet_9595bkg2Objects2);
gdjs.copyArray(runtimeScene.getObjects("Tweet_bkg3"), gdjs.MainCode.GDTweet_9595bkg3Objects2);
gdjs.copyArray(runtimeScene.getObjects("Tweet_bkg4"), gdjs.MainCode.GDTweet_9595bkg4Objects2);
gdjs.copyArray(runtimeScene.getObjects("Tweet_bkg5"), gdjs.MainCode.GDTweet_9595bkg5Objects2);
gdjs.copyArray(runtimeScene.getObjects("Tweet_bkg6"), gdjs.MainCode.GDTweet_9595bkg6Objects2);
{for(var i = 0, len = gdjs.MainCode.GDTweet_9595bkg1Objects2.length ;i < len;++i) {
    gdjs.MainCode.GDTweet_9595bkg1Objects2[i].getBehavior("Tween").addObjectPositionTween2("Tween", (( gdjs.MainCode.GDTweetMarker3Objects2.length === 0 ) ? 0 :gdjs.MainCode.GDTweetMarker3Objects2[0].getPointX("")), (( gdjs.MainCode.GDTweetMarker3Objects2.length === 0 ) ? 0 :gdjs.MainCode.GDTweetMarker3Objects2[0].getPointY("")), "linear", 0.05, false);
}
}{for(var i = 0, len = gdjs.MainCode.GDTweet_9595bkg2Objects2.length ;i < len;++i) {
    gdjs.MainCode.GDTweet_9595bkg2Objects2[i].getBehavior("Tween").addObjectPositionTween2("Tween", (( gdjs.MainCode.GDTweetMarker4Objects2.length === 0 ) ? 0 :gdjs.MainCode.GDTweetMarker4Objects2[0].getPointX("")), (( gdjs.MainCode.GDTweetMarker4Objects2.length === 0 ) ? 0 :gdjs.MainCode.GDTweetMarker4Objects2[0].getPointY("")), "linear", 0.05, false);
}
}{for(var i = 0, len = gdjs.MainCode.GDTweet_9595bkg3Objects2.length ;i < len;++i) {
    gdjs.MainCode.GDTweet_9595bkg3Objects2[i].getBehavior("Tween").addObjectPositionTween2("Tween", (( gdjs.MainCode.GDTweetMarker5Objects2.length === 0 ) ? 0 :gdjs.MainCode.GDTweetMarker5Objects2[0].getPointX("")), (( gdjs.MainCode.GDTweetMarker5Objects2.length === 0 ) ? 0 :gdjs.MainCode.GDTweetMarker5Objects2[0].getPointY("")), "linear", 0.05, false);
}
}{for(var i = 0, len = gdjs.MainCode.GDTweet_9595bkg4Objects2.length ;i < len;++i) {
    gdjs.MainCode.GDTweet_9595bkg4Objects2[i].getBehavior("Tween").addObjectPositionTween2("Tween", (( gdjs.MainCode.GDTweetMarker6Objects2.length === 0 ) ? 0 :gdjs.MainCode.GDTweetMarker6Objects2[0].getPointX("")), (( gdjs.MainCode.GDTweetMarker6Objects2.length === 0 ) ? 0 :gdjs.MainCode.GDTweetMarker6Objects2[0].getPointY("")), "linear", 0.05, false);
}
}{for(var i = 0, len = gdjs.MainCode.GDTweet_9595bkg5Objects2.length ;i < len;++i) {
    gdjs.MainCode.GDTweet_9595bkg5Objects2[i].getBehavior("Tween").addObjectPositionTween2("Tween", (( gdjs.MainCode.GDTweetMarker7Objects2.length === 0 ) ? 0 :gdjs.MainCode.GDTweetMarker7Objects2[0].getPointX("")), (( gdjs.MainCode.GDTweetMarker7Objects2.length === 0 ) ? 0 :gdjs.MainCode.GDTweetMarker7Objects2[0].getPointY("")), "linear", 0.05, false);
}
}{for(var i = 0, len = gdjs.MainCode.GDTweet_9595bkg6Objects2.length ;i < len;++i) {
    gdjs.MainCode.GDTweet_9595bkg6Objects2[i].getBehavior("Tween").addObjectPositionTween2("Tween", (( gdjs.MainCode.GDTweetMarker8Objects2.length === 0 ) ? 0 :gdjs.MainCode.GDTweetMarker8Objects2[0].getPointX("")), (( gdjs.MainCode.GDTweetMarker8Objects2.length === 0 ) ? 0 :gdjs.MainCode.GDTweetMarker8Objects2[0].getPointY("")), "linear", 0.05, false);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15086292);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Cap_comments"), gdjs.MainCode.GDCap_9595commentsObjects2);
gdjs.copyArray(runtimeScene.getObjects("Cap_faces"), gdjs.MainCode.GDCap_9595facesObjects2);
{for(var i = 0, len = gdjs.MainCode.GDCap_9595facesObjects2.length ;i < len;++i) {
    gdjs.MainCode.GDCap_9595facesObjects2[i].getBehavior("Animation").setAnimationName("sarcastic");
}
}{for(var i = 0, len = gdjs.MainCode.GDCap_9595commentsObjects2.length ;i < len;++i) {
    gdjs.MainCode.GDCap_9595commentsObjects2[i].getBehavior("Text").setText("Sarcastic comment");
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15088044);
}
if (isConditionTrue_0) {
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15088460);
}
if (isConditionTrue_0) {
{gdjs.evtsExt__ArrayTools__Shift.func(runtimeScene, runtimeScene.getScene().getVariables().getFromIndex(9), runtimeScene.getScene().getVariables().getFromIndex(1), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
{ //Subevents
gdjs.MainCode.eventsList55(runtimeScene);} //End of subevents
}

}


};gdjs.MainCode.eventsList57 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(7).getAsString() == "DAYSTART");
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.MainCode.eventsList56(runtimeScene);} //End of subevents
}

}


};gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDSend_95959595icon1Objects2Objects = Hashtable.newFrom({"Send_icon1": gdjs.MainCode.GDSend_9595icon1Objects2});
gdjs.MainCode.asyncCallback15126452 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.MainCode.localVariables);
gdjs.copyArray(runtimeScene.getObjects("Cap_comments"), gdjs.MainCode.GDCap_9595commentsObjects3);
gdjs.copyArray(runtimeScene.getObjects("Cap_faces"), gdjs.MainCode.GDCap_9595facesObjects3);
{for(var i = 0, len = gdjs.MainCode.GDCap_9595commentsObjects3.length ;i < len;++i) {
    gdjs.MainCode.GDCap_9595commentsObjects3[i].getBehavior("Text").setText(runtimeScene.getScene().getVariables().getFromIndex(11).getChild(gdjs.randomInRange(0, gdjs.evtTools.variable.getVariableChildCount(runtimeScene.getScene().getVariables().getFromIndex(11)) - 1)).getAsString());
}
}{for(var i = 0, len = gdjs.MainCode.GDCap_9595facesObjects3.length ;i < len;++i) {
    gdjs.MainCode.GDCap_9595facesObjects3[i].getBehavior("Animation").setAnimationName("EvilGrin");
}
}gdjs.MainCode.localVariables.length = 0;
}
gdjs.MainCode.eventsList58 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.MainCode.localVariables);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.5), (runtimeScene) => (gdjs.MainCode.asyncCallback15126452(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDSend_95959595icon2Objects2Objects = Hashtable.newFrom({"Send_icon2": gdjs.MainCode.GDSend_9595icon2Objects2});
gdjs.MainCode.asyncCallback15128324 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.MainCode.localVariables);
gdjs.copyArray(runtimeScene.getObjects("Cap_comments"), gdjs.MainCode.GDCap_9595commentsObjects3);
gdjs.copyArray(runtimeScene.getObjects("Cap_faces"), gdjs.MainCode.GDCap_9595facesObjects3);
{for(var i = 0, len = gdjs.MainCode.GDCap_9595commentsObjects3.length ;i < len;++i) {
    gdjs.MainCode.GDCap_9595commentsObjects3[i].getBehavior("Text").setText(runtimeScene.getScene().getVariables().getFromIndex(11).getChild(gdjs.randomInRange(0, gdjs.evtTools.variable.getVariableChildCount(runtimeScene.getScene().getVariables().getFromIndex(11)) - 1)).getAsString());
}
}{for(var i = 0, len = gdjs.MainCode.GDCap_9595facesObjects3.length ;i < len;++i) {
    gdjs.MainCode.GDCap_9595facesObjects3[i].getBehavior("Animation").setAnimationName("EvilGrin");
}
}gdjs.MainCode.localVariables.length = 0;
}
gdjs.MainCode.eventsList59 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.MainCode.localVariables);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.5), (runtimeScene) => (gdjs.MainCode.asyncCallback15128324(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDSend_95959595icon3Objects2Objects = Hashtable.newFrom({"Send_icon3": gdjs.MainCode.GDSend_9595icon3Objects2});
gdjs.MainCode.asyncCallback15129788 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.MainCode.localVariables);
gdjs.copyArray(runtimeScene.getObjects("Cap_comments"), gdjs.MainCode.GDCap_9595commentsObjects3);
gdjs.copyArray(runtimeScene.getObjects("Cap_faces"), gdjs.MainCode.GDCap_9595facesObjects3);
{for(var i = 0, len = gdjs.MainCode.GDCap_9595commentsObjects3.length ;i < len;++i) {
    gdjs.MainCode.GDCap_9595commentsObjects3[i].getBehavior("Text").setText(runtimeScene.getScene().getVariables().getFromIndex(11).getChild(gdjs.randomInRange(0, gdjs.evtTools.variable.getVariableChildCount(runtimeScene.getScene().getVariables().getFromIndex(11)) - 1)).getAsString());
}
}{for(var i = 0, len = gdjs.MainCode.GDCap_9595facesObjects3.length ;i < len;++i) {
    gdjs.MainCode.GDCap_9595facesObjects3[i].getBehavior("Animation").setAnimationName("EvilGrin");
}
}gdjs.MainCode.localVariables.length = 0;
}
gdjs.MainCode.eventsList60 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.MainCode.localVariables);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.5), (runtimeScene) => (gdjs.MainCode.asyncCallback15129788(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDOption1Objects2Objects = Hashtable.newFrom({"Option1": gdjs.MainCode.GDOption1Objects2});
gdjs.MainCode.eventsList61 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("OptionTxt1"), gdjs.MainCode.GDOptionTxt1Objects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.MainCode.GDOptionTxt1Objects3.length;i<l;++i) {
    if ( gdjs.MainCode.GDOptionTxt1Objects3[i].getBehavior("Text").getText() == "Aliens? I’ve been saying it for YEARS. The people know I’m right. #ToldYouSo" ) {
        isConditionTrue_0 = true;
        gdjs.MainCode.GDOptionTxt1Objects3[k] = gdjs.MainCode.GDOptionTxt1Objects3[i];
        ++k;
    }
}
gdjs.MainCode.GDOptionTxt1Objects3.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Cap_comments"), gdjs.MainCode.GDCap_9595commentsObjects3);
{for(var i = 0, len = gdjs.MainCode.GDCap_9595commentsObjects3.length ;i < len;++i) {
    gdjs.MainCode.GDCap_9595commentsObjects3[i].getBehavior("Text").setText("People feel so confident, they might forget your… creative history.");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("OptionTxt1"), gdjs.MainCode.GDOptionTxt1Objects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.MainCode.GDOptionTxt1Objects3.length;i<l;++i) {
    if ( gdjs.MainCode.GDOptionTxt1Objects3[i].getBehavior("Text").getText() == "This country was BUILT on ketchup. We’ll fix this with pride and extra fries." ) {
        isConditionTrue_0 = true;
        gdjs.MainCode.GDOptionTxt1Objects3[k] = gdjs.MainCode.GDOptionTxt1Objects3[i];
        ++k;
    }
}
gdjs.MainCode.GDOptionTxt1Objects3.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Cap_comments"), gdjs.MainCode.GDCap_9595commentsObjects3);
{for(var i = 0, len = gdjs.MainCode.GDCap_9595commentsObjects3.length ;i < len;++i) {
    gdjs.MainCode.GDCap_9595commentsObjects3[i].getBehavior("Text").setText("Free fries everywhere? Even in stores you own? Bold move, Prez.");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("OptionTxt1"), gdjs.MainCode.GDOptionTxt1Objects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.MainCode.GDOptionTxt1Objects3.length;i<l;++i) {
    if ( gdjs.MainCode.GDOptionTxt1Objects3[i].getBehavior("Text").getText() == "Kids love the hamster? Great. Let’s mascot it. Giant Hammy for President!" ) {
        isConditionTrue_0 = true;
        gdjs.MainCode.GDOptionTxt1Objects3[k] = gdjs.MainCode.GDOptionTxt1Objects3[i];
        ++k;
    }
}
gdjs.MainCode.GDOptionTxt1Objects3.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Cap_comments"), gdjs.MainCode.GDCap_9595commentsObjects3);
{for(var i = 0, len = gdjs.MainCode.GDCap_9595commentsObjects3.length ;i < len;++i) {
    gdjs.MainCode.GDCap_9595commentsObjects3[i].getBehavior("Text").setText("Goofy idea, rich results. Your wallet’s giggling already.");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("OptionTxt1"), gdjs.MainCode.GDOptionTxt1Objects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.MainCode.GDOptionTxt1Objects3.length;i<l;++i) {
    if ( gdjs.MainCode.GDOptionTxt1Objects3[i].getBehavior("Text").getText() == "Sunglasses? I never take mine off. Coolness is mandatory. #ShadeNation" ) {
        isConditionTrue_0 = true;
        gdjs.MainCode.GDOptionTxt1Objects3[k] = gdjs.MainCode.GDOptionTxt1Objects3[i];
        ++k;
    }
}
gdjs.MainCode.GDOptionTxt1Objects3.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Cap_comments"), gdjs.MainCode.GDCap_9595commentsObjects3);
{for(var i = 0, len = gdjs.MainCode.GDCap_9595commentsObjects3.length ;i < len;++i) {
    gdjs.MainCode.GDCap_9595commentsObjects3[i].getBehavior("Text").setText("Public adores this. Your shades? Less adored. Very pricey glare.");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("OptionTxt1"), gdjs.MainCode.GDOptionTxt1Objects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.MainCode.GDOptionTxt1Objects3.length;i<l;++i) {
    if ( gdjs.MainCode.GDOptionTxt1Objects3[i].getBehavior("Text").getText() == "Of course hotdogs are veggies. I’ve been eating healthy this whole time!" ) {
        isConditionTrue_0 = true;
        gdjs.MainCode.GDOptionTxt1Objects3[k] = gdjs.MainCode.GDOptionTxt1Objects3[i];
        ++k;
    }
}
gdjs.MainCode.GDOptionTxt1Objects3.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Cap_comments"), gdjs.MainCode.GDCap_9595commentsObjects3);
{for(var i = 0, len = gdjs.MainCode.GDCap_9595commentsObjects3.length ;i < len;++i) {
    gdjs.MainCode.GDCap_9595commentsObjects3[i].getBehavior("Text").setText("They’ll love this so much, they might forget… everything else.");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("OptionTxt1"), gdjs.MainCode.GDOptionTxt1Objects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.MainCode.GDOptionTxt1Objects3.length;i<l;++i) {
    if ( gdjs.MainCode.GDOptionTxt1Objects3[i].getBehavior("Text").getText() == "Relax, folks. I’ve got a hotline to the Internet. We’re all good. #NoOfflineZone" ) {
        isConditionTrue_0 = true;
        gdjs.MainCode.GDOptionTxt1Objects3[k] = gdjs.MainCode.GDOptionTxt1Objects3[i];
        ++k;
    }
}
gdjs.MainCode.GDOptionTxt1Objects3.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Cap_comments"), gdjs.MainCode.GDCap_9595commentsObjects3);
{for(var i = 0, len = gdjs.MainCode.GDCap_9595commentsObjects3.length ;i < len;++i) {
    gdjs.MainCode.GDCap_9595commentsObjects3[i].getBehavior("Text").setText("People will cheer! And maybe not Google your past for a while.");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("OptionTxt1"), gdjs.MainCode.GDOptionTxt1Objects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.MainCode.GDOptionTxt1Objects3.length;i<l;++i) {
    if ( gdjs.MainCode.GDOptionTxt1Objects3[i].getBehavior("Text").getText() == "That goose gets it. Maybe I’ll appoint it to my advisory board." ) {
        isConditionTrue_0 = true;
        gdjs.MainCode.GDOptionTxt1Objects3[k] = gdjs.MainCode.GDOptionTxt1Objects3[i];
        ++k;
    }
}
gdjs.MainCode.GDOptionTxt1Objects3.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Cap_comments"), gdjs.MainCode.GDCap_9595commentsObjects3);
{for(var i = 0, len = gdjs.MainCode.GDCap_9595commentsObjects3.length ;i < len;++i) {
    gdjs.MainCode.GDCap_9595commentsObjects3[i].getBehavior("Text").setText("Oof. Even I might boo this one, and I’m a hat.");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("OptionTxt1"), gdjs.MainCode.GDOptionTxt1Objects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.MainCode.GDOptionTxt1Objects3.length;i<l;++i) {
    if ( gdjs.MainCode.GDOptionTxt1Objects3[i].getBehavior("Text").getText() == "Just did the dance. My hips broke a window. #PowerMovesOnly" ) {
        isConditionTrue_0 = true;
        gdjs.MainCode.GDOptionTxt1Objects3[k] = gdjs.MainCode.GDOptionTxt1Objects3[i];
        ++k;
    }
}
gdjs.MainCode.GDOptionTxt1Objects3.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Cap_comments"), gdjs.MainCode.GDCap_9595commentsObjects3);
{for(var i = 0, len = gdjs.MainCode.GDCap_9595commentsObjects3.length ;i < len;++i) {
    gdjs.MainCode.GDCap_9595commentsObjects3[i].getBehavior("Text").setText("Breaking windows costs. But your dance moves? Totally worth it.");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("OptionTxt1"), gdjs.MainCode.GDOptionTxt1Objects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.MainCode.GDOptionTxt1Objects3.length;i<l;++i) {
    if ( gdjs.MainCode.GDOptionTxt1Objects3[i].getBehavior("Text").getText() == "I love it. The anthem SLAPS now. #RobotRhythm" ) {
        isConditionTrue_0 = true;
        gdjs.MainCode.GDOptionTxt1Objects3[k] = gdjs.MainCode.GDOptionTxt1Objects3[i];
        ++k;
    }
}
gdjs.MainCode.GDOptionTxt1Objects3.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Cap_comments"), gdjs.MainCode.GDCap_9595commentsObjects3);
{for(var i = 0, len = gdjs.MainCode.GDCap_9595commentsObjects3.length ;i < len;++i) {
    gdjs.MainCode.GDCap_9595commentsObjects3[i].getBehavior("Text").setText("Waving flags = happy wallets. Patriotism has perks.");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("OptionTxt1"), gdjs.MainCode.GDOptionTxt1Objects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.MainCode.GDOptionTxt1Objects2.length;i<l;++i) {
    if ( gdjs.MainCode.GDOptionTxt1Objects2[i].getBehavior("Text").getText() == "Every dog gets a tablet. It’s time. We believe in pet progress. #SmartDogsRule" ) {
        isConditionTrue_0 = true;
        gdjs.MainCode.GDOptionTxt1Objects2[k] = gdjs.MainCode.GDOptionTxt1Objects2[i];
        ++k;
    }
}
gdjs.MainCode.GDOptionTxt1Objects2.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Cap_comments"), gdjs.MainCode.GDCap_9595commentsObjects2);
{for(var i = 0, len = gdjs.MainCode.GDCap_9595commentsObjects2.length ;i < len;++i) {
    gdjs.MainCode.GDCap_9595commentsObjects2[i].getBehavior("Text").setText("Dog owners rejoice! Cat lovers slightly confused.");
}
}}

}


};gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDOption2Objects2Objects = Hashtable.newFrom({"Option2": gdjs.MainCode.GDOption2Objects2});
gdjs.MainCode.eventsList62 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("OptionTxt2"), gdjs.MainCode.GDOptionTxt2Objects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.MainCode.GDOptionTxt2Objects3.length;i<l;++i) {
    if ( gdjs.MainCode.GDOptionTxt2Objects3[i].getBehavior("Text").getText() == "Let’s create jobs by building eagle shaped like satellites! #EconBoom" ) {
        isConditionTrue_0 = true;
        gdjs.MainCode.GDOptionTxt2Objects3[k] = gdjs.MainCode.GDOptionTxt2Objects3[i];
        ++k;
    }
}
gdjs.MainCode.GDOptionTxt2Objects3.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Cap_comments"), gdjs.MainCode.GDCap_9595commentsObjects3);
{for(var i = 0, len = gdjs.MainCode.GDCap_9595commentsObjects3.length ;i < len;++i) {
    gdjs.MainCode.GDCap_9595commentsObjects3[i].getBehavior("Text").setText("Eagle-shaped satellites? Next up: raccoon-shaped WiFi routers!");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("OptionTxt2"), gdjs.MainCode.GDOptionTxt2Objects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.MainCode.GDOptionTxt2Objects3.length;i<l;++i) {
    if ( gdjs.MainCode.GDOptionTxt2Objects3[i].getBehavior("Text").getText() == "Time to fund local tomato farms. Red jobs for red sauce. #Agrinomics" ) {
        isConditionTrue_0 = true;
        gdjs.MainCode.GDOptionTxt2Objects3[k] = gdjs.MainCode.GDOptionTxt2Objects3[i];
        ++k;
    }
}
gdjs.MainCode.GDOptionTxt2Objects3.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Cap_comments"), gdjs.MainCode.GDCap_9595commentsObjects3);
{for(var i = 0, len = gdjs.MainCode.GDCap_9595commentsObjects3.length ;i < len;++i) {
    gdjs.MainCode.GDCap_9595commentsObjects3[i].getBehavior("Text").setText("This one screams ‘for the country!’ And whispers ‘re-election.’");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("OptionTxt2"), gdjs.MainCode.GDOptionTxt2Objects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.MainCode.GDOptionTxt2Objects3.length;i<l;++i) {
    if ( gdjs.MainCode.GDOptionTxt2Objects3[i].getBehavior("Text").getText() == "Sell plushies. Open a theme park. Call it Rodentland. Huge potential." ) {
        isConditionTrue_0 = true;
        gdjs.MainCode.GDOptionTxt2Objects3[k] = gdjs.MainCode.GDOptionTxt2Objects3[i];
        ++k;
    }
}
gdjs.MainCode.GDOptionTxt2Objects3.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Cap_comments"), gdjs.MainCode.GDCap_9595commentsObjects3);
{for(var i = 0, len = gdjs.MainCode.GDCap_9595commentsObjects3.length ;i < len;++i) {
    gdjs.MainCode.GDCap_9595commentsObjects3[i].getBehavior("Text").setText("Rodents = bad. Theme parks = good. Balance achieved?");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("OptionTxt2"), gdjs.MainCode.GDOptionTxt2Objects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.MainCode.GDOptionTxt2Objects3.length;i<l;++i) {
    if ( gdjs.MainCode.GDOptionTxt2Objects3[i].getBehavior("Text").getText() == "National production push! Boost jobs, block sun. #SolarStimulus" ) {
        isConditionTrue_0 = true;
        gdjs.MainCode.GDOptionTxt2Objects3[k] = gdjs.MainCode.GDOptionTxt2Objects3[i];
        ++k;
    }
}
gdjs.MainCode.GDOptionTxt2Objects3.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Cap_comments"), gdjs.MainCode.GDCap_9595commentsObjects3);
{for(var i = 0, len = gdjs.MainCode.GDCap_9595commentsObjects3.length ;i < len;++i) {
    gdjs.MainCode.GDCap_9595commentsObjects3[i].getBehavior("Text").setText("More jobs! Smiles everywhere. Even the economy did a lil’ dance.");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("OptionTxt2"), gdjs.MainCode.GDOptionTxt2Objects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.MainCode.GDOptionTxt2Objects3.length;i<l;++i) {
    if ( gdjs.MainCode.GDOptionTxt2Objects3[i].getBehavior("Text").getText() == "Time to rebrand school lunches. Hotdogs for everyone. tax write-off." ) {
        isConditionTrue_0 = true;
        gdjs.MainCode.GDOptionTxt2Objects3[k] = gdjs.MainCode.GDOptionTxt2Objects3[i];
        ++k;
    }
}
gdjs.MainCode.GDOptionTxt2Objects3.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Cap_comments"), gdjs.MainCode.GDCap_9595commentsObjects3);
{for(var i = 0, len = gdjs.MainCode.GDCap_9595commentsObjects3.length ;i < len;++i) {
    gdjs.MainCode.GDCap_9595commentsObjects3[i].getBehavior("Text").setText("Tax write-offs are fun;until someone asks who’s paying the bills.");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("OptionTxt2"), gdjs.MainCode.GDOptionTxt2Objects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.MainCode.GDOptionTxt2Objects3.length;i<l;++i) {
    if ( gdjs.MainCode.GDOptionTxt2Objects3[i].getBehavior("Text").getText() == "Time to build local servers. Keep the net local, keep the jobs booming." ) {
        isConditionTrue_0 = true;
        gdjs.MainCode.GDOptionTxt2Objects3[k] = gdjs.MainCode.GDOptionTxt2Objects3[i];
        ++k;
    }
}
gdjs.MainCode.GDOptionTxt2Objects3.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Cap_comments"), gdjs.MainCode.GDCap_9595commentsObjects3);
{for(var i = 0, len = gdjs.MainCode.GDCap_9595commentsObjects3.length ;i < len;++i) {
    gdjs.MainCode.GDCap_9595commentsObjects3[i].getBehavior("Text").setText("Big win for the economy. Also a high-five for your image!");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("OptionTxt2"), gdjs.MainCode.GDOptionTxt2Objects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.MainCode.GDOptionTxt2Objects3.length;i<l;++i) {
    if ( gdjs.MainCode.GDOptionTxt2Objects3[i].getBehavior("Text").getText() == "Let’s build the Goose Capitol right next to the Parliament. #GooseGDP" ) {
        isConditionTrue_0 = true;
        gdjs.MainCode.GDOptionTxt2Objects3[k] = gdjs.MainCode.GDOptionTxt2Objects3[i];
        ++k;
    }
}
gdjs.MainCode.GDOptionTxt2Objects3.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Cap_comments"), gdjs.MainCode.GDCap_9595commentsObjects3);
{for(var i = 0, len = gdjs.MainCode.GDCap_9595commentsObjects3.length ;i < len;++i) {
    gdjs.MainCode.GDCap_9595commentsObjects3[i].getBehavior("Text").setText("This idea? Surprisingly charming. Could be a sleeper hit!");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("OptionTxt2"), gdjs.MainCode.GDOptionTxt2Objects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.MainCode.GDOptionTxt2Objects3.length;i<l;++i) {
    if ( gdjs.MainCode.GDOptionTxt2Objects3[i].getBehavior("Text").getText() == "Fund our own national dance app: ChatterChirp. Jobs, fun, control. #AppConomy" ) {
        isConditionTrue_0 = true;
        gdjs.MainCode.GDOptionTxt2Objects3[k] = gdjs.MainCode.GDOptionTxt2Objects3[i];
        ++k;
    }
}
gdjs.MainCode.GDOptionTxt2Objects3.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Cap_comments"), gdjs.MainCode.GDCap_9595commentsObjects3);
{for(var i = 0, len = gdjs.MainCode.GDCap_9595commentsObjects3.length ;i < len;++i) {
    gdjs.MainCode.GDCap_9595commentsObjects3[i].getBehavior("Text").setText("People are eating this up like election-year candy!");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("OptionTxt2"), gdjs.MainCode.GDOptionTxt2Objects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.MainCode.GDOptionTxt2Objects3.length;i<l;++i) {
    if ( gdjs.MainCode.GDOptionTxt2Objects3[i].getBehavior("Text").getText() == "National AI for National anthems. Invest in future jams. #CodeToCash" ) {
        isConditionTrue_0 = true;
        gdjs.MainCode.GDOptionTxt2Objects3[k] = gdjs.MainCode.GDOptionTxt2Objects3[i];
        ++k;
    }
}
gdjs.MainCode.GDOptionTxt2Objects3.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Cap_comments"), gdjs.MainCode.GDCap_9595commentsObjects3);
{for(var i = 0, len = gdjs.MainCode.GDCap_9595commentsObjects3.length ;i < len;++i) {
    gdjs.MainCode.GDCap_9595commentsObjects3[i].getBehavior("Text").setText("AI is trending. Yours might even run for office next term.");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("OptionTxt2"), gdjs.MainCode.GDOptionTxt2Objects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.MainCode.GDOptionTxt2Objects2.length;i<l;++i) {
    if ( gdjs.MainCode.GDOptionTxt2Objects2[i].getBehavior("Text").getText() == "Launch CanineTech initiative. Training labs, jobs, dog dollars. #Pawductivity" ) {
        isConditionTrue_0 = true;
        gdjs.MainCode.GDOptionTxt2Objects2[k] = gdjs.MainCode.GDOptionTxt2Objects2[i];
        ++k;
    }
}
gdjs.MainCode.GDOptionTxt2Objects2.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Cap_comments"), gdjs.MainCode.GDCap_9595commentsObjects2);
{for(var i = 0, len = gdjs.MainCode.GDCap_9595commentsObjects2.length ;i < len;++i) {
    gdjs.MainCode.GDCap_9595commentsObjects2[i].getBehavior("Text").setText("Quick cash boost! But your wallet takes the hit this time.");
}
}}

}


};gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDOption3Objects2Objects = Hashtable.newFrom({"Option3": gdjs.MainCode.GDOption3Objects2});
gdjs.MainCode.eventsList63 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("OptionTxt3"), gdjs.MainCode.GDOptionTxt3Objects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.MainCode.GDOptionTxt3Objects3.length;i<l;++i) {
    if ( gdjs.MainCode.GDOptionTxt3Objects3[i].getBehavior("Text").getText() == "Launching new NFT: ‘First Contact Collection.’ 10,000 pics. Limited edition." ) {
        isConditionTrue_0 = true;
        gdjs.MainCode.GDOptionTxt3Objects3[k] = gdjs.MainCode.GDOptionTxt3Objects3[i];
        ++k;
    }
}
gdjs.MainCode.GDOptionTxt3Objects3.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Cap_comments"), gdjs.MainCode.GDCap_9595commentsObjects3);
{for(var i = 0, len = gdjs.MainCode.GDCap_9595commentsObjects3.length ;i < len;++i) {
    gdjs.MainCode.GDCap_9595commentsObjects3[i].getBehavior("Text").setText("NFTs are spicy. Might burn you. Might make you rich.");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("OptionTxt3"), gdjs.MainCode.GDOptionTxt3Objects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.MainCode.GDOptionTxt3Objects3.length;i<l;++i) {
    if ( gdjs.MainCode.GDOptionTxt3Objects3[i].getBehavior("Text").getText() == "Introducing: PRESIMATO. Luxury ketchup. Gold bottle, same old taste." ) {
        isConditionTrue_0 = true;
        gdjs.MainCode.GDOptionTxt3Objects3[k] = gdjs.MainCode.GDOptionTxt3Objects3[i];
        ++k;
    }
}
gdjs.MainCode.GDOptionTxt3Objects3.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Cap_comments"), gdjs.MainCode.GDCap_9595commentsObjects3);
{for(var i = 0, len = gdjs.MainCode.GDCap_9595commentsObjects3.length ;i < len;++i) {
    gdjs.MainCode.GDCap_9595commentsObjects3[i].getBehavior("Text").setText("I hear cash flowing in... and angry mobs outside. Balance, baby!");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("OptionTxt3"), gdjs.MainCode.GDOptionTxt3Objects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.MainCode.GDOptionTxt3Objects3.length;i<l;++i) {
    if ( gdjs.MainCode.GDOptionTxt3Objects3[i].getBehavior("Text").getText() == "I’m licensing the giant hamster’s image for a new crypto: ChewCoin." ) {
        isConditionTrue_0 = true;
        gdjs.MainCode.GDOptionTxt3Objects3[k] = gdjs.MainCode.GDOptionTxt3Objects3[i];
        ++k;
    }
}
gdjs.MainCode.GDOptionTxt3Objects3.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Cap_comments"), gdjs.MainCode.GDCap_9595commentsObjects3);
{for(var i = 0, len = gdjs.MainCode.GDCap_9595commentsObjects3.length ;i < len;++i) {
    gdjs.MainCode.GDCap_9595commentsObjects3[i].getBehavior("Text").setText("ChewCoins? Tasty profits or cavity-level risks? Hard to say.");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("OptionTxt3"), gdjs.MainCode.GDOptionTxt3Objects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.MainCode.GDOptionTxt3Objects3.length;i<l;++i) {
    if ( gdjs.MainCode.GDOptionTxt3Objects3[i].getBehavior("Text").getText() == "Launching limited edition red cap-shaped sunglasses. Smartest ever. #Visionary" ) {
        isConditionTrue_0 = true;
        gdjs.MainCode.GDOptionTxt3Objects3[k] = gdjs.MainCode.GDOptionTxt3Objects3[i];
        ++k;
    }
}
gdjs.MainCode.GDOptionTxt3Objects3.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Cap_comments"), gdjs.MainCode.GDCap_9595commentsObjects3);
{for(var i = 0, len = gdjs.MainCode.GDCap_9595commentsObjects3.length ;i < len;++i) {
    gdjs.MainCode.GDCap_9595commentsObjects3[i].getBehavior("Text").setText("Cap-shaped shades? Weird flex, but maybe a stylish one.");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("OptionTxt3"), gdjs.MainCode.GDOptionTxt3Objects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.MainCode.GDOptionTxt3Objects3.length;i<l;++i) {
    if ( gdjs.MainCode.GDOptionTxt3Objects3[i].getBehavior("Text").getText() == "Visit my shop: VeganDog™. 99% mystery, 1% marketing. #EarnToEat" ) {
        isConditionTrue_0 = true;
        gdjs.MainCode.GDOptionTxt3Objects3[k] = gdjs.MainCode.GDOptionTxt3Objects3[i];
        ++k;
    }
}
gdjs.MainCode.GDOptionTxt3Objects3.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Cap_comments"), gdjs.MainCode.GDCap_9595commentsObjects3);
{for(var i = 0, len = gdjs.MainCode.GDCap_9595commentsObjects3.length ;i < len;++i) {
    gdjs.MainCode.GDCap_9595commentsObjects3[i].getBehavior("Text").setText("Mystery marketing? Nah. But your hotdogs? Unifying the nation.");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("OptionTxt3"), gdjs.MainCode.GDOptionTxt3Objects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.MainCode.GDOptionTxt3Objects3.length;i<l;++i) {
    if ( gdjs.MainCode.GDOptionTxt3Objects3[i].getBehavior("Text").getText() == "Use PresiDrive™. Holds memes, emails, AND my autobiography. Only $99.99" ) {
        isConditionTrue_0 = true;
        gdjs.MainCode.GDOptionTxt3Objects3[k] = gdjs.MainCode.GDOptionTxt3Objects3[i];
        ++k;
    }
}
gdjs.MainCode.GDOptionTxt3Objects3.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Cap_comments"), gdjs.MainCode.GDCap_9595commentsObjects3);
{for(var i = 0, len = gdjs.MainCode.GDCap_9595commentsObjects3.length ;i < len;++i) {
    gdjs.MainCode.GDCap_9595commentsObjects3[i].getBehavior("Text").setText("This drive costs more than it looks. People will notice.");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("OptionTxt3"), gdjs.MainCode.GDOptionTxt3Objects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.MainCode.GDOptionTxt3Objects3.length;i<l;++i) {
    if ( gdjs.MainCode.GDOptionTxt3Objects3[i].getBehavior("Text").getText() == "Exclusive goose-branded merchandise coming. Hats, hoodies, honks." ) {
        isConditionTrue_0 = true;
        gdjs.MainCode.GDOptionTxt3Objects3[k] = gdjs.MainCode.GDOptionTxt3Objects3[i];
        ++k;
    }
}
gdjs.MainCode.GDOptionTxt3Objects3.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Cap_comments"), gdjs.MainCode.GDCap_9595commentsObjects3);
{for(var i = 0, len = gdjs.MainCode.GDCap_9595commentsObjects3.length ;i < len;++i) {
    gdjs.MainCode.GDCap_9595commentsObjects3[i].getBehavior("Text").setText("Smells like mischief. But hey, mischief sometimes pays.");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("OptionTxt3"), gdjs.MainCode.GDOptionTxt3Objects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.MainCode.GDOptionTxt3Objects3.length;i<l;++i) {
    if ( gdjs.MainCode.GDOptionTxt3Objects3[i].getBehavior("Text").getText() == "Watch me dance: The PresiSlide™. Unlockable with red cap token. #ShakeItRich" ) {
        isConditionTrue_0 = true;
        gdjs.MainCode.GDOptionTxt3Objects3[k] = gdjs.MainCode.GDOptionTxt3Objects3[i];
        ++k;
    }
}
gdjs.MainCode.GDOptionTxt3Objects3.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Cap_comments"), gdjs.MainCode.GDCap_9595commentsObjects3);
{for(var i = 0, len = gdjs.MainCode.GDCap_9595commentsObjects3.length ;i < len;++i) {
    gdjs.MainCode.GDCap_9595commentsObjects3[i].getBehavior("Text").setText("PresiSlide: prints cash, spreads chaos. A classic!");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("OptionTxt3"), gdjs.MainCode.GDOptionTxt3Objects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.MainCode.GDOptionTxt3Objects3.length;i<l;++i) {
    if ( gdjs.MainCode.GDOptionTxt3Objects3[i].getBehavior("Text").getText() == "Buy my album: PresiBeats Vol.1 - only $49.99. #StreamingEmpire" ) {
        isConditionTrue_0 = true;
        gdjs.MainCode.GDOptionTxt3Objects3[k] = gdjs.MainCode.GDOptionTxt3Objects3[i];
        ++k;
    }
}
gdjs.MainCode.GDOptionTxt3Objects3.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Cap_comments"), gdjs.MainCode.GDCap_9595commentsObjects3);
{for(var i = 0, len = gdjs.MainCode.GDCap_9595commentsObjects3.length ;i < len;++i) {
    gdjs.MainCode.GDCap_9595commentsObjects3[i].getBehavior("Text").setText("These beats slap. Also… might trigger a Senate hearing.");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("OptionTxt3"), gdjs.MainCode.GDOptionTxt3Objects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.MainCode.GDOptionTxt3Objects2.length;i<l;++i) {
    if ( gdjs.MainCode.GDOptionTxt3Objects2[i].getBehavior("Text").getText() == "Exclusive BarkCoin pre-sale begins now. Invest in your dog’s future. #FurRich" ) {
        isConditionTrue_0 = true;
        gdjs.MainCode.GDOptionTxt3Objects2[k] = gdjs.MainCode.GDOptionTxt3Objects2[i];
        ++k;
    }
}
gdjs.MainCode.GDOptionTxt3Objects2.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Cap_comments"), gdjs.MainCode.GDCap_9595commentsObjects2);
{for(var i = 0, len = gdjs.MainCode.GDCap_9595commentsObjects2.length ;i < len;++i) {
    gdjs.MainCode.GDCap_9595commentsObjects2[i].getBehavior("Text").setText("They’ll rage-post about it, then buy three. Classic FOMO play.");
}
}}

}


};gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDOption1Objects2Objects = Hashtable.newFrom({"Option1": gdjs.MainCode.GDOption1Objects2});
gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDOption2Objects2Objects = Hashtable.newFrom({"Option2": gdjs.MainCode.GDOption2Objects2});
gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDOption3Objects2Objects = Hashtable.newFrom({"Option3": gdjs.MainCode.GDOption3Objects2});
gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDOption1Objects2Objects = Hashtable.newFrom({"Option1": gdjs.MainCode.GDOption1Objects2});
gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDOption2Objects2Objects = Hashtable.newFrom({"Option2": gdjs.MainCode.GDOption2Objects2});
gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDOption3Objects2Objects = Hashtable.newFrom({"Option3": gdjs.MainCode.GDOption3Objects2});
gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDSend_95959595icon1Objects2Objects = Hashtable.newFrom({"Send_icon1": gdjs.MainCode.GDSend_9595icon1Objects2});
gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDSend_95959595icon1Objects2Objects = Hashtable.newFrom({"Send_icon1": gdjs.MainCode.GDSend_9595icon1Objects2});
gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDSend_95959595icon2Objects2Objects = Hashtable.newFrom({"Send_icon2": gdjs.MainCode.GDSend_9595icon2Objects2});
gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDSend_95959595icon2Objects2Objects = Hashtable.newFrom({"Send_icon2": gdjs.MainCode.GDSend_9595icon2Objects2});
gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDSend_95959595icon3Objects2Objects = Hashtable.newFrom({"Send_icon3": gdjs.MainCode.GDSend_9595icon3Objects2});
gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDSend_95959595icon3Objects1Objects = Hashtable.newFrom({"Send_icon3": gdjs.MainCode.GDSend_9595icon3Objects1});
gdjs.MainCode.eventsList64 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Option1"), gdjs.MainCode.GDOption1Objects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDOption1Objects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
/* Reuse gdjs.MainCode.GDOption1Objects2 */
gdjs.copyArray(runtimeScene.getObjects("Send_icon1"), gdjs.MainCode.GDSend_9595icon1Objects2);
{for(var i = 0, len = gdjs.MainCode.GDOption1Objects2.length ;i < len;++i) {
    gdjs.MainCode.GDOption1Objects2[i].getBehavior("Animation").setAnimationName("hover");
}
}{for(var i = 0, len = gdjs.MainCode.GDSend_9595icon1Objects2.length ;i < len;++i) {
    gdjs.MainCode.GDSend_9595icon1Objects2[i].hide(false);
}
}
{ //Subevents
gdjs.MainCode.eventsList61(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Option2"), gdjs.MainCode.GDOption2Objects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDOption2Objects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
/* Reuse gdjs.MainCode.GDOption2Objects2 */
gdjs.copyArray(runtimeScene.getObjects("Send_icon2"), gdjs.MainCode.GDSend_9595icon2Objects2);
{for(var i = 0, len = gdjs.MainCode.GDOption2Objects2.length ;i < len;++i) {
    gdjs.MainCode.GDOption2Objects2[i].getBehavior("Animation").setAnimationName("hover");
}
}{for(var i = 0, len = gdjs.MainCode.GDSend_9595icon2Objects2.length ;i < len;++i) {
    gdjs.MainCode.GDSend_9595icon2Objects2[i].hide(false);
}
}
{ //Subevents
gdjs.MainCode.eventsList62(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Option3"), gdjs.MainCode.GDOption3Objects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDOption3Objects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
/* Reuse gdjs.MainCode.GDOption3Objects2 */
gdjs.copyArray(runtimeScene.getObjects("Send_icon3"), gdjs.MainCode.GDSend_9595icon3Objects2);
{for(var i = 0, len = gdjs.MainCode.GDOption3Objects2.length ;i < len;++i) {
    gdjs.MainCode.GDOption3Objects2[i].getBehavior("Animation").setAnimationName("hover");
}
}{for(var i = 0, len = gdjs.MainCode.GDSend_9595icon3Objects2.length ;i < len;++i) {
    gdjs.MainCode.GDSend_9595icon3Objects2[i].hide(false);
}
}
{ //Subevents
gdjs.MainCode.eventsList63(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Option1"), gdjs.MainCode.GDOption1Objects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDOption1Objects2Objects, runtimeScene, true, true);
if (isConditionTrue_0) {
/* Reuse gdjs.MainCode.GDOption1Objects2 */
gdjs.copyArray(runtimeScene.getObjects("Send_icon1"), gdjs.MainCode.GDSend_9595icon1Objects2);
{for(var i = 0, len = gdjs.MainCode.GDOption1Objects2.length ;i < len;++i) {
    gdjs.MainCode.GDOption1Objects2[i].getBehavior("Animation").setAnimationName("default");
}
}{for(var i = 0, len = gdjs.MainCode.GDSend_9595icon1Objects2.length ;i < len;++i) {
    gdjs.MainCode.GDSend_9595icon1Objects2[i].hide();
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Option2"), gdjs.MainCode.GDOption2Objects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDOption2Objects2Objects, runtimeScene, true, true);
if (isConditionTrue_0) {
/* Reuse gdjs.MainCode.GDOption2Objects2 */
gdjs.copyArray(runtimeScene.getObjects("Send_icon2"), gdjs.MainCode.GDSend_9595icon2Objects2);
{for(var i = 0, len = gdjs.MainCode.GDOption2Objects2.length ;i < len;++i) {
    gdjs.MainCode.GDOption2Objects2[i].getBehavior("Animation").setAnimationName("default");
}
}{for(var i = 0, len = gdjs.MainCode.GDSend_9595icon2Objects2.length ;i < len;++i) {
    gdjs.MainCode.GDSend_9595icon2Objects2[i].hide();
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Option3"), gdjs.MainCode.GDOption3Objects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDOption3Objects2Objects, runtimeScene, true, true);
if (isConditionTrue_0) {
/* Reuse gdjs.MainCode.GDOption3Objects2 */
gdjs.copyArray(runtimeScene.getObjects("Send_icon3"), gdjs.MainCode.GDSend_9595icon3Objects2);
{for(var i = 0, len = gdjs.MainCode.GDOption3Objects2.length ;i < len;++i) {
    gdjs.MainCode.GDOption3Objects2[i].getBehavior("Animation").setAnimationName("default");
}
}{for(var i = 0, len = gdjs.MainCode.GDSend_9595icon3Objects2.length ;i < len;++i) {
    gdjs.MainCode.GDSend_9595icon3Objects2[i].hide();
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Option1"), gdjs.MainCode.GDOption1Objects2);
gdjs.copyArray(runtimeScene.getObjects("Option2"), gdjs.MainCode.GDOption2Objects2);
gdjs.copyArray(runtimeScene.getObjects("Option3"), gdjs.MainCode.GDOption3Objects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.cursorOnObject(gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDOption1Objects2Objects, runtimeScene, true, true);
if (isConditionTrue_1) {
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.cursorOnObject(gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDOption2Objects2Objects, runtimeScene, true, true);
if (isConditionTrue_1) {
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.cursorOnObject(gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDOption3Objects2Objects, runtimeScene, true, true);
}
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Cap_comments"), gdjs.MainCode.GDCap_9595commentsObjects2);
{for(var i = 0, len = gdjs.MainCode.GDCap_9595commentsObjects2.length ;i < len;++i) {
    gdjs.MainCode.GDCap_9595commentsObjects2[i].getBehavior("Text").setText("");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Send_icon1"), gdjs.MainCode.GDSend_9595icon1Objects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDSend_95959595icon1Objects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
/* Reuse gdjs.MainCode.GDSend_9595icon1Objects2 */
{for(var i = 0, len = gdjs.MainCode.GDSend_9595icon1Objects2.length ;i < len;++i) {
    gdjs.MainCode.GDSend_9595icon1Objects2[i].getBehavior("Animation").setAnimationName("hover");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Send_icon1"), gdjs.MainCode.GDSend_9595icon1Objects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDSend_95959595icon1Objects2Objects, runtimeScene, true, true);
if (isConditionTrue_0) {
/* Reuse gdjs.MainCode.GDSend_9595icon1Objects2 */
{for(var i = 0, len = gdjs.MainCode.GDSend_9595icon1Objects2.length ;i < len;++i) {
    gdjs.MainCode.GDSend_9595icon1Objects2[i].getBehavior("Animation").setAnimationName("default");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Send_icon2"), gdjs.MainCode.GDSend_9595icon2Objects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDSend_95959595icon2Objects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
/* Reuse gdjs.MainCode.GDSend_9595icon2Objects2 */
{for(var i = 0, len = gdjs.MainCode.GDSend_9595icon2Objects2.length ;i < len;++i) {
    gdjs.MainCode.GDSend_9595icon2Objects2[i].getBehavior("Animation").setAnimationName("hover");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Send_icon2"), gdjs.MainCode.GDSend_9595icon2Objects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDSend_95959595icon2Objects2Objects, runtimeScene, true, true);
if (isConditionTrue_0) {
/* Reuse gdjs.MainCode.GDSend_9595icon2Objects2 */
{for(var i = 0, len = gdjs.MainCode.GDSend_9595icon2Objects2.length ;i < len;++i) {
    gdjs.MainCode.GDSend_9595icon2Objects2[i].getBehavior("Animation").setAnimationName("default");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Send_icon3"), gdjs.MainCode.GDSend_9595icon3Objects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDSend_95959595icon3Objects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
/* Reuse gdjs.MainCode.GDSend_9595icon3Objects2 */
{for(var i = 0, len = gdjs.MainCode.GDSend_9595icon3Objects2.length ;i < len;++i) {
    gdjs.MainCode.GDSend_9595icon3Objects2[i].getBehavior("Animation").setAnimationName("hover");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Send_icon3"), gdjs.MainCode.GDSend_9595icon3Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDSend_95959595icon3Objects1Objects, runtimeScene, true, true);
if (isConditionTrue_0) {
/* Reuse gdjs.MainCode.GDSend_9595icon3Objects1 */
{for(var i = 0, len = gdjs.MainCode.GDSend_9595icon3Objects1.length ;i < len;++i) {
    gdjs.MainCode.GDSend_9595icon3Objects1[i].getBehavior("Animation").setAnimationName("default");
}
}}

}


};gdjs.MainCode.eventsList65 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Send_icon1"), gdjs.MainCode.GDSend_9595icon1Objects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDSend_95959595icon1Objects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("OptionTxt1"), gdjs.MainCode.GDOptionTxt1Objects2);
{runtimeScene.getScene().getVariables().getFromIndex(2).setString((( gdjs.MainCode.GDOptionTxt1Objects2.length === 0 ) ? "" :gdjs.MainCode.GDOptionTxt1Objects2[0].getBehavior("Text").getText()));
}{runtimeScene.getScene().getVariables().getFromIndex(7).setString("REACTION");
}{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "assets\\Sounds\\Send-good-6081.mp3", 2, false, 100, 1);
}
{ //Subevents
gdjs.MainCode.eventsList58(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Send_icon2"), gdjs.MainCode.GDSend_9595icon2Objects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDSend_95959595icon2Objects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("OptionTxt2"), gdjs.MainCode.GDOptionTxt2Objects2);
{runtimeScene.getScene().getVariables().getFromIndex(2).setString((( gdjs.MainCode.GDOptionTxt2Objects2.length === 0 ) ? "" :gdjs.MainCode.GDOptionTxt2Objects2[0].getBehavior("Text").getText()));
}{runtimeScene.getScene().getVariables().getFromIndex(7).setString("REACTION");
}{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "assets\\Sounds\\Send-good-6081.mp3", 2, false, 100, 1);
}
{ //Subevents
gdjs.MainCode.eventsList59(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Send_icon3"), gdjs.MainCode.GDSend_9595icon3Objects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDSend_95959595icon3Objects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("OptionTxt3"), gdjs.MainCode.GDOptionTxt3Objects2);
{runtimeScene.getScene().getVariables().getFromIndex(2).setString((( gdjs.MainCode.GDOptionTxt3Objects2.length === 0 ) ? "" :gdjs.MainCode.GDOptionTxt3Objects2[0].getBehavior("Text").getText()));
}{runtimeScene.getScene().getVariables().getFromIndex(7).setString("REACTION");
}{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "assets\\Sounds\\Send-good-6081.mp3", 2, false, 100, 1);
}
{ //Subevents
gdjs.MainCode.eventsList60(runtimeScene);} //End of subevents
}

}


{


gdjs.MainCode.eventsList64(runtimeScene);
}


};gdjs.MainCode.eventsList66 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(7).getAsString() == "DECISION");
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.MainCode.eventsList65(runtimeScene);} //End of subevents
}

}


};gdjs.MainCode.asyncCallback15177668 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.MainCode.localVariables);
{runtimeScene.getScene().getVariables().getFromIndex(22).setBoolean(true);
}gdjs.MainCode.localVariables.length = 0;
}
gdjs.MainCode.eventsList67 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
asyncObjectsList.backupLocalVariablesContainers(gdjs.MainCode.localVariables);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(2), (runtimeScene) => (gdjs.MainCode.asyncCallback15177668(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.MainCode.asyncCallback15176404 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.MainCode.localVariables);
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "FireReactionCountTimer");
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "LikeReactionCountTimer");
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "HeartReactionCountTimer");
}
{ //Subevents
gdjs.MainCode.eventsList67(runtimeScene, asyncObjectsList);} //End of subevents
gdjs.MainCode.localVariables.length = 0;
}
gdjs.MainCode.eventsList68 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.MainCode.localVariables);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1.5), (runtimeScene) => (gdjs.MainCode.asyncCallback15176404(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.MainCode.asyncCallback15185820 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.MainCode.localVariables);
{runtimeScene.getScene().getVariables().getFromIndex(23).setBoolean(true);
}gdjs.MainCode.localVariables.length = 0;
}
gdjs.MainCode.eventsList69 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.MainCode.localVariables);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(2), (runtimeScene) => (gdjs.MainCode.asyncCallback15185820(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.MainCode.asyncCallback15188852 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.MainCode.localVariables);
{runtimeScene.getScene().getVariables().getFromIndex(7).setString("RESULT");
}gdjs.MainCode.localVariables.length = 0;
}
gdjs.MainCode.eventsList70 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.MainCode.localVariables);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(2), (runtimeScene) => (gdjs.MainCode.asyncCallback15188852(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.MainCode.eventsList71 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = !runtimeScene.getScene().getVariables().getFromIndex(21).getAsBoolean();
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15173748);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Tweet4"), gdjs.MainCode.GDTweet4Objects2);
gdjs.copyArray(runtimeScene.getObjects("Tweet5"), gdjs.MainCode.GDTweet5Objects2);
gdjs.copyArray(runtimeScene.getObjects("Tweet6"), gdjs.MainCode.GDTweet6Objects2);
gdjs.copyArray(runtimeScene.getObjects("TweetMarker2"), gdjs.MainCode.GDTweetMarker2Objects2);
gdjs.copyArray(runtimeScene.getObjects("TweetMarker3"), gdjs.MainCode.GDTweetMarker3Objects2);
gdjs.copyArray(runtimeScene.getObjects("TweetMarker4"), gdjs.MainCode.GDTweetMarker4Objects2);
gdjs.copyArray(runtimeScene.getObjects("TweetMarker5"), gdjs.MainCode.GDTweetMarker5Objects2);
gdjs.copyArray(runtimeScene.getObjects("TweetMarker6"), gdjs.MainCode.GDTweetMarker6Objects2);
gdjs.copyArray(runtimeScene.getObjects("TweetMarker7"), gdjs.MainCode.GDTweetMarker7Objects2);
gdjs.copyArray(runtimeScene.getObjects("Tweet_bkg1"), gdjs.MainCode.GDTweet_9595bkg1Objects2);
gdjs.copyArray(runtimeScene.getObjects("Tweet_bkg2"), gdjs.MainCode.GDTweet_9595bkg2Objects2);
gdjs.copyArray(runtimeScene.getObjects("Tweet_bkg3"), gdjs.MainCode.GDTweet_9595bkg3Objects2);
gdjs.copyArray(runtimeScene.getObjects("Tweet_bkg4"), gdjs.MainCode.GDTweet_9595bkg4Objects2);
gdjs.copyArray(runtimeScene.getObjects("Tweet_bkg5"), gdjs.MainCode.GDTweet_9595bkg5Objects2);
gdjs.copyArray(runtimeScene.getObjects("Tweet_bkg6"), gdjs.MainCode.GDTweet_9595bkg6Objects2);
{for(var i = 0, len = gdjs.MainCode.GDTweet5Objects2.length ;i < len;++i) {
    gdjs.MainCode.GDTweet5Objects2[i].getBehavior("Text").setText(runtimeScene.getScene().getVariables().getFromIndex(12).getChild(gdjs.randomInRange(0, gdjs.evtTools.variable.getVariableChildCount(runtimeScene.getScene().getVariables().getFromIndex(12)) - 1)).getAsString());
}
}{for(var i = 0, len = gdjs.MainCode.GDTweet6Objects2.length ;i < len;++i) {
    gdjs.MainCode.GDTweet6Objects2[i].getBehavior("Text").setText(runtimeScene.getScene().getVariables().getFromIndex(25).getChild(gdjs.randomInRange(0, gdjs.evtTools.variable.getVariableChildCount(runtimeScene.getScene().getVariables().getFromIndex(25)) - 1)).getAsString());
}
}{for(var i = 0, len = gdjs.MainCode.GDTweet4Objects2.length ;i < len;++i) {
    gdjs.MainCode.GDTweet4Objects2[i].getBehavior("Text").setText(runtimeScene.getScene().getVariables().getFromIndex(2).getAsString());
}
}{for(var i = 0, len = gdjs.MainCode.GDTweet_9595bkg1Objects2.length ;i < len;++i) {
    gdjs.MainCode.GDTweet_9595bkg1Objects2[i].getBehavior("Tween").addObjectPositionTween2("Tween", (( gdjs.MainCode.GDTweetMarker2Objects2.length === 0 ) ? 0 :gdjs.MainCode.GDTweetMarker2Objects2[0].getPointX("")), (( gdjs.MainCode.GDTweetMarker2Objects2.length === 0 ) ? 0 :gdjs.MainCode.GDTweetMarker2Objects2[0].getPointY("")), "linear", 0.5, false);
}
}{for(var i = 0, len = gdjs.MainCode.GDTweet_9595bkg2Objects2.length ;i < len;++i) {
    gdjs.MainCode.GDTweet_9595bkg2Objects2[i].getBehavior("Tween").addObjectPositionTween2("Tween", (( gdjs.MainCode.GDTweetMarker3Objects2.length === 0 ) ? 0 :gdjs.MainCode.GDTweetMarker3Objects2[0].getPointX("")), (( gdjs.MainCode.GDTweetMarker3Objects2.length === 0 ) ? 0 :gdjs.MainCode.GDTweetMarker3Objects2[0].getPointY("")), "linear", 0.5, false);
}
}{for(var i = 0, len = gdjs.MainCode.GDTweet_9595bkg3Objects2.length ;i < len;++i) {
    gdjs.MainCode.GDTweet_9595bkg3Objects2[i].getBehavior("Tween").addObjectPositionTween2("Tween", (( gdjs.MainCode.GDTweetMarker4Objects2.length === 0 ) ? 0 :gdjs.MainCode.GDTweetMarker4Objects2[0].getPointX("")), (( gdjs.MainCode.GDTweetMarker4Objects2.length === 0 ) ? 0 :gdjs.MainCode.GDTweetMarker4Objects2[0].getPointY("")), "linear", 0.5, false);
}
}{for(var i = 0, len = gdjs.MainCode.GDTweet_9595bkg4Objects2.length ;i < len;++i) {
    gdjs.MainCode.GDTweet_9595bkg4Objects2[i].getBehavior("Tween").addObjectPositionTween2("Tween", (( gdjs.MainCode.GDTweetMarker5Objects2.length === 0 ) ? 0 :gdjs.MainCode.GDTweetMarker5Objects2[0].getPointX("")), (( gdjs.MainCode.GDTweetMarker5Objects2.length === 0 ) ? 0 :gdjs.MainCode.GDTweetMarker5Objects2[0].getPointY("")), "linear", 0.5, false);
}
}{for(var i = 0, len = gdjs.MainCode.GDTweet_9595bkg5Objects2.length ;i < len;++i) {
    gdjs.MainCode.GDTweet_9595bkg5Objects2[i].getBehavior("Tween").addObjectPositionTween2("Tween", (( gdjs.MainCode.GDTweetMarker6Objects2.length === 0 ) ? 0 :gdjs.MainCode.GDTweetMarker6Objects2[0].getPointX("")), (( gdjs.MainCode.GDTweetMarker6Objects2.length === 0 ) ? 0 :gdjs.MainCode.GDTweetMarker6Objects2[0].getPointY("")), "linear", 0.5, false);
}
}{for(var i = 0, len = gdjs.MainCode.GDTweet_9595bkg6Objects2.length ;i < len;++i) {
    gdjs.MainCode.GDTweet_9595bkg6Objects2[i].getBehavior("Tween").addObjectPositionTween2("Tween", (( gdjs.MainCode.GDTweetMarker7Objects2.length === 0 ) ? 0 :gdjs.MainCode.GDTweetMarker7Objects2[0].getPointX("")), (( gdjs.MainCode.GDTweetMarker7Objects2.length === 0 ) ? 0 :gdjs.MainCode.GDTweetMarker7Objects2[0].getPointY("")), "linear", 0.5, false);
}
}{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "assets\\Sounds\\Reaction appears.mp3", 2, false, 100, 1);
}
{ //Subevents
gdjs.MainCode.eventsList68(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(15).getAsNumber() < runtimeScene.getScene().getVariables().getFromIndex(18).getAsNumber());
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("FireText4"), gdjs.MainCode.GDFireText4Objects2);
gdjs.copyArray(runtimeScene.getObjects("TestText"), gdjs.MainCode.GDTestTextObjects2);
{for(var i = 0, len = gdjs.MainCode.GDTestTextObjects2.length ;i < len;++i) {
    gdjs.MainCode.GDTestTextObjects2[i].getBehavior("Text").setText("yes");
}
}{for(var i = 0, len = gdjs.MainCode.GDFireText4Objects2.length ;i < len;++i) {
    gdjs.MainCode.GDFireText4Objects2[i].getBehavior("Text").setText(gdjs.evtTools.common.toString(runtimeScene.getScene().getVariables().getFromIndex(15).getAsNumber()));
}
}{runtimeScene.getScene().getVariables().getFromIndex(15).add(1);
}{gdjs.evtTools.runtimeScene.removeTimer(runtimeScene, "FireReactionCountTimer");
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(16).getAsNumber() < runtimeScene.getScene().getVariables().getFromIndex(19).getAsNumber());
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("LikeText4"), gdjs.MainCode.GDLikeText4Objects2);
{for(var i = 0, len = gdjs.MainCode.GDLikeText4Objects2.length ;i < len;++i) {
    gdjs.MainCode.GDLikeText4Objects2[i].getBehavior("Text").setText(gdjs.evtTools.common.toString(runtimeScene.getScene().getVariables().getFromIndex(16).getAsNumber()));
}
}{runtimeScene.getScene().getVariables().getFromIndex(16).add(1);
}{runtimeScene.getScene().getVariables().getFromIndex(16).setNumber(runtimeScene.getScene().getVariables().getFromIndex(16).getAsNumber());
}{gdjs.evtTools.runtimeScene.removeTimer(runtimeScene, "LikeReactionCountTimer");
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(17).getAsNumber() < runtimeScene.getScene().getVariables().getFromIndex(20).getAsNumber());
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("HeartText4"), gdjs.MainCode.GDHeartText4Objects2);
{for(var i = 0, len = gdjs.MainCode.GDHeartText4Objects2.length ;i < len;++i) {
    gdjs.MainCode.GDHeartText4Objects2[i].getBehavior("Text").setText(gdjs.evtTools.common.toString(runtimeScene.getScene().getVariables().getFromIndex(17).getAsNumber()));
}
}{runtimeScene.getScene().getVariables().getFromIndex(17).add(1);
}{runtimeScene.getScene().getVariables().getFromIndex(17).setNumber(runtimeScene.getScene().getVariables().getFromIndex(16).getAsNumber());
}{gdjs.evtTools.runtimeScene.removeTimer(runtimeScene, "HeartReactionCountTimer");
}{runtimeScene.getScene().getVariables().getFromIndex(21).setBoolean(true);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getScene().getVariables().getFromIndex(22).getAsBoolean();
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("TweetMarker1"), gdjs.MainCode.GDTweetMarker1Objects2);
gdjs.copyArray(runtimeScene.getObjects("TweetMarker2"), gdjs.MainCode.GDTweetMarker2Objects2);
gdjs.copyArray(runtimeScene.getObjects("TweetMarker3"), gdjs.MainCode.GDTweetMarker3Objects2);
gdjs.copyArray(runtimeScene.getObjects("TweetMarker4"), gdjs.MainCode.GDTweetMarker4Objects2);
gdjs.copyArray(runtimeScene.getObjects("TweetMarker5"), gdjs.MainCode.GDTweetMarker5Objects2);
gdjs.copyArray(runtimeScene.getObjects("TweetMarker6"), gdjs.MainCode.GDTweetMarker6Objects2);
gdjs.copyArray(runtimeScene.getObjects("Tweet_bkg1"), gdjs.MainCode.GDTweet_9595bkg1Objects2);
gdjs.copyArray(runtimeScene.getObjects("Tweet_bkg2"), gdjs.MainCode.GDTweet_9595bkg2Objects2);
gdjs.copyArray(runtimeScene.getObjects("Tweet_bkg3"), gdjs.MainCode.GDTweet_9595bkg3Objects2);
gdjs.copyArray(runtimeScene.getObjects("Tweet_bkg4"), gdjs.MainCode.GDTweet_9595bkg4Objects2);
gdjs.copyArray(runtimeScene.getObjects("Tweet_bkg5"), gdjs.MainCode.GDTweet_9595bkg5Objects2);
gdjs.copyArray(runtimeScene.getObjects("Tweet_bkg6"), gdjs.MainCode.GDTweet_9595bkg6Objects2);
{for(var i = 0, len = gdjs.MainCode.GDTweet_9595bkg6Objects2.length ;i < len;++i) {
    gdjs.MainCode.GDTweet_9595bkg6Objects2[i].getBehavior("Tween").addObjectPositionTween2("Tween2", (( gdjs.MainCode.GDTweetMarker6Objects2.length === 0 ) ? 0 :gdjs.MainCode.GDTweetMarker6Objects2[0].getPointX("")), (( gdjs.MainCode.GDTweetMarker6Objects2.length === 0 ) ? 0 :gdjs.MainCode.GDTweetMarker6Objects2[0].getPointY("")), "linear", 0.5, false);
}
}{for(var i = 0, len = gdjs.MainCode.GDTweet_9595bkg5Objects2.length ;i < len;++i) {
    gdjs.MainCode.GDTweet_9595bkg5Objects2[i].getBehavior("Tween").addObjectPositionTween2("Tween2", (( gdjs.MainCode.GDTweetMarker5Objects2.length === 0 ) ? 0 :gdjs.MainCode.GDTweetMarker5Objects2[0].getPointX("")), (( gdjs.MainCode.GDTweetMarker5Objects2.length === 0 ) ? 0 :gdjs.MainCode.GDTweetMarker5Objects2[0].getPointY("")), "linear", 0.5, false);
}
}{for(var i = 0, len = gdjs.MainCode.GDTweet_9595bkg4Objects2.length ;i < len;++i) {
    gdjs.MainCode.GDTweet_9595bkg4Objects2[i].getBehavior("Tween").addObjectPositionTween2("Tween2", (( gdjs.MainCode.GDTweetMarker4Objects2.length === 0 ) ? 0 :gdjs.MainCode.GDTweetMarker4Objects2[0].getPointX("")), (( gdjs.MainCode.GDTweetMarker4Objects2.length === 0 ) ? 0 :gdjs.MainCode.GDTweetMarker4Objects2[0].getPointY("")), "linear", 0.5, false);
}
}{for(var i = 0, len = gdjs.MainCode.GDTweet_9595bkg3Objects2.length ;i < len;++i) {
    gdjs.MainCode.GDTweet_9595bkg3Objects2[i].getBehavior("Tween").addObjectPositionTween2("Tween2", (( gdjs.MainCode.GDTweetMarker3Objects2.length === 0 ) ? 0 :gdjs.MainCode.GDTweetMarker3Objects2[0].getPointX("")), (( gdjs.MainCode.GDTweetMarker3Objects2.length === 0 ) ? 0 :gdjs.MainCode.GDTweetMarker3Objects2[0].getPointY("")), "linear", 0.5, false);
}
}{for(var i = 0, len = gdjs.MainCode.GDTweet_9595bkg2Objects2.length ;i < len;++i) {
    gdjs.MainCode.GDTweet_9595bkg2Objects2[i].getBehavior("Tween").addObjectPositionTween2("Tween2", (( gdjs.MainCode.GDTweetMarker2Objects2.length === 0 ) ? 0 :gdjs.MainCode.GDTweetMarker2Objects2[0].getPointX("")), (( gdjs.MainCode.GDTweetMarker2Objects2.length === 0 ) ? 0 :gdjs.MainCode.GDTweetMarker2Objects2[0].getPointY("")), "linear", 0.5, false);
}
}{for(var i = 0, len = gdjs.MainCode.GDTweet_9595bkg1Objects2.length ;i < len;++i) {
    gdjs.MainCode.GDTweet_9595bkg1Objects2[i].getBehavior("Tween").addObjectPositionTween2("Tween2", (( gdjs.MainCode.GDTweetMarker1Objects2.length === 0 ) ? 0 :gdjs.MainCode.GDTweetMarker1Objects2[0].getPointX("")), (( gdjs.MainCode.GDTweetMarker1Objects2.length === 0 ) ? 0 :gdjs.MainCode.GDTweetMarker1Objects2[0].getPointY("")), "linear", 0.5, false);
}
}{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "assets\\Sounds\\Reaction appears.mp3", 2, false, 100, 1);
}{runtimeScene.getScene().getVariables().getFromIndex(22).setBoolean(false);
}
{ //Subevents
gdjs.MainCode.eventsList69(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getScene().getVariables().getFromIndex(23).getAsBoolean();
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15434604);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("TweetMarker1"), gdjs.MainCode.GDTweetMarker1Objects1);
gdjs.copyArray(runtimeScene.getObjects("TweetMarker2"), gdjs.MainCode.GDTweetMarker2Objects1);
gdjs.copyArray(runtimeScene.getObjects("TweetMarker3"), gdjs.MainCode.GDTweetMarker3Objects1);
gdjs.copyArray(runtimeScene.getObjects("TweetMarker4"), gdjs.MainCode.GDTweetMarker4Objects1);
gdjs.copyArray(runtimeScene.getObjects("TweetMarker5"), gdjs.MainCode.GDTweetMarker5Objects1);
gdjs.copyArray(runtimeScene.getObjects("Tweet_bkg1"), gdjs.MainCode.GDTweet_9595bkg1Objects1);
gdjs.copyArray(runtimeScene.getObjects("Tweet_bkg2"), gdjs.MainCode.GDTweet_9595bkg2Objects1);
gdjs.copyArray(runtimeScene.getObjects("Tweet_bkg3"), gdjs.MainCode.GDTweet_9595bkg3Objects1);
gdjs.copyArray(runtimeScene.getObjects("Tweet_bkg4"), gdjs.MainCode.GDTweet_9595bkg4Objects1);
gdjs.copyArray(runtimeScene.getObjects("Tweet_bkg5"), gdjs.MainCode.GDTweet_9595bkg5Objects1);
gdjs.copyArray(runtimeScene.getObjects("Tweet_bkg6"), gdjs.MainCode.GDTweet_9595bkg6Objects1);
{for(var i = 0, len = gdjs.MainCode.GDTweet_9595bkg6Objects1.length ;i < len;++i) {
    gdjs.MainCode.GDTweet_9595bkg6Objects1[i].getBehavior("Tween").addObjectPositionTween2("Tween2", (( gdjs.MainCode.GDTweetMarker5Objects1.length === 0 ) ? 0 :gdjs.MainCode.GDTweetMarker5Objects1[0].getPointX("")), (( gdjs.MainCode.GDTweetMarker5Objects1.length === 0 ) ? 0 :gdjs.MainCode.GDTweetMarker5Objects1[0].getPointY("")), "linear", 0.5, false);
}
}{for(var i = 0, len = gdjs.MainCode.GDTweet_9595bkg5Objects1.length ;i < len;++i) {
    gdjs.MainCode.GDTweet_9595bkg5Objects1[i].getBehavior("Tween").addObjectPositionTween2("Tween2", (( gdjs.MainCode.GDTweetMarker4Objects1.length === 0 ) ? 0 :gdjs.MainCode.GDTweetMarker4Objects1[0].getPointX("")), (( gdjs.MainCode.GDTweetMarker4Objects1.length === 0 ) ? 0 :gdjs.MainCode.GDTweetMarker4Objects1[0].getPointY("")), "linear", 0.5, false);
}
}{for(var i = 0, len = gdjs.MainCode.GDTweet_9595bkg4Objects1.length ;i < len;++i) {
    gdjs.MainCode.GDTweet_9595bkg4Objects1[i].getBehavior("Tween").addObjectPositionTween2("Tween2", (( gdjs.MainCode.GDTweetMarker3Objects1.length === 0 ) ? 0 :gdjs.MainCode.GDTweetMarker3Objects1[0].getPointX("")), (( gdjs.MainCode.GDTweetMarker3Objects1.length === 0 ) ? 0 :gdjs.MainCode.GDTweetMarker3Objects1[0].getPointY("")), "linear", 0.5, false);
}
}{for(var i = 0, len = gdjs.MainCode.GDTweet_9595bkg3Objects1.length ;i < len;++i) {
    gdjs.MainCode.GDTweet_9595bkg3Objects1[i].getBehavior("Tween").addObjectPositionTween2("Tween2", (( gdjs.MainCode.GDTweetMarker2Objects1.length === 0 ) ? 0 :gdjs.MainCode.GDTweetMarker2Objects1[0].getPointX("")), (( gdjs.MainCode.GDTweetMarker2Objects1.length === 0 ) ? 0 :gdjs.MainCode.GDTweetMarker2Objects1[0].getPointY("")), "linear", 0.5, false);
}
}{for(var i = 0, len = gdjs.MainCode.GDTweet_9595bkg2Objects1.length ;i < len;++i) {
    gdjs.MainCode.GDTweet_9595bkg2Objects1[i].getBehavior("Tween").addObjectPositionTween2("Tween2", (( gdjs.MainCode.GDTweetMarker1Objects1.length === 0 ) ? 0 :gdjs.MainCode.GDTweetMarker1Objects1[0].getPointX("")), (( gdjs.MainCode.GDTweetMarker1Objects1.length === 0 ) ? 0 :gdjs.MainCode.GDTweetMarker1Objects1[0].getPointY("")), "linear", 0.5, false);
}
}{for(var i = 0, len = gdjs.MainCode.GDTweet_9595bkg1Objects1.length ;i < len;++i) {
    gdjs.MainCode.GDTweet_9595bkg1Objects1[i].getBehavior("Tween").addObjectPositionTween2("Tween2", (( gdjs.MainCode.GDTweetMarker1Objects1.length === 0 ) ? 0 :gdjs.MainCode.GDTweetMarker1Objects1[0].getPointX("")), (( gdjs.MainCode.GDTweetMarker1Objects1.length === 0 ) ? 0 :gdjs.MainCode.GDTweetMarker1Objects1[0].getPointY("")), "linear", 0.5, false);
}
}{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "assets\\Sounds\\Reaction appears.mp3", 2, false, 100, 1);
}
{ //Subevents
gdjs.MainCode.eventsList70(runtimeScene);} //End of subevents
}

}


};gdjs.MainCode.eventsList72 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(7).getAsString() == "REACTION");
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.MainCode.eventsList71(runtimeScene);} //End of subevents
}

}


};gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDPAResultObjects5Objects = Hashtable.newFrom({"PAResult": gdjs.MainCode.GDPAResultObjects5});
gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDRiskResultObjects6Objects = Hashtable.newFrom({"RiskResult": gdjs.MainCode.GDRiskResultObjects6});
gdjs.MainCode.eventsList73 = function(runtimeScene, asyncObjectsList) {

{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15638252);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("ScandalRiskTxt"), gdjs.MainCode.GDScandalRiskTxtObjects6);
gdjs.MainCode.GDRiskResultObjects6.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDRiskResultObjects6Objects, (( gdjs.MainCode.GDScandalRiskTxtObjects6.length === 0 ) ? 0 :gdjs.MainCode.GDScandalRiskTxtObjects6[0].getX()), (( gdjs.MainCode.GDScandalRiskTxtObjects6.length === 0 ) ? 0 :gdjs.MainCode.GDScandalRiskTxtObjects6[0].getY()), "");
}{for(var i = 0, len = gdjs.MainCode.GDRiskResultObjects6.length ;i < len;++i) {
    gdjs.MainCode.GDRiskResultObjects6[i].getBehavior("Text").setText("-1");
}
}{for(var i = 0, len = gdjs.MainCode.GDRiskResultObjects6.length ;i < len;++i) {
    gdjs.MainCode.GDRiskResultObjects6[i].setColor("65;117;5");
}
}{for(var i = 0, len = gdjs.MainCode.GDRiskResultObjects6.length ;i < len;++i) {
    gdjs.MainCode.GDRiskResultObjects6[i].addPolarForce(180, 50, 1);
}
}{for(var i = 0, len = gdjs.MainCode.GDRiskResultObjects6.length ;i < len;++i) {
    gdjs.MainCode.GDRiskResultObjects6[i].getBehavior("Tween").addObjectOpacityTween2("Opacity", 0, "linear", 2, true);
}
}{runtimeScene.getScene().getVariables().getFromIndex(5).sub(1);
}{gdjs.evtTools.sound.playSound(runtimeScene, "assets\\Sounds\\Yay.mp3", false, 100, 1);
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("NextText"), gdjs.MainCode.GDNextTextObjects5);
gdjs.copyArray(asyncObjectsList.getObjects("Next_button"), gdjs.MainCode.GDNext_9595buttonObjects5);

{for(var i = 0, len = gdjs.MainCode.GDNext_9595buttonObjects5.length ;i < len;++i) {
    gdjs.MainCode.GDNext_9595buttonObjects5[i].hide(false);
}
for(var i = 0, len = gdjs.MainCode.GDNextTextObjects5.length ;i < len;++i) {
    gdjs.MainCode.GDNextTextObjects5[i].hide(false);
}
}}

}


};gdjs.MainCode.asyncCallback15196836 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.MainCode.localVariables);

{ //Subevents
gdjs.MainCode.eventsList73(runtimeScene, asyncObjectsList);} //End of subevents
gdjs.MainCode.localVariables.length = 0;
}
gdjs.MainCode.eventsList74 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
asyncObjectsList.backupLocalVariablesContainers(gdjs.MainCode.localVariables);
/* Don't save Next_button as it will be provided by the parent asyncObjectsList. */
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1), (runtimeScene) => (gdjs.MainCode.asyncCallback15196836(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.MainCode.eventsList75 = function(runtimeScene, asyncObjectsList) {

{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15636260);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("PublicApprovalTxt"), gdjs.MainCode.GDPublicApprovalTxtObjects5);
gdjs.MainCode.GDPAResultObjects5.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDPAResultObjects5Objects, (( gdjs.MainCode.GDPublicApprovalTxtObjects5.length === 0 ) ? 0 :gdjs.MainCode.GDPublicApprovalTxtObjects5[0].getX()), (( gdjs.MainCode.GDPublicApprovalTxtObjects5.length === 0 ) ? 0 :gdjs.MainCode.GDPublicApprovalTxtObjects5[0].getY()), "");
}{for(var i = 0, len = gdjs.MainCode.GDPAResultObjects5.length ;i < len;++i) {
    gdjs.MainCode.GDPAResultObjects5[i].getBehavior("Text").setText("+2");
}
}{for(var i = 0, len = gdjs.MainCode.GDPAResultObjects5.length ;i < len;++i) {
    gdjs.MainCode.GDPAResultObjects5[i].setColor("65;117;5");
}
}{for(var i = 0, len = gdjs.MainCode.GDPAResultObjects5.length ;i < len;++i) {
    gdjs.MainCode.GDPAResultObjects5[i].addPolarForce(180, 50, 1);
}
}{for(var i = 0, len = gdjs.MainCode.GDPAResultObjects5.length ;i < len;++i) {
    gdjs.MainCode.GDPAResultObjects5[i].getBehavior("Tween").addObjectOpacityTween2("Opacity", 0, "linear", 2, true);
}
}{runtimeScene.getScene().getVariables().getFromIndex(4).add(2);
}{gdjs.evtTools.sound.playSound(runtimeScene, "assets\\Sounds\\Yay.mp3", false, 100, 1);
}}

}


{


let isConditionTrue_0 = false;
{

{ //Subevents
gdjs.MainCode.eventsList74(runtimeScene, asyncObjectsList);} //End of subevents
}

}


};gdjs.MainCode.asyncCallback15196164 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.MainCode.localVariables);

{ //Subevents
gdjs.MainCode.eventsList75(runtimeScene, asyncObjectsList);} //End of subevents
gdjs.MainCode.localVariables.length = 0;
}
gdjs.MainCode.eventsList76 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
asyncObjectsList.backupLocalVariablesContainers(gdjs.MainCode.localVariables);
for (const obj of gdjs.MainCode.GDNext_9595buttonObjects2) asyncObjectsList.addObject("Next_button", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1), (runtimeScene) => (gdjs.MainCode.asyncCallback15196164(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.MainCode.eventsList77 = function(runtimeScene, asyncObjectsList) {

{


let isConditionTrue_0 = false;
{

{ //Subevents
gdjs.MainCode.eventsList76(runtimeScene, asyncObjectsList);} //End of subevents
}

}


};gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDEconomyResultObjects5Objects = Hashtable.newFrom({"EconomyResult": gdjs.MainCode.GDEconomyResultObjects5});
gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDPAResultObjects6Objects = Hashtable.newFrom({"PAResult": gdjs.MainCode.GDPAResultObjects6});
gdjs.MainCode.eventsList78 = function(runtimeScene, asyncObjectsList) {

{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15632276);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("PublicApprovalTxt"), gdjs.MainCode.GDPublicApprovalTxtObjects6);
gdjs.MainCode.GDPAResultObjects6.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDPAResultObjects6Objects, (( gdjs.MainCode.GDPublicApprovalTxtObjects6.length === 0 ) ? 0 :gdjs.MainCode.GDPublicApprovalTxtObjects6[0].getX()), (( gdjs.MainCode.GDPublicApprovalTxtObjects6.length === 0 ) ? 0 :gdjs.MainCode.GDPublicApprovalTxtObjects6[0].getY()), "");
}{for(var i = 0, len = gdjs.MainCode.GDPAResultObjects6.length ;i < len;++i) {
    gdjs.MainCode.GDPAResultObjects6[i].getBehavior("Text").setText("-1");
}
}{for(var i = 0, len = gdjs.MainCode.GDPAResultObjects6.length ;i < len;++i) {
    gdjs.MainCode.GDPAResultObjects6[i].setColor("208;2;27");
}
}{for(var i = 0, len = gdjs.MainCode.GDPAResultObjects6.length ;i < len;++i) {
    gdjs.MainCode.GDPAResultObjects6[i].addPolarForce(180, 50, 1);
}
}{for(var i = 0, len = gdjs.MainCode.GDPAResultObjects6.length ;i < len;++i) {
    gdjs.MainCode.GDPAResultObjects6[i].getBehavior("Tween").addObjectOpacityTween2("Opacity", 0, "linear", 2, true);
}
}{runtimeScene.getScene().getVariables().getFromIndex(4).sub(1);
}{gdjs.evtTools.sound.playSound(runtimeScene, "assets\\Sounds\\Shocked.mp3", false, 100, 1);
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("NextText"), gdjs.MainCode.GDNextTextObjects5);
gdjs.copyArray(asyncObjectsList.getObjects("Next_button"), gdjs.MainCode.GDNext_9595buttonObjects5);

{for(var i = 0, len = gdjs.MainCode.GDNext_9595buttonObjects5.length ;i < len;++i) {
    gdjs.MainCode.GDNext_9595buttonObjects5[i].hide(false);
}
for(var i = 0, len = gdjs.MainCode.GDNextTextObjects5.length ;i < len;++i) {
    gdjs.MainCode.GDNextTextObjects5[i].hide(false);
}
}}

}


};gdjs.MainCode.asyncCallback15199260 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.MainCode.localVariables);

{ //Subevents
gdjs.MainCode.eventsList78(runtimeScene, asyncObjectsList);} //End of subevents
gdjs.MainCode.localVariables.length = 0;
}
gdjs.MainCode.eventsList79 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
asyncObjectsList.backupLocalVariablesContainers(gdjs.MainCode.localVariables);
/* Don't save Next_button as it will be provided by the parent asyncObjectsList. */
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1), (runtimeScene) => (gdjs.MainCode.asyncCallback15199260(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.MainCode.eventsList80 = function(runtimeScene, asyncObjectsList) {

{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15626604);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("EconomyTxt"), gdjs.MainCode.GDEconomyTxtObjects5);
gdjs.MainCode.GDEconomyResultObjects5.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDEconomyResultObjects5Objects, (( gdjs.MainCode.GDEconomyTxtObjects5.length === 0 ) ? 0 :gdjs.MainCode.GDEconomyTxtObjects5[0].getX()), (( gdjs.MainCode.GDEconomyTxtObjects5.length === 0 ) ? 0 :gdjs.MainCode.GDEconomyTxtObjects5[0].getY()), "");
}{for(var i = 0, len = gdjs.MainCode.GDEconomyResultObjects5.length ;i < len;++i) {
    gdjs.MainCode.GDEconomyResultObjects5[i].getBehavior("Text").setText("+1");
}
}{for(var i = 0, len = gdjs.MainCode.GDEconomyResultObjects5.length ;i < len;++i) {
    gdjs.MainCode.GDEconomyResultObjects5[i].getBehavior("Tween").addObjectOpacityTween2("Opacity", 0, "linear", 2, true);
}
}{for(var i = 0, len = gdjs.MainCode.GDEconomyResultObjects5.length ;i < len;++i) {
    gdjs.MainCode.GDEconomyResultObjects5[i].setColor("65;117;5");
}
}{for(var i = 0, len = gdjs.MainCode.GDEconomyResultObjects5.length ;i < len;++i) {
    gdjs.MainCode.GDEconomyResultObjects5[i].addPolarForce(180, 50, 1);
}
}{runtimeScene.getScene().getVariables().getFromIndex(3).add(1);
}{gdjs.evtTools.sound.playSound(runtimeScene, "assets\\Sounds\\Yay.mp3", false, 100, 1);
}}

}


{


let isConditionTrue_0 = false;
{

{ //Subevents
gdjs.MainCode.eventsList79(runtimeScene, asyncObjectsList);} //End of subevents
}

}


};gdjs.MainCode.asyncCallback15198588 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.MainCode.localVariables);

{ //Subevents
gdjs.MainCode.eventsList80(runtimeScene, asyncObjectsList);} //End of subevents
gdjs.MainCode.localVariables.length = 0;
}
gdjs.MainCode.eventsList81 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
asyncObjectsList.backupLocalVariablesContainers(gdjs.MainCode.localVariables);
for (const obj of gdjs.MainCode.GDNext_9595buttonObjects2) asyncObjectsList.addObject("Next_button", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1), (runtimeScene) => (gdjs.MainCode.asyncCallback15198588(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.MainCode.eventsList82 = function(runtimeScene, asyncObjectsList) {

{


let isConditionTrue_0 = false;
{

{ //Subevents
gdjs.MainCode.eventsList81(runtimeScene, asyncObjectsList);} //End of subevents
}

}


};gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDEconomyResultObjects5Objects = Hashtable.newFrom({"EconomyResult": gdjs.MainCode.GDEconomyResultObjects5});
gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDRiskResultObjects6Objects = Hashtable.newFrom({"RiskResult": gdjs.MainCode.GDRiskResultObjects6});
gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDPersonalWealthResultObjects7Objects = Hashtable.newFrom({"PersonalWealthResult": gdjs.MainCode.GDPersonalWealthResultObjects7});
gdjs.MainCode.eventsList83 = function(runtimeScene, asyncObjectsList) {

{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15648572);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("PersonalGainsTxt"), gdjs.MainCode.GDPersonalGainsTxtObjects7);
gdjs.MainCode.GDPersonalWealthResultObjects7.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDPersonalWealthResultObjects7Objects, (( gdjs.MainCode.GDPersonalGainsTxtObjects7.length === 0 ) ? 0 :gdjs.MainCode.GDPersonalGainsTxtObjects7[0].getX()), (( gdjs.MainCode.GDPersonalGainsTxtObjects7.length === 0 ) ? 0 :gdjs.MainCode.GDPersonalGainsTxtObjects7[0].getY()), "");
}{for(var i = 0, len = gdjs.MainCode.GDPersonalWealthResultObjects7.length ;i < len;++i) {
    gdjs.MainCode.GDPersonalWealthResultObjects7[i].getBehavior("Text").setText("+1");
}
}{for(var i = 0, len = gdjs.MainCode.GDPersonalWealthResultObjects7.length ;i < len;++i) {
    gdjs.MainCode.GDPersonalWealthResultObjects7[i].setColor("65;117;5");
}
}{for(var i = 0, len = gdjs.MainCode.GDPersonalWealthResultObjects7.length ;i < len;++i) {
    gdjs.MainCode.GDPersonalWealthResultObjects7[i].addPolarForce(180, 50, 1);
}
}{for(var i = 0, len = gdjs.MainCode.GDPersonalWealthResultObjects7.length ;i < len;++i) {
    gdjs.MainCode.GDPersonalWealthResultObjects7[i].getBehavior("Tween").addObjectOpacityTween2("Opacity", 0, "linear", 2, true);
}
}{runtimeScene.getScene().getVariables().getFromIndex(6).add(1);
}{gdjs.evtTools.sound.playSound(runtimeScene, "assets\\Sounds\\Yay.mp3", false, 100, 1);
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("NextText"), gdjs.MainCode.GDNextTextObjects6);
gdjs.copyArray(asyncObjectsList.getObjects("Next_button"), gdjs.MainCode.GDNext_9595buttonObjects6);

{for(var i = 0, len = gdjs.MainCode.GDNext_9595buttonObjects6.length ;i < len;++i) {
    gdjs.MainCode.GDNext_9595buttonObjects6[i].hide(false);
}
for(var i = 0, len = gdjs.MainCode.GDNextTextObjects6.length ;i < len;++i) {
    gdjs.MainCode.GDNextTextObjects6[i].hide(false);
}
}}

}


};gdjs.MainCode.asyncCallback15202388 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.MainCode.localVariables);

{ //Subevents
gdjs.MainCode.eventsList83(runtimeScene, asyncObjectsList);} //End of subevents
gdjs.MainCode.localVariables.length = 0;
}
gdjs.MainCode.eventsList84 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
asyncObjectsList.backupLocalVariablesContainers(gdjs.MainCode.localVariables);
/* Don't save Next_button as it will be provided by the parent asyncObjectsList. */
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1), (runtimeScene) => (gdjs.MainCode.asyncCallback15202388(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.MainCode.eventsList85 = function(runtimeScene, asyncObjectsList) {

{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15641596);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("ScandalRiskTxt"), gdjs.MainCode.GDScandalRiskTxtObjects6);
gdjs.MainCode.GDRiskResultObjects6.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDRiskResultObjects6Objects, (( gdjs.MainCode.GDScandalRiskTxtObjects6.length === 0 ) ? 0 :gdjs.MainCode.GDScandalRiskTxtObjects6[0].getX()), (( gdjs.MainCode.GDScandalRiskTxtObjects6.length === 0 ) ? 0 :gdjs.MainCode.GDScandalRiskTxtObjects6[0].getY()), "");
}{for(var i = 0, len = gdjs.MainCode.GDRiskResultObjects6.length ;i < len;++i) {
    gdjs.MainCode.GDRiskResultObjects6[i].getBehavior("Text").setText("+2");
}
}{for(var i = 0, len = gdjs.MainCode.GDRiskResultObjects6.length ;i < len;++i) {
    gdjs.MainCode.GDRiskResultObjects6[i].setColor("208;2;27");
}
}{for(var i = 0, len = gdjs.MainCode.GDRiskResultObjects6.length ;i < len;++i) {
    gdjs.MainCode.GDRiskResultObjects6[i].addPolarForce(180, 50, 1);
}
}{for(var i = 0, len = gdjs.MainCode.GDRiskResultObjects6.length ;i < len;++i) {
    gdjs.MainCode.GDRiskResultObjects6[i].getBehavior("Tween").addObjectOpacityTween2("Opacity", 0, "linear", 2, true);
}
}{runtimeScene.getScene().getVariables().getFromIndex(5).add(2);
}{gdjs.evtTools.sound.playSound(runtimeScene, "assets\\Sounds\\Shocked.mp3", false, 100, 1);
}}

}


{


let isConditionTrue_0 = false;
{

{ //Subevents
gdjs.MainCode.eventsList84(runtimeScene, asyncObjectsList);} //End of subevents
}

}


};gdjs.MainCode.asyncCallback15201716 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.MainCode.localVariables);

{ //Subevents
gdjs.MainCode.eventsList85(runtimeScene, asyncObjectsList);} //End of subevents
gdjs.MainCode.localVariables.length = 0;
}
gdjs.MainCode.eventsList86 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
asyncObjectsList.backupLocalVariablesContainers(gdjs.MainCode.localVariables);
/* Don't save Next_button as it will be provided by the parent asyncObjectsList. */
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1), (runtimeScene) => (gdjs.MainCode.asyncCallback15201716(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.MainCode.eventsList87 = function(runtimeScene, asyncObjectsList) {

{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15628468);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("EconomyTxt"), gdjs.MainCode.GDEconomyTxtObjects5);
gdjs.MainCode.GDEconomyResultObjects5.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDEconomyResultObjects5Objects, (( gdjs.MainCode.GDEconomyTxtObjects5.length === 0 ) ? 0 :gdjs.MainCode.GDEconomyTxtObjects5[0].getX()), (( gdjs.MainCode.GDEconomyTxtObjects5.length === 0 ) ? 0 :gdjs.MainCode.GDEconomyTxtObjects5[0].getY()), "");
}{for(var i = 0, len = gdjs.MainCode.GDEconomyResultObjects5.length ;i < len;++i) {
    gdjs.MainCode.GDEconomyResultObjects5[i].getBehavior("Text").setText("-1");
}
}{for(var i = 0, len = gdjs.MainCode.GDEconomyResultObjects5.length ;i < len;++i) {
    gdjs.MainCode.GDEconomyResultObjects5[i].getBehavior("Tween").addObjectOpacityTween2("Opacity", 0, "linear", 2, true);
}
}{for(var i = 0, len = gdjs.MainCode.GDEconomyResultObjects5.length ;i < len;++i) {
    gdjs.MainCode.GDEconomyResultObjects5[i].setColor("208;2;27");
}
}{for(var i = 0, len = gdjs.MainCode.GDEconomyResultObjects5.length ;i < len;++i) {
    gdjs.MainCode.GDEconomyResultObjects5[i].addPolarForce(180, 50, 1);
}
}{runtimeScene.getScene().getVariables().getFromIndex(3).sub(1);
}{gdjs.evtTools.sound.playSound(runtimeScene, "assets\\Sounds\\Shocked.mp3", false, 100, 1);
}}

}


{


let isConditionTrue_0 = false;
{

{ //Subevents
gdjs.MainCode.eventsList86(runtimeScene, asyncObjectsList);} //End of subevents
}

}


};gdjs.MainCode.asyncCallback15200700 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.MainCode.localVariables);

{ //Subevents
gdjs.MainCode.eventsList87(runtimeScene, asyncObjectsList);} //End of subevents
gdjs.MainCode.localVariables.length = 0;
}
gdjs.MainCode.eventsList88 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
asyncObjectsList.backupLocalVariablesContainers(gdjs.MainCode.localVariables);
for (const obj of gdjs.MainCode.GDNext_9595buttonObjects2) asyncObjectsList.addObject("Next_button", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1), (runtimeScene) => (gdjs.MainCode.asyncCallback15200700(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.MainCode.eventsList89 = function(runtimeScene, asyncObjectsList) {

{


let isConditionTrue_0 = false;
{

{ //Subevents
gdjs.MainCode.eventsList88(runtimeScene, asyncObjectsList);} //End of subevents
}

}


};gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDEconomyResultObjects5Objects = Hashtable.newFrom({"EconomyResult": gdjs.MainCode.GDEconomyResultObjects5});
gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDPAResultObjects6Objects = Hashtable.newFrom({"PAResult": gdjs.MainCode.GDPAResultObjects6});
gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDPersonalWealthResultObjects6Objects = Hashtable.newFrom({"PersonalWealthResult": gdjs.MainCode.GDPersonalWealthResultObjects6});
gdjs.MainCode.eventsList90 = function(runtimeScene, asyncObjectsList) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("NextText"), gdjs.MainCode.GDNextTextObjects7);
gdjs.copyArray(asyncObjectsList.getObjects("Next_button"), gdjs.MainCode.GDNext_9595buttonObjects7);

{for(var i = 0, len = gdjs.MainCode.GDNext_9595buttonObjects7.length ;i < len;++i) {
    gdjs.MainCode.GDNext_9595buttonObjects7[i].hide(false);
}
for(var i = 0, len = gdjs.MainCode.GDNextTextObjects7.length ;i < len;++i) {
    gdjs.MainCode.GDNextTextObjects7[i].hide(false);
}
}}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15644084);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("PersonalGainsTxt"), gdjs.MainCode.GDPersonalGainsTxtObjects6);
gdjs.MainCode.GDPersonalWealthResultObjects6.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDPersonalWealthResultObjects6Objects, (( gdjs.MainCode.GDPersonalGainsTxtObjects6.length === 0 ) ? 0 :gdjs.MainCode.GDPersonalGainsTxtObjects6[0].getX()), (( gdjs.MainCode.GDPersonalGainsTxtObjects6.length === 0 ) ? 0 :gdjs.MainCode.GDPersonalGainsTxtObjects6[0].getY()), "");
}{for(var i = 0, len = gdjs.MainCode.GDPersonalWealthResultObjects6.length ;i < len;++i) {
    gdjs.MainCode.GDPersonalWealthResultObjects6[i].getBehavior("Text").setText("-1");
}
}{for(var i = 0, len = gdjs.MainCode.GDPersonalWealthResultObjects6.length ;i < len;++i) {
    gdjs.MainCode.GDPersonalWealthResultObjects6[i].setColor("208;2;27");
}
}{for(var i = 0, len = gdjs.MainCode.GDPersonalWealthResultObjects6.length ;i < len;++i) {
    gdjs.MainCode.GDPersonalWealthResultObjects6[i].addPolarForce(180, 50, 1);
}
}{for(var i = 0, len = gdjs.MainCode.GDPersonalWealthResultObjects6.length ;i < len;++i) {
    gdjs.MainCode.GDPersonalWealthResultObjects6[i].getBehavior("Tween").addObjectOpacityTween2("Opacity", 0, "linear", 2, true);
}
}{runtimeScene.getScene().getVariables().getFromIndex(6).sub(1);
}{gdjs.evtTools.sound.playSound(runtimeScene, "assets\\Sounds\\Shocked.mp3", false, 100, 1);
}}

}


};gdjs.MainCode.asyncCallback15205516 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.MainCode.localVariables);

{ //Subevents
gdjs.MainCode.eventsList90(runtimeScene, asyncObjectsList);} //End of subevents
gdjs.MainCode.localVariables.length = 0;
}
gdjs.MainCode.eventsList91 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
asyncObjectsList.backupLocalVariablesContainers(gdjs.MainCode.localVariables);
/* Don't save Next_button as it will be provided by the parent asyncObjectsList. */
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1), (runtimeScene) => (gdjs.MainCode.asyncCallback15205516(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.MainCode.eventsList92 = function(runtimeScene, asyncObjectsList) {

{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15634268);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("PublicApprovalTxt"), gdjs.MainCode.GDPublicApprovalTxtObjects6);
gdjs.MainCode.GDPAResultObjects6.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDPAResultObjects6Objects, (( gdjs.MainCode.GDPublicApprovalTxtObjects6.length === 0 ) ? 0 :gdjs.MainCode.GDPublicApprovalTxtObjects6[0].getX()), (( gdjs.MainCode.GDPublicApprovalTxtObjects6.length === 0 ) ? 0 :gdjs.MainCode.GDPublicApprovalTxtObjects6[0].getY()), "");
}{for(var i = 0, len = gdjs.MainCode.GDPAResultObjects6.length ;i < len;++i) {
    gdjs.MainCode.GDPAResultObjects6[i].getBehavior("Text").setText("+1");
}
}{for(var i = 0, len = gdjs.MainCode.GDPAResultObjects6.length ;i < len;++i) {
    gdjs.MainCode.GDPAResultObjects6[i].setColor("65;117;5");
}
}{for(var i = 0, len = gdjs.MainCode.GDPAResultObjects6.length ;i < len;++i) {
    gdjs.MainCode.GDPAResultObjects6[i].addPolarForce(180, 50, 1);
}
}{for(var i = 0, len = gdjs.MainCode.GDPAResultObjects6.length ;i < len;++i) {
    gdjs.MainCode.GDPAResultObjects6[i].getBehavior("Tween").addObjectOpacityTween2("Opacity", 0, "linear", 2, true);
}
}{runtimeScene.getScene().getVariables().getFromIndex(4).add(1);
}{gdjs.evtTools.sound.playSound(runtimeScene, "assets\\Sounds\\Yay.mp3", false, 100, 1);
}}

}


{


let isConditionTrue_0 = false;
{

{ //Subevents
gdjs.MainCode.eventsList91(runtimeScene, asyncObjectsList);} //End of subevents
}

}


};gdjs.MainCode.asyncCallback15204844 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.MainCode.localVariables);

{ //Subevents
gdjs.MainCode.eventsList92(runtimeScene, asyncObjectsList);} //End of subevents
gdjs.MainCode.localVariables.length = 0;
}
gdjs.MainCode.eventsList93 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
asyncObjectsList.backupLocalVariablesContainers(gdjs.MainCode.localVariables);
/* Don't save Next_button as it will be provided by the parent asyncObjectsList. */
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1), (runtimeScene) => (gdjs.MainCode.asyncCallback15204844(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.MainCode.eventsList94 = function(runtimeScene, asyncObjectsList) {

{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15626605);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("EconomyTxt"), gdjs.MainCode.GDEconomyTxtObjects5);
gdjs.MainCode.GDEconomyResultObjects5.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDEconomyResultObjects5Objects, (( gdjs.MainCode.GDEconomyTxtObjects5.length === 0 ) ? 0 :gdjs.MainCode.GDEconomyTxtObjects5[0].getX()), (( gdjs.MainCode.GDEconomyTxtObjects5.length === 0 ) ? 0 :gdjs.MainCode.GDEconomyTxtObjects5[0].getY()), "");
}{for(var i = 0, len = gdjs.MainCode.GDEconomyResultObjects5.length ;i < len;++i) {
    gdjs.MainCode.GDEconomyResultObjects5[i].getBehavior("Text").setText("+1");
}
}{for(var i = 0, len = gdjs.MainCode.GDEconomyResultObjects5.length ;i < len;++i) {
    gdjs.MainCode.GDEconomyResultObjects5[i].getBehavior("Tween").addObjectOpacityTween2("Opacity", 0, "linear", 2, true);
}
}{for(var i = 0, len = gdjs.MainCode.GDEconomyResultObjects5.length ;i < len;++i) {
    gdjs.MainCode.GDEconomyResultObjects5[i].setColor("65;117;5");
}
}{for(var i = 0, len = gdjs.MainCode.GDEconomyResultObjects5.length ;i < len;++i) {
    gdjs.MainCode.GDEconomyResultObjects5[i].addPolarForce(180, 50, 1);
}
}{runtimeScene.getScene().getVariables().getFromIndex(3).add(1);
}{gdjs.evtTools.sound.playSound(runtimeScene, "assets\\Sounds\\Yay.mp3", false, 100, 1);
}}

}


{


let isConditionTrue_0 = false;
{

{ //Subevents
gdjs.MainCode.eventsList93(runtimeScene, asyncObjectsList);} //End of subevents
}

}


};gdjs.MainCode.asyncCallback15203828 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.MainCode.localVariables);

{ //Subevents
gdjs.MainCode.eventsList94(runtimeScene, asyncObjectsList);} //End of subevents
gdjs.MainCode.localVariables.length = 0;
}
gdjs.MainCode.eventsList95 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
asyncObjectsList.backupLocalVariablesContainers(gdjs.MainCode.localVariables);
for (const obj of gdjs.MainCode.GDNext_9595buttonObjects2) asyncObjectsList.addObject("Next_button", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1), (runtimeScene) => (gdjs.MainCode.asyncCallback15203828(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.MainCode.eventsList96 = function(runtimeScene, asyncObjectsList) {

{


let isConditionTrue_0 = false;
{

{ //Subevents
gdjs.MainCode.eventsList95(runtimeScene, asyncObjectsList);} //End of subevents
}

}


};gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDEconomyResultObjects5Objects = Hashtable.newFrom({"EconomyResult": gdjs.MainCode.GDEconomyResultObjects5});
gdjs.MainCode.eventsList97 = function(runtimeScene, asyncObjectsList) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("NextText"), gdjs.MainCode.GDNextTextObjects6);
gdjs.copyArray(asyncObjectsList.getObjects("Next_button"), gdjs.MainCode.GDNext_9595buttonObjects6);

{for(var i = 0, len = gdjs.MainCode.GDNext_9595buttonObjects6.length ;i < len;++i) {
    gdjs.MainCode.GDNext_9595buttonObjects6[i].hide(false);
}
for(var i = 0, len = gdjs.MainCode.GDNextTextObjects6.length ;i < len;++i) {
    gdjs.MainCode.GDNextTextObjects6[i].hide(false);
}
}}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15630484);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("EconomyTxt"), gdjs.MainCode.GDEconomyTxtObjects5);
gdjs.MainCode.GDEconomyResultObjects5.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDEconomyResultObjects5Objects, (( gdjs.MainCode.GDEconomyTxtObjects5.length === 0 ) ? 0 :gdjs.MainCode.GDEconomyTxtObjects5[0].getX()), (( gdjs.MainCode.GDEconomyTxtObjects5.length === 0 ) ? 0 :gdjs.MainCode.GDEconomyTxtObjects5[0].getY()), "");
}{for(var i = 0, len = gdjs.MainCode.GDEconomyResultObjects5.length ;i < len;++i) {
    gdjs.MainCode.GDEconomyResultObjects5[i].getBehavior("Text").setText("+2");
}
}{for(var i = 0, len = gdjs.MainCode.GDEconomyResultObjects5.length ;i < len;++i) {
    gdjs.MainCode.GDEconomyResultObjects5[i].getBehavior("Tween").addObjectOpacityTween2("Opacity", 0, "linear", 2, true);
}
}{for(var i = 0, len = gdjs.MainCode.GDEconomyResultObjects5.length ;i < len;++i) {
    gdjs.MainCode.GDEconomyResultObjects5[i].setColor("65;117;5");
}
}{for(var i = 0, len = gdjs.MainCode.GDEconomyResultObjects5.length ;i < len;++i) {
    gdjs.MainCode.GDEconomyResultObjects5[i].addPolarForce(180, 50, 1);
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "assets\\Sounds\\Yay.mp3", false, 100, 1);
}}

}


};gdjs.MainCode.asyncCallback15207252 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.MainCode.localVariables);

{ //Subevents
gdjs.MainCode.eventsList97(runtimeScene, asyncObjectsList);} //End of subevents
gdjs.MainCode.localVariables.length = 0;
}
gdjs.MainCode.eventsList98 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
asyncObjectsList.backupLocalVariablesContainers(gdjs.MainCode.localVariables);
for (const obj of gdjs.MainCode.GDNext_9595buttonObjects2) asyncObjectsList.addObject("Next_button", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1), (runtimeScene) => (gdjs.MainCode.asyncCallback15207252(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.MainCode.eventsList99 = function(runtimeScene, asyncObjectsList) {

{


let isConditionTrue_0 = false;
{

{ //Subevents
gdjs.MainCode.eventsList98(runtimeScene, asyncObjectsList);} //End of subevents
}

}


{



}


{



}


{



}


{



}


};gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDPAResultObjects5Objects = Hashtable.newFrom({"PAResult": gdjs.MainCode.GDPAResultObjects5});
gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDRiskResultObjects6Objects = Hashtable.newFrom({"RiskResult": gdjs.MainCode.GDRiskResultObjects6});
gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDPersonalWealthResultObjects6Objects = Hashtable.newFrom({"PersonalWealthResult": gdjs.MainCode.GDPersonalWealthResultObjects6});
gdjs.MainCode.eventsList100 = function(runtimeScene, asyncObjectsList) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("NextText"), gdjs.MainCode.GDNextTextObjects7);
gdjs.copyArray(asyncObjectsList.getObjects("Next_button"), gdjs.MainCode.GDNext_9595buttonObjects7);

{for(var i = 0, len = gdjs.MainCode.GDNext_9595buttonObjects7.length ;i < len;++i) {
    gdjs.MainCode.GDNext_9595buttonObjects7[i].hide(false);
}
for(var i = 0, len = gdjs.MainCode.GDNextTextObjects7.length ;i < len;++i) {
    gdjs.MainCode.GDNextTextObjects7[i].hide(false);
}
}}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15648972);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("PersonalGainsTxt"), gdjs.MainCode.GDPersonalGainsTxtObjects6);
gdjs.MainCode.GDPersonalWealthResultObjects6.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDPersonalWealthResultObjects6Objects, (( gdjs.MainCode.GDPersonalGainsTxtObjects6.length === 0 ) ? 0 :gdjs.MainCode.GDPersonalGainsTxtObjects6[0].getX()), (( gdjs.MainCode.GDPersonalGainsTxtObjects6.length === 0 ) ? 0 :gdjs.MainCode.GDPersonalGainsTxtObjects6[0].getY()), "");
}{for(var i = 0, len = gdjs.MainCode.GDPersonalWealthResultObjects6.length ;i < len;++i) {
    gdjs.MainCode.GDPersonalWealthResultObjects6[i].getBehavior("Text").setText("+2");
}
}{for(var i = 0, len = gdjs.MainCode.GDPersonalWealthResultObjects6.length ;i < len;++i) {
    gdjs.MainCode.GDPersonalWealthResultObjects6[i].setColor("65;117;5");
}
}{for(var i = 0, len = gdjs.MainCode.GDPersonalWealthResultObjects6.length ;i < len;++i) {
    gdjs.MainCode.GDPersonalWealthResultObjects6[i].addPolarForce(180, 50, 1);
}
}{for(var i = 0, len = gdjs.MainCode.GDPersonalWealthResultObjects6.length ;i < len;++i) {
    gdjs.MainCode.GDPersonalWealthResultObjects6[i].getBehavior("Tween").addObjectOpacityTween2("Opacity", 0, "linear", 2, true);
}
}{runtimeScene.getScene().getVariables().getFromIndex(6).add(2);
}{gdjs.evtTools.sound.playSound(runtimeScene, "assets\\Sounds\\Yay.mp3", false, 100, 1);
}}

}


};gdjs.MainCode.asyncCallback15211740 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.MainCode.localVariables);

{ //Subevents
gdjs.MainCode.eventsList100(runtimeScene, asyncObjectsList);} //End of subevents
gdjs.MainCode.localVariables.length = 0;
}
gdjs.MainCode.eventsList101 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
asyncObjectsList.backupLocalVariablesContainers(gdjs.MainCode.localVariables);
/* Don't save Next_button as it will be provided by the parent asyncObjectsList. */
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1), (runtimeScene) => (gdjs.MainCode.asyncCallback15211740(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.MainCode.eventsList102 = function(runtimeScene, asyncObjectsList) {

{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15640380);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("ScandalRiskTxt"), gdjs.MainCode.GDScandalRiskTxtObjects6);
gdjs.MainCode.GDRiskResultObjects6.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDRiskResultObjects6Objects, (( gdjs.MainCode.GDScandalRiskTxtObjects6.length === 0 ) ? 0 :gdjs.MainCode.GDScandalRiskTxtObjects6[0].getX()), (( gdjs.MainCode.GDScandalRiskTxtObjects6.length === 0 ) ? 0 :gdjs.MainCode.GDScandalRiskTxtObjects6[0].getY()), "");
}{for(var i = 0, len = gdjs.MainCode.GDRiskResultObjects6.length ;i < len;++i) {
    gdjs.MainCode.GDRiskResultObjects6[i].getBehavior("Text").setText("+1");
}
}{for(var i = 0, len = gdjs.MainCode.GDRiskResultObjects6.length ;i < len;++i) {
    gdjs.MainCode.GDRiskResultObjects6[i].setColor("208;2;27");
}
}{for(var i = 0, len = gdjs.MainCode.GDRiskResultObjects6.length ;i < len;++i) {
    gdjs.MainCode.GDRiskResultObjects6[i].addPolarForce(180, 50, 1);
}
}{for(var i = 0, len = gdjs.MainCode.GDRiskResultObjects6.length ;i < len;++i) {
    gdjs.MainCode.GDRiskResultObjects6[i].getBehavior("Tween").addObjectOpacityTween2("Opacity", 0, "linear", 2, true);
}
}{runtimeScene.getScene().getVariables().getFromIndex(5).add(1);
}{gdjs.evtTools.sound.playSound(runtimeScene, "assets\\Sounds\\Shocked.mp3", false, 100, 1);
}}

}


{


let isConditionTrue_0 = false;
{

{ //Subevents
gdjs.MainCode.eventsList101(runtimeScene, asyncObjectsList);} //End of subevents
}

}


};gdjs.MainCode.asyncCallback15211068 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.MainCode.localVariables);

{ //Subevents
gdjs.MainCode.eventsList102(runtimeScene, asyncObjectsList);} //End of subevents
gdjs.MainCode.localVariables.length = 0;
}
gdjs.MainCode.eventsList103 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
asyncObjectsList.backupLocalVariablesContainers(gdjs.MainCode.localVariables);
/* Don't save Next_button as it will be provided by the parent asyncObjectsList. */
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1), (runtimeScene) => (gdjs.MainCode.asyncCallback15211068(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.MainCode.eventsList104 = function(runtimeScene, asyncObjectsList) {

{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15632277);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("PublicApprovalTxt"), gdjs.MainCode.GDPublicApprovalTxtObjects5);
gdjs.MainCode.GDPAResultObjects5.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDPAResultObjects5Objects, (( gdjs.MainCode.GDPublicApprovalTxtObjects5.length === 0 ) ? 0 :gdjs.MainCode.GDPublicApprovalTxtObjects5[0].getX()), (( gdjs.MainCode.GDPublicApprovalTxtObjects5.length === 0 ) ? 0 :gdjs.MainCode.GDPublicApprovalTxtObjects5[0].getY()), "");
}{for(var i = 0, len = gdjs.MainCode.GDPAResultObjects5.length ;i < len;++i) {
    gdjs.MainCode.GDPAResultObjects5[i].getBehavior("Text").setText("-1");
}
}{for(var i = 0, len = gdjs.MainCode.GDPAResultObjects5.length ;i < len;++i) {
    gdjs.MainCode.GDPAResultObjects5[i].setColor("208;2;27");
}
}{for(var i = 0, len = gdjs.MainCode.GDPAResultObjects5.length ;i < len;++i) {
    gdjs.MainCode.GDPAResultObjects5[i].addPolarForce(180, 50, 1);
}
}{for(var i = 0, len = gdjs.MainCode.GDPAResultObjects5.length ;i < len;++i) {
    gdjs.MainCode.GDPAResultObjects5[i].getBehavior("Tween").addObjectOpacityTween2("Opacity", 0, "linear", 2, true);
}
}{runtimeScene.getScene().getVariables().getFromIndex(4).sub(1);
}{gdjs.evtTools.sound.playSound(runtimeScene, "assets\\Sounds\\Shocked.mp3", false, 100, 1);
}}

}


{


let isConditionTrue_0 = false;
{

{ //Subevents
gdjs.MainCode.eventsList103(runtimeScene, asyncObjectsList);} //End of subevents
}

}


};gdjs.MainCode.asyncCallback15210396 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.MainCode.localVariables);

{ //Subevents
gdjs.MainCode.eventsList104(runtimeScene, asyncObjectsList);} //End of subevents
gdjs.MainCode.localVariables.length = 0;
}
gdjs.MainCode.eventsList105 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
asyncObjectsList.backupLocalVariablesContainers(gdjs.MainCode.localVariables);
for (const obj of gdjs.MainCode.GDNext_9595buttonObjects2) asyncObjectsList.addObject("Next_button", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1), (runtimeScene) => (gdjs.MainCode.asyncCallback15210396(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.MainCode.eventsList106 = function(runtimeScene, asyncObjectsList) {

{


let isConditionTrue_0 = false;
{

{ //Subevents
gdjs.MainCode.eventsList105(runtimeScene, asyncObjectsList);} //End of subevents
}

}


};gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDPAResultObjects5Objects = Hashtable.newFrom({"PAResult": gdjs.MainCode.GDPAResultObjects5});
gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDPersonalWealthResultObjects5Objects = Hashtable.newFrom({"PersonalWealthResult": gdjs.MainCode.GDPersonalWealthResultObjects5});
gdjs.MainCode.eventsList107 = function(runtimeScene, asyncObjectsList) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("NextText"), gdjs.MainCode.GDNextTextObjects6);
gdjs.copyArray(asyncObjectsList.getObjects("Next_button"), gdjs.MainCode.GDNext_9595buttonObjects6);

{for(var i = 0, len = gdjs.MainCode.GDNext_9595buttonObjects6.length ;i < len;++i) {
    gdjs.MainCode.GDNext_9595buttonObjects6[i].hide(false);
}
for(var i = 0, len = gdjs.MainCode.GDNextTextObjects6.length ;i < len;++i) {
    gdjs.MainCode.GDNextTextObjects6[i].hide(false);
}
}}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15648573);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("PersonalGainsTxt"), gdjs.MainCode.GDPersonalGainsTxtObjects5);
gdjs.MainCode.GDPersonalWealthResultObjects5.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDPersonalWealthResultObjects5Objects, (( gdjs.MainCode.GDPersonalGainsTxtObjects5.length === 0 ) ? 0 :gdjs.MainCode.GDPersonalGainsTxtObjects5[0].getX()), (( gdjs.MainCode.GDPersonalGainsTxtObjects5.length === 0 ) ? 0 :gdjs.MainCode.GDPersonalGainsTxtObjects5[0].getY()), "");
}{for(var i = 0, len = gdjs.MainCode.GDPersonalWealthResultObjects5.length ;i < len;++i) {
    gdjs.MainCode.GDPersonalWealthResultObjects5[i].getBehavior("Text").setText("+1");
}
}{for(var i = 0, len = gdjs.MainCode.GDPersonalWealthResultObjects5.length ;i < len;++i) {
    gdjs.MainCode.GDPersonalWealthResultObjects5[i].setColor("65;117;5");
}
}{for(var i = 0, len = gdjs.MainCode.GDPersonalWealthResultObjects5.length ;i < len;++i) {
    gdjs.MainCode.GDPersonalWealthResultObjects5[i].addPolarForce(180, 50, 1);
}
}{for(var i = 0, len = gdjs.MainCode.GDPersonalWealthResultObjects5.length ;i < len;++i) {
    gdjs.MainCode.GDPersonalWealthResultObjects5[i].getBehavior("Tween").addObjectOpacityTween2("Opacity", 0, "linear", 2, true);
}
}{runtimeScene.getScene().getVariables().getFromIndex(6).add(1);
}{gdjs.evtTools.sound.playSound(runtimeScene, "assets\\Sounds\\Yay.mp3", false, 100, 1);
}}

}


};gdjs.MainCode.asyncCallback15214164 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.MainCode.localVariables);

{ //Subevents
gdjs.MainCode.eventsList107(runtimeScene, asyncObjectsList);} //End of subevents
gdjs.MainCode.localVariables.length = 0;
}
gdjs.MainCode.eventsList108 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
asyncObjectsList.backupLocalVariablesContainers(gdjs.MainCode.localVariables);
/* Don't save Next_button as it will be provided by the parent asyncObjectsList. */
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1), (runtimeScene) => (gdjs.MainCode.asyncCallback15214164(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.MainCode.eventsList109 = function(runtimeScene, asyncObjectsList) {

{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15632278);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("PublicApprovalTxt"), gdjs.MainCode.GDPublicApprovalTxtObjects5);
gdjs.MainCode.GDPAResultObjects5.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDPAResultObjects5Objects, (( gdjs.MainCode.GDPublicApprovalTxtObjects5.length === 0 ) ? 0 :gdjs.MainCode.GDPublicApprovalTxtObjects5[0].getX()), (( gdjs.MainCode.GDPublicApprovalTxtObjects5.length === 0 ) ? 0 :gdjs.MainCode.GDPublicApprovalTxtObjects5[0].getY()), "");
}{for(var i = 0, len = gdjs.MainCode.GDPAResultObjects5.length ;i < len;++i) {
    gdjs.MainCode.GDPAResultObjects5[i].getBehavior("Text").setText("-1");
}
}{for(var i = 0, len = gdjs.MainCode.GDPAResultObjects5.length ;i < len;++i) {
    gdjs.MainCode.GDPAResultObjects5[i].setColor("208;2;27");
}
}{for(var i = 0, len = gdjs.MainCode.GDPAResultObjects5.length ;i < len;++i) {
    gdjs.MainCode.GDPAResultObjects5[i].addPolarForce(180, 50, 1);
}
}{for(var i = 0, len = gdjs.MainCode.GDPAResultObjects5.length ;i < len;++i) {
    gdjs.MainCode.GDPAResultObjects5[i].getBehavior("Tween").addObjectOpacityTween2("Opacity", 0, "linear", 2, true);
}
}{runtimeScene.getScene().getVariables().getFromIndex(4).sub(1);
}{gdjs.evtTools.sound.playSound(runtimeScene, "assets\\Sounds\\Shocked.mp3", false, 100, 1);
}}

}


{


let isConditionTrue_0 = false;
{

{ //Subevents
gdjs.MainCode.eventsList108(runtimeScene, asyncObjectsList);} //End of subevents
}

}


};gdjs.MainCode.asyncCallback15213492 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.MainCode.localVariables);

{ //Subevents
gdjs.MainCode.eventsList109(runtimeScene, asyncObjectsList);} //End of subevents
gdjs.MainCode.localVariables.length = 0;
}
gdjs.MainCode.eventsList110 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
asyncObjectsList.backupLocalVariablesContainers(gdjs.MainCode.localVariables);
for (const obj of gdjs.MainCode.GDNext_9595buttonObjects2) asyncObjectsList.addObject("Next_button", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1), (runtimeScene) => (gdjs.MainCode.asyncCallback15213492(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.MainCode.eventsList111 = function(runtimeScene, asyncObjectsList) {

{


let isConditionTrue_0 = false;
{

{ //Subevents
gdjs.MainCode.eventsList110(runtimeScene, asyncObjectsList);} //End of subevents
}

}


};gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDEconomyResultObjects6Objects = Hashtable.newFrom({"EconomyResult": gdjs.MainCode.GDEconomyResultObjects6});
gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDRiskResultObjects6Objects = Hashtable.newFrom({"RiskResult": gdjs.MainCode.GDRiskResultObjects6});
gdjs.MainCode.eventsList112 = function(runtimeScene, asyncObjectsList) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("NextText"), gdjs.MainCode.GDNextTextObjects7);
gdjs.copyArray(asyncObjectsList.getObjects("Next_button"), gdjs.MainCode.GDNext_9595buttonObjects7);

{for(var i = 0, len = gdjs.MainCode.GDNext_9595buttonObjects7.length ;i < len;++i) {
    gdjs.MainCode.GDNext_9595buttonObjects7[i].hide(false);
}
for(var i = 0, len = gdjs.MainCode.GDNextTextObjects7.length ;i < len;++i) {
    gdjs.MainCode.GDNextTextObjects7[i].hide(false);
}
}}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15640381);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("ScandalRiskTxt"), gdjs.MainCode.GDScandalRiskTxtObjects6);
gdjs.MainCode.GDRiskResultObjects6.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDRiskResultObjects6Objects, (( gdjs.MainCode.GDScandalRiskTxtObjects6.length === 0 ) ? 0 :gdjs.MainCode.GDScandalRiskTxtObjects6[0].getX()), (( gdjs.MainCode.GDScandalRiskTxtObjects6.length === 0 ) ? 0 :gdjs.MainCode.GDScandalRiskTxtObjects6[0].getY()), "");
}{for(var i = 0, len = gdjs.MainCode.GDRiskResultObjects6.length ;i < len;++i) {
    gdjs.MainCode.GDRiskResultObjects6[i].getBehavior("Text").setText("+1");
}
}{for(var i = 0, len = gdjs.MainCode.GDRiskResultObjects6.length ;i < len;++i) {
    gdjs.MainCode.GDRiskResultObjects6[i].setColor("208;2;27");
}
}{for(var i = 0, len = gdjs.MainCode.GDRiskResultObjects6.length ;i < len;++i) {
    gdjs.MainCode.GDRiskResultObjects6[i].addPolarForce(180, 50, 1);
}
}{for(var i = 0, len = gdjs.MainCode.GDRiskResultObjects6.length ;i < len;++i) {
    gdjs.MainCode.GDRiskResultObjects6[i].getBehavior("Tween").addObjectOpacityTween2("Opacity", 0, "linear", 2, true);
}
}{runtimeScene.getScene().getVariables().getFromIndex(5).add(1);
}{gdjs.evtTools.sound.playSound(runtimeScene, "assets\\Sounds\\Shocked.mp3", false, 100, 1);
}}

}


};gdjs.MainCode.asyncCallback15216596 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.MainCode.localVariables);

{ //Subevents
gdjs.MainCode.eventsList112(runtimeScene, asyncObjectsList);} //End of subevents
gdjs.MainCode.localVariables.length = 0;
}
gdjs.MainCode.eventsList113 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
asyncObjectsList.backupLocalVariablesContainers(gdjs.MainCode.localVariables);
/* Don't save Next_button as it will be provided by the parent asyncObjectsList. */
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1), (runtimeScene) => (gdjs.MainCode.asyncCallback15216596(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.MainCode.eventsList114 = function(runtimeScene, asyncObjectsList) {

{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15626606);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("EconomyTxt"), gdjs.MainCode.GDEconomyTxtObjects6);
gdjs.MainCode.GDEconomyResultObjects6.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDEconomyResultObjects6Objects, (( gdjs.MainCode.GDEconomyTxtObjects6.length === 0 ) ? 0 :gdjs.MainCode.GDEconomyTxtObjects6[0].getX()), (( gdjs.MainCode.GDEconomyTxtObjects6.length === 0 ) ? 0 :gdjs.MainCode.GDEconomyTxtObjects6[0].getY()), "");
}{for(var i = 0, len = gdjs.MainCode.GDEconomyResultObjects6.length ;i < len;++i) {
    gdjs.MainCode.GDEconomyResultObjects6[i].getBehavior("Text").setText("+1");
}
}{for(var i = 0, len = gdjs.MainCode.GDEconomyResultObjects6.length ;i < len;++i) {
    gdjs.MainCode.GDEconomyResultObjects6[i].getBehavior("Tween").addObjectOpacityTween2("Opacity", 0, "linear", 2, true);
}
}{for(var i = 0, len = gdjs.MainCode.GDEconomyResultObjects6.length ;i < len;++i) {
    gdjs.MainCode.GDEconomyResultObjects6[i].setColor("65;117;5");
}
}{for(var i = 0, len = gdjs.MainCode.GDEconomyResultObjects6.length ;i < len;++i) {
    gdjs.MainCode.GDEconomyResultObjects6[i].addPolarForce(180, 50, 1);
}
}{runtimeScene.getScene().getVariables().getFromIndex(3).add(1);
}{gdjs.evtTools.sound.playSound(runtimeScene, "assets\\Sounds\\Yay.mp3", false, 100, 1);
}}

}


{


let isConditionTrue_0 = false;
{

{ //Subevents
gdjs.MainCode.eventsList113(runtimeScene, asyncObjectsList);} //End of subevents
}

}


};gdjs.MainCode.asyncCallback15215924 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.MainCode.localVariables);

{ //Subevents
gdjs.MainCode.eventsList114(runtimeScene, asyncObjectsList);} //End of subevents
gdjs.MainCode.localVariables.length = 0;
}
gdjs.MainCode.eventsList115 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
asyncObjectsList.backupLocalVariablesContainers(gdjs.MainCode.localVariables);
for (const obj of gdjs.MainCode.GDNext_9595buttonObjects2) asyncObjectsList.addObject("Next_button", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1), (runtimeScene) => (gdjs.MainCode.asyncCallback15215924(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.MainCode.eventsList116 = function(runtimeScene, asyncObjectsList) {

{


let isConditionTrue_0 = false;
{

{ //Subevents
gdjs.MainCode.eventsList115(runtimeScene, asyncObjectsList);} //End of subevents
}

}


{



}


{



}


};gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDEconomyResultObjects5Objects = Hashtable.newFrom({"EconomyResult": gdjs.MainCode.GDEconomyResultObjects5});
gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDPAResultObjects6Objects = Hashtable.newFrom({"PAResult": gdjs.MainCode.GDPAResultObjects6});
gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDRiskResultObjects7Objects = Hashtable.newFrom({"RiskResult": gdjs.MainCode.GDRiskResultObjects7});
gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDPersonalWealthResultObjects7Objects = Hashtable.newFrom({"PersonalWealthResult": gdjs.MainCode.GDPersonalWealthResultObjects7});
gdjs.MainCode.eventsList117 = function(runtimeScene, asyncObjectsList) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("NextText"), gdjs.MainCode.GDNextTextObjects8);
gdjs.copyArray(asyncObjectsList.getObjects("Next_button"), gdjs.MainCode.GDNext_9595buttonObjects8);

{for(var i = 0, len = gdjs.MainCode.GDNext_9595buttonObjects8.length ;i < len;++i) {
    gdjs.MainCode.GDNext_9595buttonObjects8[i].hide(false);
}
for(var i = 0, len = gdjs.MainCode.GDNextTextObjects8.length ;i < len;++i) {
    gdjs.MainCode.GDNextTextObjects8[i].hide(false);
}
}}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15648574);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("PersonalGainsTxt"), gdjs.MainCode.GDPersonalGainsTxtObjects7);
gdjs.MainCode.GDPersonalWealthResultObjects7.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDPersonalWealthResultObjects7Objects, (( gdjs.MainCode.GDPersonalGainsTxtObjects7.length === 0 ) ? 0 :gdjs.MainCode.GDPersonalGainsTxtObjects7[0].getX()), (( gdjs.MainCode.GDPersonalGainsTxtObjects7.length === 0 ) ? 0 :gdjs.MainCode.GDPersonalGainsTxtObjects7[0].getY()), "");
}{for(var i = 0, len = gdjs.MainCode.GDPersonalWealthResultObjects7.length ;i < len;++i) {
    gdjs.MainCode.GDPersonalWealthResultObjects7[i].getBehavior("Text").setText("+1");
}
}{for(var i = 0, len = gdjs.MainCode.GDPersonalWealthResultObjects7.length ;i < len;++i) {
    gdjs.MainCode.GDPersonalWealthResultObjects7[i].setColor("65;117;5");
}
}{for(var i = 0, len = gdjs.MainCode.GDPersonalWealthResultObjects7.length ;i < len;++i) {
    gdjs.MainCode.GDPersonalWealthResultObjects7[i].addPolarForce(180, 50, 1);
}
}{for(var i = 0, len = gdjs.MainCode.GDPersonalWealthResultObjects7.length ;i < len;++i) {
    gdjs.MainCode.GDPersonalWealthResultObjects7[i].getBehavior("Tween").addObjectOpacityTween2("Opacity", 0, "linear", 2, true);
}
}{runtimeScene.getScene().getVariables().getFromIndex(6).add(1);
}{gdjs.evtTools.sound.playSound(runtimeScene, "assets\\Sounds\\Yay.mp3", false, 100, 1);
}}

}


};gdjs.MainCode.asyncCallback15221036 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.MainCode.localVariables);

{ //Subevents
gdjs.MainCode.eventsList117(runtimeScene, asyncObjectsList);} //End of subevents
gdjs.MainCode.localVariables.length = 0;
}
gdjs.MainCode.eventsList118 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
asyncObjectsList.backupLocalVariablesContainers(gdjs.MainCode.localVariables);
/* Don't save Next_button as it will be provided by the parent asyncObjectsList. */
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1), (runtimeScene) => (gdjs.MainCode.asyncCallback15221036(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.MainCode.eventsList119 = function(runtimeScene, asyncObjectsList) {

{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15641597);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("ScandalRiskTxt"), gdjs.MainCode.GDScandalRiskTxtObjects7);
gdjs.MainCode.GDRiskResultObjects7.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDRiskResultObjects7Objects, (( gdjs.MainCode.GDScandalRiskTxtObjects7.length === 0 ) ? 0 :gdjs.MainCode.GDScandalRiskTxtObjects7[0].getX()), (( gdjs.MainCode.GDScandalRiskTxtObjects7.length === 0 ) ? 0 :gdjs.MainCode.GDScandalRiskTxtObjects7[0].getY()), "");
}{for(var i = 0, len = gdjs.MainCode.GDRiskResultObjects7.length ;i < len;++i) {
    gdjs.MainCode.GDRiskResultObjects7[i].getBehavior("Text").setText("+2");
}
}{for(var i = 0, len = gdjs.MainCode.GDRiskResultObjects7.length ;i < len;++i) {
    gdjs.MainCode.GDRiskResultObjects7[i].setColor("208;2;27");
}
}{for(var i = 0, len = gdjs.MainCode.GDRiskResultObjects7.length ;i < len;++i) {
    gdjs.MainCode.GDRiskResultObjects7[i].addPolarForce(180, 50, 1);
}
}{for(var i = 0, len = gdjs.MainCode.GDRiskResultObjects7.length ;i < len;++i) {
    gdjs.MainCode.GDRiskResultObjects7[i].getBehavior("Tween").addObjectOpacityTween2("Opacity", 0, "linear", 2, true);
}
}{runtimeScene.getScene().getVariables().getFromIndex(5).add(2);
}{gdjs.evtTools.sound.playSound(runtimeScene, "assets\\Sounds\\Shocked.mp3", false, 100, 1);
}}

}


{


let isConditionTrue_0 = false;
{

{ //Subevents
gdjs.MainCode.eventsList118(runtimeScene, asyncObjectsList);} //End of subevents
}

}


};gdjs.MainCode.asyncCallback15220364 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.MainCode.localVariables);

{ //Subevents
gdjs.MainCode.eventsList119(runtimeScene, asyncObjectsList);} //End of subevents
gdjs.MainCode.localVariables.length = 0;
}
gdjs.MainCode.eventsList120 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
asyncObjectsList.backupLocalVariablesContainers(gdjs.MainCode.localVariables);
/* Don't save Next_button as it will be provided by the parent asyncObjectsList. */
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1), (runtimeScene) => (gdjs.MainCode.asyncCallback15220364(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.MainCode.eventsList121 = function(runtimeScene, asyncObjectsList) {

{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15632279);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("PublicApprovalTxt"), gdjs.MainCode.GDPublicApprovalTxtObjects6);
gdjs.MainCode.GDPAResultObjects6.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDPAResultObjects6Objects, (( gdjs.MainCode.GDPublicApprovalTxtObjects6.length === 0 ) ? 0 :gdjs.MainCode.GDPublicApprovalTxtObjects6[0].getX()), (( gdjs.MainCode.GDPublicApprovalTxtObjects6.length === 0 ) ? 0 :gdjs.MainCode.GDPublicApprovalTxtObjects6[0].getY()), "");
}{for(var i = 0, len = gdjs.MainCode.GDPAResultObjects6.length ;i < len;++i) {
    gdjs.MainCode.GDPAResultObjects6[i].getBehavior("Text").setText("-1");
}
}{for(var i = 0, len = gdjs.MainCode.GDPAResultObjects6.length ;i < len;++i) {
    gdjs.MainCode.GDPAResultObjects6[i].setColor("208;2;27");
}
}{for(var i = 0, len = gdjs.MainCode.GDPAResultObjects6.length ;i < len;++i) {
    gdjs.MainCode.GDPAResultObjects6[i].addPolarForce(180, 50, 1);
}
}{for(var i = 0, len = gdjs.MainCode.GDPAResultObjects6.length ;i < len;++i) {
    gdjs.MainCode.GDPAResultObjects6[i].getBehavior("Tween").addObjectOpacityTween2("Opacity", 0, "linear", 2, true);
}
}{runtimeScene.getScene().getVariables().getFromIndex(4).sub(1);
}{gdjs.evtTools.sound.playSound(runtimeScene, "assets\\Sounds\\Shocked.mp3", false, 100, 1);
}}

}


{


let isConditionTrue_0 = false;
{

{ //Subevents
gdjs.MainCode.eventsList120(runtimeScene, asyncObjectsList);} //End of subevents
}

}


};gdjs.MainCode.asyncCallback15219692 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.MainCode.localVariables);

{ //Subevents
gdjs.MainCode.eventsList121(runtimeScene, asyncObjectsList);} //End of subevents
gdjs.MainCode.localVariables.length = 0;
}
gdjs.MainCode.eventsList122 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
asyncObjectsList.backupLocalVariablesContainers(gdjs.MainCode.localVariables);
/* Don't save Next_button as it will be provided by the parent asyncObjectsList. */
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1), (runtimeScene) => (gdjs.MainCode.asyncCallback15219692(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.MainCode.eventsList123 = function(runtimeScene, asyncObjectsList) {

{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15628469);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("EconomyTxt"), gdjs.MainCode.GDEconomyTxtObjects5);
gdjs.MainCode.GDEconomyResultObjects5.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDEconomyResultObjects5Objects, (( gdjs.MainCode.GDEconomyTxtObjects5.length === 0 ) ? 0 :gdjs.MainCode.GDEconomyTxtObjects5[0].getX()), (( gdjs.MainCode.GDEconomyTxtObjects5.length === 0 ) ? 0 :gdjs.MainCode.GDEconomyTxtObjects5[0].getY()), "");
}{for(var i = 0, len = gdjs.MainCode.GDEconomyResultObjects5.length ;i < len;++i) {
    gdjs.MainCode.GDEconomyResultObjects5[i].getBehavior("Text").setText("-1");
}
}{for(var i = 0, len = gdjs.MainCode.GDEconomyResultObjects5.length ;i < len;++i) {
    gdjs.MainCode.GDEconomyResultObjects5[i].getBehavior("Tween").addObjectOpacityTween2("Opacity", 0, "linear", 2, true);
}
}{for(var i = 0, len = gdjs.MainCode.GDEconomyResultObjects5.length ;i < len;++i) {
    gdjs.MainCode.GDEconomyResultObjects5[i].setColor("208;2;27");
}
}{for(var i = 0, len = gdjs.MainCode.GDEconomyResultObjects5.length ;i < len;++i) {
    gdjs.MainCode.GDEconomyResultObjects5[i].addPolarForce(180, 50, 1);
}
}{runtimeScene.getScene().getVariables().getFromIndex(3).sub(1);
}{gdjs.evtTools.sound.playSound(runtimeScene, "assets\\Sounds\\Shocked.mp3", false, 100, 1);
}}

}


{


let isConditionTrue_0 = false;
{

{ //Subevents
gdjs.MainCode.eventsList122(runtimeScene, asyncObjectsList);} //End of subevents
}

}


};gdjs.MainCode.asyncCallback15219020 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.MainCode.localVariables);

{ //Subevents
gdjs.MainCode.eventsList123(runtimeScene, asyncObjectsList);} //End of subevents
gdjs.MainCode.localVariables.length = 0;
}
gdjs.MainCode.eventsList124 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
asyncObjectsList.backupLocalVariablesContainers(gdjs.MainCode.localVariables);
for (const obj of gdjs.MainCode.GDNext_9595buttonObjects2) asyncObjectsList.addObject("Next_button", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1), (runtimeScene) => (gdjs.MainCode.asyncCallback15219020(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.MainCode.eventsList125 = function(runtimeScene, asyncObjectsList) {

{


let isConditionTrue_0 = false;
{

{ //Subevents
gdjs.MainCode.eventsList124(runtimeScene, asyncObjectsList);} //End of subevents
}

}


};gdjs.MainCode.asyncCallback15222828 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.MainCode.localVariables);
gdjs.MainCode.localVariables.length = 0;
}
gdjs.MainCode.eventsList126 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
asyncObjectsList.backupLocalVariablesContainers(gdjs.MainCode.localVariables);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1), (runtimeScene) => (gdjs.MainCode.asyncCallback15222828(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDPAResultObjects5Objects = Hashtable.newFrom({"PAResult": gdjs.MainCode.GDPAResultObjects5});
gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDRiskResultObjects6Objects = Hashtable.newFrom({"RiskResult": gdjs.MainCode.GDRiskResultObjects6});
gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDPersonalWealthResultObjects6Objects = Hashtable.newFrom({"PersonalWealthResult": gdjs.MainCode.GDPersonalWealthResultObjects6});
gdjs.MainCode.eventsList127 = function(runtimeScene, asyncObjectsList) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("NextText"), gdjs.MainCode.GDNextTextObjects7);
gdjs.copyArray(asyncObjectsList.getObjects("Next_button"), gdjs.MainCode.GDNext_9595buttonObjects7);

{for(var i = 0, len = gdjs.MainCode.GDNext_9595buttonObjects7.length ;i < len;++i) {
    gdjs.MainCode.GDNext_9595buttonObjects7[i].hide(false);
}
for(var i = 0, len = gdjs.MainCode.GDNextTextObjects7.length ;i < len;++i) {
    gdjs.MainCode.GDNextTextObjects7[i].hide(false);
}
}}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15644085);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("PersonalGainsTxt"), gdjs.MainCode.GDPersonalGainsTxtObjects6);
gdjs.MainCode.GDPersonalWealthResultObjects6.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDPersonalWealthResultObjects6Objects, (( gdjs.MainCode.GDPersonalGainsTxtObjects6.length === 0 ) ? 0 :gdjs.MainCode.GDPersonalGainsTxtObjects6[0].getX()), (( gdjs.MainCode.GDPersonalGainsTxtObjects6.length === 0 ) ? 0 :gdjs.MainCode.GDPersonalGainsTxtObjects6[0].getY()), "");
}{for(var i = 0, len = gdjs.MainCode.GDPersonalWealthResultObjects6.length ;i < len;++i) {
    gdjs.MainCode.GDPersonalWealthResultObjects6[i].getBehavior("Text").setText("-1");
}
}{for(var i = 0, len = gdjs.MainCode.GDPersonalWealthResultObjects6.length ;i < len;++i) {
    gdjs.MainCode.GDPersonalWealthResultObjects6[i].setColor("208;2;27");
}
}{for(var i = 0, len = gdjs.MainCode.GDPersonalWealthResultObjects6.length ;i < len;++i) {
    gdjs.MainCode.GDPersonalWealthResultObjects6[i].addPolarForce(180, 50, 1);
}
}{for(var i = 0, len = gdjs.MainCode.GDPersonalWealthResultObjects6.length ;i < len;++i) {
    gdjs.MainCode.GDPersonalWealthResultObjects6[i].getBehavior("Tween").addObjectOpacityTween2("Opacity", 0, "linear", 2, true);
}
}{runtimeScene.getScene().getVariables().getFromIndex(6).sub(1);
}{gdjs.evtTools.sound.playSound(runtimeScene, "assets\\Sounds\\Shocked.mp3", false, 100, 1);
}}

}


};gdjs.MainCode.asyncCallback15224804 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.MainCode.localVariables);

{ //Subevents
gdjs.MainCode.eventsList127(runtimeScene, asyncObjectsList);} //End of subevents
gdjs.MainCode.localVariables.length = 0;
}
gdjs.MainCode.eventsList128 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
asyncObjectsList.backupLocalVariablesContainers(gdjs.MainCode.localVariables);
/* Don't save Next_button as it will be provided by the parent asyncObjectsList. */
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1), (runtimeScene) => (gdjs.MainCode.asyncCallback15224804(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.MainCode.eventsList129 = function(runtimeScene, asyncObjectsList) {

{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15638253);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("ScandalRiskTxt"), gdjs.MainCode.GDScandalRiskTxtObjects6);
gdjs.MainCode.GDRiskResultObjects6.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDRiskResultObjects6Objects, (( gdjs.MainCode.GDScandalRiskTxtObjects6.length === 0 ) ? 0 :gdjs.MainCode.GDScandalRiskTxtObjects6[0].getX()), (( gdjs.MainCode.GDScandalRiskTxtObjects6.length === 0 ) ? 0 :gdjs.MainCode.GDScandalRiskTxtObjects6[0].getY()), "");
}{for(var i = 0, len = gdjs.MainCode.GDRiskResultObjects6.length ;i < len;++i) {
    gdjs.MainCode.GDRiskResultObjects6[i].getBehavior("Text").setText("-1");
}
}{for(var i = 0, len = gdjs.MainCode.GDRiskResultObjects6.length ;i < len;++i) {
    gdjs.MainCode.GDRiskResultObjects6[i].setColor("65;117;5");
}
}{for(var i = 0, len = gdjs.MainCode.GDRiskResultObjects6.length ;i < len;++i) {
    gdjs.MainCode.GDRiskResultObjects6[i].addPolarForce(180, 50, 1);
}
}{for(var i = 0, len = gdjs.MainCode.GDRiskResultObjects6.length ;i < len;++i) {
    gdjs.MainCode.GDRiskResultObjects6[i].getBehavior("Tween").addObjectOpacityTween2("Opacity", 0, "linear", 2, true);
}
}{runtimeScene.getScene().getVariables().getFromIndex(5).sub(1);
}{gdjs.evtTools.sound.playSound(runtimeScene, "assets\\Sounds\\Yay.mp3", false, 100, 1);
}}

}


{


let isConditionTrue_0 = false;
{

{ //Subevents
gdjs.MainCode.eventsList128(runtimeScene, asyncObjectsList);} //End of subevents
}

}


};gdjs.MainCode.asyncCallback15224132 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.MainCode.localVariables);

{ //Subevents
gdjs.MainCode.eventsList129(runtimeScene, asyncObjectsList);} //End of subevents
gdjs.MainCode.localVariables.length = 0;
}
gdjs.MainCode.eventsList130 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
asyncObjectsList.backupLocalVariablesContainers(gdjs.MainCode.localVariables);
/* Don't save Next_button as it will be provided by the parent asyncObjectsList. */
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1), (runtimeScene) => (gdjs.MainCode.asyncCallback15224132(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.MainCode.eventsList131 = function(runtimeScene, asyncObjectsList) {

{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15634269);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("PublicApprovalTxt"), gdjs.MainCode.GDPublicApprovalTxtObjects5);
gdjs.MainCode.GDPAResultObjects5.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDPAResultObjects5Objects, (( gdjs.MainCode.GDPublicApprovalTxtObjects5.length === 0 ) ? 0 :gdjs.MainCode.GDPublicApprovalTxtObjects5[0].getX()), (( gdjs.MainCode.GDPublicApprovalTxtObjects5.length === 0 ) ? 0 :gdjs.MainCode.GDPublicApprovalTxtObjects5[0].getY()), "");
}{for(var i = 0, len = gdjs.MainCode.GDPAResultObjects5.length ;i < len;++i) {
    gdjs.MainCode.GDPAResultObjects5[i].getBehavior("Text").setText("+1");
}
}{for(var i = 0, len = gdjs.MainCode.GDPAResultObjects5.length ;i < len;++i) {
    gdjs.MainCode.GDPAResultObjects5[i].setColor("65;117;5");
}
}{for(var i = 0, len = gdjs.MainCode.GDPAResultObjects5.length ;i < len;++i) {
    gdjs.MainCode.GDPAResultObjects5[i].addPolarForce(180, 50, 1);
}
}{for(var i = 0, len = gdjs.MainCode.GDPAResultObjects5.length ;i < len;++i) {
    gdjs.MainCode.GDPAResultObjects5[i].getBehavior("Tween").addObjectOpacityTween2("Opacity", 0, "linear", 2, true);
}
}{runtimeScene.getScene().getVariables().getFromIndex(4).add(1);
}{gdjs.evtTools.sound.playSound(runtimeScene, "assets\\Sounds\\Yay.mp3", false, 100, 1);
}}

}


{


let isConditionTrue_0 = false;
{

{ //Subevents
gdjs.MainCode.eventsList130(runtimeScene, asyncObjectsList);} //End of subevents
}

}


};gdjs.MainCode.asyncCallback15223460 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.MainCode.localVariables);

{ //Subevents
gdjs.MainCode.eventsList131(runtimeScene, asyncObjectsList);} //End of subevents
gdjs.MainCode.localVariables.length = 0;
}
gdjs.MainCode.eventsList132 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
asyncObjectsList.backupLocalVariablesContainers(gdjs.MainCode.localVariables);
for (const obj of gdjs.MainCode.GDNext_9595buttonObjects2) asyncObjectsList.addObject("Next_button", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1), (runtimeScene) => (gdjs.MainCode.asyncCallback15223460(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.MainCode.eventsList133 = function(runtimeScene, asyncObjectsList) {

{


let isConditionTrue_0 = false;
{

{ //Subevents
gdjs.MainCode.eventsList126(runtimeScene, asyncObjectsList);} //End of subevents
}

}


{



}


{


let isConditionTrue_0 = false;
{

{ //Subevents
gdjs.MainCode.eventsList132(runtimeScene, asyncObjectsList);} //End of subevents
}

}


};gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDEconomyResultObjects6Objects = Hashtable.newFrom({"EconomyResult": gdjs.MainCode.GDEconomyResultObjects6});
gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDPAResultObjects7Objects = Hashtable.newFrom({"PAResult": gdjs.MainCode.GDPAResultObjects7});
gdjs.MainCode.eventsList134 = function(runtimeScene, asyncObjectsList) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("NextText"), gdjs.MainCode.GDNextTextObjects7);
gdjs.copyArray(asyncObjectsList.getObjects("Next_button"), gdjs.MainCode.GDNext_9595buttonObjects7);

{for(var i = 0, len = gdjs.MainCode.GDNext_9595buttonObjects7.length ;i < len;++i) {
    gdjs.MainCode.GDNext_9595buttonObjects7[i].hide(false);
}
for(var i = 0, len = gdjs.MainCode.GDNextTextObjects7.length ;i < len;++i) {
    gdjs.MainCode.GDNextTextObjects7[i].hide(false);
}
}}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15634270);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("PublicApprovalTxt"), gdjs.MainCode.GDPublicApprovalTxtObjects7);
gdjs.MainCode.GDPAResultObjects7.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDPAResultObjects7Objects, (( gdjs.MainCode.GDPublicApprovalTxtObjects7.length === 0 ) ? 0 :gdjs.MainCode.GDPublicApprovalTxtObjects7[0].getX()), (( gdjs.MainCode.GDPublicApprovalTxtObjects7.length === 0 ) ? 0 :gdjs.MainCode.GDPublicApprovalTxtObjects7[0].getY()), "");
}{for(var i = 0, len = gdjs.MainCode.GDPAResultObjects7.length ;i < len;++i) {
    gdjs.MainCode.GDPAResultObjects7[i].getBehavior("Text").setText("+1");
}
}{for(var i = 0, len = gdjs.MainCode.GDPAResultObjects7.length ;i < len;++i) {
    gdjs.MainCode.GDPAResultObjects7[i].setColor("65;117;5");
}
}{for(var i = 0, len = gdjs.MainCode.GDPAResultObjects7.length ;i < len;++i) {
    gdjs.MainCode.GDPAResultObjects7[i].addPolarForce(180, 50, 1);
}
}{for(var i = 0, len = gdjs.MainCode.GDPAResultObjects7.length ;i < len;++i) {
    gdjs.MainCode.GDPAResultObjects7[i].getBehavior("Tween").addObjectOpacityTween2("Opacity", 0, "linear", 2, true);
}
}{runtimeScene.getScene().getVariables().getFromIndex(4).add(1);
}{gdjs.evtTools.sound.playSound(runtimeScene, "assets\\Sounds\\Yay.mp3", false, 100, 1);
}}

}


{



}


};gdjs.MainCode.asyncCallback15227236 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.MainCode.localVariables);

{ //Subevents
gdjs.MainCode.eventsList134(runtimeScene, asyncObjectsList);} //End of subevents
gdjs.MainCode.localVariables.length = 0;
}
gdjs.MainCode.eventsList135 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
asyncObjectsList.backupLocalVariablesContainers(gdjs.MainCode.localVariables);
/* Don't save Next_button as it will be provided by the parent asyncObjectsList. */
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1), (runtimeScene) => (gdjs.MainCode.asyncCallback15227236(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.MainCode.eventsList136 = function(runtimeScene, asyncObjectsList) {

{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15630485);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("EconomyTxt"), gdjs.MainCode.GDEconomyTxtObjects6);
gdjs.MainCode.GDEconomyResultObjects6.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDEconomyResultObjects6Objects, (( gdjs.MainCode.GDEconomyTxtObjects6.length === 0 ) ? 0 :gdjs.MainCode.GDEconomyTxtObjects6[0].getX()), (( gdjs.MainCode.GDEconomyTxtObjects6.length === 0 ) ? 0 :gdjs.MainCode.GDEconomyTxtObjects6[0].getY()), "");
}{for(var i = 0, len = gdjs.MainCode.GDEconomyResultObjects6.length ;i < len;++i) {
    gdjs.MainCode.GDEconomyResultObjects6[i].getBehavior("Text").setText("+2");
}
}{for(var i = 0, len = gdjs.MainCode.GDEconomyResultObjects6.length ;i < len;++i) {
    gdjs.MainCode.GDEconomyResultObjects6[i].getBehavior("Tween").addObjectOpacityTween2("Opacity", 0, "linear", 2, true);
}
}{for(var i = 0, len = gdjs.MainCode.GDEconomyResultObjects6.length ;i < len;++i) {
    gdjs.MainCode.GDEconomyResultObjects6[i].setColor("65;117;5");
}
}{for(var i = 0, len = gdjs.MainCode.GDEconomyResultObjects6.length ;i < len;++i) {
    gdjs.MainCode.GDEconomyResultObjects6[i].addPolarForce(180, 50, 1);
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "assets\\Sounds\\Yay.mp3", false, 100, 1);
}}

}


{


let isConditionTrue_0 = false;
{

{ //Subevents
gdjs.MainCode.eventsList135(runtimeScene, asyncObjectsList);} //End of subevents
}

}


};gdjs.MainCode.asyncCallback15226564 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.MainCode.localVariables);

{ //Subevents
gdjs.MainCode.eventsList136(runtimeScene, asyncObjectsList);} //End of subevents
gdjs.MainCode.localVariables.length = 0;
}
gdjs.MainCode.eventsList137 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
asyncObjectsList.backupLocalVariablesContainers(gdjs.MainCode.localVariables);
for (const obj of gdjs.MainCode.GDNext_9595buttonObjects2) asyncObjectsList.addObject("Next_button", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1), (runtimeScene) => (gdjs.MainCode.asyncCallback15226564(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.MainCode.eventsList138 = function(runtimeScene, asyncObjectsList) {

{


let isConditionTrue_0 = false;
{

{ //Subevents
gdjs.MainCode.eventsList137(runtimeScene, asyncObjectsList);} //End of subevents
}

}


{



}


{



}


{



}


};gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDPAResultObjects5Objects = Hashtable.newFrom({"PAResult": gdjs.MainCode.GDPAResultObjects5});
gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDRiskResultObjects6Objects = Hashtable.newFrom({"RiskResult": gdjs.MainCode.GDRiskResultObjects6});
gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDPersonalWealthResultObjects6Objects = Hashtable.newFrom({"PersonalWealthResult": gdjs.MainCode.GDPersonalWealthResultObjects6});
gdjs.MainCode.eventsList139 = function(runtimeScene, asyncObjectsList) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("NextText"), gdjs.MainCode.GDNextTextObjects7);
gdjs.copyArray(asyncObjectsList.getObjects("Next_button"), gdjs.MainCode.GDNext_9595buttonObjects7);

{for(var i = 0, len = gdjs.MainCode.GDNext_9595buttonObjects7.length ;i < len;++i) {
    gdjs.MainCode.GDNext_9595buttonObjects7[i].hide(false);
}
for(var i = 0, len = gdjs.MainCode.GDNextTextObjects7.length ;i < len;++i) {
    gdjs.MainCode.GDNextTextObjects7[i].hide(false);
}
}}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15644156);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("PersonalGainsTxt"), gdjs.MainCode.GDPersonalGainsTxtObjects6);
gdjs.MainCode.GDPersonalWealthResultObjects6.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDPersonalWealthResultObjects6Objects, (( gdjs.MainCode.GDPersonalGainsTxtObjects6.length === 0 ) ? 0 :gdjs.MainCode.GDPersonalGainsTxtObjects6[0].getX()), (( gdjs.MainCode.GDPersonalGainsTxtObjects6.length === 0 ) ? 0 :gdjs.MainCode.GDPersonalGainsTxtObjects6[0].getY()), "");
}{for(var i = 0, len = gdjs.MainCode.GDPersonalWealthResultObjects6.length ;i < len;++i) {
    gdjs.MainCode.GDPersonalWealthResultObjects6[i].getBehavior("Text").setText("-2");
}
}{for(var i = 0, len = gdjs.MainCode.GDPersonalWealthResultObjects6.length ;i < len;++i) {
    gdjs.MainCode.GDPersonalWealthResultObjects6[i].setColor("208;2;27");
}
}{for(var i = 0, len = gdjs.MainCode.GDPersonalWealthResultObjects6.length ;i < len;++i) {
    gdjs.MainCode.GDPersonalWealthResultObjects6[i].addPolarForce(180, 50, 1);
}
}{for(var i = 0, len = gdjs.MainCode.GDPersonalWealthResultObjects6.length ;i < len;++i) {
    gdjs.MainCode.GDPersonalWealthResultObjects6[i].getBehavior("Tween").addObjectOpacityTween2("Opacity", 0, "linear", 2, true);
}
}{runtimeScene.getScene().getVariables().getFromIndex(6).sub(2);
}{gdjs.evtTools.sound.playSound(runtimeScene, "assets\\Sounds\\Shocked.mp3", false, 100, 1);
}}

}


};gdjs.MainCode.asyncCallback15231828 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.MainCode.localVariables);

{ //Subevents
gdjs.MainCode.eventsList139(runtimeScene, asyncObjectsList);} //End of subevents
gdjs.MainCode.localVariables.length = 0;
}
gdjs.MainCode.eventsList140 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
asyncObjectsList.backupLocalVariablesContainers(gdjs.MainCode.localVariables);
/* Don't save Next_button as it will be provided by the parent asyncObjectsList. */
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1), (runtimeScene) => (gdjs.MainCode.asyncCallback15231828(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.MainCode.eventsList141 = function(runtimeScene, asyncObjectsList) {

{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15640382);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("ScandalRiskTxt"), gdjs.MainCode.GDScandalRiskTxtObjects6);
gdjs.MainCode.GDRiskResultObjects6.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDRiskResultObjects6Objects, (( gdjs.MainCode.GDScandalRiskTxtObjects6.length === 0 ) ? 0 :gdjs.MainCode.GDScandalRiskTxtObjects6[0].getX()), (( gdjs.MainCode.GDScandalRiskTxtObjects6.length === 0 ) ? 0 :gdjs.MainCode.GDScandalRiskTxtObjects6[0].getY()), "");
}{for(var i = 0, len = gdjs.MainCode.GDRiskResultObjects6.length ;i < len;++i) {
    gdjs.MainCode.GDRiskResultObjects6[i].getBehavior("Text").setText("+1");
}
}{for(var i = 0, len = gdjs.MainCode.GDRiskResultObjects6.length ;i < len;++i) {
    gdjs.MainCode.GDRiskResultObjects6[i].setColor("208;2;27");
}
}{for(var i = 0, len = gdjs.MainCode.GDRiskResultObjects6.length ;i < len;++i) {
    gdjs.MainCode.GDRiskResultObjects6[i].addPolarForce(180, 50, 1);
}
}{for(var i = 0, len = gdjs.MainCode.GDRiskResultObjects6.length ;i < len;++i) {
    gdjs.MainCode.GDRiskResultObjects6[i].getBehavior("Tween").addObjectOpacityTween2("Opacity", 0, "linear", 2, true);
}
}{runtimeScene.getScene().getVariables().getFromIndex(5).add(1);
}{gdjs.evtTools.sound.playSound(runtimeScene, "assets\\Sounds\\Shocked.mp3", false, 100, 1);
}}

}


{


let isConditionTrue_0 = false;
{

{ //Subevents
gdjs.MainCode.eventsList140(runtimeScene, asyncObjectsList);} //End of subevents
}

}


};gdjs.MainCode.asyncCallback15231156 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.MainCode.localVariables);

{ //Subevents
gdjs.MainCode.eventsList141(runtimeScene, asyncObjectsList);} //End of subevents
gdjs.MainCode.localVariables.length = 0;
}
gdjs.MainCode.eventsList142 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
asyncObjectsList.backupLocalVariablesContainers(gdjs.MainCode.localVariables);
/* Don't save Next_button as it will be provided by the parent asyncObjectsList. */
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1), (runtimeScene) => (gdjs.MainCode.asyncCallback15231156(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.MainCode.eventsList143 = function(runtimeScene, asyncObjectsList) {

{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15632280);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("PublicApprovalTxt"), gdjs.MainCode.GDPublicApprovalTxtObjects5);
gdjs.MainCode.GDPAResultObjects5.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDPAResultObjects5Objects, (( gdjs.MainCode.GDPublicApprovalTxtObjects5.length === 0 ) ? 0 :gdjs.MainCode.GDPublicApprovalTxtObjects5[0].getX()), (( gdjs.MainCode.GDPublicApprovalTxtObjects5.length === 0 ) ? 0 :gdjs.MainCode.GDPublicApprovalTxtObjects5[0].getY()), "");
}{for(var i = 0, len = gdjs.MainCode.GDPAResultObjects5.length ;i < len;++i) {
    gdjs.MainCode.GDPAResultObjects5[i].getBehavior("Text").setText("-1");
}
}{for(var i = 0, len = gdjs.MainCode.GDPAResultObjects5.length ;i < len;++i) {
    gdjs.MainCode.GDPAResultObjects5[i].setColor("208;2;27");
}
}{for(var i = 0, len = gdjs.MainCode.GDPAResultObjects5.length ;i < len;++i) {
    gdjs.MainCode.GDPAResultObjects5[i].addPolarForce(180, 50, 1);
}
}{for(var i = 0, len = gdjs.MainCode.GDPAResultObjects5.length ;i < len;++i) {
    gdjs.MainCode.GDPAResultObjects5[i].getBehavior("Tween").addObjectOpacityTween2("Opacity", 0, "linear", 2, true);
}
}{runtimeScene.getScene().getVariables().getFromIndex(4).sub(1);
}{gdjs.evtTools.sound.playSound(runtimeScene, "assets\\Sounds\\Shocked.mp3", false, 100, 1);
}}

}


{


let isConditionTrue_0 = false;
{

{ //Subevents
gdjs.MainCode.eventsList142(runtimeScene, asyncObjectsList);} //End of subevents
}

}


};gdjs.MainCode.asyncCallback15230508 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.MainCode.localVariables);

{ //Subevents
gdjs.MainCode.eventsList143(runtimeScene, asyncObjectsList);} //End of subevents
gdjs.MainCode.localVariables.length = 0;
}
gdjs.MainCode.eventsList144 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
asyncObjectsList.backupLocalVariablesContainers(gdjs.MainCode.localVariables);
for (const obj of gdjs.MainCode.GDNext_9595buttonObjects2) asyncObjectsList.addObject("Next_button", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1), (runtimeScene) => (gdjs.MainCode.asyncCallback15230508(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.MainCode.eventsList145 = function(runtimeScene, asyncObjectsList) {

{



}


{


let isConditionTrue_0 = false;
{

{ //Subevents
gdjs.MainCode.eventsList144(runtimeScene, asyncObjectsList);} //End of subevents
}

}


};gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDPAResultObjects6Objects = Hashtable.newFrom({"PAResult": gdjs.MainCode.GDPAResultObjects6});
gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDRiskResultObjects6Objects = Hashtable.newFrom({"RiskResult": gdjs.MainCode.GDRiskResultObjects6});
gdjs.MainCode.eventsList146 = function(runtimeScene, asyncObjectsList) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("NextText"), gdjs.MainCode.GDNextTextObjects7);
gdjs.copyArray(asyncObjectsList.getObjects("Next_button"), gdjs.MainCode.GDNext_9595buttonObjects7);

{for(var i = 0, len = gdjs.MainCode.GDNext_9595buttonObjects7.length ;i < len;++i) {
    gdjs.MainCode.GDNext_9595buttonObjects7[i].hide(false);
}
for(var i = 0, len = gdjs.MainCode.GDNextTextObjects7.length ;i < len;++i) {
    gdjs.MainCode.GDNextTextObjects7[i].hide(false);
}
}}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15638254);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("ScandalRiskTxt"), gdjs.MainCode.GDScandalRiskTxtObjects6);
gdjs.MainCode.GDRiskResultObjects6.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDRiskResultObjects6Objects, (( gdjs.MainCode.GDScandalRiskTxtObjects6.length === 0 ) ? 0 :gdjs.MainCode.GDScandalRiskTxtObjects6[0].getX()), (( gdjs.MainCode.GDScandalRiskTxtObjects6.length === 0 ) ? 0 :gdjs.MainCode.GDScandalRiskTxtObjects6[0].getY()), "");
}{for(var i = 0, len = gdjs.MainCode.GDRiskResultObjects6.length ;i < len;++i) {
    gdjs.MainCode.GDRiskResultObjects6[i].getBehavior("Text").setText("-1");
}
}{for(var i = 0, len = gdjs.MainCode.GDRiskResultObjects6.length ;i < len;++i) {
    gdjs.MainCode.GDRiskResultObjects6[i].setColor("65;117;5");
}
}{for(var i = 0, len = gdjs.MainCode.GDRiskResultObjects6.length ;i < len;++i) {
    gdjs.MainCode.GDRiskResultObjects6[i].addPolarForce(180, 50, 1);
}
}{for(var i = 0, len = gdjs.MainCode.GDRiskResultObjects6.length ;i < len;++i) {
    gdjs.MainCode.GDRiskResultObjects6[i].getBehavior("Tween").addObjectOpacityTween2("Opacity", 0, "linear", 2, true);
}
}{runtimeScene.getScene().getVariables().getFromIndex(5).sub(1);
}{gdjs.evtTools.sound.playSound(runtimeScene, "assets\\Sounds\\Yay.mp3", false, 100, 1);
}}

}


};gdjs.MainCode.asyncCallback15234492 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.MainCode.localVariables);

{ //Subevents
gdjs.MainCode.eventsList146(runtimeScene, asyncObjectsList);} //End of subevents
gdjs.MainCode.localVariables.length = 0;
}
gdjs.MainCode.eventsList147 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
asyncObjectsList.backupLocalVariablesContainers(gdjs.MainCode.localVariables);
/* Don't save Next_button as it will be provided by the parent asyncObjectsList. */
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1), (runtimeScene) => (gdjs.MainCode.asyncCallback15234492(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.MainCode.eventsList148 = function(runtimeScene, asyncObjectsList) {

{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15634271);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("PublicApprovalTxt"), gdjs.MainCode.GDPublicApprovalTxtObjects6);
gdjs.MainCode.GDPAResultObjects6.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDPAResultObjects6Objects, (( gdjs.MainCode.GDPublicApprovalTxtObjects6.length === 0 ) ? 0 :gdjs.MainCode.GDPublicApprovalTxtObjects6[0].getX()), (( gdjs.MainCode.GDPublicApprovalTxtObjects6.length === 0 ) ? 0 :gdjs.MainCode.GDPublicApprovalTxtObjects6[0].getY()), "");
}{for(var i = 0, len = gdjs.MainCode.GDPAResultObjects6.length ;i < len;++i) {
    gdjs.MainCode.GDPAResultObjects6[i].getBehavior("Text").setText("+1");
}
}{for(var i = 0, len = gdjs.MainCode.GDPAResultObjects6.length ;i < len;++i) {
    gdjs.MainCode.GDPAResultObjects6[i].setColor("65;117;5");
}
}{for(var i = 0, len = gdjs.MainCode.GDPAResultObjects6.length ;i < len;++i) {
    gdjs.MainCode.GDPAResultObjects6[i].addPolarForce(180, 50, 1);
}
}{for(var i = 0, len = gdjs.MainCode.GDPAResultObjects6.length ;i < len;++i) {
    gdjs.MainCode.GDPAResultObjects6[i].getBehavior("Tween").addObjectOpacityTween2("Opacity", 0, "linear", 2, true);
}
}{runtimeScene.getScene().getVariables().getFromIndex(4).add(1);
}{gdjs.evtTools.sound.playSound(runtimeScene, "assets\\Sounds\\Yay.mp3", false, 100, 1);
}}

}


{


let isConditionTrue_0 = false;
{

{ //Subevents
gdjs.MainCode.eventsList147(runtimeScene, asyncObjectsList);} //End of subevents
}

}


};gdjs.MainCode.asyncCallback15233820 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.MainCode.localVariables);

{ //Subevents
gdjs.MainCode.eventsList148(runtimeScene, asyncObjectsList);} //End of subevents
gdjs.MainCode.localVariables.length = 0;
}
gdjs.MainCode.eventsList149 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
asyncObjectsList.backupLocalVariablesContainers(gdjs.MainCode.localVariables);
for (const obj of gdjs.MainCode.GDNext_9595buttonObjects2) asyncObjectsList.addObject("Next_button", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1), (runtimeScene) => (gdjs.MainCode.asyncCallback15233820(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.MainCode.eventsList150 = function(runtimeScene, asyncObjectsList) {

{



}


{


let isConditionTrue_0 = false;
{

{ //Subevents
gdjs.MainCode.eventsList149(runtimeScene, asyncObjectsList);} //End of subevents
}

}


{



}


{



}


};gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDEconomyResultObjects4Objects = Hashtable.newFrom({"EconomyResult": gdjs.MainCode.GDEconomyResultObjects4});
gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDPAResultObjects5Objects = Hashtable.newFrom({"PAResult": gdjs.MainCode.GDPAResultObjects5});
gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDRiskResultObjects6Objects = Hashtable.newFrom({"RiskResult": gdjs.MainCode.GDRiskResultObjects6});
gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDPersonalWealthResultObjects6Objects = Hashtable.newFrom({"PersonalWealthResult": gdjs.MainCode.GDPersonalWealthResultObjects6});
gdjs.MainCode.eventsList151 = function(runtimeScene, asyncObjectsList) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("NextText"), gdjs.MainCode.GDNextTextObjects7);
gdjs.copyArray(asyncObjectsList.getObjects("Next_button"), gdjs.MainCode.GDNext_9595buttonObjects7);

{for(var i = 0, len = gdjs.MainCode.GDNext_9595buttonObjects7.length ;i < len;++i) {
    gdjs.MainCode.GDNext_9595buttonObjects7[i].hide(false);
}
for(var i = 0, len = gdjs.MainCode.GDNextTextObjects7.length ;i < len;++i) {
    gdjs.MainCode.GDNextTextObjects7[i].hide(false);
}
}}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15644086);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("PersonalGainsTxt"), gdjs.MainCode.GDPersonalGainsTxtObjects6);
gdjs.MainCode.GDPersonalWealthResultObjects6.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDPersonalWealthResultObjects6Objects, (( gdjs.MainCode.GDPersonalGainsTxtObjects6.length === 0 ) ? 0 :gdjs.MainCode.GDPersonalGainsTxtObjects6[0].getX()), (( gdjs.MainCode.GDPersonalGainsTxtObjects6.length === 0 ) ? 0 :gdjs.MainCode.GDPersonalGainsTxtObjects6[0].getY()), "");
}{for(var i = 0, len = gdjs.MainCode.GDPersonalWealthResultObjects6.length ;i < len;++i) {
    gdjs.MainCode.GDPersonalWealthResultObjects6[i].getBehavior("Text").setText("-1");
}
}{for(var i = 0, len = gdjs.MainCode.GDPersonalWealthResultObjects6.length ;i < len;++i) {
    gdjs.MainCode.GDPersonalWealthResultObjects6[i].setColor("208;2;27");
}
}{for(var i = 0, len = gdjs.MainCode.GDPersonalWealthResultObjects6.length ;i < len;++i) {
    gdjs.MainCode.GDPersonalWealthResultObjects6[i].addPolarForce(180, 50, 1);
}
}{for(var i = 0, len = gdjs.MainCode.GDPersonalWealthResultObjects6.length ;i < len;++i) {
    gdjs.MainCode.GDPersonalWealthResultObjects6[i].getBehavior("Tween").addObjectOpacityTween2("Opacity", 0, "linear", 2, true);
}
}{runtimeScene.getScene().getVariables().getFromIndex(6).sub(1);
}{gdjs.evtTools.sound.playSound(runtimeScene, "assets\\Sounds\\Shocked.mp3", false, 100, 1);
}}

}


};gdjs.MainCode.asyncCallback15238476 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.MainCode.localVariables);

{ //Subevents
gdjs.MainCode.eventsList151(runtimeScene, asyncObjectsList);} //End of subevents
gdjs.MainCode.localVariables.length = 0;
}
gdjs.MainCode.eventsList152 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
asyncObjectsList.backupLocalVariablesContainers(gdjs.MainCode.localVariables);
/* Don't save Next_button as it will be provided by the parent asyncObjectsList. */
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1), (runtimeScene) => (gdjs.MainCode.asyncCallback15238476(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.MainCode.eventsList153 = function(runtimeScene, asyncObjectsList) {

{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15640383);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("ScandalRiskTxt"), gdjs.MainCode.GDScandalRiskTxtObjects6);
gdjs.MainCode.GDRiskResultObjects6.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDRiskResultObjects6Objects, (( gdjs.MainCode.GDScandalRiskTxtObjects6.length === 0 ) ? 0 :gdjs.MainCode.GDScandalRiskTxtObjects6[0].getX()), (( gdjs.MainCode.GDScandalRiskTxtObjects6.length === 0 ) ? 0 :gdjs.MainCode.GDScandalRiskTxtObjects6[0].getY()), "");
}{for(var i = 0, len = gdjs.MainCode.GDRiskResultObjects6.length ;i < len;++i) {
    gdjs.MainCode.GDRiskResultObjects6[i].getBehavior("Text").setText("+1");
}
}{for(var i = 0, len = gdjs.MainCode.GDRiskResultObjects6.length ;i < len;++i) {
    gdjs.MainCode.GDRiskResultObjects6[i].setColor("208;2;27");
}
}{for(var i = 0, len = gdjs.MainCode.GDRiskResultObjects6.length ;i < len;++i) {
    gdjs.MainCode.GDRiskResultObjects6[i].addPolarForce(180, 50, 1);
}
}{for(var i = 0, len = gdjs.MainCode.GDRiskResultObjects6.length ;i < len;++i) {
    gdjs.MainCode.GDRiskResultObjects6[i].getBehavior("Tween").addObjectOpacityTween2("Opacity", 0, "linear", 2, true);
}
}{runtimeScene.getScene().getVariables().getFromIndex(5).add(1);
}{gdjs.evtTools.sound.playSound(runtimeScene, "assets\\Sounds\\Shocked.mp3", false, 100, 1);
}}

}


{


let isConditionTrue_0 = false;
{

{ //Subevents
gdjs.MainCode.eventsList152(runtimeScene, asyncObjectsList);} //End of subevents
}

}


};gdjs.MainCode.asyncCallback15237804 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.MainCode.localVariables);

{ //Subevents
gdjs.MainCode.eventsList153(runtimeScene, asyncObjectsList);} //End of subevents
gdjs.MainCode.localVariables.length = 0;
}
gdjs.MainCode.eventsList154 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
asyncObjectsList.backupLocalVariablesContainers(gdjs.MainCode.localVariables);
/* Don't save Next_button as it will be provided by the parent asyncObjectsList. */
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1), (runtimeScene) => (gdjs.MainCode.asyncCallback15237804(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.MainCode.eventsList155 = function(runtimeScene, asyncObjectsList) {

{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15634272);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("PublicApprovalTxt"), gdjs.MainCode.GDPublicApprovalTxtObjects5);
gdjs.MainCode.GDPAResultObjects5.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDPAResultObjects5Objects, (( gdjs.MainCode.GDPublicApprovalTxtObjects5.length === 0 ) ? 0 :gdjs.MainCode.GDPublicApprovalTxtObjects5[0].getX()), (( gdjs.MainCode.GDPublicApprovalTxtObjects5.length === 0 ) ? 0 :gdjs.MainCode.GDPublicApprovalTxtObjects5[0].getY()), "");
}{for(var i = 0, len = gdjs.MainCode.GDPAResultObjects5.length ;i < len;++i) {
    gdjs.MainCode.GDPAResultObjects5[i].getBehavior("Text").setText("+1");
}
}{for(var i = 0, len = gdjs.MainCode.GDPAResultObjects5.length ;i < len;++i) {
    gdjs.MainCode.GDPAResultObjects5[i].setColor("65;117;5");
}
}{for(var i = 0, len = gdjs.MainCode.GDPAResultObjects5.length ;i < len;++i) {
    gdjs.MainCode.GDPAResultObjects5[i].addPolarForce(180, 50, 1);
}
}{for(var i = 0, len = gdjs.MainCode.GDPAResultObjects5.length ;i < len;++i) {
    gdjs.MainCode.GDPAResultObjects5[i].getBehavior("Tween").addObjectOpacityTween2("Opacity", 0, "linear", 2, true);
}
}{runtimeScene.getScene().getVariables().getFromIndex(4).add(1);
}{gdjs.evtTools.sound.playSound(runtimeScene, "assets\\Sounds\\Yay.mp3", false, 100, 1);
}}

}


{


let isConditionTrue_0 = false;
{

{ //Subevents
gdjs.MainCode.eventsList154(runtimeScene, asyncObjectsList);} //End of subevents
}

}


};gdjs.MainCode.asyncCallback15237132 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.MainCode.localVariables);

{ //Subevents
gdjs.MainCode.eventsList155(runtimeScene, asyncObjectsList);} //End of subevents
gdjs.MainCode.localVariables.length = 0;
}
gdjs.MainCode.eventsList156 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
asyncObjectsList.backupLocalVariablesContainers(gdjs.MainCode.localVariables);
for (const obj of gdjs.MainCode.GDNext_9595buttonObjects2) asyncObjectsList.addObject("Next_button", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1), (runtimeScene) => (gdjs.MainCode.asyncCallback15237132(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.MainCode.eventsList157 = function(runtimeScene, asyncObjectsList) {

{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15628470);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("EconomyTxt"), gdjs.MainCode.GDEconomyTxtObjects4);
gdjs.MainCode.GDEconomyResultObjects4.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDEconomyResultObjects4Objects, (( gdjs.MainCode.GDEconomyTxtObjects4.length === 0 ) ? 0 :gdjs.MainCode.GDEconomyTxtObjects4[0].getX()), (( gdjs.MainCode.GDEconomyTxtObjects4.length === 0 ) ? 0 :gdjs.MainCode.GDEconomyTxtObjects4[0].getY()), "");
}{for(var i = 0, len = gdjs.MainCode.GDEconomyResultObjects4.length ;i < len;++i) {
    gdjs.MainCode.GDEconomyResultObjects4[i].getBehavior("Text").setText("-1");
}
}{for(var i = 0, len = gdjs.MainCode.GDEconomyResultObjects4.length ;i < len;++i) {
    gdjs.MainCode.GDEconomyResultObjects4[i].getBehavior("Tween").addObjectOpacityTween2("Opacity", 0, "linear", 2, true);
}
}{for(var i = 0, len = gdjs.MainCode.GDEconomyResultObjects4.length ;i < len;++i) {
    gdjs.MainCode.GDEconomyResultObjects4[i].setColor("208;2;27");
}
}{for(var i = 0, len = gdjs.MainCode.GDEconomyResultObjects4.length ;i < len;++i) {
    gdjs.MainCode.GDEconomyResultObjects4[i].addPolarForce(180, 50, 1);
}
}{runtimeScene.getScene().getVariables().getFromIndex(3).sub(1);
}{gdjs.evtTools.sound.playSound(runtimeScene, "assets\\Sounds\\Shocked.mp3", false, 100, 1);
}}

}


{


let isConditionTrue_0 = false;
{

{ //Subevents
gdjs.MainCode.eventsList156(runtimeScene, asyncObjectsList);} //End of subevents
}

}


};gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDPAResultObjects5Objects = Hashtable.newFrom({"PAResult": gdjs.MainCode.GDPAResultObjects5});
gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDRiskResultObjects6Objects = Hashtable.newFrom({"RiskResult": gdjs.MainCode.GDRiskResultObjects6});
gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDPersonalWealthResultObjects6Objects = Hashtable.newFrom({"PersonalWealthResult": gdjs.MainCode.GDPersonalWealthResultObjects6});
gdjs.MainCode.eventsList158 = function(runtimeScene, asyncObjectsList) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("NextText"), gdjs.MainCode.GDNextTextObjects7);
gdjs.copyArray(asyncObjectsList.getObjects("Next_button"), gdjs.MainCode.GDNext_9595buttonObjects7);

{for(var i = 0, len = gdjs.MainCode.GDNext_9595buttonObjects7.length ;i < len;++i) {
    gdjs.MainCode.GDNext_9595buttonObjects7[i].hide(false);
}
for(var i = 0, len = gdjs.MainCode.GDNextTextObjects7.length ;i < len;++i) {
    gdjs.MainCode.GDNextTextObjects7[i].hide(false);
}
}}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15648973);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("PersonalGainsTxt"), gdjs.MainCode.GDPersonalGainsTxtObjects6);
gdjs.MainCode.GDPersonalWealthResultObjects6.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDPersonalWealthResultObjects6Objects, (( gdjs.MainCode.GDPersonalGainsTxtObjects6.length === 0 ) ? 0 :gdjs.MainCode.GDPersonalGainsTxtObjects6[0].getX()), (( gdjs.MainCode.GDPersonalGainsTxtObjects6.length === 0 ) ? 0 :gdjs.MainCode.GDPersonalGainsTxtObjects6[0].getY()), "");
}{for(var i = 0, len = gdjs.MainCode.GDPersonalWealthResultObjects6.length ;i < len;++i) {
    gdjs.MainCode.GDPersonalWealthResultObjects6[i].getBehavior("Text").setText("+2");
}
}{for(var i = 0, len = gdjs.MainCode.GDPersonalWealthResultObjects6.length ;i < len;++i) {
    gdjs.MainCode.GDPersonalWealthResultObjects6[i].setColor("65;117;5");
}
}{for(var i = 0, len = gdjs.MainCode.GDPersonalWealthResultObjects6.length ;i < len;++i) {
    gdjs.MainCode.GDPersonalWealthResultObjects6[i].addPolarForce(180, 50, 1);
}
}{for(var i = 0, len = gdjs.MainCode.GDPersonalWealthResultObjects6.length ;i < len;++i) {
    gdjs.MainCode.GDPersonalWealthResultObjects6[i].getBehavior("Tween").addObjectOpacityTween2("Opacity", 0, "linear", 2, true);
}
}{runtimeScene.getScene().getVariables().getFromIndex(6).add(2);
}{gdjs.evtTools.sound.playSound(runtimeScene, "assets\\Sounds\\Yay.mp3", false, 100, 1);
}}

}


};gdjs.MainCode.asyncCallback15241812 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.MainCode.localVariables);

{ //Subevents
gdjs.MainCode.eventsList158(runtimeScene, asyncObjectsList);} //End of subevents
gdjs.MainCode.localVariables.length = 0;
}
gdjs.MainCode.eventsList159 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
asyncObjectsList.backupLocalVariablesContainers(gdjs.MainCode.localVariables);
/* Don't save Next_button as it will be provided by the parent asyncObjectsList. */
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1), (runtimeScene) => (gdjs.MainCode.asyncCallback15241812(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.MainCode.eventsList160 = function(runtimeScene, asyncObjectsList) {

{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15640384);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("ScandalRiskTxt"), gdjs.MainCode.GDScandalRiskTxtObjects6);
gdjs.MainCode.GDRiskResultObjects6.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDRiskResultObjects6Objects, (( gdjs.MainCode.GDScandalRiskTxtObjects6.length === 0 ) ? 0 :gdjs.MainCode.GDScandalRiskTxtObjects6[0].getX()), (( gdjs.MainCode.GDScandalRiskTxtObjects6.length === 0 ) ? 0 :gdjs.MainCode.GDScandalRiskTxtObjects6[0].getY()), "");
}{for(var i = 0, len = gdjs.MainCode.GDRiskResultObjects6.length ;i < len;++i) {
    gdjs.MainCode.GDRiskResultObjects6[i].getBehavior("Text").setText("+1");
}
}{for(var i = 0, len = gdjs.MainCode.GDRiskResultObjects6.length ;i < len;++i) {
    gdjs.MainCode.GDRiskResultObjects6[i].setColor("208;2;27");
}
}{for(var i = 0, len = gdjs.MainCode.GDRiskResultObjects6.length ;i < len;++i) {
    gdjs.MainCode.GDRiskResultObjects6[i].addPolarForce(180, 50, 1);
}
}{for(var i = 0, len = gdjs.MainCode.GDRiskResultObjects6.length ;i < len;++i) {
    gdjs.MainCode.GDRiskResultObjects6[i].getBehavior("Tween").addObjectOpacityTween2("Opacity", 0, "linear", 2, true);
}
}{runtimeScene.getScene().getVariables().getFromIndex(5).add(1);
}{gdjs.evtTools.sound.playSound(runtimeScene, "assets\\Sounds\\Shocked.mp3", false, 100, 1);
}}

}


{


let isConditionTrue_0 = false;
{

{ //Subevents
gdjs.MainCode.eventsList159(runtimeScene, asyncObjectsList);} //End of subevents
}

}


};gdjs.MainCode.asyncCallback15241140 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.MainCode.localVariables);

{ //Subevents
gdjs.MainCode.eventsList160(runtimeScene, asyncObjectsList);} //End of subevents
gdjs.MainCode.localVariables.length = 0;
}
gdjs.MainCode.eventsList161 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
asyncObjectsList.backupLocalVariablesContainers(gdjs.MainCode.localVariables);
/* Don't save Next_button as it will be provided by the parent asyncObjectsList. */
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1), (runtimeScene) => (gdjs.MainCode.asyncCallback15241140(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.MainCode.eventsList162 = function(runtimeScene, asyncObjectsList) {

{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15632281);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("PublicApprovalTxt"), gdjs.MainCode.GDPublicApprovalTxtObjects5);
gdjs.MainCode.GDPAResultObjects5.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDPAResultObjects5Objects, (( gdjs.MainCode.GDPublicApprovalTxtObjects5.length === 0 ) ? 0 :gdjs.MainCode.GDPublicApprovalTxtObjects5[0].getX()), (( gdjs.MainCode.GDPublicApprovalTxtObjects5.length === 0 ) ? 0 :gdjs.MainCode.GDPublicApprovalTxtObjects5[0].getY()), "");
}{for(var i = 0, len = gdjs.MainCode.GDPAResultObjects5.length ;i < len;++i) {
    gdjs.MainCode.GDPAResultObjects5[i].getBehavior("Text").setText("-1");
}
}{for(var i = 0, len = gdjs.MainCode.GDPAResultObjects5.length ;i < len;++i) {
    gdjs.MainCode.GDPAResultObjects5[i].setColor("208;2;27");
}
}{for(var i = 0, len = gdjs.MainCode.GDPAResultObjects5.length ;i < len;++i) {
    gdjs.MainCode.GDPAResultObjects5[i].addPolarForce(180, 50, 1);
}
}{for(var i = 0, len = gdjs.MainCode.GDPAResultObjects5.length ;i < len;++i) {
    gdjs.MainCode.GDPAResultObjects5[i].getBehavior("Tween").addObjectOpacityTween2("Opacity", 0, "linear", 2, true);
}
}{runtimeScene.getScene().getVariables().getFromIndex(4).sub(1);
}{gdjs.evtTools.sound.playSound(runtimeScene, "assets\\Sounds\\Shocked.mp3", false, 100, 1);
}}

}


{


let isConditionTrue_0 = false;
{

{ //Subevents
gdjs.MainCode.eventsList161(runtimeScene, asyncObjectsList);} //End of subevents
}

}


};gdjs.MainCode.asyncCallback15240468 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.MainCode.localVariables);

{ //Subevents
gdjs.MainCode.eventsList162(runtimeScene, asyncObjectsList);} //End of subevents
gdjs.MainCode.localVariables.length = 0;
}
gdjs.MainCode.eventsList163 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
asyncObjectsList.backupLocalVariablesContainers(gdjs.MainCode.localVariables);
for (const obj of gdjs.MainCode.GDNext_9595buttonObjects2) asyncObjectsList.addObject("Next_button", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1), (runtimeScene) => (gdjs.MainCode.asyncCallback15240468(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.MainCode.eventsList164 = function(runtimeScene, asyncObjectsList) {

{



}


{


let isConditionTrue_0 = false;
{

{ //Subevents
gdjs.MainCode.eventsList163(runtimeScene, asyncObjectsList);} //End of subevents
}

}


};gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDPAResultObjects5Objects = Hashtable.newFrom({"PAResult": gdjs.MainCode.GDPAResultObjects5});
gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDRiskResultObjects6Objects = Hashtable.newFrom({"RiskResult": gdjs.MainCode.GDRiskResultObjects6});
gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDPersonalWealthResultObjects6Objects = Hashtable.newFrom({"PersonalWealthResult": gdjs.MainCode.GDPersonalWealthResultObjects6});
gdjs.MainCode.eventsList165 = function(runtimeScene, asyncObjectsList) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("NextText"), gdjs.MainCode.GDNextTextObjects7);
gdjs.copyArray(asyncObjectsList.getObjects("Next_button"), gdjs.MainCode.GDNext_9595buttonObjects7);

{for(var i = 0, len = gdjs.MainCode.GDNext_9595buttonObjects7.length ;i < len;++i) {
    gdjs.MainCode.GDNext_9595buttonObjects7[i].hide(false);
}
for(var i = 0, len = gdjs.MainCode.GDNextTextObjects7.length ;i < len;++i) {
    gdjs.MainCode.GDNextTextObjects7[i].hide(false);
}
}}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15648575);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("PersonalGainsTxt"), gdjs.MainCode.GDPersonalGainsTxtObjects6);
gdjs.MainCode.GDPersonalWealthResultObjects6.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDPersonalWealthResultObjects6Objects, (( gdjs.MainCode.GDPersonalGainsTxtObjects6.length === 0 ) ? 0 :gdjs.MainCode.GDPersonalGainsTxtObjects6[0].getX()), (( gdjs.MainCode.GDPersonalGainsTxtObjects6.length === 0 ) ? 0 :gdjs.MainCode.GDPersonalGainsTxtObjects6[0].getY()), "");
}{for(var i = 0, len = gdjs.MainCode.GDPersonalWealthResultObjects6.length ;i < len;++i) {
    gdjs.MainCode.GDPersonalWealthResultObjects6[i].getBehavior("Text").setText("+1");
}
}{for(var i = 0, len = gdjs.MainCode.GDPersonalWealthResultObjects6.length ;i < len;++i) {
    gdjs.MainCode.GDPersonalWealthResultObjects6[i].setColor("65;117;5");
}
}{for(var i = 0, len = gdjs.MainCode.GDPersonalWealthResultObjects6.length ;i < len;++i) {
    gdjs.MainCode.GDPersonalWealthResultObjects6[i].addPolarForce(180, 50, 1);
}
}{for(var i = 0, len = gdjs.MainCode.GDPersonalWealthResultObjects6.length ;i < len;++i) {
    gdjs.MainCode.GDPersonalWealthResultObjects6[i].getBehavior("Tween").addObjectOpacityTween2("Opacity", 0, "linear", 2, true);
}
}{runtimeScene.getScene().getVariables().getFromIndex(6).add(1);
}{gdjs.evtTools.sound.playSound(runtimeScene, "assets\\Sounds\\Yay.mp3", false, 100, 1);
}}

}


};gdjs.MainCode.asyncCallback15245148 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.MainCode.localVariables);

{ //Subevents
gdjs.MainCode.eventsList165(runtimeScene, asyncObjectsList);} //End of subevents
gdjs.MainCode.localVariables.length = 0;
}
gdjs.MainCode.eventsList166 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
asyncObjectsList.backupLocalVariablesContainers(gdjs.MainCode.localVariables);
/* Don't save Next_button as it will be provided by the parent asyncObjectsList. */
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1), (runtimeScene) => (gdjs.MainCode.asyncCallback15245148(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.MainCode.eventsList167 = function(runtimeScene, asyncObjectsList) {

{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15638255);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("ScandalRiskTxt"), gdjs.MainCode.GDScandalRiskTxtObjects6);
gdjs.MainCode.GDRiskResultObjects6.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDRiskResultObjects6Objects, (( gdjs.MainCode.GDScandalRiskTxtObjects6.length === 0 ) ? 0 :gdjs.MainCode.GDScandalRiskTxtObjects6[0].getX()), (( gdjs.MainCode.GDScandalRiskTxtObjects6.length === 0 ) ? 0 :gdjs.MainCode.GDScandalRiskTxtObjects6[0].getY()), "");
}{for(var i = 0, len = gdjs.MainCode.GDRiskResultObjects6.length ;i < len;++i) {
    gdjs.MainCode.GDRiskResultObjects6[i].getBehavior("Text").setText("-1");
}
}{for(var i = 0, len = gdjs.MainCode.GDRiskResultObjects6.length ;i < len;++i) {
    gdjs.MainCode.GDRiskResultObjects6[i].setColor("65;117;5");
}
}{for(var i = 0, len = gdjs.MainCode.GDRiskResultObjects6.length ;i < len;++i) {
    gdjs.MainCode.GDRiskResultObjects6[i].addPolarForce(180, 50, 1);
}
}{for(var i = 0, len = gdjs.MainCode.GDRiskResultObjects6.length ;i < len;++i) {
    gdjs.MainCode.GDRiskResultObjects6[i].getBehavior("Tween").addObjectOpacityTween2("Opacity", 0, "linear", 2, true);
}
}{runtimeScene.getScene().getVariables().getFromIndex(5).sub(1);
}{gdjs.evtTools.sound.playSound(runtimeScene, "assets\\Sounds\\Yay.mp3", false, 100, 1);
}}

}


{


let isConditionTrue_0 = false;
{

{ //Subevents
gdjs.MainCode.eventsList166(runtimeScene, asyncObjectsList);} //End of subevents
}

}


};gdjs.MainCode.asyncCallback15244476 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.MainCode.localVariables);

{ //Subevents
gdjs.MainCode.eventsList167(runtimeScene, asyncObjectsList);} //End of subevents
gdjs.MainCode.localVariables.length = 0;
}
gdjs.MainCode.eventsList168 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
asyncObjectsList.backupLocalVariablesContainers(gdjs.MainCode.localVariables);
/* Don't save Next_button as it will be provided by the parent asyncObjectsList. */
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1), (runtimeScene) => (gdjs.MainCode.asyncCallback15244476(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.MainCode.eventsList169 = function(runtimeScene, asyncObjectsList) {

{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15634273);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("PublicApprovalTxt"), gdjs.MainCode.GDPublicApprovalTxtObjects5);
gdjs.MainCode.GDPAResultObjects5.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDPAResultObjects5Objects, (( gdjs.MainCode.GDPublicApprovalTxtObjects5.length === 0 ) ? 0 :gdjs.MainCode.GDPublicApprovalTxtObjects5[0].getX()), (( gdjs.MainCode.GDPublicApprovalTxtObjects5.length === 0 ) ? 0 :gdjs.MainCode.GDPublicApprovalTxtObjects5[0].getY()), "");
}{for(var i = 0, len = gdjs.MainCode.GDPAResultObjects5.length ;i < len;++i) {
    gdjs.MainCode.GDPAResultObjects5[i].getBehavior("Text").setText("+1");
}
}{for(var i = 0, len = gdjs.MainCode.GDPAResultObjects5.length ;i < len;++i) {
    gdjs.MainCode.GDPAResultObjects5[i].setColor("65;117;5");
}
}{for(var i = 0, len = gdjs.MainCode.GDPAResultObjects5.length ;i < len;++i) {
    gdjs.MainCode.GDPAResultObjects5[i].addPolarForce(180, 50, 1);
}
}{for(var i = 0, len = gdjs.MainCode.GDPAResultObjects5.length ;i < len;++i) {
    gdjs.MainCode.GDPAResultObjects5[i].getBehavior("Tween").addObjectOpacityTween2("Opacity", 0, "linear", 2, true);
}
}{runtimeScene.getScene().getVariables().getFromIndex(4).add(1);
}{gdjs.evtTools.sound.playSound(runtimeScene, "assets\\Sounds\\Yay.mp3", false, 100, 1);
}}

}


{


let isConditionTrue_0 = false;
{

{ //Subevents
gdjs.MainCode.eventsList168(runtimeScene, asyncObjectsList);} //End of subevents
}

}


};gdjs.MainCode.asyncCallback15243828 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.MainCode.localVariables);

{ //Subevents
gdjs.MainCode.eventsList169(runtimeScene, asyncObjectsList);} //End of subevents
gdjs.MainCode.localVariables.length = 0;
}
gdjs.MainCode.eventsList170 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
asyncObjectsList.backupLocalVariablesContainers(gdjs.MainCode.localVariables);
for (const obj of gdjs.MainCode.GDNext_9595buttonObjects2) asyncObjectsList.addObject("Next_button", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1), (runtimeScene) => (gdjs.MainCode.asyncCallback15243828(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.MainCode.eventsList171 = function(runtimeScene, asyncObjectsList) {

{



}


{


let isConditionTrue_0 = false;
{

{ //Subevents
gdjs.MainCode.eventsList170(runtimeScene, asyncObjectsList);} //End of subevents
}

}


};gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDEconomyResultObjects5Objects = Hashtable.newFrom({"EconomyResult": gdjs.MainCode.GDEconomyResultObjects5});
gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDPAResultObjects6Objects = Hashtable.newFrom({"PAResult": gdjs.MainCode.GDPAResultObjects6});
gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDRiskResultObjects7Objects = Hashtable.newFrom({"RiskResult": gdjs.MainCode.GDRiskResultObjects7});
gdjs.MainCode.eventsList172 = function(runtimeScene, asyncObjectsList) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("NextText"), gdjs.MainCode.GDNextTextObjects7);
gdjs.copyArray(asyncObjectsList.getObjects("Next_button"), gdjs.MainCode.GDNext_9595buttonObjects7);

{for(var i = 0, len = gdjs.MainCode.GDNext_9595buttonObjects7.length ;i < len;++i) {
    gdjs.MainCode.GDNext_9595buttonObjects7[i].hide(false);
}
for(var i = 0, len = gdjs.MainCode.GDNextTextObjects7.length ;i < len;++i) {
    gdjs.MainCode.GDNextTextObjects7[i].hide(false);
}
}}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15638256);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("ScandalRiskTxt"), gdjs.MainCode.GDScandalRiskTxtObjects7);
gdjs.MainCode.GDRiskResultObjects7.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDRiskResultObjects7Objects, (( gdjs.MainCode.GDScandalRiskTxtObjects7.length === 0 ) ? 0 :gdjs.MainCode.GDScandalRiskTxtObjects7[0].getX()), (( gdjs.MainCode.GDScandalRiskTxtObjects7.length === 0 ) ? 0 :gdjs.MainCode.GDScandalRiskTxtObjects7[0].getY()), "");
}{for(var i = 0, len = gdjs.MainCode.GDRiskResultObjects7.length ;i < len;++i) {
    gdjs.MainCode.GDRiskResultObjects7[i].getBehavior("Text").setText("-1");
}
}{for(var i = 0, len = gdjs.MainCode.GDRiskResultObjects7.length ;i < len;++i) {
    gdjs.MainCode.GDRiskResultObjects7[i].setColor("65;117;5");
}
}{for(var i = 0, len = gdjs.MainCode.GDRiskResultObjects7.length ;i < len;++i) {
    gdjs.MainCode.GDRiskResultObjects7[i].addPolarForce(180, 50, 1);
}
}{for(var i = 0, len = gdjs.MainCode.GDRiskResultObjects7.length ;i < len;++i) {
    gdjs.MainCode.GDRiskResultObjects7[i].getBehavior("Tween").addObjectOpacityTween2("Opacity", 0, "linear", 2, true);
}
}{runtimeScene.getScene().getVariables().getFromIndex(5).sub(1);
}{gdjs.evtTools.sound.playSound(runtimeScene, "assets\\Sounds\\Yay.mp3", false, 100, 1);
}}

}


{



}


};gdjs.MainCode.asyncCallback15248252 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.MainCode.localVariables);

{ //Subevents
gdjs.MainCode.eventsList172(runtimeScene, asyncObjectsList);} //End of subevents
gdjs.MainCode.localVariables.length = 0;
}
gdjs.MainCode.eventsList173 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
asyncObjectsList.backupLocalVariablesContainers(gdjs.MainCode.localVariables);
/* Don't save Next_button as it will be provided by the parent asyncObjectsList. */
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1), (runtimeScene) => (gdjs.MainCode.asyncCallback15248252(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.MainCode.eventsList174 = function(runtimeScene, asyncObjectsList) {

{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15634274);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("PublicApprovalTxt"), gdjs.MainCode.GDPublicApprovalTxtObjects6);
gdjs.MainCode.GDPAResultObjects6.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDPAResultObjects6Objects, (( gdjs.MainCode.GDPublicApprovalTxtObjects6.length === 0 ) ? 0 :gdjs.MainCode.GDPublicApprovalTxtObjects6[0].getX()), (( gdjs.MainCode.GDPublicApprovalTxtObjects6.length === 0 ) ? 0 :gdjs.MainCode.GDPublicApprovalTxtObjects6[0].getY()), "");
}{for(var i = 0, len = gdjs.MainCode.GDPAResultObjects6.length ;i < len;++i) {
    gdjs.MainCode.GDPAResultObjects6[i].getBehavior("Text").setText("+1");
}
}{for(var i = 0, len = gdjs.MainCode.GDPAResultObjects6.length ;i < len;++i) {
    gdjs.MainCode.GDPAResultObjects6[i].setColor("65;117;5");
}
}{for(var i = 0, len = gdjs.MainCode.GDPAResultObjects6.length ;i < len;++i) {
    gdjs.MainCode.GDPAResultObjects6[i].addPolarForce(180, 50, 1);
}
}{for(var i = 0, len = gdjs.MainCode.GDPAResultObjects6.length ;i < len;++i) {
    gdjs.MainCode.GDPAResultObjects6[i].getBehavior("Tween").addObjectOpacityTween2("Opacity", 0, "linear", 2, true);
}
}{runtimeScene.getScene().getVariables().getFromIndex(4).add(1);
}{gdjs.evtTools.sound.playSound(runtimeScene, "assets\\Sounds\\Yay.mp3", false, 100, 1);
}}

}


{


let isConditionTrue_0 = false;
{

{ //Subevents
gdjs.MainCode.eventsList173(runtimeScene, asyncObjectsList);} //End of subevents
}

}


};gdjs.MainCode.asyncCallback15247580 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.MainCode.localVariables);

{ //Subevents
gdjs.MainCode.eventsList174(runtimeScene, asyncObjectsList);} //End of subevents
gdjs.MainCode.localVariables.length = 0;
}
gdjs.MainCode.eventsList175 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
asyncObjectsList.backupLocalVariablesContainers(gdjs.MainCode.localVariables);
/* Don't save Next_button as it will be provided by the parent asyncObjectsList. */
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1), (runtimeScene) => (gdjs.MainCode.asyncCallback15247580(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.MainCode.eventsList176 = function(runtimeScene, asyncObjectsList) {

{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15630486);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("EconomyTxt"), gdjs.MainCode.GDEconomyTxtObjects5);
gdjs.MainCode.GDEconomyResultObjects5.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDEconomyResultObjects5Objects, (( gdjs.MainCode.GDEconomyTxtObjects5.length === 0 ) ? 0 :gdjs.MainCode.GDEconomyTxtObjects5[0].getX()), (( gdjs.MainCode.GDEconomyTxtObjects5.length === 0 ) ? 0 :gdjs.MainCode.GDEconomyTxtObjects5[0].getY()), "");
}{for(var i = 0, len = gdjs.MainCode.GDEconomyResultObjects5.length ;i < len;++i) {
    gdjs.MainCode.GDEconomyResultObjects5[i].getBehavior("Text").setText("+2");
}
}{for(var i = 0, len = gdjs.MainCode.GDEconomyResultObjects5.length ;i < len;++i) {
    gdjs.MainCode.GDEconomyResultObjects5[i].getBehavior("Tween").addObjectOpacityTween2("Opacity", 0, "linear", 2, true);
}
}{for(var i = 0, len = gdjs.MainCode.GDEconomyResultObjects5.length ;i < len;++i) {
    gdjs.MainCode.GDEconomyResultObjects5[i].setColor("65;117;5");
}
}{for(var i = 0, len = gdjs.MainCode.GDEconomyResultObjects5.length ;i < len;++i) {
    gdjs.MainCode.GDEconomyResultObjects5[i].addPolarForce(180, 50, 1);
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "assets\\Sounds\\Yay.mp3", false, 100, 1);
}}

}


{


let isConditionTrue_0 = false;
{

{ //Subevents
gdjs.MainCode.eventsList175(runtimeScene, asyncObjectsList);} //End of subevents
}

}


};gdjs.MainCode.asyncCallback15246908 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.MainCode.localVariables);

{ //Subevents
gdjs.MainCode.eventsList176(runtimeScene, asyncObjectsList);} //End of subevents
gdjs.MainCode.localVariables.length = 0;
}
gdjs.MainCode.eventsList177 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
asyncObjectsList.backupLocalVariablesContainers(gdjs.MainCode.localVariables);
for (const obj of gdjs.MainCode.GDNext_9595buttonObjects2) asyncObjectsList.addObject("Next_button", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1), (runtimeScene) => (gdjs.MainCode.asyncCallback15246908(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.MainCode.eventsList178 = function(runtimeScene, asyncObjectsList) {

{


let isConditionTrue_0 = false;
{

{ //Subevents
gdjs.MainCode.eventsList177(runtimeScene, asyncObjectsList);} //End of subevents
}

}


};gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDEconomyResultObjects6Objects = Hashtable.newFrom({"EconomyResult": gdjs.MainCode.GDEconomyResultObjects6});
gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDRiskResultObjects7Objects = Hashtable.newFrom({"RiskResult": gdjs.MainCode.GDRiskResultObjects7});
gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDPersonalWealthResultObjects8Objects = Hashtable.newFrom({"PersonalWealthResult": gdjs.MainCode.GDPersonalWealthResultObjects8});
gdjs.MainCode.eventsList179 = function(runtimeScene, asyncObjectsList) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("NextText"), gdjs.MainCode.GDNextTextObjects9);
gdjs.copyArray(asyncObjectsList.getObjects("Next_button"), gdjs.MainCode.GDNext_9595buttonObjects9);

{for(var i = 0, len = gdjs.MainCode.GDNext_9595buttonObjects9.length ;i < len;++i) {
    gdjs.MainCode.GDNext_9595buttonObjects9[i].hide(false);
}
for(var i = 0, len = gdjs.MainCode.GDNextTextObjects9.length ;i < len;++i) {
    gdjs.MainCode.GDNextTextObjects9[i].hide(false);
}
}}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15648576);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("PersonalGainsTxt"), gdjs.MainCode.GDPersonalGainsTxtObjects8);
gdjs.MainCode.GDPersonalWealthResultObjects8.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDPersonalWealthResultObjects8Objects, (( gdjs.MainCode.GDPersonalGainsTxtObjects8.length === 0 ) ? 0 :gdjs.MainCode.GDPersonalGainsTxtObjects8[0].getX()), (( gdjs.MainCode.GDPersonalGainsTxtObjects8.length === 0 ) ? 0 :gdjs.MainCode.GDPersonalGainsTxtObjects8[0].getY()), "");
}{for(var i = 0, len = gdjs.MainCode.GDPersonalWealthResultObjects8.length ;i < len;++i) {
    gdjs.MainCode.GDPersonalWealthResultObjects8[i].getBehavior("Text").setText("+1");
}
}{for(var i = 0, len = gdjs.MainCode.GDPersonalWealthResultObjects8.length ;i < len;++i) {
    gdjs.MainCode.GDPersonalWealthResultObjects8[i].setColor("65;117;5");
}
}{for(var i = 0, len = gdjs.MainCode.GDPersonalWealthResultObjects8.length ;i < len;++i) {
    gdjs.MainCode.GDPersonalWealthResultObjects8[i].addPolarForce(180, 50, 1);
}
}{for(var i = 0, len = gdjs.MainCode.GDPersonalWealthResultObjects8.length ;i < len;++i) {
    gdjs.MainCode.GDPersonalWealthResultObjects8[i].getBehavior("Tween").addObjectOpacityTween2("Opacity", 0, "linear", 2, true);
}
}{runtimeScene.getScene().getVariables().getFromIndex(6).add(1);
}{gdjs.evtTools.sound.playSound(runtimeScene, "assets\\Sounds\\Yay.mp3", false, 100, 1);
}}

}


};gdjs.MainCode.asyncCallback15252116 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.MainCode.localVariables);

{ //Subevents
gdjs.MainCode.eventsList179(runtimeScene, asyncObjectsList);} //End of subevents
gdjs.MainCode.localVariables.length = 0;
}
gdjs.MainCode.eventsList180 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
asyncObjectsList.backupLocalVariablesContainers(gdjs.MainCode.localVariables);
/* Don't save Next_button as it will be provided by the parent asyncObjectsList. */
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1), (runtimeScene) => (gdjs.MainCode.asyncCallback15252116(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.MainCode.eventsList181 = function(runtimeScene, asyncObjectsList) {

{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15640385);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("ScandalRiskTxt"), gdjs.MainCode.GDScandalRiskTxtObjects7);
gdjs.MainCode.GDRiskResultObjects7.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDRiskResultObjects7Objects, (( gdjs.MainCode.GDScandalRiskTxtObjects7.length === 0 ) ? 0 :gdjs.MainCode.GDScandalRiskTxtObjects7[0].getX()), (( gdjs.MainCode.GDScandalRiskTxtObjects7.length === 0 ) ? 0 :gdjs.MainCode.GDScandalRiskTxtObjects7[0].getY()), "");
}{for(var i = 0, len = gdjs.MainCode.GDRiskResultObjects7.length ;i < len;++i) {
    gdjs.MainCode.GDRiskResultObjects7[i].getBehavior("Text").setText("+1");
}
}{for(var i = 0, len = gdjs.MainCode.GDRiskResultObjects7.length ;i < len;++i) {
    gdjs.MainCode.GDRiskResultObjects7[i].setColor("208;2;27");
}
}{for(var i = 0, len = gdjs.MainCode.GDRiskResultObjects7.length ;i < len;++i) {
    gdjs.MainCode.GDRiskResultObjects7[i].addPolarForce(180, 50, 1);
}
}{for(var i = 0, len = gdjs.MainCode.GDRiskResultObjects7.length ;i < len;++i) {
    gdjs.MainCode.GDRiskResultObjects7[i].getBehavior("Tween").addObjectOpacityTween2("Opacity", 0, "linear", 2, true);
}
}{runtimeScene.getScene().getVariables().getFromIndex(5).add(1);
}{gdjs.evtTools.sound.playSound(runtimeScene, "assets\\Sounds\\Shocked.mp3", false, 100, 1);
}}

}


{


let isConditionTrue_0 = false;
{

{ //Subevents
gdjs.MainCode.eventsList180(runtimeScene, asyncObjectsList);} //End of subevents
}

}


{



}


};gdjs.MainCode.asyncCallback15251444 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.MainCode.localVariables);

{ //Subevents
gdjs.MainCode.eventsList181(runtimeScene, asyncObjectsList);} //End of subevents
gdjs.MainCode.localVariables.length = 0;
}
gdjs.MainCode.eventsList182 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
asyncObjectsList.backupLocalVariablesContainers(gdjs.MainCode.localVariables);
/* Don't save Next_button as it will be provided by the parent asyncObjectsList. */
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1), (runtimeScene) => (gdjs.MainCode.asyncCallback15251444(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.MainCode.eventsList183 = function(runtimeScene, asyncObjectsList) {

{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15628471);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("EconomyTxt"), gdjs.MainCode.GDEconomyTxtObjects6);
gdjs.MainCode.GDEconomyResultObjects6.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDEconomyResultObjects6Objects, (( gdjs.MainCode.GDEconomyTxtObjects6.length === 0 ) ? 0 :gdjs.MainCode.GDEconomyTxtObjects6[0].getX()), (( gdjs.MainCode.GDEconomyTxtObjects6.length === 0 ) ? 0 :gdjs.MainCode.GDEconomyTxtObjects6[0].getY()), "");
}{for(var i = 0, len = gdjs.MainCode.GDEconomyResultObjects6.length ;i < len;++i) {
    gdjs.MainCode.GDEconomyResultObjects6[i].getBehavior("Text").setText("-1");
}
}{for(var i = 0, len = gdjs.MainCode.GDEconomyResultObjects6.length ;i < len;++i) {
    gdjs.MainCode.GDEconomyResultObjects6[i].getBehavior("Tween").addObjectOpacityTween2("Opacity", 0, "linear", 2, true);
}
}{for(var i = 0, len = gdjs.MainCode.GDEconomyResultObjects6.length ;i < len;++i) {
    gdjs.MainCode.GDEconomyResultObjects6[i].setColor("208;2;27");
}
}{for(var i = 0, len = gdjs.MainCode.GDEconomyResultObjects6.length ;i < len;++i) {
    gdjs.MainCode.GDEconomyResultObjects6[i].addPolarForce(180, 50, 1);
}
}{runtimeScene.getScene().getVariables().getFromIndex(3).sub(1);
}{gdjs.evtTools.sound.playSound(runtimeScene, "assets\\Sounds\\Shocked.mp3", false, 100, 1);
}}

}


{


let isConditionTrue_0 = false;
{

{ //Subevents
gdjs.MainCode.eventsList182(runtimeScene, asyncObjectsList);} //End of subevents
}

}


};gdjs.MainCode.asyncCallback15250772 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.MainCode.localVariables);

{ //Subevents
gdjs.MainCode.eventsList183(runtimeScene, asyncObjectsList);} //End of subevents
gdjs.MainCode.localVariables.length = 0;
}
gdjs.MainCode.eventsList184 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
asyncObjectsList.backupLocalVariablesContainers(gdjs.MainCode.localVariables);
for (const obj of gdjs.MainCode.GDNext_9595buttonObjects2) asyncObjectsList.addObject("Next_button", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1), (runtimeScene) => (gdjs.MainCode.asyncCallback15250772(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.MainCode.eventsList185 = function(runtimeScene, asyncObjectsList) {

{


let isConditionTrue_0 = false;
{

{ //Subevents
gdjs.MainCode.eventsList184(runtimeScene, asyncObjectsList);} //End of subevents
}

}


{



}


};gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDPAResultObjects5Objects = Hashtable.newFrom({"PAResult": gdjs.MainCode.GDPAResultObjects5});
gdjs.MainCode.eventsList186 = function(runtimeScene, asyncObjectsList) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("NextText"), gdjs.MainCode.GDNextTextObjects6);
gdjs.copyArray(asyncObjectsList.getObjects("Next_button"), gdjs.MainCode.GDNext_9595buttonObjects6);

{for(var i = 0, len = gdjs.MainCode.GDNext_9595buttonObjects6.length ;i < len;++i) {
    gdjs.MainCode.GDNext_9595buttonObjects6[i].hide(false);
}
for(var i = 0, len = gdjs.MainCode.GDNextTextObjects6.length ;i < len;++i) {
    gdjs.MainCode.GDNextTextObjects6[i].hide(false);
}
}}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15632282);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("PublicApprovalTxt"), gdjs.MainCode.GDPublicApprovalTxtObjects5);
gdjs.MainCode.GDPAResultObjects5.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDPAResultObjects5Objects, (( gdjs.MainCode.GDPublicApprovalTxtObjects5.length === 0 ) ? 0 :gdjs.MainCode.GDPublicApprovalTxtObjects5[0].getX()), (( gdjs.MainCode.GDPublicApprovalTxtObjects5.length === 0 ) ? 0 :gdjs.MainCode.GDPublicApprovalTxtObjects5[0].getY()), "");
}{for(var i = 0, len = gdjs.MainCode.GDPAResultObjects5.length ;i < len;++i) {
    gdjs.MainCode.GDPAResultObjects5[i].getBehavior("Text").setText("-1");
}
}{for(var i = 0, len = gdjs.MainCode.GDPAResultObjects5.length ;i < len;++i) {
    gdjs.MainCode.GDPAResultObjects5[i].setColor("208;2;27");
}
}{for(var i = 0, len = gdjs.MainCode.GDPAResultObjects5.length ;i < len;++i) {
    gdjs.MainCode.GDPAResultObjects5[i].addPolarForce(180, 50, 1);
}
}{for(var i = 0, len = gdjs.MainCode.GDPAResultObjects5.length ;i < len;++i) {
    gdjs.MainCode.GDPAResultObjects5[i].getBehavior("Tween").addObjectOpacityTween2("Opacity", 0, "linear", 2, true);
}
}{runtimeScene.getScene().getVariables().getFromIndex(4).sub(1);
}{gdjs.evtTools.sound.playSound(runtimeScene, "assets\\Sounds\\Shocked.mp3", false, 100, 1);
}}

}


};gdjs.MainCode.asyncCallback15254716 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.MainCode.localVariables);

{ //Subevents
gdjs.MainCode.eventsList186(runtimeScene, asyncObjectsList);} //End of subevents
gdjs.MainCode.localVariables.length = 0;
}
gdjs.MainCode.eventsList187 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
asyncObjectsList.backupLocalVariablesContainers(gdjs.MainCode.localVariables);
for (const obj of gdjs.MainCode.GDNext_9595buttonObjects2) asyncObjectsList.addObject("Next_button", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1), (runtimeScene) => (gdjs.MainCode.asyncCallback15254716(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.MainCode.eventsList188 = function(runtimeScene, asyncObjectsList) {

{



}


{


let isConditionTrue_0 = false;
{

{ //Subevents
gdjs.MainCode.eventsList187(runtimeScene, asyncObjectsList);} //End of subevents
}

}


{



}


{



}


{



}


{



}


};gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDPAResultObjects5Objects = Hashtable.newFrom({"PAResult": gdjs.MainCode.GDPAResultObjects5});
gdjs.MainCode.eventsList189 = function(runtimeScene, asyncObjectsList) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("NextText"), gdjs.MainCode.GDNextTextObjects6);
gdjs.copyArray(asyncObjectsList.getObjects("Next_button"), gdjs.MainCode.GDNext_9595buttonObjects6);

{for(var i = 0, len = gdjs.MainCode.GDNext_9595buttonObjects6.length ;i < len;++i) {
    gdjs.MainCode.GDNext_9595buttonObjects6[i].hide(false);
}
for(var i = 0, len = gdjs.MainCode.GDNextTextObjects6.length ;i < len;++i) {
    gdjs.MainCode.GDNextTextObjects6[i].hide(false);
}
}}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15634275);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("PublicApprovalTxt"), gdjs.MainCode.GDPublicApprovalTxtObjects5);
gdjs.MainCode.GDPAResultObjects5.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDPAResultObjects5Objects, (( gdjs.MainCode.GDPublicApprovalTxtObjects5.length === 0 ) ? 0 :gdjs.MainCode.GDPublicApprovalTxtObjects5[0].getX()), (( gdjs.MainCode.GDPublicApprovalTxtObjects5.length === 0 ) ? 0 :gdjs.MainCode.GDPublicApprovalTxtObjects5[0].getY()), "");
}{for(var i = 0, len = gdjs.MainCode.GDPAResultObjects5.length ;i < len;++i) {
    gdjs.MainCode.GDPAResultObjects5[i].getBehavior("Text").setText("+1");
}
}{for(var i = 0, len = gdjs.MainCode.GDPAResultObjects5.length ;i < len;++i) {
    gdjs.MainCode.GDPAResultObjects5[i].setColor("65;117;5");
}
}{for(var i = 0, len = gdjs.MainCode.GDPAResultObjects5.length ;i < len;++i) {
    gdjs.MainCode.GDPAResultObjects5[i].addPolarForce(180, 50, 1);
}
}{for(var i = 0, len = gdjs.MainCode.GDPAResultObjects5.length ;i < len;++i) {
    gdjs.MainCode.GDPAResultObjects5[i].getBehavior("Tween").addObjectOpacityTween2("Opacity", 0, "linear", 2, true);
}
}{runtimeScene.getScene().getVariables().getFromIndex(4).add(1);
}{gdjs.evtTools.sound.playSound(runtimeScene, "assets\\Sounds\\Yay.mp3", false, 100, 1);
}}

}


};gdjs.MainCode.asyncCallback15258020 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.MainCode.localVariables);

{ //Subevents
gdjs.MainCode.eventsList189(runtimeScene, asyncObjectsList);} //End of subevents
gdjs.MainCode.localVariables.length = 0;
}
gdjs.MainCode.eventsList190 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
asyncObjectsList.backupLocalVariablesContainers(gdjs.MainCode.localVariables);
for (const obj of gdjs.MainCode.GDNext_9595buttonObjects2) asyncObjectsList.addObject("Next_button", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1), (runtimeScene) => (gdjs.MainCode.asyncCallback15258020(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.MainCode.eventsList191 = function(runtimeScene, asyncObjectsList) {

{



}


{


let isConditionTrue_0 = false;
{

{ //Subevents
gdjs.MainCode.eventsList190(runtimeScene, asyncObjectsList);} //End of subevents
}

}


{



}


{



}


{



}


{



}


};gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDRiskResultObjects5Objects = Hashtable.newFrom({"RiskResult": gdjs.MainCode.GDRiskResultObjects5});
gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDPersonalWealthResultObjects5Objects = Hashtable.newFrom({"PersonalWealthResult": gdjs.MainCode.GDPersonalWealthResultObjects5});
gdjs.MainCode.eventsList192 = function(runtimeScene, asyncObjectsList) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("NextText"), gdjs.MainCode.GDNextTextObjects6);
gdjs.copyArray(asyncObjectsList.getObjects("Next_button"), gdjs.MainCode.GDNext_9595buttonObjects6);

{for(var i = 0, len = gdjs.MainCode.GDNext_9595buttonObjects6.length ;i < len;++i) {
    gdjs.MainCode.GDNext_9595buttonObjects6[i].hide(false);
}
for(var i = 0, len = gdjs.MainCode.GDNextTextObjects6.length ;i < len;++i) {
    gdjs.MainCode.GDNextTextObjects6[i].hide(false);
}
}}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15648577);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("PersonalGainsTxt"), gdjs.MainCode.GDPersonalGainsTxtObjects5);
gdjs.MainCode.GDPersonalWealthResultObjects5.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDPersonalWealthResultObjects5Objects, (( gdjs.MainCode.GDPersonalGainsTxtObjects5.length === 0 ) ? 0 :gdjs.MainCode.GDPersonalGainsTxtObjects5[0].getX()), (( gdjs.MainCode.GDPersonalGainsTxtObjects5.length === 0 ) ? 0 :gdjs.MainCode.GDPersonalGainsTxtObjects5[0].getY()), "");
}{for(var i = 0, len = gdjs.MainCode.GDPersonalWealthResultObjects5.length ;i < len;++i) {
    gdjs.MainCode.GDPersonalWealthResultObjects5[i].getBehavior("Text").setText("+1");
}
}{for(var i = 0, len = gdjs.MainCode.GDPersonalWealthResultObjects5.length ;i < len;++i) {
    gdjs.MainCode.GDPersonalWealthResultObjects5[i].setColor("65;117;5");
}
}{for(var i = 0, len = gdjs.MainCode.GDPersonalWealthResultObjects5.length ;i < len;++i) {
    gdjs.MainCode.GDPersonalWealthResultObjects5[i].addPolarForce(180, 50, 1);
}
}{for(var i = 0, len = gdjs.MainCode.GDPersonalWealthResultObjects5.length ;i < len;++i) {
    gdjs.MainCode.GDPersonalWealthResultObjects5[i].getBehavior("Tween").addObjectOpacityTween2("Opacity", 0, "linear", 2, true);
}
}{runtimeScene.getScene().getVariables().getFromIndex(6).add(1);
}{gdjs.evtTools.sound.playSound(runtimeScene, "assets\\Sounds\\Yay.mp3", false, 100, 1);
}}

}


};gdjs.MainCode.asyncCallback15262636 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.MainCode.localVariables);

{ //Subevents
gdjs.MainCode.eventsList192(runtimeScene, asyncObjectsList);} //End of subevents
gdjs.MainCode.localVariables.length = 0;
}
gdjs.MainCode.eventsList193 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
asyncObjectsList.backupLocalVariablesContainers(gdjs.MainCode.localVariables);
/* Don't save Next_button as it will be provided by the parent asyncObjectsList. */
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1), (runtimeScene) => (gdjs.MainCode.asyncCallback15262636(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.MainCode.eventsList194 = function(runtimeScene, asyncObjectsList) {

{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15641598);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("ScandalRiskTxt"), gdjs.MainCode.GDScandalRiskTxtObjects5);
gdjs.MainCode.GDRiskResultObjects5.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDRiskResultObjects5Objects, (( gdjs.MainCode.GDScandalRiskTxtObjects5.length === 0 ) ? 0 :gdjs.MainCode.GDScandalRiskTxtObjects5[0].getX()), (( gdjs.MainCode.GDScandalRiskTxtObjects5.length === 0 ) ? 0 :gdjs.MainCode.GDScandalRiskTxtObjects5[0].getY()), "");
}{for(var i = 0, len = gdjs.MainCode.GDRiskResultObjects5.length ;i < len;++i) {
    gdjs.MainCode.GDRiskResultObjects5[i].getBehavior("Text").setText("+2");
}
}{for(var i = 0, len = gdjs.MainCode.GDRiskResultObjects5.length ;i < len;++i) {
    gdjs.MainCode.GDRiskResultObjects5[i].setColor("208;2;27");
}
}{for(var i = 0, len = gdjs.MainCode.GDRiskResultObjects5.length ;i < len;++i) {
    gdjs.MainCode.GDRiskResultObjects5[i].addPolarForce(180, 50, 1);
}
}{for(var i = 0, len = gdjs.MainCode.GDRiskResultObjects5.length ;i < len;++i) {
    gdjs.MainCode.GDRiskResultObjects5[i].getBehavior("Tween").addObjectOpacityTween2("Opacity", 0, "linear", 2, true);
}
}{runtimeScene.getScene().getVariables().getFromIndex(5).add(2);
}{gdjs.evtTools.sound.playSound(runtimeScene, "assets\\Sounds\\Shocked.mp3", false, 100, 1);
}}

}


{


let isConditionTrue_0 = false;
{

{ //Subevents
gdjs.MainCode.eventsList193(runtimeScene, asyncObjectsList);} //End of subevents
}

}


};gdjs.MainCode.asyncCallback15261964 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.MainCode.localVariables);

{ //Subevents
gdjs.MainCode.eventsList194(runtimeScene, asyncObjectsList);} //End of subevents
gdjs.MainCode.localVariables.length = 0;
}
gdjs.MainCode.eventsList195 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
asyncObjectsList.backupLocalVariablesContainers(gdjs.MainCode.localVariables);
for (const obj of gdjs.MainCode.GDNext_9595buttonObjects2) asyncObjectsList.addObject("Next_button", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1), (runtimeScene) => (gdjs.MainCode.asyncCallback15261964(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.MainCode.eventsList196 = function(runtimeScene, asyncObjectsList) {

{



}


{



}


{



}


{


let isConditionTrue_0 = false;
{

{ //Subevents
gdjs.MainCode.eventsList195(runtimeScene, asyncObjectsList);} //End of subevents
}

}


};gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDPAResultObjects5Objects = Hashtable.newFrom({"PAResult": gdjs.MainCode.GDPAResultObjects5});
gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDRiskResultObjects6Objects = Hashtable.newFrom({"RiskResult": gdjs.MainCode.GDRiskResultObjects6});
gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDPersonalWealthResultObjects6Objects = Hashtable.newFrom({"PersonalWealthResult": gdjs.MainCode.GDPersonalWealthResultObjects6});
gdjs.MainCode.eventsList197 = function(runtimeScene, asyncObjectsList) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("NextText"), gdjs.MainCode.GDNextTextObjects7);
gdjs.copyArray(asyncObjectsList.getObjects("Next_button"), gdjs.MainCode.GDNext_9595buttonObjects7);

{for(var i = 0, len = gdjs.MainCode.GDNext_9595buttonObjects7.length ;i < len;++i) {
    gdjs.MainCode.GDNext_9595buttonObjects7[i].hide(false);
}
for(var i = 0, len = gdjs.MainCode.GDNextTextObjects7.length ;i < len;++i) {
    gdjs.MainCode.GDNextTextObjects7[i].hide(false);
}
}}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15644157);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("PersonalGainsTxt"), gdjs.MainCode.GDPersonalGainsTxtObjects6);
gdjs.MainCode.GDPersonalWealthResultObjects6.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDPersonalWealthResultObjects6Objects, (( gdjs.MainCode.GDPersonalGainsTxtObjects6.length === 0 ) ? 0 :gdjs.MainCode.GDPersonalGainsTxtObjects6[0].getX()), (( gdjs.MainCode.GDPersonalGainsTxtObjects6.length === 0 ) ? 0 :gdjs.MainCode.GDPersonalGainsTxtObjects6[0].getY()), "");
}{for(var i = 0, len = gdjs.MainCode.GDPersonalWealthResultObjects6.length ;i < len;++i) {
    gdjs.MainCode.GDPersonalWealthResultObjects6[i].getBehavior("Text").setText("-2");
}
}{for(var i = 0, len = gdjs.MainCode.GDPersonalWealthResultObjects6.length ;i < len;++i) {
    gdjs.MainCode.GDPersonalWealthResultObjects6[i].setColor("208;2;27");
}
}{for(var i = 0, len = gdjs.MainCode.GDPersonalWealthResultObjects6.length ;i < len;++i) {
    gdjs.MainCode.GDPersonalWealthResultObjects6[i].addPolarForce(180, 50, 1);
}
}{for(var i = 0, len = gdjs.MainCode.GDPersonalWealthResultObjects6.length ;i < len;++i) {
    gdjs.MainCode.GDPersonalWealthResultObjects6[i].getBehavior("Tween").addObjectOpacityTween2("Opacity", 0, "linear", 2, true);
}
}{runtimeScene.getScene().getVariables().getFromIndex(6).sub(2);
}{gdjs.evtTools.sound.playSound(runtimeScene, "assets\\Sounds\\Shocked.mp3", false, 100, 1);
}}

}


};gdjs.MainCode.asyncCallback15265972 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.MainCode.localVariables);

{ //Subevents
gdjs.MainCode.eventsList197(runtimeScene, asyncObjectsList);} //End of subevents
gdjs.MainCode.localVariables.length = 0;
}
gdjs.MainCode.eventsList198 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
asyncObjectsList.backupLocalVariablesContainers(gdjs.MainCode.localVariables);
/* Don't save Next_button as it will be provided by the parent asyncObjectsList. */
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1), (runtimeScene) => (gdjs.MainCode.asyncCallback15265972(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.MainCode.eventsList199 = function(runtimeScene, asyncObjectsList) {

{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15638257);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("ScandalRiskTxt"), gdjs.MainCode.GDScandalRiskTxtObjects6);
gdjs.MainCode.GDRiskResultObjects6.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDRiskResultObjects6Objects, (( gdjs.MainCode.GDScandalRiskTxtObjects6.length === 0 ) ? 0 :gdjs.MainCode.GDScandalRiskTxtObjects6[0].getX()), (( gdjs.MainCode.GDScandalRiskTxtObjects6.length === 0 ) ? 0 :gdjs.MainCode.GDScandalRiskTxtObjects6[0].getY()), "");
}{for(var i = 0, len = gdjs.MainCode.GDRiskResultObjects6.length ;i < len;++i) {
    gdjs.MainCode.GDRiskResultObjects6[i].getBehavior("Text").setText("-1");
}
}{for(var i = 0, len = gdjs.MainCode.GDRiskResultObjects6.length ;i < len;++i) {
    gdjs.MainCode.GDRiskResultObjects6[i].setColor("65;117;5");
}
}{for(var i = 0, len = gdjs.MainCode.GDRiskResultObjects6.length ;i < len;++i) {
    gdjs.MainCode.GDRiskResultObjects6[i].addPolarForce(180, 50, 1);
}
}{for(var i = 0, len = gdjs.MainCode.GDRiskResultObjects6.length ;i < len;++i) {
    gdjs.MainCode.GDRiskResultObjects6[i].getBehavior("Tween").addObjectOpacityTween2("Opacity", 0, "linear", 2, true);
}
}{runtimeScene.getScene().getVariables().getFromIndex(5).sub(1);
}{gdjs.evtTools.sound.playSound(runtimeScene, "assets\\Sounds\\Yay.mp3", false, 100, 1);
}}

}


{


let isConditionTrue_0 = false;
{

{ //Subevents
gdjs.MainCode.eventsList198(runtimeScene, asyncObjectsList);} //End of subevents
}

}


};gdjs.MainCode.asyncCallback15265300 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.MainCode.localVariables);

{ //Subevents
gdjs.MainCode.eventsList199(runtimeScene, asyncObjectsList);} //End of subevents
gdjs.MainCode.localVariables.length = 0;
}
gdjs.MainCode.eventsList200 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
asyncObjectsList.backupLocalVariablesContainers(gdjs.MainCode.localVariables);
/* Don't save Next_button as it will be provided by the parent asyncObjectsList. */
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1), (runtimeScene) => (gdjs.MainCode.asyncCallback15265300(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.MainCode.eventsList201 = function(runtimeScene, asyncObjectsList) {

{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15634276);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("PublicApprovalTxt"), gdjs.MainCode.GDPublicApprovalTxtObjects5);
gdjs.MainCode.GDPAResultObjects5.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDPAResultObjects5Objects, (( gdjs.MainCode.GDPublicApprovalTxtObjects5.length === 0 ) ? 0 :gdjs.MainCode.GDPublicApprovalTxtObjects5[0].getX()), (( gdjs.MainCode.GDPublicApprovalTxtObjects5.length === 0 ) ? 0 :gdjs.MainCode.GDPublicApprovalTxtObjects5[0].getY()), "");
}{for(var i = 0, len = gdjs.MainCode.GDPAResultObjects5.length ;i < len;++i) {
    gdjs.MainCode.GDPAResultObjects5[i].getBehavior("Text").setText("+1");
}
}{for(var i = 0, len = gdjs.MainCode.GDPAResultObjects5.length ;i < len;++i) {
    gdjs.MainCode.GDPAResultObjects5[i].setColor("65;117;5");
}
}{for(var i = 0, len = gdjs.MainCode.GDPAResultObjects5.length ;i < len;++i) {
    gdjs.MainCode.GDPAResultObjects5[i].addPolarForce(180, 50, 1);
}
}{for(var i = 0, len = gdjs.MainCode.GDPAResultObjects5.length ;i < len;++i) {
    gdjs.MainCode.GDPAResultObjects5[i].getBehavior("Tween").addObjectOpacityTween2("Opacity", 0, "linear", 2, true);
}
}{runtimeScene.getScene().getVariables().getFromIndex(4).add(1);
}{gdjs.evtTools.sound.playSound(runtimeScene, "assets\\Sounds\\Yay.mp3", false, 100, 1);
}}

}


{


let isConditionTrue_0 = false;
{

{ //Subevents
gdjs.MainCode.eventsList200(runtimeScene, asyncObjectsList);} //End of subevents
}

}


};gdjs.MainCode.asyncCallback15264628 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.MainCode.localVariables);

{ //Subevents
gdjs.MainCode.eventsList201(runtimeScene, asyncObjectsList);} //End of subevents
gdjs.MainCode.localVariables.length = 0;
}
gdjs.MainCode.eventsList202 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
asyncObjectsList.backupLocalVariablesContainers(gdjs.MainCode.localVariables);
for (const obj of gdjs.MainCode.GDNext_9595buttonObjects2) asyncObjectsList.addObject("Next_button", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1), (runtimeScene) => (gdjs.MainCode.asyncCallback15264628(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.MainCode.eventsList203 = function(runtimeScene, asyncObjectsList) {

{



}


{


let isConditionTrue_0 = false;
{

{ //Subevents
gdjs.MainCode.eventsList202(runtimeScene, asyncObjectsList);} //End of subevents
}

}


};gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDEconomyResultObjects6Objects = Hashtable.newFrom({"EconomyResult": gdjs.MainCode.GDEconomyResultObjects6});
gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDPAResultObjects7Objects = Hashtable.newFrom({"PAResult": gdjs.MainCode.GDPAResultObjects7});
gdjs.MainCode.eventsList204 = function(runtimeScene, asyncObjectsList) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("NextText"), gdjs.MainCode.GDNextTextObjects7);
gdjs.copyArray(asyncObjectsList.getObjects("Next_button"), gdjs.MainCode.GDNext_9595buttonObjects7);

{for(var i = 0, len = gdjs.MainCode.GDNext_9595buttonObjects7.length ;i < len;++i) {
    gdjs.MainCode.GDNext_9595buttonObjects7[i].hide(false);
}
for(var i = 0, len = gdjs.MainCode.GDNextTextObjects7.length ;i < len;++i) {
    gdjs.MainCode.GDNextTextObjects7[i].hide(false);
}
}}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15636261);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("PublicApprovalTxt"), gdjs.MainCode.GDPublicApprovalTxtObjects7);
gdjs.MainCode.GDPAResultObjects7.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDPAResultObjects7Objects, (( gdjs.MainCode.GDPublicApprovalTxtObjects7.length === 0 ) ? 0 :gdjs.MainCode.GDPublicApprovalTxtObjects7[0].getX()), (( gdjs.MainCode.GDPublicApprovalTxtObjects7.length === 0 ) ? 0 :gdjs.MainCode.GDPublicApprovalTxtObjects7[0].getY()), "");
}{for(var i = 0, len = gdjs.MainCode.GDPAResultObjects7.length ;i < len;++i) {
    gdjs.MainCode.GDPAResultObjects7[i].getBehavior("Text").setText("+2");
}
}{for(var i = 0, len = gdjs.MainCode.GDPAResultObjects7.length ;i < len;++i) {
    gdjs.MainCode.GDPAResultObjects7[i].setColor("65;117;5");
}
}{for(var i = 0, len = gdjs.MainCode.GDPAResultObjects7.length ;i < len;++i) {
    gdjs.MainCode.GDPAResultObjects7[i].addPolarForce(180, 50, 1);
}
}{for(var i = 0, len = gdjs.MainCode.GDPAResultObjects7.length ;i < len;++i) {
    gdjs.MainCode.GDPAResultObjects7[i].getBehavior("Tween").addObjectOpacityTween2("Opacity", 0, "linear", 2, true);
}
}{runtimeScene.getScene().getVariables().getFromIndex(4).add(2);
}{gdjs.evtTools.sound.playSound(runtimeScene, "assets\\Sounds\\Yay.mp3", false, 100, 1);
}}

}


{



}


};gdjs.MainCode.asyncCallback15268404 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.MainCode.localVariables);

{ //Subevents
gdjs.MainCode.eventsList204(runtimeScene, asyncObjectsList);} //End of subevents
gdjs.MainCode.localVariables.length = 0;
}
gdjs.MainCode.eventsList205 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
asyncObjectsList.backupLocalVariablesContainers(gdjs.MainCode.localVariables);
/* Don't save Next_button as it will be provided by the parent asyncObjectsList. */
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1), (runtimeScene) => (gdjs.MainCode.asyncCallback15268404(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.MainCode.eventsList206 = function(runtimeScene, asyncObjectsList) {

{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15630487);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("EconomyTxt"), gdjs.MainCode.GDEconomyTxtObjects6);
gdjs.MainCode.GDEconomyResultObjects6.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDEconomyResultObjects6Objects, (( gdjs.MainCode.GDEconomyTxtObjects6.length === 0 ) ? 0 :gdjs.MainCode.GDEconomyTxtObjects6[0].getX()), (( gdjs.MainCode.GDEconomyTxtObjects6.length === 0 ) ? 0 :gdjs.MainCode.GDEconomyTxtObjects6[0].getY()), "");
}{for(var i = 0, len = gdjs.MainCode.GDEconomyResultObjects6.length ;i < len;++i) {
    gdjs.MainCode.GDEconomyResultObjects6[i].getBehavior("Text").setText("+2");
}
}{for(var i = 0, len = gdjs.MainCode.GDEconomyResultObjects6.length ;i < len;++i) {
    gdjs.MainCode.GDEconomyResultObjects6[i].getBehavior("Tween").addObjectOpacityTween2("Opacity", 0, "linear", 2, true);
}
}{for(var i = 0, len = gdjs.MainCode.GDEconomyResultObjects6.length ;i < len;++i) {
    gdjs.MainCode.GDEconomyResultObjects6[i].setColor("65;117;5");
}
}{for(var i = 0, len = gdjs.MainCode.GDEconomyResultObjects6.length ;i < len;++i) {
    gdjs.MainCode.GDEconomyResultObjects6[i].addPolarForce(180, 50, 1);
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "assets\\Sounds\\Yay.mp3", false, 100, 1);
}}

}


{


let isConditionTrue_0 = false;
{

{ //Subevents
gdjs.MainCode.eventsList205(runtimeScene, asyncObjectsList);} //End of subevents
}

}


};gdjs.MainCode.asyncCallback15267732 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.MainCode.localVariables);

{ //Subevents
gdjs.MainCode.eventsList206(runtimeScene, asyncObjectsList);} //End of subevents
gdjs.MainCode.localVariables.length = 0;
}
gdjs.MainCode.eventsList207 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
asyncObjectsList.backupLocalVariablesContainers(gdjs.MainCode.localVariables);
for (const obj of gdjs.MainCode.GDNext_9595buttonObjects2) asyncObjectsList.addObject("Next_button", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1), (runtimeScene) => (gdjs.MainCode.asyncCallback15267732(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.MainCode.eventsList208 = function(runtimeScene, asyncObjectsList) {

{


let isConditionTrue_0 = false;
{

{ //Subevents
gdjs.MainCode.eventsList207(runtimeScene, asyncObjectsList);} //End of subevents
}

}


{



}


{



}


{



}


};gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDPAResultObjects5Objects = Hashtable.newFrom({"PAResult": gdjs.MainCode.GDPAResultObjects5});
gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDRiskResultObjects6Objects = Hashtable.newFrom({"RiskResult": gdjs.MainCode.GDRiskResultObjects6});
gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDPersonalWealthResultObjects6Objects = Hashtable.newFrom({"PersonalWealthResult": gdjs.MainCode.GDPersonalWealthResultObjects6});
gdjs.MainCode.eventsList209 = function(runtimeScene, asyncObjectsList) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("NextText"), gdjs.MainCode.GDNextTextObjects7);
gdjs.copyArray(asyncObjectsList.getObjects("Next_button"), gdjs.MainCode.GDNext_9595buttonObjects7);

{for(var i = 0, len = gdjs.MainCode.GDNext_9595buttonObjects7.length ;i < len;++i) {
    gdjs.MainCode.GDNext_9595buttonObjects7[i].hide(false);
}
for(var i = 0, len = gdjs.MainCode.GDNextTextObjects7.length ;i < len;++i) {
    gdjs.MainCode.GDNextTextObjects7[i].hide(false);
}
}}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15648578);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("PersonalGainsTxt"), gdjs.MainCode.GDPersonalGainsTxtObjects6);
gdjs.MainCode.GDPersonalWealthResultObjects6.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDPersonalWealthResultObjects6Objects, (( gdjs.MainCode.GDPersonalGainsTxtObjects6.length === 0 ) ? 0 :gdjs.MainCode.GDPersonalGainsTxtObjects6[0].getX()), (( gdjs.MainCode.GDPersonalGainsTxtObjects6.length === 0 ) ? 0 :gdjs.MainCode.GDPersonalGainsTxtObjects6[0].getY()), "");
}{for(var i = 0, len = gdjs.MainCode.GDPersonalWealthResultObjects6.length ;i < len;++i) {
    gdjs.MainCode.GDPersonalWealthResultObjects6[i].getBehavior("Text").setText("+1");
}
}{for(var i = 0, len = gdjs.MainCode.GDPersonalWealthResultObjects6.length ;i < len;++i) {
    gdjs.MainCode.GDPersonalWealthResultObjects6[i].setColor("65;117;5");
}
}{for(var i = 0, len = gdjs.MainCode.GDPersonalWealthResultObjects6.length ;i < len;++i) {
    gdjs.MainCode.GDPersonalWealthResultObjects6[i].addPolarForce(180, 50, 1);
}
}{for(var i = 0, len = gdjs.MainCode.GDPersonalWealthResultObjects6.length ;i < len;++i) {
    gdjs.MainCode.GDPersonalWealthResultObjects6[i].getBehavior("Tween").addObjectOpacityTween2("Opacity", 0, "linear", 2, true);
}
}{runtimeScene.getScene().getVariables().getFromIndex(6).add(1);
}{gdjs.evtTools.sound.playSound(runtimeScene, "assets\\Sounds\\Yay.mp3", false, 100, 1);
}}

}


};gdjs.MainCode.asyncCallback15272996 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.MainCode.localVariables);

{ //Subevents
gdjs.MainCode.eventsList209(runtimeScene, asyncObjectsList);} //End of subevents
gdjs.MainCode.localVariables.length = 0;
}
gdjs.MainCode.eventsList210 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
asyncObjectsList.backupLocalVariablesContainers(gdjs.MainCode.localVariables);
/* Don't save Next_button as it will be provided by the parent asyncObjectsList. */
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1), (runtimeScene) => (gdjs.MainCode.asyncCallback15272996(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.MainCode.eventsList211 = function(runtimeScene, asyncObjectsList) {

{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15640386);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("ScandalRiskTxt"), gdjs.MainCode.GDScandalRiskTxtObjects6);
gdjs.MainCode.GDRiskResultObjects6.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDRiskResultObjects6Objects, (( gdjs.MainCode.GDScandalRiskTxtObjects6.length === 0 ) ? 0 :gdjs.MainCode.GDScandalRiskTxtObjects6[0].getX()), (( gdjs.MainCode.GDScandalRiskTxtObjects6.length === 0 ) ? 0 :gdjs.MainCode.GDScandalRiskTxtObjects6[0].getY()), "");
}{for(var i = 0, len = gdjs.MainCode.GDRiskResultObjects6.length ;i < len;++i) {
    gdjs.MainCode.GDRiskResultObjects6[i].getBehavior("Text").setText("+1");
}
}{for(var i = 0, len = gdjs.MainCode.GDRiskResultObjects6.length ;i < len;++i) {
    gdjs.MainCode.GDRiskResultObjects6[i].setColor("208;2;27");
}
}{for(var i = 0, len = gdjs.MainCode.GDRiskResultObjects6.length ;i < len;++i) {
    gdjs.MainCode.GDRiskResultObjects6[i].addPolarForce(180, 50, 1);
}
}{for(var i = 0, len = gdjs.MainCode.GDRiskResultObjects6.length ;i < len;++i) {
    gdjs.MainCode.GDRiskResultObjects6[i].getBehavior("Tween").addObjectOpacityTween2("Opacity", 0, "linear", 2, true);
}
}{runtimeScene.getScene().getVariables().getFromIndex(5).add(1);
}{gdjs.evtTools.sound.playSound(runtimeScene, "assets\\Sounds\\Shocked.mp3", false, 100, 1);
}}

}


{


let isConditionTrue_0 = false;
{

{ //Subevents
gdjs.MainCode.eventsList210(runtimeScene, asyncObjectsList);} //End of subevents
}

}


};gdjs.MainCode.asyncCallback15272324 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.MainCode.localVariables);

{ //Subevents
gdjs.MainCode.eventsList211(runtimeScene, asyncObjectsList);} //End of subevents
gdjs.MainCode.localVariables.length = 0;
}
gdjs.MainCode.eventsList212 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
asyncObjectsList.backupLocalVariablesContainers(gdjs.MainCode.localVariables);
/* Don't save Next_button as it will be provided by the parent asyncObjectsList. */
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1), (runtimeScene) => (gdjs.MainCode.asyncCallback15272324(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.MainCode.eventsList213 = function(runtimeScene, asyncObjectsList) {

{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15634277);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("PublicApprovalTxt"), gdjs.MainCode.GDPublicApprovalTxtObjects5);
gdjs.MainCode.GDPAResultObjects5.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDPAResultObjects5Objects, (( gdjs.MainCode.GDPublicApprovalTxtObjects5.length === 0 ) ? 0 :gdjs.MainCode.GDPublicApprovalTxtObjects5[0].getX()), (( gdjs.MainCode.GDPublicApprovalTxtObjects5.length === 0 ) ? 0 :gdjs.MainCode.GDPublicApprovalTxtObjects5[0].getY()), "");
}{for(var i = 0, len = gdjs.MainCode.GDPAResultObjects5.length ;i < len;++i) {
    gdjs.MainCode.GDPAResultObjects5[i].getBehavior("Text").setText("+1");
}
}{for(var i = 0, len = gdjs.MainCode.GDPAResultObjects5.length ;i < len;++i) {
    gdjs.MainCode.GDPAResultObjects5[i].setColor("65;117;5");
}
}{for(var i = 0, len = gdjs.MainCode.GDPAResultObjects5.length ;i < len;++i) {
    gdjs.MainCode.GDPAResultObjects5[i].addPolarForce(180, 50, 1);
}
}{for(var i = 0, len = gdjs.MainCode.GDPAResultObjects5.length ;i < len;++i) {
    gdjs.MainCode.GDPAResultObjects5[i].getBehavior("Tween").addObjectOpacityTween2("Opacity", 0, "linear", 2, true);
}
}{runtimeScene.getScene().getVariables().getFromIndex(4).add(1);
}{gdjs.evtTools.sound.playSound(runtimeScene, "assets\\Sounds\\Yay.mp3", false, 100, 1);
}}

}


{


let isConditionTrue_0 = false;
{

{ //Subevents
gdjs.MainCode.eventsList212(runtimeScene, asyncObjectsList);} //End of subevents
}

}


};gdjs.MainCode.asyncCallback15271676 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.MainCode.localVariables);

{ //Subevents
gdjs.MainCode.eventsList213(runtimeScene, asyncObjectsList);} //End of subevents
gdjs.MainCode.localVariables.length = 0;
}
gdjs.MainCode.eventsList214 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
asyncObjectsList.backupLocalVariablesContainers(gdjs.MainCode.localVariables);
for (const obj of gdjs.MainCode.GDNext_9595buttonObjects2) asyncObjectsList.addObject("Next_button", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1), (runtimeScene) => (gdjs.MainCode.asyncCallback15271676(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.MainCode.eventsList215 = function(runtimeScene, asyncObjectsList) {

{



}


{


let isConditionTrue_0 = false;
{

{ //Subevents
gdjs.MainCode.eventsList214(runtimeScene, asyncObjectsList);} //End of subevents
}

}


};gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDEconomyResultObjects6Objects = Hashtable.newFrom({"EconomyResult": gdjs.MainCode.GDEconomyResultObjects6});
gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDPAResultObjects6Objects = Hashtable.newFrom({"PAResult": gdjs.MainCode.GDPAResultObjects6});
gdjs.MainCode.eventsList216 = function(runtimeScene, asyncObjectsList) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("NextText"), gdjs.MainCode.GDNextTextObjects7);
gdjs.copyArray(asyncObjectsList.getObjects("Next_button"), gdjs.MainCode.GDNext_9595buttonObjects7);

{for(var i = 0, len = gdjs.MainCode.GDNext_9595buttonObjects7.length ;i < len;++i) {
    gdjs.MainCode.GDNext_9595buttonObjects7[i].hide(false);
}
for(var i = 0, len = gdjs.MainCode.GDNextTextObjects7.length ;i < len;++i) {
    gdjs.MainCode.GDNextTextObjects7[i].hide(false);
}
}}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15634278);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("PublicApprovalTxt"), gdjs.MainCode.GDPublicApprovalTxtObjects6);
gdjs.MainCode.GDPAResultObjects6.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDPAResultObjects6Objects, (( gdjs.MainCode.GDPublicApprovalTxtObjects6.length === 0 ) ? 0 :gdjs.MainCode.GDPublicApprovalTxtObjects6[0].getX()), (( gdjs.MainCode.GDPublicApprovalTxtObjects6.length === 0 ) ? 0 :gdjs.MainCode.GDPublicApprovalTxtObjects6[0].getY()), "");
}{for(var i = 0, len = gdjs.MainCode.GDPAResultObjects6.length ;i < len;++i) {
    gdjs.MainCode.GDPAResultObjects6[i].getBehavior("Text").setText("+1");
}
}{for(var i = 0, len = gdjs.MainCode.GDPAResultObjects6.length ;i < len;++i) {
    gdjs.MainCode.GDPAResultObjects6[i].setColor("65;117;5");
}
}{for(var i = 0, len = gdjs.MainCode.GDPAResultObjects6.length ;i < len;++i) {
    gdjs.MainCode.GDPAResultObjects6[i].addPolarForce(180, 50, 1);
}
}{for(var i = 0, len = gdjs.MainCode.GDPAResultObjects6.length ;i < len;++i) {
    gdjs.MainCode.GDPAResultObjects6[i].getBehavior("Tween").addObjectOpacityTween2("Opacity", 0, "linear", 2, true);
}
}{runtimeScene.getScene().getVariables().getFromIndex(4).add(1);
}{gdjs.evtTools.sound.playSound(runtimeScene, "assets\\Sounds\\Yay.mp3", false, 100, 1);
}}

}


};gdjs.MainCode.asyncCallback15275428 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.MainCode.localVariables);

{ //Subevents
gdjs.MainCode.eventsList216(runtimeScene, asyncObjectsList);} //End of subevents
gdjs.MainCode.localVariables.length = 0;
}
gdjs.MainCode.eventsList217 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
asyncObjectsList.backupLocalVariablesContainers(gdjs.MainCode.localVariables);
/* Don't save Next_button as it will be provided by the parent asyncObjectsList. */
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1), (runtimeScene) => (gdjs.MainCode.asyncCallback15275428(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.MainCode.eventsList218 = function(runtimeScene, asyncObjectsList) {

{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15626607);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("EconomyTxt"), gdjs.MainCode.GDEconomyTxtObjects6);
gdjs.MainCode.GDEconomyResultObjects6.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDEconomyResultObjects6Objects, (( gdjs.MainCode.GDEconomyTxtObjects6.length === 0 ) ? 0 :gdjs.MainCode.GDEconomyTxtObjects6[0].getX()), (( gdjs.MainCode.GDEconomyTxtObjects6.length === 0 ) ? 0 :gdjs.MainCode.GDEconomyTxtObjects6[0].getY()), "");
}{for(var i = 0, len = gdjs.MainCode.GDEconomyResultObjects6.length ;i < len;++i) {
    gdjs.MainCode.GDEconomyResultObjects6[i].getBehavior("Text").setText("+1");
}
}{for(var i = 0, len = gdjs.MainCode.GDEconomyResultObjects6.length ;i < len;++i) {
    gdjs.MainCode.GDEconomyResultObjects6[i].getBehavior("Tween").addObjectOpacityTween2("Opacity", 0, "linear", 2, true);
}
}{for(var i = 0, len = gdjs.MainCode.GDEconomyResultObjects6.length ;i < len;++i) {
    gdjs.MainCode.GDEconomyResultObjects6[i].setColor("65;117;5");
}
}{for(var i = 0, len = gdjs.MainCode.GDEconomyResultObjects6.length ;i < len;++i) {
    gdjs.MainCode.GDEconomyResultObjects6[i].addPolarForce(180, 50, 1);
}
}{runtimeScene.getScene().getVariables().getFromIndex(3).add(1);
}{gdjs.evtTools.sound.playSound(runtimeScene, "assets\\Sounds\\Yay.mp3", false, 100, 1);
}}

}


{


let isConditionTrue_0 = false;
{

{ //Subevents
gdjs.MainCode.eventsList217(runtimeScene, asyncObjectsList);} //End of subevents
}

}


};gdjs.MainCode.asyncCallback15274756 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.MainCode.localVariables);

{ //Subevents
gdjs.MainCode.eventsList218(runtimeScene, asyncObjectsList);} //End of subevents
gdjs.MainCode.localVariables.length = 0;
}
gdjs.MainCode.eventsList219 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
asyncObjectsList.backupLocalVariablesContainers(gdjs.MainCode.localVariables);
for (const obj of gdjs.MainCode.GDNext_9595buttonObjects2) asyncObjectsList.addObject("Next_button", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1), (runtimeScene) => (gdjs.MainCode.asyncCallback15274756(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.MainCode.eventsList220 = function(runtimeScene, asyncObjectsList) {

{


let isConditionTrue_0 = false;
{

{ //Subevents
gdjs.MainCode.eventsList219(runtimeScene, asyncObjectsList);} //End of subevents
}

}


{



}


{



}


{



}


{



}


};gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDEconomyResultObjects6Objects = Hashtable.newFrom({"EconomyResult": gdjs.MainCode.GDEconomyResultObjects6});
gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDPAResultObjects6Objects = Hashtable.newFrom({"PAResult": gdjs.MainCode.GDPAResultObjects6});
gdjs.MainCode.eventsList221 = function(runtimeScene, asyncObjectsList) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("NextText"), gdjs.MainCode.GDNextTextObjects7);
gdjs.copyArray(asyncObjectsList.getObjects("Next_button"), gdjs.MainCode.GDNext_9595buttonObjects7);

{for(var i = 0, len = gdjs.MainCode.GDNext_9595buttonObjects7.length ;i < len;++i) {
    gdjs.MainCode.GDNext_9595buttonObjects7[i].hide(false);
}
for(var i = 0, len = gdjs.MainCode.GDNextTextObjects7.length ;i < len;++i) {
    gdjs.MainCode.GDNextTextObjects7[i].hide(false);
}
}}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15634279);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("PublicApprovalTxt"), gdjs.MainCode.GDPublicApprovalTxtObjects6);
gdjs.MainCode.GDPAResultObjects6.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDPAResultObjects6Objects, (( gdjs.MainCode.GDPublicApprovalTxtObjects6.length === 0 ) ? 0 :gdjs.MainCode.GDPublicApprovalTxtObjects6[0].getX()), (( gdjs.MainCode.GDPublicApprovalTxtObjects6.length === 0 ) ? 0 :gdjs.MainCode.GDPublicApprovalTxtObjects6[0].getY()), "");
}{for(var i = 0, len = gdjs.MainCode.GDPAResultObjects6.length ;i < len;++i) {
    gdjs.MainCode.GDPAResultObjects6[i].getBehavior("Text").setText("+1");
}
}{for(var i = 0, len = gdjs.MainCode.GDPAResultObjects6.length ;i < len;++i) {
    gdjs.MainCode.GDPAResultObjects6[i].setColor("65;117;5");
}
}{for(var i = 0, len = gdjs.MainCode.GDPAResultObjects6.length ;i < len;++i) {
    gdjs.MainCode.GDPAResultObjects6[i].addPolarForce(180, 50, 1);
}
}{for(var i = 0, len = gdjs.MainCode.GDPAResultObjects6.length ;i < len;++i) {
    gdjs.MainCode.GDPAResultObjects6[i].getBehavior("Tween").addObjectOpacityTween2("Opacity", 0, "linear", 2, true);
}
}{runtimeScene.getScene().getVariables().getFromIndex(4).add(1);
}{gdjs.evtTools.sound.playSound(runtimeScene, "assets\\Sounds\\Yay.mp3", false, 100, 1);
}}

}


};gdjs.MainCode.asyncCallback15279172 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.MainCode.localVariables);

{ //Subevents
gdjs.MainCode.eventsList221(runtimeScene, asyncObjectsList);} //End of subevents
gdjs.MainCode.localVariables.length = 0;
}
gdjs.MainCode.eventsList222 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
asyncObjectsList.backupLocalVariablesContainers(gdjs.MainCode.localVariables);
/* Don't save Next_button as it will be provided by the parent asyncObjectsList. */
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1), (runtimeScene) => (gdjs.MainCode.asyncCallback15279172(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.MainCode.eventsList223 = function(runtimeScene, asyncObjectsList) {

{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15626608);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("EconomyTxt"), gdjs.MainCode.GDEconomyTxtObjects6);
gdjs.MainCode.GDEconomyResultObjects6.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDEconomyResultObjects6Objects, (( gdjs.MainCode.GDEconomyTxtObjects6.length === 0 ) ? 0 :gdjs.MainCode.GDEconomyTxtObjects6[0].getX()), (( gdjs.MainCode.GDEconomyTxtObjects6.length === 0 ) ? 0 :gdjs.MainCode.GDEconomyTxtObjects6[0].getY()), "");
}{for(var i = 0, len = gdjs.MainCode.GDEconomyResultObjects6.length ;i < len;++i) {
    gdjs.MainCode.GDEconomyResultObjects6[i].getBehavior("Text").setText("+1");
}
}{for(var i = 0, len = gdjs.MainCode.GDEconomyResultObjects6.length ;i < len;++i) {
    gdjs.MainCode.GDEconomyResultObjects6[i].getBehavior("Tween").addObjectOpacityTween2("Opacity", 0, "linear", 2, true);
}
}{for(var i = 0, len = gdjs.MainCode.GDEconomyResultObjects6.length ;i < len;++i) {
    gdjs.MainCode.GDEconomyResultObjects6[i].setColor("65;117;5");
}
}{for(var i = 0, len = gdjs.MainCode.GDEconomyResultObjects6.length ;i < len;++i) {
    gdjs.MainCode.GDEconomyResultObjects6[i].addPolarForce(180, 50, 1);
}
}{runtimeScene.getScene().getVariables().getFromIndex(3).add(1);
}{gdjs.evtTools.sound.playSound(runtimeScene, "assets\\Sounds\\Yay.mp3", false, 100, 1);
}}

}


{


let isConditionTrue_0 = false;
{

{ //Subevents
gdjs.MainCode.eventsList222(runtimeScene, asyncObjectsList);} //End of subevents
}

}


};gdjs.MainCode.asyncCallback15278500 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.MainCode.localVariables);

{ //Subevents
gdjs.MainCode.eventsList223(runtimeScene, asyncObjectsList);} //End of subevents
gdjs.MainCode.localVariables.length = 0;
}
gdjs.MainCode.eventsList224 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
asyncObjectsList.backupLocalVariablesContainers(gdjs.MainCode.localVariables);
for (const obj of gdjs.MainCode.GDNext_9595buttonObjects2) asyncObjectsList.addObject("Next_button", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1), (runtimeScene) => (gdjs.MainCode.asyncCallback15278500(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDPersonalWealthResultObjects3Objects = Hashtable.newFrom({"PersonalWealthResult": gdjs.MainCode.GDPersonalWealthResultObjects3});
gdjs.MainCode.eventsList225 = function(runtimeScene, asyncObjectsList) {

{


let isConditionTrue_0 = false;
{

{ //Subevents
gdjs.MainCode.eventsList224(runtimeScene, asyncObjectsList);} //End of subevents
}

}


{



}


{



}


{



}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15648579);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("PersonalGainsTxt"), gdjs.MainCode.GDPersonalGainsTxtObjects3);
gdjs.MainCode.GDPersonalWealthResultObjects3.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDPersonalWealthResultObjects3Objects, (( gdjs.MainCode.GDPersonalGainsTxtObjects3.length === 0 ) ? 0 :gdjs.MainCode.GDPersonalGainsTxtObjects3[0].getX()), (( gdjs.MainCode.GDPersonalGainsTxtObjects3.length === 0 ) ? 0 :gdjs.MainCode.GDPersonalGainsTxtObjects3[0].getY()), "");
}{for(var i = 0, len = gdjs.MainCode.GDPersonalWealthResultObjects3.length ;i < len;++i) {
    gdjs.MainCode.GDPersonalWealthResultObjects3[i].getBehavior("Text").setText("+1");
}
}{for(var i = 0, len = gdjs.MainCode.GDPersonalWealthResultObjects3.length ;i < len;++i) {
    gdjs.MainCode.GDPersonalWealthResultObjects3[i].setColor("65;117;5");
}
}{for(var i = 0, len = gdjs.MainCode.GDPersonalWealthResultObjects3.length ;i < len;++i) {
    gdjs.MainCode.GDPersonalWealthResultObjects3[i].addPolarForce(180, 50, 1);
}
}{for(var i = 0, len = gdjs.MainCode.GDPersonalWealthResultObjects3.length ;i < len;++i) {
    gdjs.MainCode.GDPersonalWealthResultObjects3[i].getBehavior("Tween").addObjectOpacityTween2("Opacity", 0, "linear", 2, true);
}
}{runtimeScene.getScene().getVariables().getFromIndex(6).add(1);
}{gdjs.evtTools.sound.playSound(runtimeScene, "assets\\Sounds\\Yay.mp3", false, 100, 1);
}}

}


};gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDPAResultObjects5Objects = Hashtable.newFrom({"PAResult": gdjs.MainCode.GDPAResultObjects5});
gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDRiskResultObjects6Objects = Hashtable.newFrom({"RiskResult": gdjs.MainCode.GDRiskResultObjects6});
gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDPersonalWealthResultObjects6Objects = Hashtable.newFrom({"PersonalWealthResult": gdjs.MainCode.GDPersonalWealthResultObjects6});
gdjs.MainCode.eventsList226 = function(runtimeScene, asyncObjectsList) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("NextText"), gdjs.MainCode.GDNextTextObjects7);
gdjs.copyArray(asyncObjectsList.getObjects("Next_button"), gdjs.MainCode.GDNext_9595buttonObjects7);

{for(var i = 0, len = gdjs.MainCode.GDNext_9595buttonObjects7.length ;i < len;++i) {
    gdjs.MainCode.GDNext_9595buttonObjects7[i].hide(false);
}
for(var i = 0, len = gdjs.MainCode.GDNextTextObjects7.length ;i < len;++i) {
    gdjs.MainCode.GDNextTextObjects7[i].hide(false);
}
}}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15648580);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("PersonalGainsTxt"), gdjs.MainCode.GDPersonalGainsTxtObjects6);
gdjs.MainCode.GDPersonalWealthResultObjects6.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDPersonalWealthResultObjects6Objects, (( gdjs.MainCode.GDPersonalGainsTxtObjects6.length === 0 ) ? 0 :gdjs.MainCode.GDPersonalGainsTxtObjects6[0].getX()), (( gdjs.MainCode.GDPersonalGainsTxtObjects6.length === 0 ) ? 0 :gdjs.MainCode.GDPersonalGainsTxtObjects6[0].getY()), "");
}{for(var i = 0, len = gdjs.MainCode.GDPersonalWealthResultObjects6.length ;i < len;++i) {
    gdjs.MainCode.GDPersonalWealthResultObjects6[i].getBehavior("Text").setText("+1");
}
}{for(var i = 0, len = gdjs.MainCode.GDPersonalWealthResultObjects6.length ;i < len;++i) {
    gdjs.MainCode.GDPersonalWealthResultObjects6[i].setColor("65;117;5");
}
}{for(var i = 0, len = gdjs.MainCode.GDPersonalWealthResultObjects6.length ;i < len;++i) {
    gdjs.MainCode.GDPersonalWealthResultObjects6[i].addPolarForce(180, 50, 1);
}
}{for(var i = 0, len = gdjs.MainCode.GDPersonalWealthResultObjects6.length ;i < len;++i) {
    gdjs.MainCode.GDPersonalWealthResultObjects6[i].getBehavior("Tween").addObjectOpacityTween2("Opacity", 0, "linear", 2, true);
}
}{runtimeScene.getScene().getVariables().getFromIndex(6).add(1);
}{gdjs.evtTools.sound.playSound(runtimeScene, "assets\\Sounds\\Yay.mp3", false, 100, 1);
}}

}


};gdjs.MainCode.asyncCallback15283820 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.MainCode.localVariables);

{ //Subevents
gdjs.MainCode.eventsList226(runtimeScene, asyncObjectsList);} //End of subevents
gdjs.MainCode.localVariables.length = 0;
}
gdjs.MainCode.eventsList227 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
asyncObjectsList.backupLocalVariablesContainers(gdjs.MainCode.localVariables);
/* Don't save Next_button as it will be provided by the parent asyncObjectsList. */
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1), (runtimeScene) => (gdjs.MainCode.asyncCallback15283820(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.MainCode.eventsList228 = function(runtimeScene, asyncObjectsList) {

{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15641599);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("ScandalRiskTxt"), gdjs.MainCode.GDScandalRiskTxtObjects6);
gdjs.MainCode.GDRiskResultObjects6.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDRiskResultObjects6Objects, (( gdjs.MainCode.GDScandalRiskTxtObjects6.length === 0 ) ? 0 :gdjs.MainCode.GDScandalRiskTxtObjects6[0].getX()), (( gdjs.MainCode.GDScandalRiskTxtObjects6.length === 0 ) ? 0 :gdjs.MainCode.GDScandalRiskTxtObjects6[0].getY()), "");
}{for(var i = 0, len = gdjs.MainCode.GDRiskResultObjects6.length ;i < len;++i) {
    gdjs.MainCode.GDRiskResultObjects6[i].getBehavior("Text").setText("+2");
}
}{for(var i = 0, len = gdjs.MainCode.GDRiskResultObjects6.length ;i < len;++i) {
    gdjs.MainCode.GDRiskResultObjects6[i].setColor("208;2;27");
}
}{for(var i = 0, len = gdjs.MainCode.GDRiskResultObjects6.length ;i < len;++i) {
    gdjs.MainCode.GDRiskResultObjects6[i].addPolarForce(180, 50, 1);
}
}{for(var i = 0, len = gdjs.MainCode.GDRiskResultObjects6.length ;i < len;++i) {
    gdjs.MainCode.GDRiskResultObjects6[i].getBehavior("Tween").addObjectOpacityTween2("Opacity", 0, "linear", 2, true);
}
}{runtimeScene.getScene().getVariables().getFromIndex(5).add(2);
}{gdjs.evtTools.sound.playSound(runtimeScene, "assets\\Sounds\\Shocked.mp3", false, 100, 1);
}}

}


{


let isConditionTrue_0 = false;
{

{ //Subevents
gdjs.MainCode.eventsList227(runtimeScene, asyncObjectsList);} //End of subevents
}

}


};gdjs.MainCode.asyncCallback15283148 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.MainCode.localVariables);

{ //Subevents
gdjs.MainCode.eventsList228(runtimeScene, asyncObjectsList);} //End of subevents
gdjs.MainCode.localVariables.length = 0;
}
gdjs.MainCode.eventsList229 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
asyncObjectsList.backupLocalVariablesContainers(gdjs.MainCode.localVariables);
/* Don't save Next_button as it will be provided by the parent asyncObjectsList. */
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1), (runtimeScene) => (gdjs.MainCode.asyncCallback15283148(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.MainCode.eventsList230 = function(runtimeScene, asyncObjectsList) {

{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15634280);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("PublicApprovalTxt"), gdjs.MainCode.GDPublicApprovalTxtObjects5);
gdjs.MainCode.GDPAResultObjects5.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDPAResultObjects5Objects, (( gdjs.MainCode.GDPublicApprovalTxtObjects5.length === 0 ) ? 0 :gdjs.MainCode.GDPublicApprovalTxtObjects5[0].getX()), (( gdjs.MainCode.GDPublicApprovalTxtObjects5.length === 0 ) ? 0 :gdjs.MainCode.GDPublicApprovalTxtObjects5[0].getY()), "");
}{for(var i = 0, len = gdjs.MainCode.GDPAResultObjects5.length ;i < len;++i) {
    gdjs.MainCode.GDPAResultObjects5[i].getBehavior("Text").setText("+1");
}
}{for(var i = 0, len = gdjs.MainCode.GDPAResultObjects5.length ;i < len;++i) {
    gdjs.MainCode.GDPAResultObjects5[i].setColor("65;117;5");
}
}{for(var i = 0, len = gdjs.MainCode.GDPAResultObjects5.length ;i < len;++i) {
    gdjs.MainCode.GDPAResultObjects5[i].addPolarForce(180, 50, 1);
}
}{for(var i = 0, len = gdjs.MainCode.GDPAResultObjects5.length ;i < len;++i) {
    gdjs.MainCode.GDPAResultObjects5[i].getBehavior("Tween").addObjectOpacityTween2("Opacity", 0, "linear", 2, true);
}
}{runtimeScene.getScene().getVariables().getFromIndex(4).add(1);
}{gdjs.evtTools.sound.playSound(runtimeScene, "assets\\Sounds\\Yay.mp3", false, 100, 1);
}}

}


{


let isConditionTrue_0 = false;
{

{ //Subevents
gdjs.MainCode.eventsList229(runtimeScene, asyncObjectsList);} //End of subevents
}

}


};gdjs.MainCode.asyncCallback15282476 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.MainCode.localVariables);

{ //Subevents
gdjs.MainCode.eventsList230(runtimeScene, asyncObjectsList);} //End of subevents
gdjs.MainCode.localVariables.length = 0;
}
gdjs.MainCode.eventsList231 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
asyncObjectsList.backupLocalVariablesContainers(gdjs.MainCode.localVariables);
for (const obj of gdjs.MainCode.GDNext_9595buttonObjects2) asyncObjectsList.addObject("Next_button", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1), (runtimeScene) => (gdjs.MainCode.asyncCallback15282476(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.MainCode.eventsList232 = function(runtimeScene, asyncObjectsList) {

{



}


{


let isConditionTrue_0 = false;
{

{ //Subevents
gdjs.MainCode.eventsList231(runtimeScene, asyncObjectsList);} //End of subevents
}

}


};gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDPAResultObjects5Objects = Hashtable.newFrom({"PAResult": gdjs.MainCode.GDPAResultObjects5});
gdjs.MainCode.eventsList233 = function(runtimeScene, asyncObjectsList) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("NextText"), gdjs.MainCode.GDNextTextObjects6);
gdjs.copyArray(asyncObjectsList.getObjects("Next_button"), gdjs.MainCode.GDNext_9595buttonObjects6);

{for(var i = 0, len = gdjs.MainCode.GDNext_9595buttonObjects6.length ;i < len;++i) {
    gdjs.MainCode.GDNext_9595buttonObjects6[i].hide(false);
}
for(var i = 0, len = gdjs.MainCode.GDNextTextObjects6.length ;i < len;++i) {
    gdjs.MainCode.GDNextTextObjects6[i].hide(false);
}
}}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15634281);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("PublicApprovalTxt"), gdjs.MainCode.GDPublicApprovalTxtObjects5);
gdjs.MainCode.GDPAResultObjects5.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDPAResultObjects5Objects, (( gdjs.MainCode.GDPublicApprovalTxtObjects5.length === 0 ) ? 0 :gdjs.MainCode.GDPublicApprovalTxtObjects5[0].getX()), (( gdjs.MainCode.GDPublicApprovalTxtObjects5.length === 0 ) ? 0 :gdjs.MainCode.GDPublicApprovalTxtObjects5[0].getY()), "");
}{for(var i = 0, len = gdjs.MainCode.GDPAResultObjects5.length ;i < len;++i) {
    gdjs.MainCode.GDPAResultObjects5[i].getBehavior("Text").setText("+1");
}
}{for(var i = 0, len = gdjs.MainCode.GDPAResultObjects5.length ;i < len;++i) {
    gdjs.MainCode.GDPAResultObjects5[i].setColor("65;117;5");
}
}{for(var i = 0, len = gdjs.MainCode.GDPAResultObjects5.length ;i < len;++i) {
    gdjs.MainCode.GDPAResultObjects5[i].addPolarForce(180, 50, 1);
}
}{for(var i = 0, len = gdjs.MainCode.GDPAResultObjects5.length ;i < len;++i) {
    gdjs.MainCode.GDPAResultObjects5[i].getBehavior("Tween").addObjectOpacityTween2("Opacity", 0, "linear", 2, true);
}
}{runtimeScene.getScene().getVariables().getFromIndex(4).add(1);
}{gdjs.evtTools.sound.playSound(runtimeScene, "assets\\Sounds\\Yay.mp3", false, 100, 1);
}}

}


};gdjs.MainCode.asyncCallback15285820 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.MainCode.localVariables);

{ //Subevents
gdjs.MainCode.eventsList233(runtimeScene, asyncObjectsList);} //End of subevents
gdjs.MainCode.localVariables.length = 0;
}
gdjs.MainCode.eventsList234 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
asyncObjectsList.backupLocalVariablesContainers(gdjs.MainCode.localVariables);
for (const obj of gdjs.MainCode.GDNext_9595buttonObjects2) asyncObjectsList.addObject("Next_button", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1), (runtimeScene) => (gdjs.MainCode.asyncCallback15285820(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.MainCode.eventsList235 = function(runtimeScene, asyncObjectsList) {

{



}


{


let isConditionTrue_0 = false;
{

{ //Subevents
gdjs.MainCode.eventsList234(runtimeScene, asyncObjectsList);} //End of subevents
}

}


{



}


{



}


{



}


{



}


};gdjs.MainCode.asyncCallback15288908 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.MainCode.localVariables);
gdjs.MainCode.localVariables.length = 0;
}
gdjs.MainCode.eventsList236 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
asyncObjectsList.backupLocalVariablesContainers(gdjs.MainCode.localVariables);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1), (runtimeScene) => (gdjs.MainCode.asyncCallback15288908(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDEconomyResultObjects4Objects = Hashtable.newFrom({"EconomyResult": gdjs.MainCode.GDEconomyResultObjects4});
gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDPersonalWealthResultObjects5Objects = Hashtable.newFrom({"PersonalWealthResult": gdjs.MainCode.GDPersonalWealthResultObjects5});
gdjs.MainCode.eventsList237 = function(runtimeScene, asyncObjectsList) {

{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15644087);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("PersonalGainsTxt"), gdjs.MainCode.GDPersonalGainsTxtObjects5);
gdjs.MainCode.GDPersonalWealthResultObjects5.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDPersonalWealthResultObjects5Objects, (( gdjs.MainCode.GDPersonalGainsTxtObjects5.length === 0 ) ? 0 :gdjs.MainCode.GDPersonalGainsTxtObjects5[0].getX()), (( gdjs.MainCode.GDPersonalGainsTxtObjects5.length === 0 ) ? 0 :gdjs.MainCode.GDPersonalGainsTxtObjects5[0].getY()), "");
}{for(var i = 0, len = gdjs.MainCode.GDPersonalWealthResultObjects5.length ;i < len;++i) {
    gdjs.MainCode.GDPersonalWealthResultObjects5[i].getBehavior("Text").setText("-1");
}
}{for(var i = 0, len = gdjs.MainCode.GDPersonalWealthResultObjects5.length ;i < len;++i) {
    gdjs.MainCode.GDPersonalWealthResultObjects5[i].setColor("208;2;27");
}
}{for(var i = 0, len = gdjs.MainCode.GDPersonalWealthResultObjects5.length ;i < len;++i) {
    gdjs.MainCode.GDPersonalWealthResultObjects5[i].addPolarForce(180, 50, 1);
}
}{for(var i = 0, len = gdjs.MainCode.GDPersonalWealthResultObjects5.length ;i < len;++i) {
    gdjs.MainCode.GDPersonalWealthResultObjects5[i].getBehavior("Tween").addObjectOpacityTween2("Opacity", 0, "linear", 2, true);
}
}{runtimeScene.getScene().getVariables().getFromIndex(6).sub(1);
}{gdjs.evtTools.sound.playSound(runtimeScene, "assets\\Sounds\\Shocked.mp3", false, 100, 1);
}}

}


};gdjs.MainCode.eventsList238 = function(runtimeScene, asyncObjectsList) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("NextText"), gdjs.MainCode.GDNextTextObjects5);
gdjs.copyArray(asyncObjectsList.getObjects("Next_button"), gdjs.MainCode.GDNext_9595buttonObjects5);

{for(var i = 0, len = gdjs.MainCode.GDNext_9595buttonObjects5.length ;i < len;++i) {
    gdjs.MainCode.GDNext_9595buttonObjects5[i].hide(false);
}
for(var i = 0, len = gdjs.MainCode.GDNextTextObjects5.length ;i < len;++i) {
    gdjs.MainCode.GDNextTextObjects5[i].hide(false);
}
}
{ //Subevents
gdjs.MainCode.eventsList237(runtimeScene, asyncObjectsList);} //End of subevents
}

}


};gdjs.MainCode.asyncCallback15289580 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.MainCode.localVariables);

{ //Subevents
gdjs.MainCode.eventsList238(runtimeScene, asyncObjectsList);} //End of subevents
gdjs.MainCode.localVariables.length = 0;
}
gdjs.MainCode.eventsList239 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
asyncObjectsList.backupLocalVariablesContainers(gdjs.MainCode.localVariables);
for (const obj of gdjs.MainCode.GDNext_9595buttonObjects2) asyncObjectsList.addObject("Next_button", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1), (runtimeScene) => (gdjs.MainCode.asyncCallback15289580(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.MainCode.eventsList240 = function(runtimeScene, asyncObjectsList) {

{


let isConditionTrue_0 = false;
{

{ //Subevents
gdjs.MainCode.eventsList236(runtimeScene, asyncObjectsList);} //End of subevents
}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15626609);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("EconomyTxt"), gdjs.MainCode.GDEconomyTxtObjects4);
gdjs.MainCode.GDEconomyResultObjects4.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDEconomyResultObjects4Objects, (( gdjs.MainCode.GDEconomyTxtObjects4.length === 0 ) ? 0 :gdjs.MainCode.GDEconomyTxtObjects4[0].getX()), (( gdjs.MainCode.GDEconomyTxtObjects4.length === 0 ) ? 0 :gdjs.MainCode.GDEconomyTxtObjects4[0].getY()), "");
}{for(var i = 0, len = gdjs.MainCode.GDEconomyResultObjects4.length ;i < len;++i) {
    gdjs.MainCode.GDEconomyResultObjects4[i].getBehavior("Text").setText("+1");
}
}{for(var i = 0, len = gdjs.MainCode.GDEconomyResultObjects4.length ;i < len;++i) {
    gdjs.MainCode.GDEconomyResultObjects4[i].getBehavior("Tween").addObjectOpacityTween2("Opacity", 0, "linear", 2, true);
}
}{for(var i = 0, len = gdjs.MainCode.GDEconomyResultObjects4.length ;i < len;++i) {
    gdjs.MainCode.GDEconomyResultObjects4[i].setColor("65;117;5");
}
}{for(var i = 0, len = gdjs.MainCode.GDEconomyResultObjects4.length ;i < len;++i) {
    gdjs.MainCode.GDEconomyResultObjects4[i].addPolarForce(180, 50, 1);
}
}{runtimeScene.getScene().getVariables().getFromIndex(3).add(1);
}{gdjs.evtTools.sound.playSound(runtimeScene, "assets\\Sounds\\Yay.mp3", false, 100, 1);
}}

}


{


let isConditionTrue_0 = false;
{

{ //Subevents
gdjs.MainCode.eventsList239(runtimeScene, asyncObjectsList);} //End of subevents
}

}


{



}


{



}


{



}


{



}


};gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDPAResultObjects4Objects = Hashtable.newFrom({"PAResult": gdjs.MainCode.GDPAResultObjects4});
gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDRiskResultObjects5Objects = Hashtable.newFrom({"RiskResult": gdjs.MainCode.GDRiskResultObjects5});
gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDPersonalWealthResultObjects5Objects = Hashtable.newFrom({"PersonalWealthResult": gdjs.MainCode.GDPersonalWealthResultObjects5});
gdjs.MainCode.eventsList241 = function(runtimeScene, asyncObjectsList) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("NextText"), gdjs.MainCode.GDNextTextObjects6);
gdjs.copyArray(asyncObjectsList.getObjects("Next_button"), gdjs.MainCode.GDNext_9595buttonObjects6);

{for(var i = 0, len = gdjs.MainCode.GDNext_9595buttonObjects6.length ;i < len;++i) {
    gdjs.MainCode.GDNext_9595buttonObjects6[i].hide(false);
}
for(var i = 0, len = gdjs.MainCode.GDNextTextObjects6.length ;i < len;++i) {
    gdjs.MainCode.GDNextTextObjects6[i].hide(false);
}
}}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15648581);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("PersonalGainsTxt"), gdjs.MainCode.GDPersonalGainsTxtObjects5);
gdjs.MainCode.GDPersonalWealthResultObjects5.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDPersonalWealthResultObjects5Objects, (( gdjs.MainCode.GDPersonalGainsTxtObjects5.length === 0 ) ? 0 :gdjs.MainCode.GDPersonalGainsTxtObjects5[0].getX()), (( gdjs.MainCode.GDPersonalGainsTxtObjects5.length === 0 ) ? 0 :gdjs.MainCode.GDPersonalGainsTxtObjects5[0].getY()), "");
}{for(var i = 0, len = gdjs.MainCode.GDPersonalWealthResultObjects5.length ;i < len;++i) {
    gdjs.MainCode.GDPersonalWealthResultObjects5[i].getBehavior("Text").setText("+1");
}
}{for(var i = 0, len = gdjs.MainCode.GDPersonalWealthResultObjects5.length ;i < len;++i) {
    gdjs.MainCode.GDPersonalWealthResultObjects5[i].setColor("65;117;5");
}
}{for(var i = 0, len = gdjs.MainCode.GDPersonalWealthResultObjects5.length ;i < len;++i) {
    gdjs.MainCode.GDPersonalWealthResultObjects5[i].addPolarForce(180, 50, 1);
}
}{for(var i = 0, len = gdjs.MainCode.GDPersonalWealthResultObjects5.length ;i < len;++i) {
    gdjs.MainCode.GDPersonalWealthResultObjects5[i].getBehavior("Tween").addObjectOpacityTween2("Opacity", 0, "linear", 2, true);
}
}{runtimeScene.getScene().getVariables().getFromIndex(6).add(1);
}{gdjs.evtTools.sound.playSound(runtimeScene, "assets\\Sounds\\Yay.mp3", false, 100, 1);
}}

}


};gdjs.MainCode.asyncCallback15294132 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.MainCode.localVariables);

{ //Subevents
gdjs.MainCode.eventsList241(runtimeScene, asyncObjectsList);} //End of subevents
gdjs.MainCode.localVariables.length = 0;
}
gdjs.MainCode.eventsList242 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
asyncObjectsList.backupLocalVariablesContainers(gdjs.MainCode.localVariables);
/* Don't save Next_button as it will be provided by the parent asyncObjectsList. */
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1), (runtimeScene) => (gdjs.MainCode.asyncCallback15294132(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.MainCode.eventsList243 = function(runtimeScene, asyncObjectsList) {

{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15640387);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("ScandalRiskTxt"), gdjs.MainCode.GDScandalRiskTxtObjects5);
gdjs.MainCode.GDRiskResultObjects5.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDRiskResultObjects5Objects, (( gdjs.MainCode.GDScandalRiskTxtObjects5.length === 0 ) ? 0 :gdjs.MainCode.GDScandalRiskTxtObjects5[0].getX()), (( gdjs.MainCode.GDScandalRiskTxtObjects5.length === 0 ) ? 0 :gdjs.MainCode.GDScandalRiskTxtObjects5[0].getY()), "");
}{for(var i = 0, len = gdjs.MainCode.GDRiskResultObjects5.length ;i < len;++i) {
    gdjs.MainCode.GDRiskResultObjects5[i].getBehavior("Text").setText("+1");
}
}{for(var i = 0, len = gdjs.MainCode.GDRiskResultObjects5.length ;i < len;++i) {
    gdjs.MainCode.GDRiskResultObjects5[i].setColor("208;2;27");
}
}{for(var i = 0, len = gdjs.MainCode.GDRiskResultObjects5.length ;i < len;++i) {
    gdjs.MainCode.GDRiskResultObjects5[i].addPolarForce(180, 50, 1);
}
}{for(var i = 0, len = gdjs.MainCode.GDRiskResultObjects5.length ;i < len;++i) {
    gdjs.MainCode.GDRiskResultObjects5[i].getBehavior("Tween").addObjectOpacityTween2("Opacity", 0, "linear", 2, true);
}
}{runtimeScene.getScene().getVariables().getFromIndex(5).add(1);
}{gdjs.evtTools.sound.playSound(runtimeScene, "assets\\Sounds\\Shocked.mp3", false, 100, 1);
}}

}


{


let isConditionTrue_0 = false;
{

{ //Subevents
gdjs.MainCode.eventsList242(runtimeScene, asyncObjectsList);} //End of subevents
}

}


};gdjs.MainCode.asyncCallback15293460 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.MainCode.localVariables);

{ //Subevents
gdjs.MainCode.eventsList243(runtimeScene, asyncObjectsList);} //End of subevents
gdjs.MainCode.localVariables.length = 0;
}
gdjs.MainCode.eventsList244 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
asyncObjectsList.backupLocalVariablesContainers(gdjs.MainCode.localVariables);
/* Don't save Next_button as it will be provided by the parent asyncObjectsList. */
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1), (runtimeScene) => (gdjs.MainCode.asyncCallback15293460(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.MainCode.eventsList245 = function(runtimeScene, asyncObjectsList) {

{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15632283);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("PublicApprovalTxt"), gdjs.MainCode.GDPublicApprovalTxtObjects4);
gdjs.MainCode.GDPAResultObjects4.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDPAResultObjects4Objects, (( gdjs.MainCode.GDPublicApprovalTxtObjects4.length === 0 ) ? 0 :gdjs.MainCode.GDPublicApprovalTxtObjects4[0].getX()), (( gdjs.MainCode.GDPublicApprovalTxtObjects4.length === 0 ) ? 0 :gdjs.MainCode.GDPublicApprovalTxtObjects4[0].getY()), "");
}{for(var i = 0, len = gdjs.MainCode.GDPAResultObjects4.length ;i < len;++i) {
    gdjs.MainCode.GDPAResultObjects4[i].getBehavior("Text").setText("-1");
}
}{for(var i = 0, len = gdjs.MainCode.GDPAResultObjects4.length ;i < len;++i) {
    gdjs.MainCode.GDPAResultObjects4[i].setColor("208;2;27");
}
}{for(var i = 0, len = gdjs.MainCode.GDPAResultObjects4.length ;i < len;++i) {
    gdjs.MainCode.GDPAResultObjects4[i].addPolarForce(180, 50, 1);
}
}{for(var i = 0, len = gdjs.MainCode.GDPAResultObjects4.length ;i < len;++i) {
    gdjs.MainCode.GDPAResultObjects4[i].getBehavior("Tween").addObjectOpacityTween2("Opacity", 0, "linear", 2, true);
}
}{runtimeScene.getScene().getVariables().getFromIndex(4).sub(1);
}{gdjs.evtTools.sound.playSound(runtimeScene, "assets\\Sounds\\Shocked.mp3", false, 100, 1);
}}

}


{


let isConditionTrue_0 = false;
{

{ //Subevents
gdjs.MainCode.eventsList244(runtimeScene, asyncObjectsList);} //End of subevents
}

}


};gdjs.MainCode.asyncCallback15292812 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.MainCode.localVariables);

{ //Subevents
gdjs.MainCode.eventsList245(runtimeScene, asyncObjectsList);} //End of subevents
gdjs.MainCode.localVariables.length = 0;
}
gdjs.MainCode.eventsList246 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
asyncObjectsList.backupLocalVariablesContainers(gdjs.MainCode.localVariables);
for (const obj of gdjs.MainCode.GDNext_9595buttonObjects2) asyncObjectsList.addObject("Next_button", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1), (runtimeScene) => (gdjs.MainCode.asyncCallback15292812(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.MainCode.eventsList247 = function(runtimeScene, asyncObjectsList) {

{



}


{


let isConditionTrue_0 = false;
{

{ //Subevents
gdjs.MainCode.eventsList246(runtimeScene, asyncObjectsList);} //End of subevents
}

}


};gdjs.MainCode.eventsList248 = function(runtimeScene, asyncObjectsList) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(2).getAsString() == "Aliens? I’ve been saying it for YEARS. The people know I’m right. #ToldYouSo");
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15195292);
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.MainCode.eventsList77(runtimeScene, asyncObjectsList);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(2).getAsString() == "Let’s create jobs by building eagle shaped like satellites! #EconBoom");
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15197756);
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.MainCode.eventsList82(runtimeScene, asyncObjectsList);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(2).getAsString() == "Launching new NFT: ‘First Contact Collection.’ 10,000 pics. Limited edition.");
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15200140);
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.MainCode.eventsList89(runtimeScene, asyncObjectsList);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(2).getAsString() == "This country was BUILT on ketchup. We’ll fix this with pride and extra fries.");
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15203268);
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.MainCode.eventsList96(runtimeScene, asyncObjectsList);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(2).getAsString() == "Time to fund local tomato farms. Red jobs for red sauce. #Agrinomics");
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15206300);
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.MainCode.eventsList99(runtimeScene, asyncObjectsList);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(2).getAsString() == "Introducing: PRESIMATO. Luxury ketchup. Gold bottle, same old taste.");
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15209524);
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.MainCode.eventsList106(runtimeScene, asyncObjectsList);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(2).getAsString() == "Kids love the hamster? Great. Let’s mascot it. Giant Hammy for President!");
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15212540);
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.MainCode.eventsList111(runtimeScene, asyncObjectsList);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(2).getAsString() == "Sell plushies. Open a theme park. Call it Rodentland. Huge potential.");
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15214948);
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.MainCode.eventsList116(runtimeScene, asyncObjectsList);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(2).getAsString() == "I’m licensing the giant hamster’s image for a new crypto: ChewCoin.");
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15218044);
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.MainCode.eventsList125(runtimeScene, asyncObjectsList);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(2).getAsString() == "Sunglasses? I never take mine off. Coolness is mandatory. #ShadeNation");
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15209220);
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.MainCode.eventsList133(runtimeScene, asyncObjectsList);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(2).getAsString() == "National production push! Boost jobs, block sun. #SolarStimulus");
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15225588);
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.MainCode.eventsList138(runtimeScene, asyncObjectsList);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(2).getAsString() == "Launching limited edition red cap-shaped sunglasses. Smartest ever. #Visionary");
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15229372);
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.MainCode.eventsList145(runtimeScene, asyncObjectsList);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(2).getAsString() == "Of course hotdogs are veggies. I’ve been eating healthy this whole time!");
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15232612);
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.MainCode.eventsList150(runtimeScene, asyncObjectsList);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(2).getAsString() == "Time to rebrand school lunches. Hotdogs for everyone. tax write-off.");
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15235948);
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.MainCode.eventsList157(runtimeScene, asyncObjectsList);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(2).getAsString() == "Visit my shop: VeganDog™. 99% mystery, 1% marketing. #EarnToEat");
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15239260);
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.MainCode.eventsList164(runtimeScene, asyncObjectsList);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(2).getAsString() == "Relax, folks. I’ve got a hotline to the Internet. We’re all good. #NoOfflineZone");
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15242692);
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.MainCode.eventsList171(runtimeScene, asyncObjectsList);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(2).getAsString() == "Time to build local servers. Keep the net local, keep the jobs booming.");
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15245932);
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.MainCode.eventsList178(runtimeScene, asyncObjectsList);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(2).getAsString() == "Use PresiDrive™. Holds memes, emails, AND my autobiography. Only $99.99");
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15249940);
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.MainCode.eventsList185(runtimeScene, asyncObjectsList);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(2).getAsString() == "That goose gets it. Maybe I’ll appoint it to my advisory board.");
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15253508);
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.MainCode.eventsList188(runtimeScene, asyncObjectsList);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(2).getAsString() == "Let’s build the Goose Capitol right next to the Parliament. #GooseGDP");
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15256812);
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.MainCode.eventsList191(runtimeScene, asyncObjectsList);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(2).getAsString() == "Exclusive goose-branded merchandise coming. Hats, hoodies, honks.");
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15260116);
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.MainCode.eventsList196(runtimeScene, asyncObjectsList);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(2).getAsString() == "Just did the dance. My hips broke a window. #PowerMovesOnly");
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15263588);
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.MainCode.eventsList203(runtimeScene, asyncObjectsList);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(2).getAsString() == "Fund our own national dance app: ChatterChirp. Jobs, fun, control. #AppConomy");
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15266756);
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.MainCode.eventsList208(runtimeScene, asyncObjectsList);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(2).getAsString() == "Watch me dance: The PresiSlide™. Unlockable with red cap token. #ShakeItRich");
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15270540);
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.MainCode.eventsList215(runtimeScene, asyncObjectsList);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(2).getAsString() == "I love it. The anthem SLAPS now. #RobotRhythm");
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15273780);
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.MainCode.eventsList220(runtimeScene, asyncObjectsList);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(2).getAsString() == "National AI for National anthems. Invest in future jams. #CodeToCash");
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15277524);
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.MainCode.eventsList225(runtimeScene, asyncObjectsList);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(2).getAsString() == "Buy my album: PresiBeats Vol.1 - only $49.99. #StreamingEmpire");
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15281268);
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.MainCode.eventsList232(runtimeScene, asyncObjectsList);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(2).getAsString() == "Every dog gets a tablet. It’s time. We believe in pet progress. #SmartDogsRule");
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15284684);
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.MainCode.eventsList235(runtimeScene, asyncObjectsList);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(2).getAsString() == "Launch CanineTech initiative. Training labs, jobs, dog dollars. #Pawductivity");
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15287932);
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.MainCode.eventsList240(runtimeScene, asyncObjectsList);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(2).getAsString() == "Exclusive BarkCoin pre-sale begins now. Invest in your dog’s future. #FurRich");
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15291676);
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.MainCode.eventsList247(runtimeScene, asyncObjectsList);} //End of subevents
}

}


};gdjs.MainCode.eventsList249 = function(runtimeScene, asyncObjectsList) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
{isConditionTrue_1 = (runtimeScene.getScene().getVariables().getFromIndex(4).getAsNumber() >= 5);
}
if (isConditionTrue_1) {
isConditionTrue_1 = false;
{isConditionTrue_1 = (runtimeScene.getScene().getVariables().getFromIndex(3).getAsNumber() >= 5);
}
if (isConditionTrue_1) {
isConditionTrue_1 = false;
{isConditionTrue_1 = (runtimeScene.getScene().getVariables().getFromIndex(5).getAsNumber() <= 5);
}
}
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Cap_comments"), gdjs.MainCode.GDCap_9595commentsObjects3);
gdjs.copyArray(runtimeScene.getObjects("Cap_faces"), gdjs.MainCode.GDCap_9595facesObjects3);
{for(var i = 0, len = gdjs.MainCode.GDCap_9595commentsObjects3.length ;i < len;++i) {
    gdjs.MainCode.GDCap_9595commentsObjects3[i].getBehavior("Text").setText(runtimeScene.getScene().getVariables().getFromIndex(28).getChild((gdjs.evtTools.common.toString(gdjs.randomInRange(0, gdjs.evtTools.variable.getVariableChildCount(runtimeScene.getScene().getVariables().getFromIndex(28)) - 1)))).getAsString());
}
}{for(var i = 0, len = gdjs.MainCode.GDCap_9595facesObjects3.length ;i < len;++i) {
    gdjs.MainCode.GDCap_9595facesObjects3[i].getBehavior("Animation").setAnimationName("Happy2");
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
{isConditionTrue_1 = (runtimeScene.getScene().getVariables().getFromIndex(4).getAsNumber() < 5);
}
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
{isConditionTrue_1 = (runtimeScene.getScene().getVariables().getFromIndex(3).getAsNumber() < 5);
}
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
{isConditionTrue_1 = (runtimeScene.getScene().getVariables().getFromIndex(5).getAsNumber() > 5);
}
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Cap_comments"), gdjs.MainCode.GDCap_9595commentsObjects3);
gdjs.copyArray(runtimeScene.getObjects("Cap_faces"), gdjs.MainCode.GDCap_9595facesObjects3);
{for(var i = 0, len = gdjs.MainCode.GDCap_9595commentsObjects3.length ;i < len;++i) {
    gdjs.MainCode.GDCap_9595commentsObjects3[i].getBehavior("Text").setText(runtimeScene.getScene().getVariables().getFromIndex(29).getChild((gdjs.evtTools.common.toString(gdjs.randomInRange(0, gdjs.evtTools.variable.getVariableChildCount(runtimeScene.getScene().getVariables().getFromIndex(29)) - 1)))).getAsString());
}
}{for(var i = 0, len = gdjs.MainCode.GDCap_9595facesObjects3.length ;i < len;++i) {
    gdjs.MainCode.GDCap_9595facesObjects3[i].getBehavior("Animation").setAnimationName("Glum");
}
}}

}


{


gdjs.MainCode.eventsList248(runtimeScene, asyncObjectsList);
}


};gdjs.MainCode.asyncCallback15190244 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.MainCode.localVariables);
gdjs.copyArray(runtimeScene.getObjects("Next_button"), gdjs.MainCode.GDNext_9595buttonObjects2);
{for(var i = 0, len = gdjs.MainCode.GDNext_9595buttonObjects2.length ;i < len;++i) {
    gdjs.MainCode.GDNext_9595buttonObjects2[i].getBehavior("ShakeObject_PositionAngleScale").ShakeObject_PositionAngleScale(1, 0, 0, 0, 20, 0.2, true, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}
{ //Subevents
gdjs.MainCode.eventsList249(runtimeScene, asyncObjectsList);} //End of subevents
gdjs.MainCode.localVariables.length = 0;
}
gdjs.MainCode.eventsList250 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.MainCode.localVariables);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1), (runtimeScene) => (gdjs.MainCode.asyncCallback15190244(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.MainCode.eventsList251 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(7).getAsString() == "RESULT");
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15190012);
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.MainCode.eventsList250(runtimeScene);} //End of subevents
}

}


};gdjs.MainCode.asyncCallback15298172 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.MainCode.localVariables);
gdjs.copyArray(asyncObjectsList.getObjects("CapCondition"), gdjs.MainCode.GDCapConditionObjects4);

{gdjs.evtTools.camera.hideLayer(runtimeScene, "BlackScreen");
}{for(var i = 0, len = gdjs.MainCode.GDCapConditionObjects4.length ;i < len;++i) {
    gdjs.MainCode.GDCapConditionObjects4[i].getBehavior("Animation").setAnimationName("Sleeping");
}
}gdjs.MainCode.localVariables.length = 0;
}
gdjs.MainCode.eventsList252 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
asyncObjectsList.backupLocalVariablesContainers(gdjs.MainCode.localVariables);
for (const obj of gdjs.MainCode.GDCapConditionObjects3) asyncObjectsList.addObject("CapCondition", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(3), (runtimeScene) => (gdjs.MainCode.asyncCallback15298172(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.MainCode.asyncCallback11340652 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.MainCode.localVariables);
gdjs.copyArray(asyncObjectsList.getObjects("BlackScreen"), gdjs.MainCode.GDBlackScreenObjects3);

gdjs.copyArray(asyncObjectsList.getObjects("BlackScreenText"), gdjs.MainCode.GDBlackScreenTextObjects3);

gdjs.copyArray(asyncObjectsList.getObjects("CapCondition"), gdjs.MainCode.GDCapConditionObjects3);

{for(var i = 0, len = gdjs.MainCode.GDBlackScreenObjects3.length ;i < len;++i) {
    gdjs.MainCode.GDBlackScreenObjects3[i].getBehavior("Tween").addObjectOpacityTween2("OpacityZero", 0, "linear", 1, false);
}
}{for(var i = 0, len = gdjs.MainCode.GDBlackScreenTextObjects3.length ;i < len;++i) {
    gdjs.MainCode.GDBlackScreenTextObjects3[i].getBehavior("Tween").addObjectOpacityTween2("OpacityZero", 0, "linear", 1, false);
}
}{for(var i = 0, len = gdjs.MainCode.GDCapConditionObjects3.length ;i < len;++i) {
    gdjs.MainCode.GDCapConditionObjects3[i].getBehavior("Tween").addObjectOpacityTween2("OpacityZero", 0, "linear", 1, false);
}
}{runtimeScene.getScene().getVariables().getFromIndex(7).setString("DAYSTART");
}
{ //Subevents
gdjs.MainCode.eventsList252(runtimeScene, asyncObjectsList);} //End of subevents
gdjs.MainCode.localVariables.length = 0;
}
gdjs.MainCode.eventsList253 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
asyncObjectsList.backupLocalVariablesContainers(gdjs.MainCode.localVariables);
/* Don't save BlackScreen as it will be provided by the parent asyncObjectsList. */
/* Don't save BlackScreenText as it will be provided by the parent asyncObjectsList. */
for (const obj of gdjs.MainCode.GDCapConditionObjects2) asyncObjectsList.addObject("CapCondition", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(2), (runtimeScene) => (gdjs.MainCode.asyncCallback11340652(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.MainCode.asyncCallback11397868 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.MainCode.localVariables);
gdjs.copyArray(asyncObjectsList.getObjects("CapCondition"), gdjs.MainCode.GDCapConditionObjects2);

{for(var i = 0, len = gdjs.MainCode.GDCapConditionObjects2.length ;i < len;++i) {
    gdjs.MainCode.GDCapConditionObjects2[i].getBehavior("Animation").setAnimationName("wakeup");
}
}
{ //Subevents
gdjs.MainCode.eventsList253(runtimeScene, asyncObjectsList);} //End of subevents
gdjs.MainCode.localVariables.length = 0;
}
gdjs.MainCode.eventsList254 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.MainCode.localVariables);
for (const obj of gdjs.MainCode.GDBlackScreenObjects1) asyncObjectsList.addObject("BlackScreen", obj);
for (const obj of gdjs.MainCode.GDBlackScreenTextObjects1) asyncObjectsList.addObject("BlackScreenText", obj);
for (const obj of gdjs.MainCode.GDCapConditionObjects1) asyncObjectsList.addObject("CapCondition", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(3), (runtimeScene) => (gdjs.MainCode.asyncCallback11397868(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.MainCode.eventsList255 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("BlackScreenText"), gdjs.MainCode.GDBlackScreenTextObjects2);
{for(var i = 0, len = gdjs.MainCode.GDBlackScreenTextObjects2.length ;i < len;++i) {
    gdjs.MainCode.GDBlackScreenTextObjects2[i].getBehavior("Text").setText("Next Day " + gdjs.evtTools.common.toString(runtimeScene.getScene().getVariables().getFromIndex(0).getAsNumber()) + " / 11");
}
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("BlackScreen"), gdjs.MainCode.GDBlackScreenObjects1);
gdjs.copyArray(runtimeScene.getObjects("BlackScreenText"), gdjs.MainCode.GDBlackScreenTextObjects1);
gdjs.copyArray(runtimeScene.getObjects("CapCondition"), gdjs.MainCode.GDCapConditionObjects1);
{for(var i = 0, len = gdjs.MainCode.GDCapConditionObjects1.length ;i < len;++i) {
    gdjs.MainCode.GDCapConditionObjects1[i].getBehavior("Animation").setAnimationName("Sleeping");
}
}{gdjs.evtTools.camera.showLayer(runtimeScene, "BlackScreen");
}{for(var i = 0, len = gdjs.MainCode.GDBlackScreenObjects1.length ;i < len;++i) {
    gdjs.MainCode.GDBlackScreenObjects1[i].getBehavior("Tween").addObjectOpacityTween2("FadetoLight", 255, "linear", 2, false);
}
}{for(var i = 0, len = gdjs.MainCode.GDBlackScreenTextObjects1.length ;i < len;++i) {
    gdjs.MainCode.GDBlackScreenTextObjects1[i].getBehavior("Tween").addObjectOpacityTween2("FadetoLight", 255, "linear", 2, false);
}
}{for(var i = 0, len = gdjs.MainCode.GDCapConditionObjects1.length ;i < len;++i) {
    gdjs.MainCode.GDCapConditionObjects1[i].getBehavior("Tween").addObjectOpacityTween2("FadetoLight", 255, "linear", 2, false);
}
}
{ //Subevents
gdjs.MainCode.eventsList254(runtimeScene);} //End of subevents
}

}


};gdjs.MainCode.eventsList256 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(7).getAsString() == "CLOSING");
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15295252);
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.MainCode.eventsList255(runtimeScene);} //End of subevents
}

}


};gdjs.MainCode.asyncCallback15319524 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.MainCode.localVariables);
gdjs.copyArray(asyncObjectsList.getObjects("BlackScreenText"), gdjs.MainCode.GDBlackScreenTextObjects3);

gdjs.copyArray(runtimeScene.getObjects("Restart_button"), gdjs.MainCode.GDRestart_9595buttonObjects3);
{for(var i = 0, len = gdjs.MainCode.GDBlackScreenTextObjects3.length ;i < len;++i) {
    gdjs.MainCode.GDBlackScreenTextObjects3[i].getBehavior("Text").setText(runtimeScene.getScene().getVariables().getFromIndex(30).getAsString());
}
}{for(var i = 0, len = gdjs.MainCode.GDRestart_9595buttonObjects3.length ;i < len;++i) {
    gdjs.MainCode.GDRestart_9595buttonObjects3[i].getBehavior("Opacity").setOpacity(150);
}
}{for(var i = 0, len = gdjs.MainCode.GDRestart_9595buttonObjects3.length ;i < len;++i) {
    gdjs.MainCode.GDRestart_9595buttonObjects3[i].hide(false);
}
}gdjs.MainCode.localVariables.length = 0;
}
gdjs.MainCode.eventsList257 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
asyncObjectsList.backupLocalVariablesContainers(gdjs.MainCode.localVariables);
/* Don't save BlackScreenText as it will be provided by the parent asyncObjectsList. */
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.5), (runtimeScene) => (gdjs.MainCode.asyncCallback15319524(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.MainCode.eventsList258 = function(runtimeScene, asyncObjectsList) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
{isConditionTrue_1 = (runtimeScene.getScene().getVariables().getFromIndex(4).getAsNumber() >= 5);
}
if (isConditionTrue_1) {
isConditionTrue_1 = false;
{isConditionTrue_1 = (runtimeScene.getScene().getVariables().getFromIndex(3).getAsNumber() >= 5);
}
if (isConditionTrue_1) {
isConditionTrue_1 = false;
{isConditionTrue_1 = (runtimeScene.getScene().getVariables().getFromIndex(5).getAsNumber() <= 5);
}
}
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
gdjs.copyArray(asyncObjectsList.getObjects("CapCondition"), gdjs.MainCode.GDCapConditionObjects3);

{for(var i = 0, len = gdjs.MainCode.GDCapConditionObjects3.length ;i < len;++i) {
    gdjs.MainCode.GDCapConditionObjects3[i].getBehavior("Animation").setAnimationName("Win");
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
{isConditionTrue_1 = (runtimeScene.getScene().getVariables().getFromIndex(4).getAsNumber() < 5);
}
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
{isConditionTrue_1 = (runtimeScene.getScene().getVariables().getFromIndex(3).getAsNumber() < 5);
}
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
{isConditionTrue_1 = (runtimeScene.getScene().getVariables().getFromIndex(5).getAsNumber() > 5);
}
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
}
}
if (isConditionTrue_0) {
gdjs.copyArray(asyncObjectsList.getObjects("CapCondition"), gdjs.MainCode.GDCapConditionObjects3);

{for(var i = 0, len = gdjs.MainCode.GDCapConditionObjects3.length ;i < len;++i) {
    gdjs.MainCode.GDCapConditionObjects3[i].getBehavior("Animation").setAnimationName("Lost");
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(3).getAsNumber() >= 5);
}
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(30).setString("Economy = " + runtimeScene.getScene().getVariables().getFromIndex(3).getAsString() + " The economy’s booming! Cash rains harder than confetti.");
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(3).getAsNumber() < 5);
}
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(30).setString("Economy = " + runtimeScene.getScene().getVariables().getFromIndex(3).getAsString() + " The economy collapsed faster than your last campaign promise.");
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(4).getAsNumber() >= 5);
}
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(30).concatenateString(gdjs.evtTools.string.newLine() + "Public Approval = " + runtimeScene.getScene().getVariables().getFromIndex(4).getAsString() + " The people love you! Even pigeons are wearing your merch");
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(4).getAsNumber() < 5);
}
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(30).concatenateString(gdjs.evtTools.string.newLine() + "Public Approval = " + runtimeScene.getScene().getVariables().getFromIndex(4).getAsString() + " The people turned on you. Streets are filled with boo signs.");
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(5).getAsNumber() < 5);
}
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(30).concatenateString(gdjs.evtTools.string.newLine() + "Risk of Scandal = " + runtimeScene.getScene().getVariables().getFromIndex(5).getAsString() + " No scandals! You look cleaner than a freshly waxed limo.");
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(5).getAsNumber() >= 5);
}
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(30).concatenateString(gdjs.evtTools.string.newLine() + "Risk of Scandal = " + runtimeScene.getScene().getVariables().getFromIndex(5).getAsString() + " Scandals exploded! The headlines now call you ‘Disgrace-in-Chief’.");
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(6).getAsNumber() == 1);
}
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(30).concatenateString(gdjs.evtTools.string.newLine() + gdjs.evtTools.string.newLine() + "Personal Wealth = " + runtimeScene.getScene().getVariables().getFromIndex(6).getAsString() + gdjs.evtTools.string.newLine() + "You’ve got lint in your pockets and dreams in the air. Back to square one");
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(6).getAsNumber() == 2);
}
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(30).concatenateString(gdjs.evtTools.string.newLine() + gdjs.evtTools.string.newLine() + "Personal Wealth = " + runtimeScene.getScene().getVariables().getFromIndex(6).getAsString() + gdjs.evtTools.string.newLine() + "A little richer than a sock puppet. Barely.");
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(6).getAsNumber() == 3);
}
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(30).concatenateString(gdjs.evtTools.string.newLine() + gdjs.evtTools.string.newLine() + "Personal Wealth = " + runtimeScene.getScene().getVariables().getFromIndex(6).getAsString() + gdjs.evtTools.string.newLine() + "Three coins jingling. Still not enough for a fancy latte.");
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(6).getAsNumber() == 4);
}
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(30).concatenateString(gdjs.evtTools.string.newLine() + gdjs.evtTools.string.newLine() + "Personal Wealth = " + runtimeScene.getScene().getVariables().getFromIndex(6).getAsString() + gdjs.evtTools.string.newLine() + "Hey, you can finally afford premium hand sanitizer!");
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(6).getAsNumber() == 5);
}
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(30).concatenateString(gdjs.evtTools.string.newLine() + gdjs.evtTools.string.newLine() + "Personal Wealth = " + runtimeScene.getScene().getVariables().getFromIndex(6).getAsString() + gdjs.evtTools.string.newLine() + "Halfway to riches, and already eyeing gold napkins.");
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(6).getAsNumber() == 6);
}
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(30).concatenateString(gdjs.evtTools.string.newLine() + gdjs.evtTools.string.newLine() + "Personal Wealth = " + runtimeScene.getScene().getVariables().getFromIndex(6).getAsString() + gdjs.evtTools.string.newLine() + "Not bad! You’ve got the wealth of a B-list villain.");
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(6).getAsNumber() == 7);
}
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(30).concatenateString(gdjs.evtTools.string.newLine() + gdjs.evtTools.string.newLine() + "Personal Wealth = " + runtimeScene.getScene().getVariables().getFromIndex(6).getAsString() + gdjs.evtTools.string.newLine() + "Nice! Your wallet’s wearing sunglasses now.");
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(6).getAsNumber() == 8);
}
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(30).concatenateString(gdjs.evtTools.string.newLine() + gdjs.evtTools.string.newLine() + "Personal Wealth = " + runtimeScene.getScene().getVariables().getFromIndex(6).getAsString() + gdjs.evtTools.string.newLine() + "You’re rich enough to fake your own moon landing.");
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(6).getAsNumber() == 9);
}
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(30).concatenateString(gdjs.evtTools.string.newLine() + gdjs.evtTools.string.newLine() + "Personal Wealth = " + runtimeScene.getScene().getVariables().getFromIndex(6).getAsString() + gdjs.evtTools.string.newLine() + "Okay, now you're rich enough for private islands.");
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(6).getAsNumber() == 10);
}
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(30).concatenateString(gdjs.evtTools.string.newLine() + gdjs.evtTools.string.newLine() + "Personal Wealth = " + runtimeScene.getScene().getVariables().getFromIndex(6).getAsString() + gdjs.evtTools.string.newLine() + "Congrats! You're so rich you’ve probably bought a moon by now.");
}}

}


{


let isConditionTrue_0 = false;
{

{ //Subevents
gdjs.MainCode.eventsList257(runtimeScene, asyncObjectsList);} //End of subevents
}

}


};gdjs.MainCode.asyncCallback15303252 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.MainCode.localVariables);

{ //Subevents
gdjs.MainCode.eventsList258(runtimeScene, asyncObjectsList);} //End of subevents
gdjs.MainCode.localVariables.length = 0;
}
gdjs.MainCode.eventsList259 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.MainCode.localVariables);
for (const obj of gdjs.MainCode.GDBlackScreenTextObjects1) asyncObjectsList.addObject("BlackScreenText", obj);
for (const obj of gdjs.MainCode.GDCapConditionObjects1) asyncObjectsList.addObject("CapCondition", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.5), (runtimeScene) => (gdjs.MainCode.asyncCallback15303252(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.MainCode.eventsList260 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15301692);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("BlackScreen"), gdjs.MainCode.GDBlackScreenObjects1);
gdjs.copyArray(runtimeScene.getObjects("BlackScreenText"), gdjs.MainCode.GDBlackScreenTextObjects1);
gdjs.copyArray(runtimeScene.getObjects("CapCondition"), gdjs.MainCode.GDCapConditionObjects1);
{gdjs.evtTools.camera.showLayer(runtimeScene, "BlackScreen");
}{for(var i = 0, len = gdjs.MainCode.GDBlackScreenTextObjects1.length ;i < len;++i) {
    gdjs.MainCode.GDBlackScreenTextObjects1[i].setCharacterSize(24);
}
}{for(var i = 0, len = gdjs.MainCode.GDBlackScreenObjects1.length ;i < len;++i) {
    gdjs.MainCode.GDBlackScreenObjects1[i].getBehavior("Tween").addObjectOpacityTween2("FadetoLight", 255, "linear", 2, false);
}
}{for(var i = 0, len = gdjs.MainCode.GDBlackScreenTextObjects1.length ;i < len;++i) {
    gdjs.MainCode.GDBlackScreenTextObjects1[i].getBehavior("Tween").addObjectOpacityTween2("FadetoLight", 255, "linear", 2, false);
}
}{for(var i = 0, len = gdjs.MainCode.GDCapConditionObjects1.length ;i < len;++i) {
    gdjs.MainCode.GDCapConditionObjects1[i].getBehavior("Tween").addObjectOpacityTween2("FadetoLight", 255, "linear", 2, false);
}
}
{ //Subevents
gdjs.MainCode.eventsList259(runtimeScene);} //End of subevents
}

}


};gdjs.MainCode.eventsList261 = function(runtimeScene) {

{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(7).getAsString() == "WIN_LOSE");
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.MainCode.eventsList260(runtimeScene);} //End of subevents
}

}


};gdjs.MainCode.eventsList262 = function(runtimeScene) {

{



}


{



}


};gdjs.MainCode.eventsList263 = function(runtimeScene) {

{


gdjs.MainCode.eventsList0(runtimeScene);
}


{


gdjs.MainCode.eventsList12(runtimeScene);
}


{


gdjs.MainCode.eventsList15(runtimeScene);
}


{


gdjs.MainCode.eventsList16(runtimeScene);
}


{


gdjs.MainCode.eventsList21(runtimeScene);
}


{


gdjs.MainCode.eventsList23(runtimeScene);
}


{


gdjs.MainCode.eventsList33(runtimeScene);
}


{


gdjs.MainCode.eventsList57(runtimeScene);
}


{


gdjs.MainCode.eventsList66(runtimeScene);
}


{


gdjs.MainCode.eventsList72(runtimeScene);
}


{


gdjs.MainCode.eventsList251(runtimeScene);
}


{


gdjs.MainCode.eventsList256(runtimeScene);
}


{


gdjs.MainCode.eventsList261(runtimeScene);
}


{


gdjs.MainCode.eventsList262(runtimeScene);
}


};

gdjs.MainCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.MainCode.GDTweet1Objects1.length = 0;
gdjs.MainCode.GDTweet1Objects2.length = 0;
gdjs.MainCode.GDTweet1Objects3.length = 0;
gdjs.MainCode.GDTweet1Objects4.length = 0;
gdjs.MainCode.GDTweet1Objects5.length = 0;
gdjs.MainCode.GDTweet1Objects6.length = 0;
gdjs.MainCode.GDTweet1Objects7.length = 0;
gdjs.MainCode.GDTweet1Objects8.length = 0;
gdjs.MainCode.GDTweet1Objects9.length = 0;
gdjs.MainCode.GDTweet1Objects10.length = 0;
gdjs.MainCode.GDTweetTitle1Objects1.length = 0;
gdjs.MainCode.GDTweetTitle1Objects2.length = 0;
gdjs.MainCode.GDTweetTitle1Objects3.length = 0;
gdjs.MainCode.GDTweetTitle1Objects4.length = 0;
gdjs.MainCode.GDTweetTitle1Objects5.length = 0;
gdjs.MainCode.GDTweetTitle1Objects6.length = 0;
gdjs.MainCode.GDTweetTitle1Objects7.length = 0;
gdjs.MainCode.GDTweetTitle1Objects8.length = 0;
gdjs.MainCode.GDTweetTitle1Objects9.length = 0;
gdjs.MainCode.GDTweetTitle1Objects10.length = 0;
gdjs.MainCode.GDReactionIcons_9595HeartObjects1.length = 0;
gdjs.MainCode.GDReactionIcons_9595HeartObjects2.length = 0;
gdjs.MainCode.GDReactionIcons_9595HeartObjects3.length = 0;
gdjs.MainCode.GDReactionIcons_9595HeartObjects4.length = 0;
gdjs.MainCode.GDReactionIcons_9595HeartObjects5.length = 0;
gdjs.MainCode.GDReactionIcons_9595HeartObjects6.length = 0;
gdjs.MainCode.GDReactionIcons_9595HeartObjects7.length = 0;
gdjs.MainCode.GDReactionIcons_9595HeartObjects8.length = 0;
gdjs.MainCode.GDReactionIcons_9595HeartObjects9.length = 0;
gdjs.MainCode.GDReactionIcons_9595HeartObjects10.length = 0;
gdjs.MainCode.GDHeartText1Objects1.length = 0;
gdjs.MainCode.GDHeartText1Objects2.length = 0;
gdjs.MainCode.GDHeartText1Objects3.length = 0;
gdjs.MainCode.GDHeartText1Objects4.length = 0;
gdjs.MainCode.GDHeartText1Objects5.length = 0;
gdjs.MainCode.GDHeartText1Objects6.length = 0;
gdjs.MainCode.GDHeartText1Objects7.length = 0;
gdjs.MainCode.GDHeartText1Objects8.length = 0;
gdjs.MainCode.GDHeartText1Objects9.length = 0;
gdjs.MainCode.GDHeartText1Objects10.length = 0;
gdjs.MainCode.GDReactionIcon_9595LikeObjects1.length = 0;
gdjs.MainCode.GDReactionIcon_9595LikeObjects2.length = 0;
gdjs.MainCode.GDReactionIcon_9595LikeObjects3.length = 0;
gdjs.MainCode.GDReactionIcon_9595LikeObjects4.length = 0;
gdjs.MainCode.GDReactionIcon_9595LikeObjects5.length = 0;
gdjs.MainCode.GDReactionIcon_9595LikeObjects6.length = 0;
gdjs.MainCode.GDReactionIcon_9595LikeObjects7.length = 0;
gdjs.MainCode.GDReactionIcon_9595LikeObjects8.length = 0;
gdjs.MainCode.GDReactionIcon_9595LikeObjects9.length = 0;
gdjs.MainCode.GDReactionIcon_9595LikeObjects10.length = 0;
gdjs.MainCode.GDLikeText1Objects1.length = 0;
gdjs.MainCode.GDLikeText1Objects2.length = 0;
gdjs.MainCode.GDLikeText1Objects3.length = 0;
gdjs.MainCode.GDLikeText1Objects4.length = 0;
gdjs.MainCode.GDLikeText1Objects5.length = 0;
gdjs.MainCode.GDLikeText1Objects6.length = 0;
gdjs.MainCode.GDLikeText1Objects7.length = 0;
gdjs.MainCode.GDLikeText1Objects8.length = 0;
gdjs.MainCode.GDLikeText1Objects9.length = 0;
gdjs.MainCode.GDLikeText1Objects10.length = 0;
gdjs.MainCode.GDReactionIcon_9595FireObjects1.length = 0;
gdjs.MainCode.GDReactionIcon_9595FireObjects2.length = 0;
gdjs.MainCode.GDReactionIcon_9595FireObjects3.length = 0;
gdjs.MainCode.GDReactionIcon_9595FireObjects4.length = 0;
gdjs.MainCode.GDReactionIcon_9595FireObjects5.length = 0;
gdjs.MainCode.GDReactionIcon_9595FireObjects6.length = 0;
gdjs.MainCode.GDReactionIcon_9595FireObjects7.length = 0;
gdjs.MainCode.GDReactionIcon_9595FireObjects8.length = 0;
gdjs.MainCode.GDReactionIcon_9595FireObjects9.length = 0;
gdjs.MainCode.GDReactionIcon_9595FireObjects10.length = 0;
gdjs.MainCode.GDFireText1Objects1.length = 0;
gdjs.MainCode.GDFireText1Objects2.length = 0;
gdjs.MainCode.GDFireText1Objects3.length = 0;
gdjs.MainCode.GDFireText1Objects4.length = 0;
gdjs.MainCode.GDFireText1Objects5.length = 0;
gdjs.MainCode.GDFireText1Objects6.length = 0;
gdjs.MainCode.GDFireText1Objects7.length = 0;
gdjs.MainCode.GDFireText1Objects8.length = 0;
gdjs.MainCode.GDFireText1Objects9.length = 0;
gdjs.MainCode.GDFireText1Objects10.length = 0;
gdjs.MainCode.GDFireText2Objects1.length = 0;
gdjs.MainCode.GDFireText2Objects2.length = 0;
gdjs.MainCode.GDFireText2Objects3.length = 0;
gdjs.MainCode.GDFireText2Objects4.length = 0;
gdjs.MainCode.GDFireText2Objects5.length = 0;
gdjs.MainCode.GDFireText2Objects6.length = 0;
gdjs.MainCode.GDFireText2Objects7.length = 0;
gdjs.MainCode.GDFireText2Objects8.length = 0;
gdjs.MainCode.GDFireText2Objects9.length = 0;
gdjs.MainCode.GDFireText2Objects10.length = 0;
gdjs.MainCode.GDLikeText2Objects1.length = 0;
gdjs.MainCode.GDLikeText2Objects2.length = 0;
gdjs.MainCode.GDLikeText2Objects3.length = 0;
gdjs.MainCode.GDLikeText2Objects4.length = 0;
gdjs.MainCode.GDLikeText2Objects5.length = 0;
gdjs.MainCode.GDLikeText2Objects6.length = 0;
gdjs.MainCode.GDLikeText2Objects7.length = 0;
gdjs.MainCode.GDLikeText2Objects8.length = 0;
gdjs.MainCode.GDLikeText2Objects9.length = 0;
gdjs.MainCode.GDLikeText2Objects10.length = 0;
gdjs.MainCode.GDHeartText2Objects1.length = 0;
gdjs.MainCode.GDHeartText2Objects2.length = 0;
gdjs.MainCode.GDHeartText2Objects3.length = 0;
gdjs.MainCode.GDHeartText2Objects4.length = 0;
gdjs.MainCode.GDHeartText2Objects5.length = 0;
gdjs.MainCode.GDHeartText2Objects6.length = 0;
gdjs.MainCode.GDHeartText2Objects7.length = 0;
gdjs.MainCode.GDHeartText2Objects8.length = 0;
gdjs.MainCode.GDHeartText2Objects9.length = 0;
gdjs.MainCode.GDHeartText2Objects10.length = 0;
gdjs.MainCode.GDFireText3Objects1.length = 0;
gdjs.MainCode.GDFireText3Objects2.length = 0;
gdjs.MainCode.GDFireText3Objects3.length = 0;
gdjs.MainCode.GDFireText3Objects4.length = 0;
gdjs.MainCode.GDFireText3Objects5.length = 0;
gdjs.MainCode.GDFireText3Objects6.length = 0;
gdjs.MainCode.GDFireText3Objects7.length = 0;
gdjs.MainCode.GDFireText3Objects8.length = 0;
gdjs.MainCode.GDFireText3Objects9.length = 0;
gdjs.MainCode.GDFireText3Objects10.length = 0;
gdjs.MainCode.GDLikeText3Objects1.length = 0;
gdjs.MainCode.GDLikeText3Objects2.length = 0;
gdjs.MainCode.GDLikeText3Objects3.length = 0;
gdjs.MainCode.GDLikeText3Objects4.length = 0;
gdjs.MainCode.GDLikeText3Objects5.length = 0;
gdjs.MainCode.GDLikeText3Objects6.length = 0;
gdjs.MainCode.GDLikeText3Objects7.length = 0;
gdjs.MainCode.GDLikeText3Objects8.length = 0;
gdjs.MainCode.GDLikeText3Objects9.length = 0;
gdjs.MainCode.GDLikeText3Objects10.length = 0;
gdjs.MainCode.GDHeartText3Objects1.length = 0;
gdjs.MainCode.GDHeartText3Objects2.length = 0;
gdjs.MainCode.GDHeartText3Objects3.length = 0;
gdjs.MainCode.GDHeartText3Objects4.length = 0;
gdjs.MainCode.GDHeartText3Objects5.length = 0;
gdjs.MainCode.GDHeartText3Objects6.length = 0;
gdjs.MainCode.GDHeartText3Objects7.length = 0;
gdjs.MainCode.GDHeartText3Objects8.length = 0;
gdjs.MainCode.GDHeartText3Objects9.length = 0;
gdjs.MainCode.GDHeartText3Objects10.length = 0;
gdjs.MainCode.GDTweetFace3Objects1.length = 0;
gdjs.MainCode.GDTweetFace3Objects2.length = 0;
gdjs.MainCode.GDTweetFace3Objects3.length = 0;
gdjs.MainCode.GDTweetFace3Objects4.length = 0;
gdjs.MainCode.GDTweetFace3Objects5.length = 0;
gdjs.MainCode.GDTweetFace3Objects6.length = 0;
gdjs.MainCode.GDTweetFace3Objects7.length = 0;
gdjs.MainCode.GDTweetFace3Objects8.length = 0;
gdjs.MainCode.GDTweetFace3Objects9.length = 0;
gdjs.MainCode.GDTweetFace3Objects10.length = 0;
gdjs.MainCode.GDTweetTitle2Objects1.length = 0;
gdjs.MainCode.GDTweetTitle2Objects2.length = 0;
gdjs.MainCode.GDTweetTitle2Objects3.length = 0;
gdjs.MainCode.GDTweetTitle2Objects4.length = 0;
gdjs.MainCode.GDTweetTitle2Objects5.length = 0;
gdjs.MainCode.GDTweetTitle2Objects6.length = 0;
gdjs.MainCode.GDTweetTitle2Objects7.length = 0;
gdjs.MainCode.GDTweetTitle2Objects8.length = 0;
gdjs.MainCode.GDTweetTitle2Objects9.length = 0;
gdjs.MainCode.GDTweetTitle2Objects10.length = 0;
gdjs.MainCode.GDTweetTitle3Objects1.length = 0;
gdjs.MainCode.GDTweetTitle3Objects2.length = 0;
gdjs.MainCode.GDTweetTitle3Objects3.length = 0;
gdjs.MainCode.GDTweetTitle3Objects4.length = 0;
gdjs.MainCode.GDTweetTitle3Objects5.length = 0;
gdjs.MainCode.GDTweetTitle3Objects6.length = 0;
gdjs.MainCode.GDTweetTitle3Objects7.length = 0;
gdjs.MainCode.GDTweetTitle3Objects8.length = 0;
gdjs.MainCode.GDTweetTitle3Objects9.length = 0;
gdjs.MainCode.GDTweetTitle3Objects10.length = 0;
gdjs.MainCode.GDTweet2Objects1.length = 0;
gdjs.MainCode.GDTweet2Objects2.length = 0;
gdjs.MainCode.GDTweet2Objects3.length = 0;
gdjs.MainCode.GDTweet2Objects4.length = 0;
gdjs.MainCode.GDTweet2Objects5.length = 0;
gdjs.MainCode.GDTweet2Objects6.length = 0;
gdjs.MainCode.GDTweet2Objects7.length = 0;
gdjs.MainCode.GDTweet2Objects8.length = 0;
gdjs.MainCode.GDTweet2Objects9.length = 0;
gdjs.MainCode.GDTweet2Objects10.length = 0;
gdjs.MainCode.GDTweet3Objects1.length = 0;
gdjs.MainCode.GDTweet3Objects2.length = 0;
gdjs.MainCode.GDTweet3Objects3.length = 0;
gdjs.MainCode.GDTweet3Objects4.length = 0;
gdjs.MainCode.GDTweet3Objects5.length = 0;
gdjs.MainCode.GDTweet3Objects6.length = 0;
gdjs.MainCode.GDTweet3Objects7.length = 0;
gdjs.MainCode.GDTweet3Objects8.length = 0;
gdjs.MainCode.GDTweet3Objects9.length = 0;
gdjs.MainCode.GDTweet3Objects10.length = 0;
gdjs.MainCode.GDTweet_9595bkg1Objects1.length = 0;
gdjs.MainCode.GDTweet_9595bkg1Objects2.length = 0;
gdjs.MainCode.GDTweet_9595bkg1Objects3.length = 0;
gdjs.MainCode.GDTweet_9595bkg1Objects4.length = 0;
gdjs.MainCode.GDTweet_9595bkg1Objects5.length = 0;
gdjs.MainCode.GDTweet_9595bkg1Objects6.length = 0;
gdjs.MainCode.GDTweet_9595bkg1Objects7.length = 0;
gdjs.MainCode.GDTweet_9595bkg1Objects8.length = 0;
gdjs.MainCode.GDTweet_9595bkg1Objects9.length = 0;
gdjs.MainCode.GDTweet_9595bkg1Objects10.length = 0;
gdjs.MainCode.GDOption1Objects1.length = 0;
gdjs.MainCode.GDOption1Objects2.length = 0;
gdjs.MainCode.GDOption1Objects3.length = 0;
gdjs.MainCode.GDOption1Objects4.length = 0;
gdjs.MainCode.GDOption1Objects5.length = 0;
gdjs.MainCode.GDOption1Objects6.length = 0;
gdjs.MainCode.GDOption1Objects7.length = 0;
gdjs.MainCode.GDOption1Objects8.length = 0;
gdjs.MainCode.GDOption1Objects9.length = 0;
gdjs.MainCode.GDOption1Objects10.length = 0;
gdjs.MainCode.GDOption2Objects1.length = 0;
gdjs.MainCode.GDOption2Objects2.length = 0;
gdjs.MainCode.GDOption2Objects3.length = 0;
gdjs.MainCode.GDOption2Objects4.length = 0;
gdjs.MainCode.GDOption2Objects5.length = 0;
gdjs.MainCode.GDOption2Objects6.length = 0;
gdjs.MainCode.GDOption2Objects7.length = 0;
gdjs.MainCode.GDOption2Objects8.length = 0;
gdjs.MainCode.GDOption2Objects9.length = 0;
gdjs.MainCode.GDOption2Objects10.length = 0;
gdjs.MainCode.GDOption3Objects1.length = 0;
gdjs.MainCode.GDOption3Objects2.length = 0;
gdjs.MainCode.GDOption3Objects3.length = 0;
gdjs.MainCode.GDOption3Objects4.length = 0;
gdjs.MainCode.GDOption3Objects5.length = 0;
gdjs.MainCode.GDOption3Objects6.length = 0;
gdjs.MainCode.GDOption3Objects7.length = 0;
gdjs.MainCode.GDOption3Objects8.length = 0;
gdjs.MainCode.GDOption3Objects9.length = 0;
gdjs.MainCode.GDOption3Objects10.length = 0;
gdjs.MainCode.GDOptionTxt1Objects1.length = 0;
gdjs.MainCode.GDOptionTxt1Objects2.length = 0;
gdjs.MainCode.GDOptionTxt1Objects3.length = 0;
gdjs.MainCode.GDOptionTxt1Objects4.length = 0;
gdjs.MainCode.GDOptionTxt1Objects5.length = 0;
gdjs.MainCode.GDOptionTxt1Objects6.length = 0;
gdjs.MainCode.GDOptionTxt1Objects7.length = 0;
gdjs.MainCode.GDOptionTxt1Objects8.length = 0;
gdjs.MainCode.GDOptionTxt1Objects9.length = 0;
gdjs.MainCode.GDOptionTxt1Objects10.length = 0;
gdjs.MainCode.GDOptionTxt2Objects1.length = 0;
gdjs.MainCode.GDOptionTxt2Objects2.length = 0;
gdjs.MainCode.GDOptionTxt2Objects3.length = 0;
gdjs.MainCode.GDOptionTxt2Objects4.length = 0;
gdjs.MainCode.GDOptionTxt2Objects5.length = 0;
gdjs.MainCode.GDOptionTxt2Objects6.length = 0;
gdjs.MainCode.GDOptionTxt2Objects7.length = 0;
gdjs.MainCode.GDOptionTxt2Objects8.length = 0;
gdjs.MainCode.GDOptionTxt2Objects9.length = 0;
gdjs.MainCode.GDOptionTxt2Objects10.length = 0;
gdjs.MainCode.GDOptionTxt3Objects1.length = 0;
gdjs.MainCode.GDOptionTxt3Objects2.length = 0;
gdjs.MainCode.GDOptionTxt3Objects3.length = 0;
gdjs.MainCode.GDOptionTxt3Objects4.length = 0;
gdjs.MainCode.GDOptionTxt3Objects5.length = 0;
gdjs.MainCode.GDOptionTxt3Objects6.length = 0;
gdjs.MainCode.GDOptionTxt3Objects7.length = 0;
gdjs.MainCode.GDOptionTxt3Objects8.length = 0;
gdjs.MainCode.GDOptionTxt3Objects9.length = 0;
gdjs.MainCode.GDOptionTxt3Objects10.length = 0;
gdjs.MainCode.GDSend_9595icon1Objects1.length = 0;
gdjs.MainCode.GDSend_9595icon1Objects2.length = 0;
gdjs.MainCode.GDSend_9595icon1Objects3.length = 0;
gdjs.MainCode.GDSend_9595icon1Objects4.length = 0;
gdjs.MainCode.GDSend_9595icon1Objects5.length = 0;
gdjs.MainCode.GDSend_9595icon1Objects6.length = 0;
gdjs.MainCode.GDSend_9595icon1Objects7.length = 0;
gdjs.MainCode.GDSend_9595icon1Objects8.length = 0;
gdjs.MainCode.GDSend_9595icon1Objects9.length = 0;
gdjs.MainCode.GDSend_9595icon1Objects10.length = 0;
gdjs.MainCode.GDblue_9595barsObjects1.length = 0;
gdjs.MainCode.GDblue_9595barsObjects2.length = 0;
gdjs.MainCode.GDblue_9595barsObjects3.length = 0;
gdjs.MainCode.GDblue_9595barsObjects4.length = 0;
gdjs.MainCode.GDblue_9595barsObjects5.length = 0;
gdjs.MainCode.GDblue_9595barsObjects6.length = 0;
gdjs.MainCode.GDblue_9595barsObjects7.length = 0;
gdjs.MainCode.GDblue_9595barsObjects8.length = 0;
gdjs.MainCode.GDblue_9595barsObjects9.length = 0;
gdjs.MainCode.GDblue_9595barsObjects10.length = 0;
gdjs.MainCode.GDGreen_9595barsObjects1.length = 0;
gdjs.MainCode.GDGreen_9595barsObjects2.length = 0;
gdjs.MainCode.GDGreen_9595barsObjects3.length = 0;
gdjs.MainCode.GDGreen_9595barsObjects4.length = 0;
gdjs.MainCode.GDGreen_9595barsObjects5.length = 0;
gdjs.MainCode.GDGreen_9595barsObjects6.length = 0;
gdjs.MainCode.GDGreen_9595barsObjects7.length = 0;
gdjs.MainCode.GDGreen_9595barsObjects8.length = 0;
gdjs.MainCode.GDGreen_9595barsObjects9.length = 0;
gdjs.MainCode.GDGreen_9595barsObjects10.length = 0;
gdjs.MainCode.GDOrange_9595barsObjects1.length = 0;
gdjs.MainCode.GDOrange_9595barsObjects2.length = 0;
gdjs.MainCode.GDOrange_9595barsObjects3.length = 0;
gdjs.MainCode.GDOrange_9595barsObjects4.length = 0;
gdjs.MainCode.GDOrange_9595barsObjects5.length = 0;
gdjs.MainCode.GDOrange_9595barsObjects6.length = 0;
gdjs.MainCode.GDOrange_9595barsObjects7.length = 0;
gdjs.MainCode.GDOrange_9595barsObjects8.length = 0;
gdjs.MainCode.GDOrange_9595barsObjects9.length = 0;
gdjs.MainCode.GDOrange_9595barsObjects10.length = 0;
gdjs.MainCode.GDPink_9595barsObjects1.length = 0;
gdjs.MainCode.GDPink_9595barsObjects2.length = 0;
gdjs.MainCode.GDPink_9595barsObjects3.length = 0;
gdjs.MainCode.GDPink_9595barsObjects4.length = 0;
gdjs.MainCode.GDPink_9595barsObjects5.length = 0;
gdjs.MainCode.GDPink_9595barsObjects6.length = 0;
gdjs.MainCode.GDPink_9595barsObjects7.length = 0;
gdjs.MainCode.GDPink_9595barsObjects8.length = 0;
gdjs.MainCode.GDPink_9595barsObjects9.length = 0;
gdjs.MainCode.GDPink_9595barsObjects10.length = 0;
gdjs.MainCode.GDEconomyTxtObjects1.length = 0;
gdjs.MainCode.GDEconomyTxtObjects2.length = 0;
gdjs.MainCode.GDEconomyTxtObjects3.length = 0;
gdjs.MainCode.GDEconomyTxtObjects4.length = 0;
gdjs.MainCode.GDEconomyTxtObjects5.length = 0;
gdjs.MainCode.GDEconomyTxtObjects6.length = 0;
gdjs.MainCode.GDEconomyTxtObjects7.length = 0;
gdjs.MainCode.GDEconomyTxtObjects8.length = 0;
gdjs.MainCode.GDEconomyTxtObjects9.length = 0;
gdjs.MainCode.GDEconomyTxtObjects10.length = 0;
gdjs.MainCode.GDPersonalGainsTxtObjects1.length = 0;
gdjs.MainCode.GDPersonalGainsTxtObjects2.length = 0;
gdjs.MainCode.GDPersonalGainsTxtObjects3.length = 0;
gdjs.MainCode.GDPersonalGainsTxtObjects4.length = 0;
gdjs.MainCode.GDPersonalGainsTxtObjects5.length = 0;
gdjs.MainCode.GDPersonalGainsTxtObjects6.length = 0;
gdjs.MainCode.GDPersonalGainsTxtObjects7.length = 0;
gdjs.MainCode.GDPersonalGainsTxtObjects8.length = 0;
gdjs.MainCode.GDPersonalGainsTxtObjects9.length = 0;
gdjs.MainCode.GDPersonalGainsTxtObjects10.length = 0;
gdjs.MainCode.GDScandalRiskTxtObjects1.length = 0;
gdjs.MainCode.GDScandalRiskTxtObjects2.length = 0;
gdjs.MainCode.GDScandalRiskTxtObjects3.length = 0;
gdjs.MainCode.GDScandalRiskTxtObjects4.length = 0;
gdjs.MainCode.GDScandalRiskTxtObjects5.length = 0;
gdjs.MainCode.GDScandalRiskTxtObjects6.length = 0;
gdjs.MainCode.GDScandalRiskTxtObjects7.length = 0;
gdjs.MainCode.GDScandalRiskTxtObjects8.length = 0;
gdjs.MainCode.GDScandalRiskTxtObjects9.length = 0;
gdjs.MainCode.GDScandalRiskTxtObjects10.length = 0;
gdjs.MainCode.GDPublicApprovalTxtObjects1.length = 0;
gdjs.MainCode.GDPublicApprovalTxtObjects2.length = 0;
gdjs.MainCode.GDPublicApprovalTxtObjects3.length = 0;
gdjs.MainCode.GDPublicApprovalTxtObjects4.length = 0;
gdjs.MainCode.GDPublicApprovalTxtObjects5.length = 0;
gdjs.MainCode.GDPublicApprovalTxtObjects6.length = 0;
gdjs.MainCode.GDPublicApprovalTxtObjects7.length = 0;
gdjs.MainCode.GDPublicApprovalTxtObjects8.length = 0;
gdjs.MainCode.GDPublicApprovalTxtObjects9.length = 0;
gdjs.MainCode.GDPublicApprovalTxtObjects10.length = 0;
gdjs.MainCode.GDCapObjects1.length = 0;
gdjs.MainCode.GDCapObjects2.length = 0;
gdjs.MainCode.GDCapObjects3.length = 0;
gdjs.MainCode.GDCapObjects4.length = 0;
gdjs.MainCode.GDCapObjects5.length = 0;
gdjs.MainCode.GDCapObjects6.length = 0;
gdjs.MainCode.GDCapObjects7.length = 0;
gdjs.MainCode.GDCapObjects8.length = 0;
gdjs.MainCode.GDCapObjects9.length = 0;
gdjs.MainCode.GDCapObjects10.length = 0;
gdjs.MainCode.GDCap_9595commentsObjects1.length = 0;
gdjs.MainCode.GDCap_9595commentsObjects2.length = 0;
gdjs.MainCode.GDCap_9595commentsObjects3.length = 0;
gdjs.MainCode.GDCap_9595commentsObjects4.length = 0;
gdjs.MainCode.GDCap_9595commentsObjects5.length = 0;
gdjs.MainCode.GDCap_9595commentsObjects6.length = 0;
gdjs.MainCode.GDCap_9595commentsObjects7.length = 0;
gdjs.MainCode.GDCap_9595commentsObjects8.length = 0;
gdjs.MainCode.GDCap_9595commentsObjects9.length = 0;
gdjs.MainCode.GDCap_9595commentsObjects10.length = 0;
gdjs.MainCode.GDDayTxtObjects1.length = 0;
gdjs.MainCode.GDDayTxtObjects2.length = 0;
gdjs.MainCode.GDDayTxtObjects3.length = 0;
gdjs.MainCode.GDDayTxtObjects4.length = 0;
gdjs.MainCode.GDDayTxtObjects5.length = 0;
gdjs.MainCode.GDDayTxtObjects6.length = 0;
gdjs.MainCode.GDDayTxtObjects7.length = 0;
gdjs.MainCode.GDDayTxtObjects8.length = 0;
gdjs.MainCode.GDDayTxtObjects9.length = 0;
gdjs.MainCode.GDDayTxtObjects10.length = 0;
gdjs.MainCode.GDChirpObjects1.length = 0;
gdjs.MainCode.GDChirpObjects2.length = 0;
gdjs.MainCode.GDChirpObjects3.length = 0;
gdjs.MainCode.GDChirpObjects4.length = 0;
gdjs.MainCode.GDChirpObjects5.length = 0;
gdjs.MainCode.GDChirpObjects6.length = 0;
gdjs.MainCode.GDChirpObjects7.length = 0;
gdjs.MainCode.GDChirpObjects8.length = 0;
gdjs.MainCode.GDChirpObjects9.length = 0;
gdjs.MainCode.GDChirpObjects10.length = 0;
gdjs.MainCode.GDMy_9595optionsObjects1.length = 0;
gdjs.MainCode.GDMy_9595optionsObjects2.length = 0;
gdjs.MainCode.GDMy_9595optionsObjects3.length = 0;
gdjs.MainCode.GDMy_9595optionsObjects4.length = 0;
gdjs.MainCode.GDMy_9595optionsObjects5.length = 0;
gdjs.MainCode.GDMy_9595optionsObjects6.length = 0;
gdjs.MainCode.GDMy_9595optionsObjects7.length = 0;
gdjs.MainCode.GDMy_9595optionsObjects8.length = 0;
gdjs.MainCode.GDMy_9595optionsObjects9.length = 0;
gdjs.MainCode.GDMy_9595optionsObjects10.length = 0;
gdjs.MainCode.GDCap_9595facesObjects1.length = 0;
gdjs.MainCode.GDCap_9595facesObjects2.length = 0;
gdjs.MainCode.GDCap_9595facesObjects3.length = 0;
gdjs.MainCode.GDCap_9595facesObjects4.length = 0;
gdjs.MainCode.GDCap_9595facesObjects5.length = 0;
gdjs.MainCode.GDCap_9595facesObjects6.length = 0;
gdjs.MainCode.GDCap_9595facesObjects7.length = 0;
gdjs.MainCode.GDCap_9595facesObjects8.length = 0;
gdjs.MainCode.GDCap_9595facesObjects9.length = 0;
gdjs.MainCode.GDCap_9595facesObjects10.length = 0;
gdjs.MainCode.GDSend_9595icon2Objects1.length = 0;
gdjs.MainCode.GDSend_9595icon2Objects2.length = 0;
gdjs.MainCode.GDSend_9595icon2Objects3.length = 0;
gdjs.MainCode.GDSend_9595icon2Objects4.length = 0;
gdjs.MainCode.GDSend_9595icon2Objects5.length = 0;
gdjs.MainCode.GDSend_9595icon2Objects6.length = 0;
gdjs.MainCode.GDSend_9595icon2Objects7.length = 0;
gdjs.MainCode.GDSend_9595icon2Objects8.length = 0;
gdjs.MainCode.GDSend_9595icon2Objects9.length = 0;
gdjs.MainCode.GDSend_9595icon2Objects10.length = 0;
gdjs.MainCode.GDSend_9595icon3Objects1.length = 0;
gdjs.MainCode.GDSend_9595icon3Objects2.length = 0;
gdjs.MainCode.GDSend_9595icon3Objects3.length = 0;
gdjs.MainCode.GDSend_9595icon3Objects4.length = 0;
gdjs.MainCode.GDSend_9595icon3Objects5.length = 0;
gdjs.MainCode.GDSend_9595icon3Objects6.length = 0;
gdjs.MainCode.GDSend_9595icon3Objects7.length = 0;
gdjs.MainCode.GDSend_9595icon3Objects8.length = 0;
gdjs.MainCode.GDSend_9595icon3Objects9.length = 0;
gdjs.MainCode.GDSend_9595icon3Objects10.length = 0;
gdjs.MainCode.GDTweetFace2Objects1.length = 0;
gdjs.MainCode.GDTweetFace2Objects2.length = 0;
gdjs.MainCode.GDTweetFace2Objects3.length = 0;
gdjs.MainCode.GDTweetFace2Objects4.length = 0;
gdjs.MainCode.GDTweetFace2Objects5.length = 0;
gdjs.MainCode.GDTweetFace2Objects6.length = 0;
gdjs.MainCode.GDTweetFace2Objects7.length = 0;
gdjs.MainCode.GDTweetFace2Objects8.length = 0;
gdjs.MainCode.GDTweetFace2Objects9.length = 0;
gdjs.MainCode.GDTweetFace2Objects10.length = 0;
gdjs.MainCode.GDTweetFace1Objects1.length = 0;
gdjs.MainCode.GDTweetFace1Objects2.length = 0;
gdjs.MainCode.GDTweetFace1Objects3.length = 0;
gdjs.MainCode.GDTweetFace1Objects4.length = 0;
gdjs.MainCode.GDTweetFace1Objects5.length = 0;
gdjs.MainCode.GDTweetFace1Objects6.length = 0;
gdjs.MainCode.GDTweetFace1Objects7.length = 0;
gdjs.MainCode.GDTweetFace1Objects8.length = 0;
gdjs.MainCode.GDTweetFace1Objects9.length = 0;
gdjs.MainCode.GDTweetFace1Objects10.length = 0;
gdjs.MainCode.GDLayoutObjects1.length = 0;
gdjs.MainCode.GDLayoutObjects2.length = 0;
gdjs.MainCode.GDLayoutObjects3.length = 0;
gdjs.MainCode.GDLayoutObjects4.length = 0;
gdjs.MainCode.GDLayoutObjects5.length = 0;
gdjs.MainCode.GDLayoutObjects6.length = 0;
gdjs.MainCode.GDLayoutObjects7.length = 0;
gdjs.MainCode.GDLayoutObjects8.length = 0;
gdjs.MainCode.GDLayoutObjects9.length = 0;
gdjs.MainCode.GDLayoutObjects10.length = 0;
gdjs.MainCode.GDTweetMarker1Objects1.length = 0;
gdjs.MainCode.GDTweetMarker1Objects2.length = 0;
gdjs.MainCode.GDTweetMarker1Objects3.length = 0;
gdjs.MainCode.GDTweetMarker1Objects4.length = 0;
gdjs.MainCode.GDTweetMarker1Objects5.length = 0;
gdjs.MainCode.GDTweetMarker1Objects6.length = 0;
gdjs.MainCode.GDTweetMarker1Objects7.length = 0;
gdjs.MainCode.GDTweetMarker1Objects8.length = 0;
gdjs.MainCode.GDTweetMarker1Objects9.length = 0;
gdjs.MainCode.GDTweetMarker1Objects10.length = 0;
gdjs.MainCode.GDTweetMarker2Objects1.length = 0;
gdjs.MainCode.GDTweetMarker2Objects2.length = 0;
gdjs.MainCode.GDTweetMarker2Objects3.length = 0;
gdjs.MainCode.GDTweetMarker2Objects4.length = 0;
gdjs.MainCode.GDTweetMarker2Objects5.length = 0;
gdjs.MainCode.GDTweetMarker2Objects6.length = 0;
gdjs.MainCode.GDTweetMarker2Objects7.length = 0;
gdjs.MainCode.GDTweetMarker2Objects8.length = 0;
gdjs.MainCode.GDTweetMarker2Objects9.length = 0;
gdjs.MainCode.GDTweetMarker2Objects10.length = 0;
gdjs.MainCode.GDTweetMarker3Objects1.length = 0;
gdjs.MainCode.GDTweetMarker3Objects2.length = 0;
gdjs.MainCode.GDTweetMarker3Objects3.length = 0;
gdjs.MainCode.GDTweetMarker3Objects4.length = 0;
gdjs.MainCode.GDTweetMarker3Objects5.length = 0;
gdjs.MainCode.GDTweetMarker3Objects6.length = 0;
gdjs.MainCode.GDTweetMarker3Objects7.length = 0;
gdjs.MainCode.GDTweetMarker3Objects8.length = 0;
gdjs.MainCode.GDTweetMarker3Objects9.length = 0;
gdjs.MainCode.GDTweetMarker3Objects10.length = 0;
gdjs.MainCode.GDTweetMarker4Objects1.length = 0;
gdjs.MainCode.GDTweetMarker4Objects2.length = 0;
gdjs.MainCode.GDTweetMarker4Objects3.length = 0;
gdjs.MainCode.GDTweetMarker4Objects4.length = 0;
gdjs.MainCode.GDTweetMarker4Objects5.length = 0;
gdjs.MainCode.GDTweetMarker4Objects6.length = 0;
gdjs.MainCode.GDTweetMarker4Objects7.length = 0;
gdjs.MainCode.GDTweetMarker4Objects8.length = 0;
gdjs.MainCode.GDTweetMarker4Objects9.length = 0;
gdjs.MainCode.GDTweetMarker4Objects10.length = 0;
gdjs.MainCode.GDTweetMarker5Objects1.length = 0;
gdjs.MainCode.GDTweetMarker5Objects2.length = 0;
gdjs.MainCode.GDTweetMarker5Objects3.length = 0;
gdjs.MainCode.GDTweetMarker5Objects4.length = 0;
gdjs.MainCode.GDTweetMarker5Objects5.length = 0;
gdjs.MainCode.GDTweetMarker5Objects6.length = 0;
gdjs.MainCode.GDTweetMarker5Objects7.length = 0;
gdjs.MainCode.GDTweetMarker5Objects8.length = 0;
gdjs.MainCode.GDTweetMarker5Objects9.length = 0;
gdjs.MainCode.GDTweetMarker5Objects10.length = 0;
gdjs.MainCode.GDTweetMarker6Objects1.length = 0;
gdjs.MainCode.GDTweetMarker6Objects2.length = 0;
gdjs.MainCode.GDTweetMarker6Objects3.length = 0;
gdjs.MainCode.GDTweetMarker6Objects4.length = 0;
gdjs.MainCode.GDTweetMarker6Objects5.length = 0;
gdjs.MainCode.GDTweetMarker6Objects6.length = 0;
gdjs.MainCode.GDTweetMarker6Objects7.length = 0;
gdjs.MainCode.GDTweetMarker6Objects8.length = 0;
gdjs.MainCode.GDTweetMarker6Objects9.length = 0;
gdjs.MainCode.GDTweetMarker6Objects10.length = 0;
gdjs.MainCode.GDTweetMarker7Objects1.length = 0;
gdjs.MainCode.GDTweetMarker7Objects2.length = 0;
gdjs.MainCode.GDTweetMarker7Objects3.length = 0;
gdjs.MainCode.GDTweetMarker7Objects4.length = 0;
gdjs.MainCode.GDTweetMarker7Objects5.length = 0;
gdjs.MainCode.GDTweetMarker7Objects6.length = 0;
gdjs.MainCode.GDTweetMarker7Objects7.length = 0;
gdjs.MainCode.GDTweetMarker7Objects8.length = 0;
gdjs.MainCode.GDTweetMarker7Objects9.length = 0;
gdjs.MainCode.GDTweetMarker7Objects10.length = 0;
gdjs.MainCode.GDTweet_9595bkg2Objects1.length = 0;
gdjs.MainCode.GDTweet_9595bkg2Objects2.length = 0;
gdjs.MainCode.GDTweet_9595bkg2Objects3.length = 0;
gdjs.MainCode.GDTweet_9595bkg2Objects4.length = 0;
gdjs.MainCode.GDTweet_9595bkg2Objects5.length = 0;
gdjs.MainCode.GDTweet_9595bkg2Objects6.length = 0;
gdjs.MainCode.GDTweet_9595bkg2Objects7.length = 0;
gdjs.MainCode.GDTweet_9595bkg2Objects8.length = 0;
gdjs.MainCode.GDTweet_9595bkg2Objects9.length = 0;
gdjs.MainCode.GDTweet_9595bkg2Objects10.length = 0;
gdjs.MainCode.GDTweet_9595bkg3Objects1.length = 0;
gdjs.MainCode.GDTweet_9595bkg3Objects2.length = 0;
gdjs.MainCode.GDTweet_9595bkg3Objects3.length = 0;
gdjs.MainCode.GDTweet_9595bkg3Objects4.length = 0;
gdjs.MainCode.GDTweet_9595bkg3Objects5.length = 0;
gdjs.MainCode.GDTweet_9595bkg3Objects6.length = 0;
gdjs.MainCode.GDTweet_9595bkg3Objects7.length = 0;
gdjs.MainCode.GDTweet_9595bkg3Objects8.length = 0;
gdjs.MainCode.GDTweet_9595bkg3Objects9.length = 0;
gdjs.MainCode.GDTweet_9595bkg3Objects10.length = 0;
gdjs.MainCode.GDTweet_9595bkg4Objects1.length = 0;
gdjs.MainCode.GDTweet_9595bkg4Objects2.length = 0;
gdjs.MainCode.GDTweet_9595bkg4Objects3.length = 0;
gdjs.MainCode.GDTweet_9595bkg4Objects4.length = 0;
gdjs.MainCode.GDTweet_9595bkg4Objects5.length = 0;
gdjs.MainCode.GDTweet_9595bkg4Objects6.length = 0;
gdjs.MainCode.GDTweet_9595bkg4Objects7.length = 0;
gdjs.MainCode.GDTweet_9595bkg4Objects8.length = 0;
gdjs.MainCode.GDTweet_9595bkg4Objects9.length = 0;
gdjs.MainCode.GDTweet_9595bkg4Objects10.length = 0;
gdjs.MainCode.GDTweet_9595bkg5Objects1.length = 0;
gdjs.MainCode.GDTweet_9595bkg5Objects2.length = 0;
gdjs.MainCode.GDTweet_9595bkg5Objects3.length = 0;
gdjs.MainCode.GDTweet_9595bkg5Objects4.length = 0;
gdjs.MainCode.GDTweet_9595bkg5Objects5.length = 0;
gdjs.MainCode.GDTweet_9595bkg5Objects6.length = 0;
gdjs.MainCode.GDTweet_9595bkg5Objects7.length = 0;
gdjs.MainCode.GDTweet_9595bkg5Objects8.length = 0;
gdjs.MainCode.GDTweet_9595bkg5Objects9.length = 0;
gdjs.MainCode.GDTweet_9595bkg5Objects10.length = 0;
gdjs.MainCode.GDTweet_9595bkg6Objects1.length = 0;
gdjs.MainCode.GDTweet_9595bkg6Objects2.length = 0;
gdjs.MainCode.GDTweet_9595bkg6Objects3.length = 0;
gdjs.MainCode.GDTweet_9595bkg6Objects4.length = 0;
gdjs.MainCode.GDTweet_9595bkg6Objects5.length = 0;
gdjs.MainCode.GDTweet_9595bkg6Objects6.length = 0;
gdjs.MainCode.GDTweet_9595bkg6Objects7.length = 0;
gdjs.MainCode.GDTweet_9595bkg6Objects8.length = 0;
gdjs.MainCode.GDTweet_9595bkg6Objects9.length = 0;
gdjs.MainCode.GDTweet_9595bkg6Objects10.length = 0;
gdjs.MainCode.GDTweetMarker8Objects1.length = 0;
gdjs.MainCode.GDTweetMarker8Objects2.length = 0;
gdjs.MainCode.GDTweetMarker8Objects3.length = 0;
gdjs.MainCode.GDTweetMarker8Objects4.length = 0;
gdjs.MainCode.GDTweetMarker8Objects5.length = 0;
gdjs.MainCode.GDTweetMarker8Objects6.length = 0;
gdjs.MainCode.GDTweetMarker8Objects7.length = 0;
gdjs.MainCode.GDTweetMarker8Objects8.length = 0;
gdjs.MainCode.GDTweetMarker8Objects9.length = 0;
gdjs.MainCode.GDTweetMarker8Objects10.length = 0;
gdjs.MainCode.GDFireText4Objects1.length = 0;
gdjs.MainCode.GDFireText4Objects2.length = 0;
gdjs.MainCode.GDFireText4Objects3.length = 0;
gdjs.MainCode.GDFireText4Objects4.length = 0;
gdjs.MainCode.GDFireText4Objects5.length = 0;
gdjs.MainCode.GDFireText4Objects6.length = 0;
gdjs.MainCode.GDFireText4Objects7.length = 0;
gdjs.MainCode.GDFireText4Objects8.length = 0;
gdjs.MainCode.GDFireText4Objects9.length = 0;
gdjs.MainCode.GDFireText4Objects10.length = 0;
gdjs.MainCode.GDFireText5Objects1.length = 0;
gdjs.MainCode.GDFireText5Objects2.length = 0;
gdjs.MainCode.GDFireText5Objects3.length = 0;
gdjs.MainCode.GDFireText5Objects4.length = 0;
gdjs.MainCode.GDFireText5Objects5.length = 0;
gdjs.MainCode.GDFireText5Objects6.length = 0;
gdjs.MainCode.GDFireText5Objects7.length = 0;
gdjs.MainCode.GDFireText5Objects8.length = 0;
gdjs.MainCode.GDFireText5Objects9.length = 0;
gdjs.MainCode.GDFireText5Objects10.length = 0;
gdjs.MainCode.GDFireText6Objects1.length = 0;
gdjs.MainCode.GDFireText6Objects2.length = 0;
gdjs.MainCode.GDFireText6Objects3.length = 0;
gdjs.MainCode.GDFireText6Objects4.length = 0;
gdjs.MainCode.GDFireText6Objects5.length = 0;
gdjs.MainCode.GDFireText6Objects6.length = 0;
gdjs.MainCode.GDFireText6Objects7.length = 0;
gdjs.MainCode.GDFireText6Objects8.length = 0;
gdjs.MainCode.GDFireText6Objects9.length = 0;
gdjs.MainCode.GDFireText6Objects10.length = 0;
gdjs.MainCode.GDLikeText4Objects1.length = 0;
gdjs.MainCode.GDLikeText4Objects2.length = 0;
gdjs.MainCode.GDLikeText4Objects3.length = 0;
gdjs.MainCode.GDLikeText4Objects4.length = 0;
gdjs.MainCode.GDLikeText4Objects5.length = 0;
gdjs.MainCode.GDLikeText4Objects6.length = 0;
gdjs.MainCode.GDLikeText4Objects7.length = 0;
gdjs.MainCode.GDLikeText4Objects8.length = 0;
gdjs.MainCode.GDLikeText4Objects9.length = 0;
gdjs.MainCode.GDLikeText4Objects10.length = 0;
gdjs.MainCode.GDLikeText5Objects1.length = 0;
gdjs.MainCode.GDLikeText5Objects2.length = 0;
gdjs.MainCode.GDLikeText5Objects3.length = 0;
gdjs.MainCode.GDLikeText5Objects4.length = 0;
gdjs.MainCode.GDLikeText5Objects5.length = 0;
gdjs.MainCode.GDLikeText5Objects6.length = 0;
gdjs.MainCode.GDLikeText5Objects7.length = 0;
gdjs.MainCode.GDLikeText5Objects8.length = 0;
gdjs.MainCode.GDLikeText5Objects9.length = 0;
gdjs.MainCode.GDLikeText5Objects10.length = 0;
gdjs.MainCode.GDLikeText6Objects1.length = 0;
gdjs.MainCode.GDLikeText6Objects2.length = 0;
gdjs.MainCode.GDLikeText6Objects3.length = 0;
gdjs.MainCode.GDLikeText6Objects4.length = 0;
gdjs.MainCode.GDLikeText6Objects5.length = 0;
gdjs.MainCode.GDLikeText6Objects6.length = 0;
gdjs.MainCode.GDLikeText6Objects7.length = 0;
gdjs.MainCode.GDLikeText6Objects8.length = 0;
gdjs.MainCode.GDLikeText6Objects9.length = 0;
gdjs.MainCode.GDLikeText6Objects10.length = 0;
gdjs.MainCode.GDHeartText4Objects1.length = 0;
gdjs.MainCode.GDHeartText4Objects2.length = 0;
gdjs.MainCode.GDHeartText4Objects3.length = 0;
gdjs.MainCode.GDHeartText4Objects4.length = 0;
gdjs.MainCode.GDHeartText4Objects5.length = 0;
gdjs.MainCode.GDHeartText4Objects6.length = 0;
gdjs.MainCode.GDHeartText4Objects7.length = 0;
gdjs.MainCode.GDHeartText4Objects8.length = 0;
gdjs.MainCode.GDHeartText4Objects9.length = 0;
gdjs.MainCode.GDHeartText4Objects10.length = 0;
gdjs.MainCode.GDHeartText5Objects1.length = 0;
gdjs.MainCode.GDHeartText5Objects2.length = 0;
gdjs.MainCode.GDHeartText5Objects3.length = 0;
gdjs.MainCode.GDHeartText5Objects4.length = 0;
gdjs.MainCode.GDHeartText5Objects5.length = 0;
gdjs.MainCode.GDHeartText5Objects6.length = 0;
gdjs.MainCode.GDHeartText5Objects7.length = 0;
gdjs.MainCode.GDHeartText5Objects8.length = 0;
gdjs.MainCode.GDHeartText5Objects9.length = 0;
gdjs.MainCode.GDHeartText5Objects10.length = 0;
gdjs.MainCode.GDHeartText6Objects1.length = 0;
gdjs.MainCode.GDHeartText6Objects2.length = 0;
gdjs.MainCode.GDHeartText6Objects3.length = 0;
gdjs.MainCode.GDHeartText6Objects4.length = 0;
gdjs.MainCode.GDHeartText6Objects5.length = 0;
gdjs.MainCode.GDHeartText6Objects6.length = 0;
gdjs.MainCode.GDHeartText6Objects7.length = 0;
gdjs.MainCode.GDHeartText6Objects8.length = 0;
gdjs.MainCode.GDHeartText6Objects9.length = 0;
gdjs.MainCode.GDHeartText6Objects10.length = 0;
gdjs.MainCode.GDTweetFace4Objects1.length = 0;
gdjs.MainCode.GDTweetFace4Objects2.length = 0;
gdjs.MainCode.GDTweetFace4Objects3.length = 0;
gdjs.MainCode.GDTweetFace4Objects4.length = 0;
gdjs.MainCode.GDTweetFace4Objects5.length = 0;
gdjs.MainCode.GDTweetFace4Objects6.length = 0;
gdjs.MainCode.GDTweetFace4Objects7.length = 0;
gdjs.MainCode.GDTweetFace4Objects8.length = 0;
gdjs.MainCode.GDTweetFace4Objects9.length = 0;
gdjs.MainCode.GDTweetFace4Objects10.length = 0;
gdjs.MainCode.GDTweetFace5Objects1.length = 0;
gdjs.MainCode.GDTweetFace5Objects2.length = 0;
gdjs.MainCode.GDTweetFace5Objects3.length = 0;
gdjs.MainCode.GDTweetFace5Objects4.length = 0;
gdjs.MainCode.GDTweetFace5Objects5.length = 0;
gdjs.MainCode.GDTweetFace5Objects6.length = 0;
gdjs.MainCode.GDTweetFace5Objects7.length = 0;
gdjs.MainCode.GDTweetFace5Objects8.length = 0;
gdjs.MainCode.GDTweetFace5Objects9.length = 0;
gdjs.MainCode.GDTweetFace5Objects10.length = 0;
gdjs.MainCode.GDTweetFace6Objects1.length = 0;
gdjs.MainCode.GDTweetFace6Objects2.length = 0;
gdjs.MainCode.GDTweetFace6Objects3.length = 0;
gdjs.MainCode.GDTweetFace6Objects4.length = 0;
gdjs.MainCode.GDTweetFace6Objects5.length = 0;
gdjs.MainCode.GDTweetFace6Objects6.length = 0;
gdjs.MainCode.GDTweetFace6Objects7.length = 0;
gdjs.MainCode.GDTweetFace6Objects8.length = 0;
gdjs.MainCode.GDTweetFace6Objects9.length = 0;
gdjs.MainCode.GDTweetFace6Objects10.length = 0;
gdjs.MainCode.GDTweetTitle4Objects1.length = 0;
gdjs.MainCode.GDTweetTitle4Objects2.length = 0;
gdjs.MainCode.GDTweetTitle4Objects3.length = 0;
gdjs.MainCode.GDTweetTitle4Objects4.length = 0;
gdjs.MainCode.GDTweetTitle4Objects5.length = 0;
gdjs.MainCode.GDTweetTitle4Objects6.length = 0;
gdjs.MainCode.GDTweetTitle4Objects7.length = 0;
gdjs.MainCode.GDTweetTitle4Objects8.length = 0;
gdjs.MainCode.GDTweetTitle4Objects9.length = 0;
gdjs.MainCode.GDTweetTitle4Objects10.length = 0;
gdjs.MainCode.GDTweetTitle5Objects1.length = 0;
gdjs.MainCode.GDTweetTitle5Objects2.length = 0;
gdjs.MainCode.GDTweetTitle5Objects3.length = 0;
gdjs.MainCode.GDTweetTitle5Objects4.length = 0;
gdjs.MainCode.GDTweetTitle5Objects5.length = 0;
gdjs.MainCode.GDTweetTitle5Objects6.length = 0;
gdjs.MainCode.GDTweetTitle5Objects7.length = 0;
gdjs.MainCode.GDTweetTitle5Objects8.length = 0;
gdjs.MainCode.GDTweetTitle5Objects9.length = 0;
gdjs.MainCode.GDTweetTitle5Objects10.length = 0;
gdjs.MainCode.GDTweetTitle6Objects1.length = 0;
gdjs.MainCode.GDTweetTitle6Objects2.length = 0;
gdjs.MainCode.GDTweetTitle6Objects3.length = 0;
gdjs.MainCode.GDTweetTitle6Objects4.length = 0;
gdjs.MainCode.GDTweetTitle6Objects5.length = 0;
gdjs.MainCode.GDTweetTitle6Objects6.length = 0;
gdjs.MainCode.GDTweetTitle6Objects7.length = 0;
gdjs.MainCode.GDTweetTitle6Objects8.length = 0;
gdjs.MainCode.GDTweetTitle6Objects9.length = 0;
gdjs.MainCode.GDTweetTitle6Objects10.length = 0;
gdjs.MainCode.GDTweet4Objects1.length = 0;
gdjs.MainCode.GDTweet4Objects2.length = 0;
gdjs.MainCode.GDTweet4Objects3.length = 0;
gdjs.MainCode.GDTweet4Objects4.length = 0;
gdjs.MainCode.GDTweet4Objects5.length = 0;
gdjs.MainCode.GDTweet4Objects6.length = 0;
gdjs.MainCode.GDTweet4Objects7.length = 0;
gdjs.MainCode.GDTweet4Objects8.length = 0;
gdjs.MainCode.GDTweet4Objects9.length = 0;
gdjs.MainCode.GDTweet4Objects10.length = 0;
gdjs.MainCode.GDTweet5Objects1.length = 0;
gdjs.MainCode.GDTweet5Objects2.length = 0;
gdjs.MainCode.GDTweet5Objects3.length = 0;
gdjs.MainCode.GDTweet5Objects4.length = 0;
gdjs.MainCode.GDTweet5Objects5.length = 0;
gdjs.MainCode.GDTweet5Objects6.length = 0;
gdjs.MainCode.GDTweet5Objects7.length = 0;
gdjs.MainCode.GDTweet5Objects8.length = 0;
gdjs.MainCode.GDTweet5Objects9.length = 0;
gdjs.MainCode.GDTweet5Objects10.length = 0;
gdjs.MainCode.GDTweet6Objects1.length = 0;
gdjs.MainCode.GDTweet6Objects2.length = 0;
gdjs.MainCode.GDTweet6Objects3.length = 0;
gdjs.MainCode.GDTweet6Objects4.length = 0;
gdjs.MainCode.GDTweet6Objects5.length = 0;
gdjs.MainCode.GDTweet6Objects6.length = 0;
gdjs.MainCode.GDTweet6Objects7.length = 0;
gdjs.MainCode.GDTweet6Objects8.length = 0;
gdjs.MainCode.GDTweet6Objects9.length = 0;
gdjs.MainCode.GDTweet6Objects10.length = 0;
gdjs.MainCode.GDBars_9595cover_9595blueObjects1.length = 0;
gdjs.MainCode.GDBars_9595cover_9595blueObjects2.length = 0;
gdjs.MainCode.GDBars_9595cover_9595blueObjects3.length = 0;
gdjs.MainCode.GDBars_9595cover_9595blueObjects4.length = 0;
gdjs.MainCode.GDBars_9595cover_9595blueObjects5.length = 0;
gdjs.MainCode.GDBars_9595cover_9595blueObjects6.length = 0;
gdjs.MainCode.GDBars_9595cover_9595blueObjects7.length = 0;
gdjs.MainCode.GDBars_9595cover_9595blueObjects8.length = 0;
gdjs.MainCode.GDBars_9595cover_9595blueObjects9.length = 0;
gdjs.MainCode.GDBars_9595cover_9595blueObjects10.length = 0;
gdjs.MainCode.GDBars_9595cover_9595greenObjects1.length = 0;
gdjs.MainCode.GDBars_9595cover_9595greenObjects2.length = 0;
gdjs.MainCode.GDBars_9595cover_9595greenObjects3.length = 0;
gdjs.MainCode.GDBars_9595cover_9595greenObjects4.length = 0;
gdjs.MainCode.GDBars_9595cover_9595greenObjects5.length = 0;
gdjs.MainCode.GDBars_9595cover_9595greenObjects6.length = 0;
gdjs.MainCode.GDBars_9595cover_9595greenObjects7.length = 0;
gdjs.MainCode.GDBars_9595cover_9595greenObjects8.length = 0;
gdjs.MainCode.GDBars_9595cover_9595greenObjects9.length = 0;
gdjs.MainCode.GDBars_9595cover_9595greenObjects10.length = 0;
gdjs.MainCode.GDBars_9595cover_9595orangeObjects1.length = 0;
gdjs.MainCode.GDBars_9595cover_9595orangeObjects2.length = 0;
gdjs.MainCode.GDBars_9595cover_9595orangeObjects3.length = 0;
gdjs.MainCode.GDBars_9595cover_9595orangeObjects4.length = 0;
gdjs.MainCode.GDBars_9595cover_9595orangeObjects5.length = 0;
gdjs.MainCode.GDBars_9595cover_9595orangeObjects6.length = 0;
gdjs.MainCode.GDBars_9595cover_9595orangeObjects7.length = 0;
gdjs.MainCode.GDBars_9595cover_9595orangeObjects8.length = 0;
gdjs.MainCode.GDBars_9595cover_9595orangeObjects9.length = 0;
gdjs.MainCode.GDBars_9595cover_9595orangeObjects10.length = 0;
gdjs.MainCode.GDBars_9595cover_9595pinkObjects1.length = 0;
gdjs.MainCode.GDBars_9595cover_9595pinkObjects2.length = 0;
gdjs.MainCode.GDBars_9595cover_9595pinkObjects3.length = 0;
gdjs.MainCode.GDBars_9595cover_9595pinkObjects4.length = 0;
gdjs.MainCode.GDBars_9595cover_9595pinkObjects5.length = 0;
gdjs.MainCode.GDBars_9595cover_9595pinkObjects6.length = 0;
gdjs.MainCode.GDBars_9595cover_9595pinkObjects7.length = 0;
gdjs.MainCode.GDBars_9595cover_9595pinkObjects8.length = 0;
gdjs.MainCode.GDBars_9595cover_9595pinkObjects9.length = 0;
gdjs.MainCode.GDBars_9595cover_9595pinkObjects10.length = 0;
gdjs.MainCode.GDTestTextObjects1.length = 0;
gdjs.MainCode.GDTestTextObjects2.length = 0;
gdjs.MainCode.GDTestTextObjects3.length = 0;
gdjs.MainCode.GDTestTextObjects4.length = 0;
gdjs.MainCode.GDTestTextObjects5.length = 0;
gdjs.MainCode.GDTestTextObjects6.length = 0;
gdjs.MainCode.GDTestTextObjects7.length = 0;
gdjs.MainCode.GDTestTextObjects8.length = 0;
gdjs.MainCode.GDTestTextObjects9.length = 0;
gdjs.MainCode.GDTestTextObjects10.length = 0;
gdjs.MainCode.GDTestText2Objects1.length = 0;
gdjs.MainCode.GDTestText2Objects2.length = 0;
gdjs.MainCode.GDTestText2Objects3.length = 0;
gdjs.MainCode.GDTestText2Objects4.length = 0;
gdjs.MainCode.GDTestText2Objects5.length = 0;
gdjs.MainCode.GDTestText2Objects6.length = 0;
gdjs.MainCode.GDTestText2Objects7.length = 0;
gdjs.MainCode.GDTestText2Objects8.length = 0;
gdjs.MainCode.GDTestText2Objects9.length = 0;
gdjs.MainCode.GDTestText2Objects10.length = 0;
gdjs.MainCode.GDBlackScreenObjects1.length = 0;
gdjs.MainCode.GDBlackScreenObjects2.length = 0;
gdjs.MainCode.GDBlackScreenObjects3.length = 0;
gdjs.MainCode.GDBlackScreenObjects4.length = 0;
gdjs.MainCode.GDBlackScreenObjects5.length = 0;
gdjs.MainCode.GDBlackScreenObjects6.length = 0;
gdjs.MainCode.GDBlackScreenObjects7.length = 0;
gdjs.MainCode.GDBlackScreenObjects8.length = 0;
gdjs.MainCode.GDBlackScreenObjects9.length = 0;
gdjs.MainCode.GDBlackScreenObjects10.length = 0;
gdjs.MainCode.GDBlackScreenTextObjects1.length = 0;
gdjs.MainCode.GDBlackScreenTextObjects2.length = 0;
gdjs.MainCode.GDBlackScreenTextObjects3.length = 0;
gdjs.MainCode.GDBlackScreenTextObjects4.length = 0;
gdjs.MainCode.GDBlackScreenTextObjects5.length = 0;
gdjs.MainCode.GDBlackScreenTextObjects6.length = 0;
gdjs.MainCode.GDBlackScreenTextObjects7.length = 0;
gdjs.MainCode.GDBlackScreenTextObjects8.length = 0;
gdjs.MainCode.GDBlackScreenTextObjects9.length = 0;
gdjs.MainCode.GDBlackScreenTextObjects10.length = 0;
gdjs.MainCode.GDLayout_9595maskObjects1.length = 0;
gdjs.MainCode.GDLayout_9595maskObjects2.length = 0;
gdjs.MainCode.GDLayout_9595maskObjects3.length = 0;
gdjs.MainCode.GDLayout_9595maskObjects4.length = 0;
gdjs.MainCode.GDLayout_9595maskObjects5.length = 0;
gdjs.MainCode.GDLayout_9595maskObjects6.length = 0;
gdjs.MainCode.GDLayout_9595maskObjects7.length = 0;
gdjs.MainCode.GDLayout_9595maskObjects8.length = 0;
gdjs.MainCode.GDLayout_9595maskObjects9.length = 0;
gdjs.MainCode.GDLayout_9595maskObjects10.length = 0;
gdjs.MainCode.GDEconomyResultObjects1.length = 0;
gdjs.MainCode.GDEconomyResultObjects2.length = 0;
gdjs.MainCode.GDEconomyResultObjects3.length = 0;
gdjs.MainCode.GDEconomyResultObjects4.length = 0;
gdjs.MainCode.GDEconomyResultObjects5.length = 0;
gdjs.MainCode.GDEconomyResultObjects6.length = 0;
gdjs.MainCode.GDEconomyResultObjects7.length = 0;
gdjs.MainCode.GDEconomyResultObjects8.length = 0;
gdjs.MainCode.GDEconomyResultObjects9.length = 0;
gdjs.MainCode.GDEconomyResultObjects10.length = 0;
gdjs.MainCode.GDPAResultObjects1.length = 0;
gdjs.MainCode.GDPAResultObjects2.length = 0;
gdjs.MainCode.GDPAResultObjects3.length = 0;
gdjs.MainCode.GDPAResultObjects4.length = 0;
gdjs.MainCode.GDPAResultObjects5.length = 0;
gdjs.MainCode.GDPAResultObjects6.length = 0;
gdjs.MainCode.GDPAResultObjects7.length = 0;
gdjs.MainCode.GDPAResultObjects8.length = 0;
gdjs.MainCode.GDPAResultObjects9.length = 0;
gdjs.MainCode.GDPAResultObjects10.length = 0;
gdjs.MainCode.GDRiskResultObjects1.length = 0;
gdjs.MainCode.GDRiskResultObjects2.length = 0;
gdjs.MainCode.GDRiskResultObjects3.length = 0;
gdjs.MainCode.GDRiskResultObjects4.length = 0;
gdjs.MainCode.GDRiskResultObjects5.length = 0;
gdjs.MainCode.GDRiskResultObjects6.length = 0;
gdjs.MainCode.GDRiskResultObjects7.length = 0;
gdjs.MainCode.GDRiskResultObjects8.length = 0;
gdjs.MainCode.GDRiskResultObjects9.length = 0;
gdjs.MainCode.GDRiskResultObjects10.length = 0;
gdjs.MainCode.GDPersonalWealthResultObjects1.length = 0;
gdjs.MainCode.GDPersonalWealthResultObjects2.length = 0;
gdjs.MainCode.GDPersonalWealthResultObjects3.length = 0;
gdjs.MainCode.GDPersonalWealthResultObjects4.length = 0;
gdjs.MainCode.GDPersonalWealthResultObjects5.length = 0;
gdjs.MainCode.GDPersonalWealthResultObjects6.length = 0;
gdjs.MainCode.GDPersonalWealthResultObjects7.length = 0;
gdjs.MainCode.GDPersonalWealthResultObjects8.length = 0;
gdjs.MainCode.GDPersonalWealthResultObjects9.length = 0;
gdjs.MainCode.GDPersonalWealthResultObjects10.length = 0;
gdjs.MainCode.GDNext_9595buttonObjects1.length = 0;
gdjs.MainCode.GDNext_9595buttonObjects2.length = 0;
gdjs.MainCode.GDNext_9595buttonObjects3.length = 0;
gdjs.MainCode.GDNext_9595buttonObjects4.length = 0;
gdjs.MainCode.GDNext_9595buttonObjects5.length = 0;
gdjs.MainCode.GDNext_9595buttonObjects6.length = 0;
gdjs.MainCode.GDNext_9595buttonObjects7.length = 0;
gdjs.MainCode.GDNext_9595buttonObjects8.length = 0;
gdjs.MainCode.GDNext_9595buttonObjects9.length = 0;
gdjs.MainCode.GDNext_9595buttonObjects10.length = 0;
gdjs.MainCode.GDNextTextObjects1.length = 0;
gdjs.MainCode.GDNextTextObjects2.length = 0;
gdjs.MainCode.GDNextTextObjects3.length = 0;
gdjs.MainCode.GDNextTextObjects4.length = 0;
gdjs.MainCode.GDNextTextObjects5.length = 0;
gdjs.MainCode.GDNextTextObjects6.length = 0;
gdjs.MainCode.GDNextTextObjects7.length = 0;
gdjs.MainCode.GDNextTextObjects8.length = 0;
gdjs.MainCode.GDNextTextObjects9.length = 0;
gdjs.MainCode.GDNextTextObjects10.length = 0;
gdjs.MainCode.GDSoundToggleObjects1.length = 0;
gdjs.MainCode.GDSoundToggleObjects2.length = 0;
gdjs.MainCode.GDSoundToggleObjects3.length = 0;
gdjs.MainCode.GDSoundToggleObjects4.length = 0;
gdjs.MainCode.GDSoundToggleObjects5.length = 0;
gdjs.MainCode.GDSoundToggleObjects6.length = 0;
gdjs.MainCode.GDSoundToggleObjects7.length = 0;
gdjs.MainCode.GDSoundToggleObjects8.length = 0;
gdjs.MainCode.GDSoundToggleObjects9.length = 0;
gdjs.MainCode.GDSoundToggleObjects10.length = 0;
gdjs.MainCode.GDSkipTutorialObjects1.length = 0;
gdjs.MainCode.GDSkipTutorialObjects2.length = 0;
gdjs.MainCode.GDSkipTutorialObjects3.length = 0;
gdjs.MainCode.GDSkipTutorialObjects4.length = 0;
gdjs.MainCode.GDSkipTutorialObjects5.length = 0;
gdjs.MainCode.GDSkipTutorialObjects6.length = 0;
gdjs.MainCode.GDSkipTutorialObjects7.length = 0;
gdjs.MainCode.GDSkipTutorialObjects8.length = 0;
gdjs.MainCode.GDSkipTutorialObjects9.length = 0;
gdjs.MainCode.GDSkipTutorialObjects10.length = 0;
gdjs.MainCode.GDCapConditionObjects1.length = 0;
gdjs.MainCode.GDCapConditionObjects2.length = 0;
gdjs.MainCode.GDCapConditionObjects3.length = 0;
gdjs.MainCode.GDCapConditionObjects4.length = 0;
gdjs.MainCode.GDCapConditionObjects5.length = 0;
gdjs.MainCode.GDCapConditionObjects6.length = 0;
gdjs.MainCode.GDCapConditionObjects7.length = 0;
gdjs.MainCode.GDCapConditionObjects8.length = 0;
gdjs.MainCode.GDCapConditionObjects9.length = 0;
gdjs.MainCode.GDCapConditionObjects10.length = 0;
gdjs.MainCode.GDRestart_9595buttonObjects1.length = 0;
gdjs.MainCode.GDRestart_9595buttonObjects2.length = 0;
gdjs.MainCode.GDRestart_9595buttonObjects3.length = 0;
gdjs.MainCode.GDRestart_9595buttonObjects4.length = 0;
gdjs.MainCode.GDRestart_9595buttonObjects5.length = 0;
gdjs.MainCode.GDRestart_9595buttonObjects6.length = 0;
gdjs.MainCode.GDRestart_9595buttonObjects7.length = 0;
gdjs.MainCode.GDRestart_9595buttonObjects8.length = 0;
gdjs.MainCode.GDRestart_9595buttonObjects9.length = 0;
gdjs.MainCode.GDRestart_9595buttonObjects10.length = 0;
gdjs.MainCode.GDMenu_9595bkgObjects1.length = 0;
gdjs.MainCode.GDMenu_9595bkgObjects2.length = 0;
gdjs.MainCode.GDMenu_9595bkgObjects3.length = 0;
gdjs.MainCode.GDMenu_9595bkgObjects4.length = 0;
gdjs.MainCode.GDMenu_9595bkgObjects5.length = 0;
gdjs.MainCode.GDMenu_9595bkgObjects6.length = 0;
gdjs.MainCode.GDMenu_9595bkgObjects7.length = 0;
gdjs.MainCode.GDMenu_9595bkgObjects8.length = 0;
gdjs.MainCode.GDMenu_9595bkgObjects9.length = 0;
gdjs.MainCode.GDMenu_9595bkgObjects10.length = 0;
gdjs.MainCode.GDPlay_9595buttonObjects1.length = 0;
gdjs.MainCode.GDPlay_9595buttonObjects2.length = 0;
gdjs.MainCode.GDPlay_9595buttonObjects3.length = 0;
gdjs.MainCode.GDPlay_9595buttonObjects4.length = 0;
gdjs.MainCode.GDPlay_9595buttonObjects5.length = 0;
gdjs.MainCode.GDPlay_9595buttonObjects6.length = 0;
gdjs.MainCode.GDPlay_9595buttonObjects7.length = 0;
gdjs.MainCode.GDPlay_9595buttonObjects8.length = 0;
gdjs.MainCode.GDPlay_9595buttonObjects9.length = 0;
gdjs.MainCode.GDPlay_9595buttonObjects10.length = 0;

gdjs.MainCode.eventsList263(runtimeScene);
gdjs.MainCode.GDTweet1Objects1.length = 0;
gdjs.MainCode.GDTweet1Objects2.length = 0;
gdjs.MainCode.GDTweet1Objects3.length = 0;
gdjs.MainCode.GDTweet1Objects4.length = 0;
gdjs.MainCode.GDTweet1Objects5.length = 0;
gdjs.MainCode.GDTweet1Objects6.length = 0;
gdjs.MainCode.GDTweet1Objects7.length = 0;
gdjs.MainCode.GDTweet1Objects8.length = 0;
gdjs.MainCode.GDTweet1Objects9.length = 0;
gdjs.MainCode.GDTweet1Objects10.length = 0;
gdjs.MainCode.GDTweetTitle1Objects1.length = 0;
gdjs.MainCode.GDTweetTitle1Objects2.length = 0;
gdjs.MainCode.GDTweetTitle1Objects3.length = 0;
gdjs.MainCode.GDTweetTitle1Objects4.length = 0;
gdjs.MainCode.GDTweetTitle1Objects5.length = 0;
gdjs.MainCode.GDTweetTitle1Objects6.length = 0;
gdjs.MainCode.GDTweetTitle1Objects7.length = 0;
gdjs.MainCode.GDTweetTitle1Objects8.length = 0;
gdjs.MainCode.GDTweetTitle1Objects9.length = 0;
gdjs.MainCode.GDTweetTitle1Objects10.length = 0;
gdjs.MainCode.GDReactionIcons_9595HeartObjects1.length = 0;
gdjs.MainCode.GDReactionIcons_9595HeartObjects2.length = 0;
gdjs.MainCode.GDReactionIcons_9595HeartObjects3.length = 0;
gdjs.MainCode.GDReactionIcons_9595HeartObjects4.length = 0;
gdjs.MainCode.GDReactionIcons_9595HeartObjects5.length = 0;
gdjs.MainCode.GDReactionIcons_9595HeartObjects6.length = 0;
gdjs.MainCode.GDReactionIcons_9595HeartObjects7.length = 0;
gdjs.MainCode.GDReactionIcons_9595HeartObjects8.length = 0;
gdjs.MainCode.GDReactionIcons_9595HeartObjects9.length = 0;
gdjs.MainCode.GDReactionIcons_9595HeartObjects10.length = 0;
gdjs.MainCode.GDHeartText1Objects1.length = 0;
gdjs.MainCode.GDHeartText1Objects2.length = 0;
gdjs.MainCode.GDHeartText1Objects3.length = 0;
gdjs.MainCode.GDHeartText1Objects4.length = 0;
gdjs.MainCode.GDHeartText1Objects5.length = 0;
gdjs.MainCode.GDHeartText1Objects6.length = 0;
gdjs.MainCode.GDHeartText1Objects7.length = 0;
gdjs.MainCode.GDHeartText1Objects8.length = 0;
gdjs.MainCode.GDHeartText1Objects9.length = 0;
gdjs.MainCode.GDHeartText1Objects10.length = 0;
gdjs.MainCode.GDReactionIcon_9595LikeObjects1.length = 0;
gdjs.MainCode.GDReactionIcon_9595LikeObjects2.length = 0;
gdjs.MainCode.GDReactionIcon_9595LikeObjects3.length = 0;
gdjs.MainCode.GDReactionIcon_9595LikeObjects4.length = 0;
gdjs.MainCode.GDReactionIcon_9595LikeObjects5.length = 0;
gdjs.MainCode.GDReactionIcon_9595LikeObjects6.length = 0;
gdjs.MainCode.GDReactionIcon_9595LikeObjects7.length = 0;
gdjs.MainCode.GDReactionIcon_9595LikeObjects8.length = 0;
gdjs.MainCode.GDReactionIcon_9595LikeObjects9.length = 0;
gdjs.MainCode.GDReactionIcon_9595LikeObjects10.length = 0;
gdjs.MainCode.GDLikeText1Objects1.length = 0;
gdjs.MainCode.GDLikeText1Objects2.length = 0;
gdjs.MainCode.GDLikeText1Objects3.length = 0;
gdjs.MainCode.GDLikeText1Objects4.length = 0;
gdjs.MainCode.GDLikeText1Objects5.length = 0;
gdjs.MainCode.GDLikeText1Objects6.length = 0;
gdjs.MainCode.GDLikeText1Objects7.length = 0;
gdjs.MainCode.GDLikeText1Objects8.length = 0;
gdjs.MainCode.GDLikeText1Objects9.length = 0;
gdjs.MainCode.GDLikeText1Objects10.length = 0;
gdjs.MainCode.GDReactionIcon_9595FireObjects1.length = 0;
gdjs.MainCode.GDReactionIcon_9595FireObjects2.length = 0;
gdjs.MainCode.GDReactionIcon_9595FireObjects3.length = 0;
gdjs.MainCode.GDReactionIcon_9595FireObjects4.length = 0;
gdjs.MainCode.GDReactionIcon_9595FireObjects5.length = 0;
gdjs.MainCode.GDReactionIcon_9595FireObjects6.length = 0;
gdjs.MainCode.GDReactionIcon_9595FireObjects7.length = 0;
gdjs.MainCode.GDReactionIcon_9595FireObjects8.length = 0;
gdjs.MainCode.GDReactionIcon_9595FireObjects9.length = 0;
gdjs.MainCode.GDReactionIcon_9595FireObjects10.length = 0;
gdjs.MainCode.GDFireText1Objects1.length = 0;
gdjs.MainCode.GDFireText1Objects2.length = 0;
gdjs.MainCode.GDFireText1Objects3.length = 0;
gdjs.MainCode.GDFireText1Objects4.length = 0;
gdjs.MainCode.GDFireText1Objects5.length = 0;
gdjs.MainCode.GDFireText1Objects6.length = 0;
gdjs.MainCode.GDFireText1Objects7.length = 0;
gdjs.MainCode.GDFireText1Objects8.length = 0;
gdjs.MainCode.GDFireText1Objects9.length = 0;
gdjs.MainCode.GDFireText1Objects10.length = 0;
gdjs.MainCode.GDFireText2Objects1.length = 0;
gdjs.MainCode.GDFireText2Objects2.length = 0;
gdjs.MainCode.GDFireText2Objects3.length = 0;
gdjs.MainCode.GDFireText2Objects4.length = 0;
gdjs.MainCode.GDFireText2Objects5.length = 0;
gdjs.MainCode.GDFireText2Objects6.length = 0;
gdjs.MainCode.GDFireText2Objects7.length = 0;
gdjs.MainCode.GDFireText2Objects8.length = 0;
gdjs.MainCode.GDFireText2Objects9.length = 0;
gdjs.MainCode.GDFireText2Objects10.length = 0;
gdjs.MainCode.GDLikeText2Objects1.length = 0;
gdjs.MainCode.GDLikeText2Objects2.length = 0;
gdjs.MainCode.GDLikeText2Objects3.length = 0;
gdjs.MainCode.GDLikeText2Objects4.length = 0;
gdjs.MainCode.GDLikeText2Objects5.length = 0;
gdjs.MainCode.GDLikeText2Objects6.length = 0;
gdjs.MainCode.GDLikeText2Objects7.length = 0;
gdjs.MainCode.GDLikeText2Objects8.length = 0;
gdjs.MainCode.GDLikeText2Objects9.length = 0;
gdjs.MainCode.GDLikeText2Objects10.length = 0;
gdjs.MainCode.GDHeartText2Objects1.length = 0;
gdjs.MainCode.GDHeartText2Objects2.length = 0;
gdjs.MainCode.GDHeartText2Objects3.length = 0;
gdjs.MainCode.GDHeartText2Objects4.length = 0;
gdjs.MainCode.GDHeartText2Objects5.length = 0;
gdjs.MainCode.GDHeartText2Objects6.length = 0;
gdjs.MainCode.GDHeartText2Objects7.length = 0;
gdjs.MainCode.GDHeartText2Objects8.length = 0;
gdjs.MainCode.GDHeartText2Objects9.length = 0;
gdjs.MainCode.GDHeartText2Objects10.length = 0;
gdjs.MainCode.GDFireText3Objects1.length = 0;
gdjs.MainCode.GDFireText3Objects2.length = 0;
gdjs.MainCode.GDFireText3Objects3.length = 0;
gdjs.MainCode.GDFireText3Objects4.length = 0;
gdjs.MainCode.GDFireText3Objects5.length = 0;
gdjs.MainCode.GDFireText3Objects6.length = 0;
gdjs.MainCode.GDFireText3Objects7.length = 0;
gdjs.MainCode.GDFireText3Objects8.length = 0;
gdjs.MainCode.GDFireText3Objects9.length = 0;
gdjs.MainCode.GDFireText3Objects10.length = 0;
gdjs.MainCode.GDLikeText3Objects1.length = 0;
gdjs.MainCode.GDLikeText3Objects2.length = 0;
gdjs.MainCode.GDLikeText3Objects3.length = 0;
gdjs.MainCode.GDLikeText3Objects4.length = 0;
gdjs.MainCode.GDLikeText3Objects5.length = 0;
gdjs.MainCode.GDLikeText3Objects6.length = 0;
gdjs.MainCode.GDLikeText3Objects7.length = 0;
gdjs.MainCode.GDLikeText3Objects8.length = 0;
gdjs.MainCode.GDLikeText3Objects9.length = 0;
gdjs.MainCode.GDLikeText3Objects10.length = 0;
gdjs.MainCode.GDHeartText3Objects1.length = 0;
gdjs.MainCode.GDHeartText3Objects2.length = 0;
gdjs.MainCode.GDHeartText3Objects3.length = 0;
gdjs.MainCode.GDHeartText3Objects4.length = 0;
gdjs.MainCode.GDHeartText3Objects5.length = 0;
gdjs.MainCode.GDHeartText3Objects6.length = 0;
gdjs.MainCode.GDHeartText3Objects7.length = 0;
gdjs.MainCode.GDHeartText3Objects8.length = 0;
gdjs.MainCode.GDHeartText3Objects9.length = 0;
gdjs.MainCode.GDHeartText3Objects10.length = 0;
gdjs.MainCode.GDTweetFace3Objects1.length = 0;
gdjs.MainCode.GDTweetFace3Objects2.length = 0;
gdjs.MainCode.GDTweetFace3Objects3.length = 0;
gdjs.MainCode.GDTweetFace3Objects4.length = 0;
gdjs.MainCode.GDTweetFace3Objects5.length = 0;
gdjs.MainCode.GDTweetFace3Objects6.length = 0;
gdjs.MainCode.GDTweetFace3Objects7.length = 0;
gdjs.MainCode.GDTweetFace3Objects8.length = 0;
gdjs.MainCode.GDTweetFace3Objects9.length = 0;
gdjs.MainCode.GDTweetFace3Objects10.length = 0;
gdjs.MainCode.GDTweetTitle2Objects1.length = 0;
gdjs.MainCode.GDTweetTitle2Objects2.length = 0;
gdjs.MainCode.GDTweetTitle2Objects3.length = 0;
gdjs.MainCode.GDTweetTitle2Objects4.length = 0;
gdjs.MainCode.GDTweetTitle2Objects5.length = 0;
gdjs.MainCode.GDTweetTitle2Objects6.length = 0;
gdjs.MainCode.GDTweetTitle2Objects7.length = 0;
gdjs.MainCode.GDTweetTitle2Objects8.length = 0;
gdjs.MainCode.GDTweetTitle2Objects9.length = 0;
gdjs.MainCode.GDTweetTitle2Objects10.length = 0;
gdjs.MainCode.GDTweetTitle3Objects1.length = 0;
gdjs.MainCode.GDTweetTitle3Objects2.length = 0;
gdjs.MainCode.GDTweetTitle3Objects3.length = 0;
gdjs.MainCode.GDTweetTitle3Objects4.length = 0;
gdjs.MainCode.GDTweetTitle3Objects5.length = 0;
gdjs.MainCode.GDTweetTitle3Objects6.length = 0;
gdjs.MainCode.GDTweetTitle3Objects7.length = 0;
gdjs.MainCode.GDTweetTitle3Objects8.length = 0;
gdjs.MainCode.GDTweetTitle3Objects9.length = 0;
gdjs.MainCode.GDTweetTitle3Objects10.length = 0;
gdjs.MainCode.GDTweet2Objects1.length = 0;
gdjs.MainCode.GDTweet2Objects2.length = 0;
gdjs.MainCode.GDTweet2Objects3.length = 0;
gdjs.MainCode.GDTweet2Objects4.length = 0;
gdjs.MainCode.GDTweet2Objects5.length = 0;
gdjs.MainCode.GDTweet2Objects6.length = 0;
gdjs.MainCode.GDTweet2Objects7.length = 0;
gdjs.MainCode.GDTweet2Objects8.length = 0;
gdjs.MainCode.GDTweet2Objects9.length = 0;
gdjs.MainCode.GDTweet2Objects10.length = 0;
gdjs.MainCode.GDTweet3Objects1.length = 0;
gdjs.MainCode.GDTweet3Objects2.length = 0;
gdjs.MainCode.GDTweet3Objects3.length = 0;
gdjs.MainCode.GDTweet3Objects4.length = 0;
gdjs.MainCode.GDTweet3Objects5.length = 0;
gdjs.MainCode.GDTweet3Objects6.length = 0;
gdjs.MainCode.GDTweet3Objects7.length = 0;
gdjs.MainCode.GDTweet3Objects8.length = 0;
gdjs.MainCode.GDTweet3Objects9.length = 0;
gdjs.MainCode.GDTweet3Objects10.length = 0;
gdjs.MainCode.GDTweet_9595bkg1Objects1.length = 0;
gdjs.MainCode.GDTweet_9595bkg1Objects2.length = 0;
gdjs.MainCode.GDTweet_9595bkg1Objects3.length = 0;
gdjs.MainCode.GDTweet_9595bkg1Objects4.length = 0;
gdjs.MainCode.GDTweet_9595bkg1Objects5.length = 0;
gdjs.MainCode.GDTweet_9595bkg1Objects6.length = 0;
gdjs.MainCode.GDTweet_9595bkg1Objects7.length = 0;
gdjs.MainCode.GDTweet_9595bkg1Objects8.length = 0;
gdjs.MainCode.GDTweet_9595bkg1Objects9.length = 0;
gdjs.MainCode.GDTweet_9595bkg1Objects10.length = 0;
gdjs.MainCode.GDOption1Objects1.length = 0;
gdjs.MainCode.GDOption1Objects2.length = 0;
gdjs.MainCode.GDOption1Objects3.length = 0;
gdjs.MainCode.GDOption1Objects4.length = 0;
gdjs.MainCode.GDOption1Objects5.length = 0;
gdjs.MainCode.GDOption1Objects6.length = 0;
gdjs.MainCode.GDOption1Objects7.length = 0;
gdjs.MainCode.GDOption1Objects8.length = 0;
gdjs.MainCode.GDOption1Objects9.length = 0;
gdjs.MainCode.GDOption1Objects10.length = 0;
gdjs.MainCode.GDOption2Objects1.length = 0;
gdjs.MainCode.GDOption2Objects2.length = 0;
gdjs.MainCode.GDOption2Objects3.length = 0;
gdjs.MainCode.GDOption2Objects4.length = 0;
gdjs.MainCode.GDOption2Objects5.length = 0;
gdjs.MainCode.GDOption2Objects6.length = 0;
gdjs.MainCode.GDOption2Objects7.length = 0;
gdjs.MainCode.GDOption2Objects8.length = 0;
gdjs.MainCode.GDOption2Objects9.length = 0;
gdjs.MainCode.GDOption2Objects10.length = 0;
gdjs.MainCode.GDOption3Objects1.length = 0;
gdjs.MainCode.GDOption3Objects2.length = 0;
gdjs.MainCode.GDOption3Objects3.length = 0;
gdjs.MainCode.GDOption3Objects4.length = 0;
gdjs.MainCode.GDOption3Objects5.length = 0;
gdjs.MainCode.GDOption3Objects6.length = 0;
gdjs.MainCode.GDOption3Objects7.length = 0;
gdjs.MainCode.GDOption3Objects8.length = 0;
gdjs.MainCode.GDOption3Objects9.length = 0;
gdjs.MainCode.GDOption3Objects10.length = 0;
gdjs.MainCode.GDOptionTxt1Objects1.length = 0;
gdjs.MainCode.GDOptionTxt1Objects2.length = 0;
gdjs.MainCode.GDOptionTxt1Objects3.length = 0;
gdjs.MainCode.GDOptionTxt1Objects4.length = 0;
gdjs.MainCode.GDOptionTxt1Objects5.length = 0;
gdjs.MainCode.GDOptionTxt1Objects6.length = 0;
gdjs.MainCode.GDOptionTxt1Objects7.length = 0;
gdjs.MainCode.GDOptionTxt1Objects8.length = 0;
gdjs.MainCode.GDOptionTxt1Objects9.length = 0;
gdjs.MainCode.GDOptionTxt1Objects10.length = 0;
gdjs.MainCode.GDOptionTxt2Objects1.length = 0;
gdjs.MainCode.GDOptionTxt2Objects2.length = 0;
gdjs.MainCode.GDOptionTxt2Objects3.length = 0;
gdjs.MainCode.GDOptionTxt2Objects4.length = 0;
gdjs.MainCode.GDOptionTxt2Objects5.length = 0;
gdjs.MainCode.GDOptionTxt2Objects6.length = 0;
gdjs.MainCode.GDOptionTxt2Objects7.length = 0;
gdjs.MainCode.GDOptionTxt2Objects8.length = 0;
gdjs.MainCode.GDOptionTxt2Objects9.length = 0;
gdjs.MainCode.GDOptionTxt2Objects10.length = 0;
gdjs.MainCode.GDOptionTxt3Objects1.length = 0;
gdjs.MainCode.GDOptionTxt3Objects2.length = 0;
gdjs.MainCode.GDOptionTxt3Objects3.length = 0;
gdjs.MainCode.GDOptionTxt3Objects4.length = 0;
gdjs.MainCode.GDOptionTxt3Objects5.length = 0;
gdjs.MainCode.GDOptionTxt3Objects6.length = 0;
gdjs.MainCode.GDOptionTxt3Objects7.length = 0;
gdjs.MainCode.GDOptionTxt3Objects8.length = 0;
gdjs.MainCode.GDOptionTxt3Objects9.length = 0;
gdjs.MainCode.GDOptionTxt3Objects10.length = 0;
gdjs.MainCode.GDSend_9595icon1Objects1.length = 0;
gdjs.MainCode.GDSend_9595icon1Objects2.length = 0;
gdjs.MainCode.GDSend_9595icon1Objects3.length = 0;
gdjs.MainCode.GDSend_9595icon1Objects4.length = 0;
gdjs.MainCode.GDSend_9595icon1Objects5.length = 0;
gdjs.MainCode.GDSend_9595icon1Objects6.length = 0;
gdjs.MainCode.GDSend_9595icon1Objects7.length = 0;
gdjs.MainCode.GDSend_9595icon1Objects8.length = 0;
gdjs.MainCode.GDSend_9595icon1Objects9.length = 0;
gdjs.MainCode.GDSend_9595icon1Objects10.length = 0;
gdjs.MainCode.GDblue_9595barsObjects1.length = 0;
gdjs.MainCode.GDblue_9595barsObjects2.length = 0;
gdjs.MainCode.GDblue_9595barsObjects3.length = 0;
gdjs.MainCode.GDblue_9595barsObjects4.length = 0;
gdjs.MainCode.GDblue_9595barsObjects5.length = 0;
gdjs.MainCode.GDblue_9595barsObjects6.length = 0;
gdjs.MainCode.GDblue_9595barsObjects7.length = 0;
gdjs.MainCode.GDblue_9595barsObjects8.length = 0;
gdjs.MainCode.GDblue_9595barsObjects9.length = 0;
gdjs.MainCode.GDblue_9595barsObjects10.length = 0;
gdjs.MainCode.GDGreen_9595barsObjects1.length = 0;
gdjs.MainCode.GDGreen_9595barsObjects2.length = 0;
gdjs.MainCode.GDGreen_9595barsObjects3.length = 0;
gdjs.MainCode.GDGreen_9595barsObjects4.length = 0;
gdjs.MainCode.GDGreen_9595barsObjects5.length = 0;
gdjs.MainCode.GDGreen_9595barsObjects6.length = 0;
gdjs.MainCode.GDGreen_9595barsObjects7.length = 0;
gdjs.MainCode.GDGreen_9595barsObjects8.length = 0;
gdjs.MainCode.GDGreen_9595barsObjects9.length = 0;
gdjs.MainCode.GDGreen_9595barsObjects10.length = 0;
gdjs.MainCode.GDOrange_9595barsObjects1.length = 0;
gdjs.MainCode.GDOrange_9595barsObjects2.length = 0;
gdjs.MainCode.GDOrange_9595barsObjects3.length = 0;
gdjs.MainCode.GDOrange_9595barsObjects4.length = 0;
gdjs.MainCode.GDOrange_9595barsObjects5.length = 0;
gdjs.MainCode.GDOrange_9595barsObjects6.length = 0;
gdjs.MainCode.GDOrange_9595barsObjects7.length = 0;
gdjs.MainCode.GDOrange_9595barsObjects8.length = 0;
gdjs.MainCode.GDOrange_9595barsObjects9.length = 0;
gdjs.MainCode.GDOrange_9595barsObjects10.length = 0;
gdjs.MainCode.GDPink_9595barsObjects1.length = 0;
gdjs.MainCode.GDPink_9595barsObjects2.length = 0;
gdjs.MainCode.GDPink_9595barsObjects3.length = 0;
gdjs.MainCode.GDPink_9595barsObjects4.length = 0;
gdjs.MainCode.GDPink_9595barsObjects5.length = 0;
gdjs.MainCode.GDPink_9595barsObjects6.length = 0;
gdjs.MainCode.GDPink_9595barsObjects7.length = 0;
gdjs.MainCode.GDPink_9595barsObjects8.length = 0;
gdjs.MainCode.GDPink_9595barsObjects9.length = 0;
gdjs.MainCode.GDPink_9595barsObjects10.length = 0;
gdjs.MainCode.GDEconomyTxtObjects1.length = 0;
gdjs.MainCode.GDEconomyTxtObjects2.length = 0;
gdjs.MainCode.GDEconomyTxtObjects3.length = 0;
gdjs.MainCode.GDEconomyTxtObjects4.length = 0;
gdjs.MainCode.GDEconomyTxtObjects5.length = 0;
gdjs.MainCode.GDEconomyTxtObjects6.length = 0;
gdjs.MainCode.GDEconomyTxtObjects7.length = 0;
gdjs.MainCode.GDEconomyTxtObjects8.length = 0;
gdjs.MainCode.GDEconomyTxtObjects9.length = 0;
gdjs.MainCode.GDEconomyTxtObjects10.length = 0;
gdjs.MainCode.GDPersonalGainsTxtObjects1.length = 0;
gdjs.MainCode.GDPersonalGainsTxtObjects2.length = 0;
gdjs.MainCode.GDPersonalGainsTxtObjects3.length = 0;
gdjs.MainCode.GDPersonalGainsTxtObjects4.length = 0;
gdjs.MainCode.GDPersonalGainsTxtObjects5.length = 0;
gdjs.MainCode.GDPersonalGainsTxtObjects6.length = 0;
gdjs.MainCode.GDPersonalGainsTxtObjects7.length = 0;
gdjs.MainCode.GDPersonalGainsTxtObjects8.length = 0;
gdjs.MainCode.GDPersonalGainsTxtObjects9.length = 0;
gdjs.MainCode.GDPersonalGainsTxtObjects10.length = 0;
gdjs.MainCode.GDScandalRiskTxtObjects1.length = 0;
gdjs.MainCode.GDScandalRiskTxtObjects2.length = 0;
gdjs.MainCode.GDScandalRiskTxtObjects3.length = 0;
gdjs.MainCode.GDScandalRiskTxtObjects4.length = 0;
gdjs.MainCode.GDScandalRiskTxtObjects5.length = 0;
gdjs.MainCode.GDScandalRiskTxtObjects6.length = 0;
gdjs.MainCode.GDScandalRiskTxtObjects7.length = 0;
gdjs.MainCode.GDScandalRiskTxtObjects8.length = 0;
gdjs.MainCode.GDScandalRiskTxtObjects9.length = 0;
gdjs.MainCode.GDScandalRiskTxtObjects10.length = 0;
gdjs.MainCode.GDPublicApprovalTxtObjects1.length = 0;
gdjs.MainCode.GDPublicApprovalTxtObjects2.length = 0;
gdjs.MainCode.GDPublicApprovalTxtObjects3.length = 0;
gdjs.MainCode.GDPublicApprovalTxtObjects4.length = 0;
gdjs.MainCode.GDPublicApprovalTxtObjects5.length = 0;
gdjs.MainCode.GDPublicApprovalTxtObjects6.length = 0;
gdjs.MainCode.GDPublicApprovalTxtObjects7.length = 0;
gdjs.MainCode.GDPublicApprovalTxtObjects8.length = 0;
gdjs.MainCode.GDPublicApprovalTxtObjects9.length = 0;
gdjs.MainCode.GDPublicApprovalTxtObjects10.length = 0;
gdjs.MainCode.GDCapObjects1.length = 0;
gdjs.MainCode.GDCapObjects2.length = 0;
gdjs.MainCode.GDCapObjects3.length = 0;
gdjs.MainCode.GDCapObjects4.length = 0;
gdjs.MainCode.GDCapObjects5.length = 0;
gdjs.MainCode.GDCapObjects6.length = 0;
gdjs.MainCode.GDCapObjects7.length = 0;
gdjs.MainCode.GDCapObjects8.length = 0;
gdjs.MainCode.GDCapObjects9.length = 0;
gdjs.MainCode.GDCapObjects10.length = 0;
gdjs.MainCode.GDCap_9595commentsObjects1.length = 0;
gdjs.MainCode.GDCap_9595commentsObjects2.length = 0;
gdjs.MainCode.GDCap_9595commentsObjects3.length = 0;
gdjs.MainCode.GDCap_9595commentsObjects4.length = 0;
gdjs.MainCode.GDCap_9595commentsObjects5.length = 0;
gdjs.MainCode.GDCap_9595commentsObjects6.length = 0;
gdjs.MainCode.GDCap_9595commentsObjects7.length = 0;
gdjs.MainCode.GDCap_9595commentsObjects8.length = 0;
gdjs.MainCode.GDCap_9595commentsObjects9.length = 0;
gdjs.MainCode.GDCap_9595commentsObjects10.length = 0;
gdjs.MainCode.GDDayTxtObjects1.length = 0;
gdjs.MainCode.GDDayTxtObjects2.length = 0;
gdjs.MainCode.GDDayTxtObjects3.length = 0;
gdjs.MainCode.GDDayTxtObjects4.length = 0;
gdjs.MainCode.GDDayTxtObjects5.length = 0;
gdjs.MainCode.GDDayTxtObjects6.length = 0;
gdjs.MainCode.GDDayTxtObjects7.length = 0;
gdjs.MainCode.GDDayTxtObjects8.length = 0;
gdjs.MainCode.GDDayTxtObjects9.length = 0;
gdjs.MainCode.GDDayTxtObjects10.length = 0;
gdjs.MainCode.GDChirpObjects1.length = 0;
gdjs.MainCode.GDChirpObjects2.length = 0;
gdjs.MainCode.GDChirpObjects3.length = 0;
gdjs.MainCode.GDChirpObjects4.length = 0;
gdjs.MainCode.GDChirpObjects5.length = 0;
gdjs.MainCode.GDChirpObjects6.length = 0;
gdjs.MainCode.GDChirpObjects7.length = 0;
gdjs.MainCode.GDChirpObjects8.length = 0;
gdjs.MainCode.GDChirpObjects9.length = 0;
gdjs.MainCode.GDChirpObjects10.length = 0;
gdjs.MainCode.GDMy_9595optionsObjects1.length = 0;
gdjs.MainCode.GDMy_9595optionsObjects2.length = 0;
gdjs.MainCode.GDMy_9595optionsObjects3.length = 0;
gdjs.MainCode.GDMy_9595optionsObjects4.length = 0;
gdjs.MainCode.GDMy_9595optionsObjects5.length = 0;
gdjs.MainCode.GDMy_9595optionsObjects6.length = 0;
gdjs.MainCode.GDMy_9595optionsObjects7.length = 0;
gdjs.MainCode.GDMy_9595optionsObjects8.length = 0;
gdjs.MainCode.GDMy_9595optionsObjects9.length = 0;
gdjs.MainCode.GDMy_9595optionsObjects10.length = 0;
gdjs.MainCode.GDCap_9595facesObjects1.length = 0;
gdjs.MainCode.GDCap_9595facesObjects2.length = 0;
gdjs.MainCode.GDCap_9595facesObjects3.length = 0;
gdjs.MainCode.GDCap_9595facesObjects4.length = 0;
gdjs.MainCode.GDCap_9595facesObjects5.length = 0;
gdjs.MainCode.GDCap_9595facesObjects6.length = 0;
gdjs.MainCode.GDCap_9595facesObjects7.length = 0;
gdjs.MainCode.GDCap_9595facesObjects8.length = 0;
gdjs.MainCode.GDCap_9595facesObjects9.length = 0;
gdjs.MainCode.GDCap_9595facesObjects10.length = 0;
gdjs.MainCode.GDSend_9595icon2Objects1.length = 0;
gdjs.MainCode.GDSend_9595icon2Objects2.length = 0;
gdjs.MainCode.GDSend_9595icon2Objects3.length = 0;
gdjs.MainCode.GDSend_9595icon2Objects4.length = 0;
gdjs.MainCode.GDSend_9595icon2Objects5.length = 0;
gdjs.MainCode.GDSend_9595icon2Objects6.length = 0;
gdjs.MainCode.GDSend_9595icon2Objects7.length = 0;
gdjs.MainCode.GDSend_9595icon2Objects8.length = 0;
gdjs.MainCode.GDSend_9595icon2Objects9.length = 0;
gdjs.MainCode.GDSend_9595icon2Objects10.length = 0;
gdjs.MainCode.GDSend_9595icon3Objects1.length = 0;
gdjs.MainCode.GDSend_9595icon3Objects2.length = 0;
gdjs.MainCode.GDSend_9595icon3Objects3.length = 0;
gdjs.MainCode.GDSend_9595icon3Objects4.length = 0;
gdjs.MainCode.GDSend_9595icon3Objects5.length = 0;
gdjs.MainCode.GDSend_9595icon3Objects6.length = 0;
gdjs.MainCode.GDSend_9595icon3Objects7.length = 0;
gdjs.MainCode.GDSend_9595icon3Objects8.length = 0;
gdjs.MainCode.GDSend_9595icon3Objects9.length = 0;
gdjs.MainCode.GDSend_9595icon3Objects10.length = 0;
gdjs.MainCode.GDTweetFace2Objects1.length = 0;
gdjs.MainCode.GDTweetFace2Objects2.length = 0;
gdjs.MainCode.GDTweetFace2Objects3.length = 0;
gdjs.MainCode.GDTweetFace2Objects4.length = 0;
gdjs.MainCode.GDTweetFace2Objects5.length = 0;
gdjs.MainCode.GDTweetFace2Objects6.length = 0;
gdjs.MainCode.GDTweetFace2Objects7.length = 0;
gdjs.MainCode.GDTweetFace2Objects8.length = 0;
gdjs.MainCode.GDTweetFace2Objects9.length = 0;
gdjs.MainCode.GDTweetFace2Objects10.length = 0;
gdjs.MainCode.GDTweetFace1Objects1.length = 0;
gdjs.MainCode.GDTweetFace1Objects2.length = 0;
gdjs.MainCode.GDTweetFace1Objects3.length = 0;
gdjs.MainCode.GDTweetFace1Objects4.length = 0;
gdjs.MainCode.GDTweetFace1Objects5.length = 0;
gdjs.MainCode.GDTweetFace1Objects6.length = 0;
gdjs.MainCode.GDTweetFace1Objects7.length = 0;
gdjs.MainCode.GDTweetFace1Objects8.length = 0;
gdjs.MainCode.GDTweetFace1Objects9.length = 0;
gdjs.MainCode.GDTweetFace1Objects10.length = 0;
gdjs.MainCode.GDLayoutObjects1.length = 0;
gdjs.MainCode.GDLayoutObjects2.length = 0;
gdjs.MainCode.GDLayoutObjects3.length = 0;
gdjs.MainCode.GDLayoutObjects4.length = 0;
gdjs.MainCode.GDLayoutObjects5.length = 0;
gdjs.MainCode.GDLayoutObjects6.length = 0;
gdjs.MainCode.GDLayoutObjects7.length = 0;
gdjs.MainCode.GDLayoutObjects8.length = 0;
gdjs.MainCode.GDLayoutObjects9.length = 0;
gdjs.MainCode.GDLayoutObjects10.length = 0;
gdjs.MainCode.GDTweetMarker1Objects1.length = 0;
gdjs.MainCode.GDTweetMarker1Objects2.length = 0;
gdjs.MainCode.GDTweetMarker1Objects3.length = 0;
gdjs.MainCode.GDTweetMarker1Objects4.length = 0;
gdjs.MainCode.GDTweetMarker1Objects5.length = 0;
gdjs.MainCode.GDTweetMarker1Objects6.length = 0;
gdjs.MainCode.GDTweetMarker1Objects7.length = 0;
gdjs.MainCode.GDTweetMarker1Objects8.length = 0;
gdjs.MainCode.GDTweetMarker1Objects9.length = 0;
gdjs.MainCode.GDTweetMarker1Objects10.length = 0;
gdjs.MainCode.GDTweetMarker2Objects1.length = 0;
gdjs.MainCode.GDTweetMarker2Objects2.length = 0;
gdjs.MainCode.GDTweetMarker2Objects3.length = 0;
gdjs.MainCode.GDTweetMarker2Objects4.length = 0;
gdjs.MainCode.GDTweetMarker2Objects5.length = 0;
gdjs.MainCode.GDTweetMarker2Objects6.length = 0;
gdjs.MainCode.GDTweetMarker2Objects7.length = 0;
gdjs.MainCode.GDTweetMarker2Objects8.length = 0;
gdjs.MainCode.GDTweetMarker2Objects9.length = 0;
gdjs.MainCode.GDTweetMarker2Objects10.length = 0;
gdjs.MainCode.GDTweetMarker3Objects1.length = 0;
gdjs.MainCode.GDTweetMarker3Objects2.length = 0;
gdjs.MainCode.GDTweetMarker3Objects3.length = 0;
gdjs.MainCode.GDTweetMarker3Objects4.length = 0;
gdjs.MainCode.GDTweetMarker3Objects5.length = 0;
gdjs.MainCode.GDTweetMarker3Objects6.length = 0;
gdjs.MainCode.GDTweetMarker3Objects7.length = 0;
gdjs.MainCode.GDTweetMarker3Objects8.length = 0;
gdjs.MainCode.GDTweetMarker3Objects9.length = 0;
gdjs.MainCode.GDTweetMarker3Objects10.length = 0;
gdjs.MainCode.GDTweetMarker4Objects1.length = 0;
gdjs.MainCode.GDTweetMarker4Objects2.length = 0;
gdjs.MainCode.GDTweetMarker4Objects3.length = 0;
gdjs.MainCode.GDTweetMarker4Objects4.length = 0;
gdjs.MainCode.GDTweetMarker4Objects5.length = 0;
gdjs.MainCode.GDTweetMarker4Objects6.length = 0;
gdjs.MainCode.GDTweetMarker4Objects7.length = 0;
gdjs.MainCode.GDTweetMarker4Objects8.length = 0;
gdjs.MainCode.GDTweetMarker4Objects9.length = 0;
gdjs.MainCode.GDTweetMarker4Objects10.length = 0;
gdjs.MainCode.GDTweetMarker5Objects1.length = 0;
gdjs.MainCode.GDTweetMarker5Objects2.length = 0;
gdjs.MainCode.GDTweetMarker5Objects3.length = 0;
gdjs.MainCode.GDTweetMarker5Objects4.length = 0;
gdjs.MainCode.GDTweetMarker5Objects5.length = 0;
gdjs.MainCode.GDTweetMarker5Objects6.length = 0;
gdjs.MainCode.GDTweetMarker5Objects7.length = 0;
gdjs.MainCode.GDTweetMarker5Objects8.length = 0;
gdjs.MainCode.GDTweetMarker5Objects9.length = 0;
gdjs.MainCode.GDTweetMarker5Objects10.length = 0;
gdjs.MainCode.GDTweetMarker6Objects1.length = 0;
gdjs.MainCode.GDTweetMarker6Objects2.length = 0;
gdjs.MainCode.GDTweetMarker6Objects3.length = 0;
gdjs.MainCode.GDTweetMarker6Objects4.length = 0;
gdjs.MainCode.GDTweetMarker6Objects5.length = 0;
gdjs.MainCode.GDTweetMarker6Objects6.length = 0;
gdjs.MainCode.GDTweetMarker6Objects7.length = 0;
gdjs.MainCode.GDTweetMarker6Objects8.length = 0;
gdjs.MainCode.GDTweetMarker6Objects9.length = 0;
gdjs.MainCode.GDTweetMarker6Objects10.length = 0;
gdjs.MainCode.GDTweetMarker7Objects1.length = 0;
gdjs.MainCode.GDTweetMarker7Objects2.length = 0;
gdjs.MainCode.GDTweetMarker7Objects3.length = 0;
gdjs.MainCode.GDTweetMarker7Objects4.length = 0;
gdjs.MainCode.GDTweetMarker7Objects5.length = 0;
gdjs.MainCode.GDTweetMarker7Objects6.length = 0;
gdjs.MainCode.GDTweetMarker7Objects7.length = 0;
gdjs.MainCode.GDTweetMarker7Objects8.length = 0;
gdjs.MainCode.GDTweetMarker7Objects9.length = 0;
gdjs.MainCode.GDTweetMarker7Objects10.length = 0;
gdjs.MainCode.GDTweet_9595bkg2Objects1.length = 0;
gdjs.MainCode.GDTweet_9595bkg2Objects2.length = 0;
gdjs.MainCode.GDTweet_9595bkg2Objects3.length = 0;
gdjs.MainCode.GDTweet_9595bkg2Objects4.length = 0;
gdjs.MainCode.GDTweet_9595bkg2Objects5.length = 0;
gdjs.MainCode.GDTweet_9595bkg2Objects6.length = 0;
gdjs.MainCode.GDTweet_9595bkg2Objects7.length = 0;
gdjs.MainCode.GDTweet_9595bkg2Objects8.length = 0;
gdjs.MainCode.GDTweet_9595bkg2Objects9.length = 0;
gdjs.MainCode.GDTweet_9595bkg2Objects10.length = 0;
gdjs.MainCode.GDTweet_9595bkg3Objects1.length = 0;
gdjs.MainCode.GDTweet_9595bkg3Objects2.length = 0;
gdjs.MainCode.GDTweet_9595bkg3Objects3.length = 0;
gdjs.MainCode.GDTweet_9595bkg3Objects4.length = 0;
gdjs.MainCode.GDTweet_9595bkg3Objects5.length = 0;
gdjs.MainCode.GDTweet_9595bkg3Objects6.length = 0;
gdjs.MainCode.GDTweet_9595bkg3Objects7.length = 0;
gdjs.MainCode.GDTweet_9595bkg3Objects8.length = 0;
gdjs.MainCode.GDTweet_9595bkg3Objects9.length = 0;
gdjs.MainCode.GDTweet_9595bkg3Objects10.length = 0;
gdjs.MainCode.GDTweet_9595bkg4Objects1.length = 0;
gdjs.MainCode.GDTweet_9595bkg4Objects2.length = 0;
gdjs.MainCode.GDTweet_9595bkg4Objects3.length = 0;
gdjs.MainCode.GDTweet_9595bkg4Objects4.length = 0;
gdjs.MainCode.GDTweet_9595bkg4Objects5.length = 0;
gdjs.MainCode.GDTweet_9595bkg4Objects6.length = 0;
gdjs.MainCode.GDTweet_9595bkg4Objects7.length = 0;
gdjs.MainCode.GDTweet_9595bkg4Objects8.length = 0;
gdjs.MainCode.GDTweet_9595bkg4Objects9.length = 0;
gdjs.MainCode.GDTweet_9595bkg4Objects10.length = 0;
gdjs.MainCode.GDTweet_9595bkg5Objects1.length = 0;
gdjs.MainCode.GDTweet_9595bkg5Objects2.length = 0;
gdjs.MainCode.GDTweet_9595bkg5Objects3.length = 0;
gdjs.MainCode.GDTweet_9595bkg5Objects4.length = 0;
gdjs.MainCode.GDTweet_9595bkg5Objects5.length = 0;
gdjs.MainCode.GDTweet_9595bkg5Objects6.length = 0;
gdjs.MainCode.GDTweet_9595bkg5Objects7.length = 0;
gdjs.MainCode.GDTweet_9595bkg5Objects8.length = 0;
gdjs.MainCode.GDTweet_9595bkg5Objects9.length = 0;
gdjs.MainCode.GDTweet_9595bkg5Objects10.length = 0;
gdjs.MainCode.GDTweet_9595bkg6Objects1.length = 0;
gdjs.MainCode.GDTweet_9595bkg6Objects2.length = 0;
gdjs.MainCode.GDTweet_9595bkg6Objects3.length = 0;
gdjs.MainCode.GDTweet_9595bkg6Objects4.length = 0;
gdjs.MainCode.GDTweet_9595bkg6Objects5.length = 0;
gdjs.MainCode.GDTweet_9595bkg6Objects6.length = 0;
gdjs.MainCode.GDTweet_9595bkg6Objects7.length = 0;
gdjs.MainCode.GDTweet_9595bkg6Objects8.length = 0;
gdjs.MainCode.GDTweet_9595bkg6Objects9.length = 0;
gdjs.MainCode.GDTweet_9595bkg6Objects10.length = 0;
gdjs.MainCode.GDTweetMarker8Objects1.length = 0;
gdjs.MainCode.GDTweetMarker8Objects2.length = 0;
gdjs.MainCode.GDTweetMarker8Objects3.length = 0;
gdjs.MainCode.GDTweetMarker8Objects4.length = 0;
gdjs.MainCode.GDTweetMarker8Objects5.length = 0;
gdjs.MainCode.GDTweetMarker8Objects6.length = 0;
gdjs.MainCode.GDTweetMarker8Objects7.length = 0;
gdjs.MainCode.GDTweetMarker8Objects8.length = 0;
gdjs.MainCode.GDTweetMarker8Objects9.length = 0;
gdjs.MainCode.GDTweetMarker8Objects10.length = 0;
gdjs.MainCode.GDFireText4Objects1.length = 0;
gdjs.MainCode.GDFireText4Objects2.length = 0;
gdjs.MainCode.GDFireText4Objects3.length = 0;
gdjs.MainCode.GDFireText4Objects4.length = 0;
gdjs.MainCode.GDFireText4Objects5.length = 0;
gdjs.MainCode.GDFireText4Objects6.length = 0;
gdjs.MainCode.GDFireText4Objects7.length = 0;
gdjs.MainCode.GDFireText4Objects8.length = 0;
gdjs.MainCode.GDFireText4Objects9.length = 0;
gdjs.MainCode.GDFireText4Objects10.length = 0;
gdjs.MainCode.GDFireText5Objects1.length = 0;
gdjs.MainCode.GDFireText5Objects2.length = 0;
gdjs.MainCode.GDFireText5Objects3.length = 0;
gdjs.MainCode.GDFireText5Objects4.length = 0;
gdjs.MainCode.GDFireText5Objects5.length = 0;
gdjs.MainCode.GDFireText5Objects6.length = 0;
gdjs.MainCode.GDFireText5Objects7.length = 0;
gdjs.MainCode.GDFireText5Objects8.length = 0;
gdjs.MainCode.GDFireText5Objects9.length = 0;
gdjs.MainCode.GDFireText5Objects10.length = 0;
gdjs.MainCode.GDFireText6Objects1.length = 0;
gdjs.MainCode.GDFireText6Objects2.length = 0;
gdjs.MainCode.GDFireText6Objects3.length = 0;
gdjs.MainCode.GDFireText6Objects4.length = 0;
gdjs.MainCode.GDFireText6Objects5.length = 0;
gdjs.MainCode.GDFireText6Objects6.length = 0;
gdjs.MainCode.GDFireText6Objects7.length = 0;
gdjs.MainCode.GDFireText6Objects8.length = 0;
gdjs.MainCode.GDFireText6Objects9.length = 0;
gdjs.MainCode.GDFireText6Objects10.length = 0;
gdjs.MainCode.GDLikeText4Objects1.length = 0;
gdjs.MainCode.GDLikeText4Objects2.length = 0;
gdjs.MainCode.GDLikeText4Objects3.length = 0;
gdjs.MainCode.GDLikeText4Objects4.length = 0;
gdjs.MainCode.GDLikeText4Objects5.length = 0;
gdjs.MainCode.GDLikeText4Objects6.length = 0;
gdjs.MainCode.GDLikeText4Objects7.length = 0;
gdjs.MainCode.GDLikeText4Objects8.length = 0;
gdjs.MainCode.GDLikeText4Objects9.length = 0;
gdjs.MainCode.GDLikeText4Objects10.length = 0;
gdjs.MainCode.GDLikeText5Objects1.length = 0;
gdjs.MainCode.GDLikeText5Objects2.length = 0;
gdjs.MainCode.GDLikeText5Objects3.length = 0;
gdjs.MainCode.GDLikeText5Objects4.length = 0;
gdjs.MainCode.GDLikeText5Objects5.length = 0;
gdjs.MainCode.GDLikeText5Objects6.length = 0;
gdjs.MainCode.GDLikeText5Objects7.length = 0;
gdjs.MainCode.GDLikeText5Objects8.length = 0;
gdjs.MainCode.GDLikeText5Objects9.length = 0;
gdjs.MainCode.GDLikeText5Objects10.length = 0;
gdjs.MainCode.GDLikeText6Objects1.length = 0;
gdjs.MainCode.GDLikeText6Objects2.length = 0;
gdjs.MainCode.GDLikeText6Objects3.length = 0;
gdjs.MainCode.GDLikeText6Objects4.length = 0;
gdjs.MainCode.GDLikeText6Objects5.length = 0;
gdjs.MainCode.GDLikeText6Objects6.length = 0;
gdjs.MainCode.GDLikeText6Objects7.length = 0;
gdjs.MainCode.GDLikeText6Objects8.length = 0;
gdjs.MainCode.GDLikeText6Objects9.length = 0;
gdjs.MainCode.GDLikeText6Objects10.length = 0;
gdjs.MainCode.GDHeartText4Objects1.length = 0;
gdjs.MainCode.GDHeartText4Objects2.length = 0;
gdjs.MainCode.GDHeartText4Objects3.length = 0;
gdjs.MainCode.GDHeartText4Objects4.length = 0;
gdjs.MainCode.GDHeartText4Objects5.length = 0;
gdjs.MainCode.GDHeartText4Objects6.length = 0;
gdjs.MainCode.GDHeartText4Objects7.length = 0;
gdjs.MainCode.GDHeartText4Objects8.length = 0;
gdjs.MainCode.GDHeartText4Objects9.length = 0;
gdjs.MainCode.GDHeartText4Objects10.length = 0;
gdjs.MainCode.GDHeartText5Objects1.length = 0;
gdjs.MainCode.GDHeartText5Objects2.length = 0;
gdjs.MainCode.GDHeartText5Objects3.length = 0;
gdjs.MainCode.GDHeartText5Objects4.length = 0;
gdjs.MainCode.GDHeartText5Objects5.length = 0;
gdjs.MainCode.GDHeartText5Objects6.length = 0;
gdjs.MainCode.GDHeartText5Objects7.length = 0;
gdjs.MainCode.GDHeartText5Objects8.length = 0;
gdjs.MainCode.GDHeartText5Objects9.length = 0;
gdjs.MainCode.GDHeartText5Objects10.length = 0;
gdjs.MainCode.GDHeartText6Objects1.length = 0;
gdjs.MainCode.GDHeartText6Objects2.length = 0;
gdjs.MainCode.GDHeartText6Objects3.length = 0;
gdjs.MainCode.GDHeartText6Objects4.length = 0;
gdjs.MainCode.GDHeartText6Objects5.length = 0;
gdjs.MainCode.GDHeartText6Objects6.length = 0;
gdjs.MainCode.GDHeartText6Objects7.length = 0;
gdjs.MainCode.GDHeartText6Objects8.length = 0;
gdjs.MainCode.GDHeartText6Objects9.length = 0;
gdjs.MainCode.GDHeartText6Objects10.length = 0;
gdjs.MainCode.GDTweetFace4Objects1.length = 0;
gdjs.MainCode.GDTweetFace4Objects2.length = 0;
gdjs.MainCode.GDTweetFace4Objects3.length = 0;
gdjs.MainCode.GDTweetFace4Objects4.length = 0;
gdjs.MainCode.GDTweetFace4Objects5.length = 0;
gdjs.MainCode.GDTweetFace4Objects6.length = 0;
gdjs.MainCode.GDTweetFace4Objects7.length = 0;
gdjs.MainCode.GDTweetFace4Objects8.length = 0;
gdjs.MainCode.GDTweetFace4Objects9.length = 0;
gdjs.MainCode.GDTweetFace4Objects10.length = 0;
gdjs.MainCode.GDTweetFace5Objects1.length = 0;
gdjs.MainCode.GDTweetFace5Objects2.length = 0;
gdjs.MainCode.GDTweetFace5Objects3.length = 0;
gdjs.MainCode.GDTweetFace5Objects4.length = 0;
gdjs.MainCode.GDTweetFace5Objects5.length = 0;
gdjs.MainCode.GDTweetFace5Objects6.length = 0;
gdjs.MainCode.GDTweetFace5Objects7.length = 0;
gdjs.MainCode.GDTweetFace5Objects8.length = 0;
gdjs.MainCode.GDTweetFace5Objects9.length = 0;
gdjs.MainCode.GDTweetFace5Objects10.length = 0;
gdjs.MainCode.GDTweetFace6Objects1.length = 0;
gdjs.MainCode.GDTweetFace6Objects2.length = 0;
gdjs.MainCode.GDTweetFace6Objects3.length = 0;
gdjs.MainCode.GDTweetFace6Objects4.length = 0;
gdjs.MainCode.GDTweetFace6Objects5.length = 0;
gdjs.MainCode.GDTweetFace6Objects6.length = 0;
gdjs.MainCode.GDTweetFace6Objects7.length = 0;
gdjs.MainCode.GDTweetFace6Objects8.length = 0;
gdjs.MainCode.GDTweetFace6Objects9.length = 0;
gdjs.MainCode.GDTweetFace6Objects10.length = 0;
gdjs.MainCode.GDTweetTitle4Objects1.length = 0;
gdjs.MainCode.GDTweetTitle4Objects2.length = 0;
gdjs.MainCode.GDTweetTitle4Objects3.length = 0;
gdjs.MainCode.GDTweetTitle4Objects4.length = 0;
gdjs.MainCode.GDTweetTitle4Objects5.length = 0;
gdjs.MainCode.GDTweetTitle4Objects6.length = 0;
gdjs.MainCode.GDTweetTitle4Objects7.length = 0;
gdjs.MainCode.GDTweetTitle4Objects8.length = 0;
gdjs.MainCode.GDTweetTitle4Objects9.length = 0;
gdjs.MainCode.GDTweetTitle4Objects10.length = 0;
gdjs.MainCode.GDTweetTitle5Objects1.length = 0;
gdjs.MainCode.GDTweetTitle5Objects2.length = 0;
gdjs.MainCode.GDTweetTitle5Objects3.length = 0;
gdjs.MainCode.GDTweetTitle5Objects4.length = 0;
gdjs.MainCode.GDTweetTitle5Objects5.length = 0;
gdjs.MainCode.GDTweetTitle5Objects6.length = 0;
gdjs.MainCode.GDTweetTitle5Objects7.length = 0;
gdjs.MainCode.GDTweetTitle5Objects8.length = 0;
gdjs.MainCode.GDTweetTitle5Objects9.length = 0;
gdjs.MainCode.GDTweetTitle5Objects10.length = 0;
gdjs.MainCode.GDTweetTitle6Objects1.length = 0;
gdjs.MainCode.GDTweetTitle6Objects2.length = 0;
gdjs.MainCode.GDTweetTitle6Objects3.length = 0;
gdjs.MainCode.GDTweetTitle6Objects4.length = 0;
gdjs.MainCode.GDTweetTitle6Objects5.length = 0;
gdjs.MainCode.GDTweetTitle6Objects6.length = 0;
gdjs.MainCode.GDTweetTitle6Objects7.length = 0;
gdjs.MainCode.GDTweetTitle6Objects8.length = 0;
gdjs.MainCode.GDTweetTitle6Objects9.length = 0;
gdjs.MainCode.GDTweetTitle6Objects10.length = 0;
gdjs.MainCode.GDTweet4Objects1.length = 0;
gdjs.MainCode.GDTweet4Objects2.length = 0;
gdjs.MainCode.GDTweet4Objects3.length = 0;
gdjs.MainCode.GDTweet4Objects4.length = 0;
gdjs.MainCode.GDTweet4Objects5.length = 0;
gdjs.MainCode.GDTweet4Objects6.length = 0;
gdjs.MainCode.GDTweet4Objects7.length = 0;
gdjs.MainCode.GDTweet4Objects8.length = 0;
gdjs.MainCode.GDTweet4Objects9.length = 0;
gdjs.MainCode.GDTweet4Objects10.length = 0;
gdjs.MainCode.GDTweet5Objects1.length = 0;
gdjs.MainCode.GDTweet5Objects2.length = 0;
gdjs.MainCode.GDTweet5Objects3.length = 0;
gdjs.MainCode.GDTweet5Objects4.length = 0;
gdjs.MainCode.GDTweet5Objects5.length = 0;
gdjs.MainCode.GDTweet5Objects6.length = 0;
gdjs.MainCode.GDTweet5Objects7.length = 0;
gdjs.MainCode.GDTweet5Objects8.length = 0;
gdjs.MainCode.GDTweet5Objects9.length = 0;
gdjs.MainCode.GDTweet5Objects10.length = 0;
gdjs.MainCode.GDTweet6Objects1.length = 0;
gdjs.MainCode.GDTweet6Objects2.length = 0;
gdjs.MainCode.GDTweet6Objects3.length = 0;
gdjs.MainCode.GDTweet6Objects4.length = 0;
gdjs.MainCode.GDTweet6Objects5.length = 0;
gdjs.MainCode.GDTweet6Objects6.length = 0;
gdjs.MainCode.GDTweet6Objects7.length = 0;
gdjs.MainCode.GDTweet6Objects8.length = 0;
gdjs.MainCode.GDTweet6Objects9.length = 0;
gdjs.MainCode.GDTweet6Objects10.length = 0;
gdjs.MainCode.GDBars_9595cover_9595blueObjects1.length = 0;
gdjs.MainCode.GDBars_9595cover_9595blueObjects2.length = 0;
gdjs.MainCode.GDBars_9595cover_9595blueObjects3.length = 0;
gdjs.MainCode.GDBars_9595cover_9595blueObjects4.length = 0;
gdjs.MainCode.GDBars_9595cover_9595blueObjects5.length = 0;
gdjs.MainCode.GDBars_9595cover_9595blueObjects6.length = 0;
gdjs.MainCode.GDBars_9595cover_9595blueObjects7.length = 0;
gdjs.MainCode.GDBars_9595cover_9595blueObjects8.length = 0;
gdjs.MainCode.GDBars_9595cover_9595blueObjects9.length = 0;
gdjs.MainCode.GDBars_9595cover_9595blueObjects10.length = 0;
gdjs.MainCode.GDBars_9595cover_9595greenObjects1.length = 0;
gdjs.MainCode.GDBars_9595cover_9595greenObjects2.length = 0;
gdjs.MainCode.GDBars_9595cover_9595greenObjects3.length = 0;
gdjs.MainCode.GDBars_9595cover_9595greenObjects4.length = 0;
gdjs.MainCode.GDBars_9595cover_9595greenObjects5.length = 0;
gdjs.MainCode.GDBars_9595cover_9595greenObjects6.length = 0;
gdjs.MainCode.GDBars_9595cover_9595greenObjects7.length = 0;
gdjs.MainCode.GDBars_9595cover_9595greenObjects8.length = 0;
gdjs.MainCode.GDBars_9595cover_9595greenObjects9.length = 0;
gdjs.MainCode.GDBars_9595cover_9595greenObjects10.length = 0;
gdjs.MainCode.GDBars_9595cover_9595orangeObjects1.length = 0;
gdjs.MainCode.GDBars_9595cover_9595orangeObjects2.length = 0;
gdjs.MainCode.GDBars_9595cover_9595orangeObjects3.length = 0;
gdjs.MainCode.GDBars_9595cover_9595orangeObjects4.length = 0;
gdjs.MainCode.GDBars_9595cover_9595orangeObjects5.length = 0;
gdjs.MainCode.GDBars_9595cover_9595orangeObjects6.length = 0;
gdjs.MainCode.GDBars_9595cover_9595orangeObjects7.length = 0;
gdjs.MainCode.GDBars_9595cover_9595orangeObjects8.length = 0;
gdjs.MainCode.GDBars_9595cover_9595orangeObjects9.length = 0;
gdjs.MainCode.GDBars_9595cover_9595orangeObjects10.length = 0;
gdjs.MainCode.GDBars_9595cover_9595pinkObjects1.length = 0;
gdjs.MainCode.GDBars_9595cover_9595pinkObjects2.length = 0;
gdjs.MainCode.GDBars_9595cover_9595pinkObjects3.length = 0;
gdjs.MainCode.GDBars_9595cover_9595pinkObjects4.length = 0;
gdjs.MainCode.GDBars_9595cover_9595pinkObjects5.length = 0;
gdjs.MainCode.GDBars_9595cover_9595pinkObjects6.length = 0;
gdjs.MainCode.GDBars_9595cover_9595pinkObjects7.length = 0;
gdjs.MainCode.GDBars_9595cover_9595pinkObjects8.length = 0;
gdjs.MainCode.GDBars_9595cover_9595pinkObjects9.length = 0;
gdjs.MainCode.GDBars_9595cover_9595pinkObjects10.length = 0;
gdjs.MainCode.GDTestTextObjects1.length = 0;
gdjs.MainCode.GDTestTextObjects2.length = 0;
gdjs.MainCode.GDTestTextObjects3.length = 0;
gdjs.MainCode.GDTestTextObjects4.length = 0;
gdjs.MainCode.GDTestTextObjects5.length = 0;
gdjs.MainCode.GDTestTextObjects6.length = 0;
gdjs.MainCode.GDTestTextObjects7.length = 0;
gdjs.MainCode.GDTestTextObjects8.length = 0;
gdjs.MainCode.GDTestTextObjects9.length = 0;
gdjs.MainCode.GDTestTextObjects10.length = 0;
gdjs.MainCode.GDTestText2Objects1.length = 0;
gdjs.MainCode.GDTestText2Objects2.length = 0;
gdjs.MainCode.GDTestText2Objects3.length = 0;
gdjs.MainCode.GDTestText2Objects4.length = 0;
gdjs.MainCode.GDTestText2Objects5.length = 0;
gdjs.MainCode.GDTestText2Objects6.length = 0;
gdjs.MainCode.GDTestText2Objects7.length = 0;
gdjs.MainCode.GDTestText2Objects8.length = 0;
gdjs.MainCode.GDTestText2Objects9.length = 0;
gdjs.MainCode.GDTestText2Objects10.length = 0;
gdjs.MainCode.GDBlackScreenObjects1.length = 0;
gdjs.MainCode.GDBlackScreenObjects2.length = 0;
gdjs.MainCode.GDBlackScreenObjects3.length = 0;
gdjs.MainCode.GDBlackScreenObjects4.length = 0;
gdjs.MainCode.GDBlackScreenObjects5.length = 0;
gdjs.MainCode.GDBlackScreenObjects6.length = 0;
gdjs.MainCode.GDBlackScreenObjects7.length = 0;
gdjs.MainCode.GDBlackScreenObjects8.length = 0;
gdjs.MainCode.GDBlackScreenObjects9.length = 0;
gdjs.MainCode.GDBlackScreenObjects10.length = 0;
gdjs.MainCode.GDBlackScreenTextObjects1.length = 0;
gdjs.MainCode.GDBlackScreenTextObjects2.length = 0;
gdjs.MainCode.GDBlackScreenTextObjects3.length = 0;
gdjs.MainCode.GDBlackScreenTextObjects4.length = 0;
gdjs.MainCode.GDBlackScreenTextObjects5.length = 0;
gdjs.MainCode.GDBlackScreenTextObjects6.length = 0;
gdjs.MainCode.GDBlackScreenTextObjects7.length = 0;
gdjs.MainCode.GDBlackScreenTextObjects8.length = 0;
gdjs.MainCode.GDBlackScreenTextObjects9.length = 0;
gdjs.MainCode.GDBlackScreenTextObjects10.length = 0;
gdjs.MainCode.GDLayout_9595maskObjects1.length = 0;
gdjs.MainCode.GDLayout_9595maskObjects2.length = 0;
gdjs.MainCode.GDLayout_9595maskObjects3.length = 0;
gdjs.MainCode.GDLayout_9595maskObjects4.length = 0;
gdjs.MainCode.GDLayout_9595maskObjects5.length = 0;
gdjs.MainCode.GDLayout_9595maskObjects6.length = 0;
gdjs.MainCode.GDLayout_9595maskObjects7.length = 0;
gdjs.MainCode.GDLayout_9595maskObjects8.length = 0;
gdjs.MainCode.GDLayout_9595maskObjects9.length = 0;
gdjs.MainCode.GDLayout_9595maskObjects10.length = 0;
gdjs.MainCode.GDEconomyResultObjects1.length = 0;
gdjs.MainCode.GDEconomyResultObjects2.length = 0;
gdjs.MainCode.GDEconomyResultObjects3.length = 0;
gdjs.MainCode.GDEconomyResultObjects4.length = 0;
gdjs.MainCode.GDEconomyResultObjects5.length = 0;
gdjs.MainCode.GDEconomyResultObjects6.length = 0;
gdjs.MainCode.GDEconomyResultObjects7.length = 0;
gdjs.MainCode.GDEconomyResultObjects8.length = 0;
gdjs.MainCode.GDEconomyResultObjects9.length = 0;
gdjs.MainCode.GDEconomyResultObjects10.length = 0;
gdjs.MainCode.GDPAResultObjects1.length = 0;
gdjs.MainCode.GDPAResultObjects2.length = 0;
gdjs.MainCode.GDPAResultObjects3.length = 0;
gdjs.MainCode.GDPAResultObjects4.length = 0;
gdjs.MainCode.GDPAResultObjects5.length = 0;
gdjs.MainCode.GDPAResultObjects6.length = 0;
gdjs.MainCode.GDPAResultObjects7.length = 0;
gdjs.MainCode.GDPAResultObjects8.length = 0;
gdjs.MainCode.GDPAResultObjects9.length = 0;
gdjs.MainCode.GDPAResultObjects10.length = 0;
gdjs.MainCode.GDRiskResultObjects1.length = 0;
gdjs.MainCode.GDRiskResultObjects2.length = 0;
gdjs.MainCode.GDRiskResultObjects3.length = 0;
gdjs.MainCode.GDRiskResultObjects4.length = 0;
gdjs.MainCode.GDRiskResultObjects5.length = 0;
gdjs.MainCode.GDRiskResultObjects6.length = 0;
gdjs.MainCode.GDRiskResultObjects7.length = 0;
gdjs.MainCode.GDRiskResultObjects8.length = 0;
gdjs.MainCode.GDRiskResultObjects9.length = 0;
gdjs.MainCode.GDRiskResultObjects10.length = 0;
gdjs.MainCode.GDPersonalWealthResultObjects1.length = 0;
gdjs.MainCode.GDPersonalWealthResultObjects2.length = 0;
gdjs.MainCode.GDPersonalWealthResultObjects3.length = 0;
gdjs.MainCode.GDPersonalWealthResultObjects4.length = 0;
gdjs.MainCode.GDPersonalWealthResultObjects5.length = 0;
gdjs.MainCode.GDPersonalWealthResultObjects6.length = 0;
gdjs.MainCode.GDPersonalWealthResultObjects7.length = 0;
gdjs.MainCode.GDPersonalWealthResultObjects8.length = 0;
gdjs.MainCode.GDPersonalWealthResultObjects9.length = 0;
gdjs.MainCode.GDPersonalWealthResultObjects10.length = 0;
gdjs.MainCode.GDNext_9595buttonObjects1.length = 0;
gdjs.MainCode.GDNext_9595buttonObjects2.length = 0;
gdjs.MainCode.GDNext_9595buttonObjects3.length = 0;
gdjs.MainCode.GDNext_9595buttonObjects4.length = 0;
gdjs.MainCode.GDNext_9595buttonObjects5.length = 0;
gdjs.MainCode.GDNext_9595buttonObjects6.length = 0;
gdjs.MainCode.GDNext_9595buttonObjects7.length = 0;
gdjs.MainCode.GDNext_9595buttonObjects8.length = 0;
gdjs.MainCode.GDNext_9595buttonObjects9.length = 0;
gdjs.MainCode.GDNext_9595buttonObjects10.length = 0;
gdjs.MainCode.GDNextTextObjects1.length = 0;
gdjs.MainCode.GDNextTextObjects2.length = 0;
gdjs.MainCode.GDNextTextObjects3.length = 0;
gdjs.MainCode.GDNextTextObjects4.length = 0;
gdjs.MainCode.GDNextTextObjects5.length = 0;
gdjs.MainCode.GDNextTextObjects6.length = 0;
gdjs.MainCode.GDNextTextObjects7.length = 0;
gdjs.MainCode.GDNextTextObjects8.length = 0;
gdjs.MainCode.GDNextTextObjects9.length = 0;
gdjs.MainCode.GDNextTextObjects10.length = 0;
gdjs.MainCode.GDSoundToggleObjects1.length = 0;
gdjs.MainCode.GDSoundToggleObjects2.length = 0;
gdjs.MainCode.GDSoundToggleObjects3.length = 0;
gdjs.MainCode.GDSoundToggleObjects4.length = 0;
gdjs.MainCode.GDSoundToggleObjects5.length = 0;
gdjs.MainCode.GDSoundToggleObjects6.length = 0;
gdjs.MainCode.GDSoundToggleObjects7.length = 0;
gdjs.MainCode.GDSoundToggleObjects8.length = 0;
gdjs.MainCode.GDSoundToggleObjects9.length = 0;
gdjs.MainCode.GDSoundToggleObjects10.length = 0;
gdjs.MainCode.GDSkipTutorialObjects1.length = 0;
gdjs.MainCode.GDSkipTutorialObjects2.length = 0;
gdjs.MainCode.GDSkipTutorialObjects3.length = 0;
gdjs.MainCode.GDSkipTutorialObjects4.length = 0;
gdjs.MainCode.GDSkipTutorialObjects5.length = 0;
gdjs.MainCode.GDSkipTutorialObjects6.length = 0;
gdjs.MainCode.GDSkipTutorialObjects7.length = 0;
gdjs.MainCode.GDSkipTutorialObjects8.length = 0;
gdjs.MainCode.GDSkipTutorialObjects9.length = 0;
gdjs.MainCode.GDSkipTutorialObjects10.length = 0;
gdjs.MainCode.GDCapConditionObjects1.length = 0;
gdjs.MainCode.GDCapConditionObjects2.length = 0;
gdjs.MainCode.GDCapConditionObjects3.length = 0;
gdjs.MainCode.GDCapConditionObjects4.length = 0;
gdjs.MainCode.GDCapConditionObjects5.length = 0;
gdjs.MainCode.GDCapConditionObjects6.length = 0;
gdjs.MainCode.GDCapConditionObjects7.length = 0;
gdjs.MainCode.GDCapConditionObjects8.length = 0;
gdjs.MainCode.GDCapConditionObjects9.length = 0;
gdjs.MainCode.GDCapConditionObjects10.length = 0;
gdjs.MainCode.GDRestart_9595buttonObjects1.length = 0;
gdjs.MainCode.GDRestart_9595buttonObjects2.length = 0;
gdjs.MainCode.GDRestart_9595buttonObjects3.length = 0;
gdjs.MainCode.GDRestart_9595buttonObjects4.length = 0;
gdjs.MainCode.GDRestart_9595buttonObjects5.length = 0;
gdjs.MainCode.GDRestart_9595buttonObjects6.length = 0;
gdjs.MainCode.GDRestart_9595buttonObjects7.length = 0;
gdjs.MainCode.GDRestart_9595buttonObjects8.length = 0;
gdjs.MainCode.GDRestart_9595buttonObjects9.length = 0;
gdjs.MainCode.GDRestart_9595buttonObjects10.length = 0;
gdjs.MainCode.GDMenu_9595bkgObjects1.length = 0;
gdjs.MainCode.GDMenu_9595bkgObjects2.length = 0;
gdjs.MainCode.GDMenu_9595bkgObjects3.length = 0;
gdjs.MainCode.GDMenu_9595bkgObjects4.length = 0;
gdjs.MainCode.GDMenu_9595bkgObjects5.length = 0;
gdjs.MainCode.GDMenu_9595bkgObjects6.length = 0;
gdjs.MainCode.GDMenu_9595bkgObjects7.length = 0;
gdjs.MainCode.GDMenu_9595bkgObjects8.length = 0;
gdjs.MainCode.GDMenu_9595bkgObjects9.length = 0;
gdjs.MainCode.GDMenu_9595bkgObjects10.length = 0;
gdjs.MainCode.GDPlay_9595buttonObjects1.length = 0;
gdjs.MainCode.GDPlay_9595buttonObjects2.length = 0;
gdjs.MainCode.GDPlay_9595buttonObjects3.length = 0;
gdjs.MainCode.GDPlay_9595buttonObjects4.length = 0;
gdjs.MainCode.GDPlay_9595buttonObjects5.length = 0;
gdjs.MainCode.GDPlay_9595buttonObjects6.length = 0;
gdjs.MainCode.GDPlay_9595buttonObjects7.length = 0;
gdjs.MainCode.GDPlay_9595buttonObjects8.length = 0;
gdjs.MainCode.GDPlay_9595buttonObjects9.length = 0;
gdjs.MainCode.GDPlay_9595buttonObjects10.length = 0;


return;

}

gdjs['MainCode'] = gdjs.MainCode;
